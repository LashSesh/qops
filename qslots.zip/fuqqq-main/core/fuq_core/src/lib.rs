pub mod types;
pub mod mesh;
pub mod operators;
pub mod surgery;
pub mod singularity;
pub mod quantum_bridge;

pub use types::*;
pub use mesh::*;
pub use operators::*;
pub use surgery::*;
pub use singularity::*;
pub use quantum_bridge::*;

use serde::{Deserialize, Serialize};

/// Main FUQ engine entry point
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FuqEngine {
    pub operator_family: OperatorFamily,
}

impl FuqEngine {
    pub fn new() -> Self {
        Self {
            operator_family: OperatorFamily::new(),
        }
    }

    /// Create a 5D mesh from Metatron structure and problem spec
    pub fn create_mesh(
        &self,
        structure: &metatron_core::MetatronStructure,
        problem_spec: &metatron_core::ProblemSpec,
    ) -> U5dMesh {
        create_mesh_from_structure(structure, problem_spec)
    }

    /// Run surgery loop on mesh
    pub fn run_surgery(
        &self,
        mesh: &U5dMesh,
        params: &SurgeryParams,
    ) -> SurgeryResult {
        run_surgery_loop(mesh, params, &self.operator_family)
    }

    /// Detect singularities in mesh
    pub fn detect_singularities(&self, mesh: &U5dMesh) -> Vec<Singularity> {
        detect_singularities_impl(mesh)
    }

    /// Convert singularity to algorithm spec
    pub fn quantum_bridge(
        &self,
        problem_spec: &metatron_core::ProblemSpec,
        singularity: &Singularity,
        metatron_sig: &str,
    ) -> AlgorithmSpec {
        quantum_bridge_impl(problem_spec, singularity, metatron_sig)
    }
}

impl Default for FuqEngine {
    fn default() -> Self {
        Self::new()
    }
}
