use crate::types::State5D;
use metatron_core::{MetatronStructure, ProblemSpec};
use serde::{Deserialize, Serialize};

/// 5D point cloud and triangulation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct U5dMesh {
    pub points: Vec<State5D>,
    pub simplices: Vec<Simplex5D>,
    pub boundary_flags: Vec<bool>,
    pub metadata: MeshMetadata,
}

/// A 5D simplex (6 vertices)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Simplex5D {
    pub vertices: [usize; 6],
    pub volume: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MeshMetadata {
    pub source_signature: String,
    pub num_points: usize,
    pub num_simplices: usize,
    pub bounding_radius: f64,
}

impl U5dMesh {
    pub fn new(points: Vec<State5D>) -> Self {
        let num_points = points.len();
        let simplices = Vec::new(); // Simplified: no full triangulation for MVP
        let boundary_flags = vec![false; num_points];

        let bounding_radius = points
            .iter()
            .map(|p| p.norm())
            .max_by(|a, b| a.partial_cmp(b).unwrap())
            .unwrap_or(1.0);

        Self {
            points,
            simplices,
            boundary_flags,
            metadata: MeshMetadata {
                source_signature: String::new(),
                num_points,
                num_simplices: 0,
                bounding_radius,
            },
        }
    }

    pub fn centroid(&self) -> State5D {
        if self.points.is_empty() {
            return State5D::zero();
        }

        let mut sum = State5D::zero();
        for p in &self.points {
            sum.psi += p.psi;
            sum.rho += p.rho;
            sum.omega += p.omega;
            sum.chi += p.chi;
            sum.tau += p.tau;
        }

        let n = self.points.len() as f64;
        State5D::new(
            sum.psi / n,
            sum.rho / n,
            sum.omega / n,
            sum.chi / n,
            sum.tau / n,
        )
    }
}

/// Create mesh from Metatron structure
pub fn create_mesh_from_structure(
    structure: &MetatronStructure,
    problem_spec: &ProblemSpec,
) -> U5dMesh {
    // Convert Metatron structure to 5D point cloud
    let mut points = Vec::new();

    // Use permuted adjacency to generate points
    for (i, (from, to, weight)) in structure.permuted_adjacency.iter().enumerate() {
        let t = i as f64 / structure.permuted_adjacency.len() as f64;

        // Map to 5D space using structure features
        let features = &structure.structural_features;

        let state = State5D::new(
            (from.0 as f64 / 13.0) * 2.0 * std::f64::consts::PI,
            *weight * features.connectivity_score,
            (to.0 as f64 / 13.0) * 2.0 * std::f64::consts::PI,
            features.symmetry_score * (1.0 - t),
            t * features.depth_score,
        );

        points.push(state);
    }

    // Add central points based on problem type
    let problem_type_code = match problem_spec.problem_type {
        metatron_core::ProblemType::Search => 0.0,
        metatron_core::ProblemType::CombinatorialOptimization => 1.0,
        metatron_core::ProblemType::Classification => 2.0,
        metatron_core::ProblemType::Regression => 3.0,
        metatron_core::ProblemType::Simulation => 4.0,
        metatron_core::ProblemType::Custom => 5.0,
    };

    points.push(State5D::new(
        problem_type_code,
        structure.structural_features.complexity_score,
        0.0,
        0.0,
        0.5,
    ));

    let mut mesh = U5dMesh::new(points);
    mesh.metadata.source_signature = structure.route_signature.clone();

    mesh
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mesh_creation() {
        let points = vec![
            State5D::new(0.0, 0.0, 0.0, 0.0, 0.0),
            State5D::new(1.0, 1.0, 1.0, 1.0, 1.0),
        ];

        let mesh = U5dMesh::new(points);
        assert_eq!(mesh.points.len(), 2);
    }

    #[test]
    fn test_centroid() {
        let points = vec![
            State5D::new(0.0, 0.0, 0.0, 0.0, 0.0),
            State5D::new(2.0, 2.0, 2.0, 2.0, 2.0),
        ];

        let mesh = U5dMesh::new(points);
        let centroid = mesh.centroid();

        assert!((centroid.psi - 1.0).abs() < 1e-6);
        assert!((centroid.rho - 1.0).abs() < 1e-6);
    }
}
