use crate::types::State5D;
use serde::{Deserialize, Serialize};

/// Family of FUQ operators Ω(H5)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorFamily {
    pub operators: Vec<FuqOperator>,
}

impl OperatorFamily {
    pub fn new() -> Self {
        Self {
            operators: vec![
                FuqOperator::QuaternionRotation { axis: 0, angle: 0.0 },
                FuqOperator::Damping { factor: 0.9 },
                FuqOperator::Transfer { direction: 0 },
                FuqOperator::Threshold { level: 0.5 },
                FuqOperator::Nullpoint,
            ],
        }
    }

    pub fn apply(&self, state: &State5D, op_index: usize, param: f64) -> State5D {
        let op = &self.operators[op_index % self.operators.len()];
        op.apply(state, param)
    }

    pub fn apply_sequence(&self, state: &State5D, sequence: &[usize], param: f64) -> State5D {
        let mut current = *state;
        for &op_idx in sequence {
            current = self.apply(&current, op_idx, param);
        }
        current
    }
}

impl Default for OperatorFamily {
    fn default() -> Self {
        Self::new()
    }
}

/// Individual FUQ operator types
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum FuqOperator {
    /// Quaternion-like rotation in 5D space
    QuaternionRotation { axis: u8, angle: f64 },
    /// Damping/decay operator
    Damping { factor: f64 },
    /// Transfer between dimensions
    Transfer { direction: u8 },
    /// Thresholding operator
    Threshold { level: f64 },
    /// Nullpoint operator KN (identity-like closure)
    Nullpoint,
}

impl FuqOperator {
    pub fn apply(&self, state: &State5D, param: f64) -> State5D {
        match self {
            FuqOperator::QuaternionRotation { axis, angle } => {
                apply_rotation(state, *axis, *angle + param)
            }
            FuqOperator::Damping { factor } => apply_damping(state, *factor * (1.0 + param * 0.1)),
            FuqOperator::Transfer { direction } => apply_transfer(state, *direction),
            FuqOperator::Threshold { level } => apply_threshold(state, *level),
            FuqOperator::Nullpoint => apply_nullpoint(state),
        }
    }
}

fn apply_rotation(state: &State5D, axis: u8, angle: f64) -> State5D {
    let cos_a = angle.cos();
    let sin_a = angle.sin();

    match axis % 5 {
        0 => {
            // Rotate in psi-rho plane
            State5D::new(
                state.psi * cos_a - state.rho * sin_a,
                state.psi * sin_a + state.rho * cos_a,
                state.omega,
                state.chi,
                state.tau,
            )
        }
        1 => {
            // Rotate in omega-chi plane
            State5D::new(
                state.psi,
                state.rho,
                state.omega * cos_a - state.chi * sin_a,
                state.omega * sin_a + state.chi * cos_a,
                state.tau,
            )
        }
        2 => {
            // Rotate in psi-tau plane
            State5D::new(
                state.psi * cos_a - state.tau * sin_a,
                state.rho,
                state.omega,
                state.chi,
                state.psi * sin_a + state.tau * cos_a,
            )
        }
        3 => {
            // Rotate in rho-chi plane
            State5D::new(
                state.psi,
                state.rho * cos_a - state.chi * sin_a,
                state.omega,
                state.rho * sin_a + state.chi * cos_a,
                state.tau,
            )
        }
        _ => {
            // Rotate in omega-tau plane
            State5D::new(
                state.psi,
                state.rho,
                state.omega * cos_a - state.tau * sin_a,
                state.chi,
                state.omega * sin_a + state.tau * cos_a,
            )
        }
    }
}

fn apply_damping(state: &State5D, factor: f64) -> State5D {
    State5D::new(
        state.psi * factor,
        state.rho * factor,
        state.omega * factor,
        state.chi * factor,
        state.tau * factor,
    )
}

fn apply_transfer(state: &State5D, direction: u8) -> State5D {
    match direction % 5 {
        0 => State5D::new(state.rho, state.psi, state.omega, state.chi, state.tau),
        1 => State5D::new(state.psi, state.omega, state.rho, state.chi, state.tau),
        2 => State5D::new(state.psi, state.rho, state.chi, state.omega, state.tau),
        3 => State5D::new(state.psi, state.rho, state.omega, state.tau, state.chi),
        _ => State5D::new(state.tau, state.rho, state.omega, state.chi, state.psi),
    }
}

fn apply_threshold(state: &State5D, level: f64) -> State5D {
    let threshold = |x: f64| if x.abs() > level { x } else { 0.0 };

    State5D::new(
        threshold(state.psi),
        threshold(state.rho),
        threshold(state.omega),
        threshold(state.chi),
        threshold(state.tau),
    )
}

fn apply_nullpoint(state: &State5D) -> State5D {
    // Nullpoint operator: gentle contraction toward origin
    let norm = state.norm();
    if norm < 1e-6 {
        return *state;
    }

    let factor = (1.0 - 1.0 / (1.0 + norm)).max(0.5);

    State5D::new(
        state.psi * factor,
        state.rho * factor,
        state.omega * factor,
        state.chi * factor,
        state.tau * factor,
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_operator_family() {
        let family = OperatorFamily::new();
        assert!(!family.operators.is_empty());
    }

    #[test]
    fn test_rotation() {
        let state = State5D::new(1.0, 0.0, 0.0, 0.0, 0.0);
        let rotated = apply_rotation(&state, 0, std::f64::consts::PI / 2.0);

        // Should rotate psi into rho
        assert!(rotated.psi.abs() < 1e-6);
        assert!((rotated.rho - 1.0).abs() < 1e-6);
    }

    #[test]
    fn test_damping() {
        let state = State5D::new(1.0, 1.0, 1.0, 1.0, 1.0);
        let damped = apply_damping(&state, 0.5);

        assert!((damped.psi - 0.5).abs() < 1e-6);
        assert!((damped.rho - 0.5).abs() < 1e-6);
    }
}
