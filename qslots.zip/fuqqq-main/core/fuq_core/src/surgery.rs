use crate::mesh::U5dMesh;
use crate::operators::OperatorFamily;
use serde::{Deserialize, Serialize};

/// Parameters for surgery loop
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SurgeryParams {
    pub max_iterations: usize,
    pub convergence_threshold: f64,
    pub operator_sequence: Vec<usize>,
    pub step_size: f64,
}

impl Default for SurgeryParams {
    fn default() -> Self {
        Self {
            max_iterations: 50,
            convergence_threshold: 1e-4,
            operator_sequence: vec![0, 1, 2, 3, 4],
            step_size: 0.1,
        }
    }
}

/// Result of surgery loop
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SurgeryResult {
    pub final_mesh: U5dMesh,
    pub j_evolution: Vec<f64>,
    pub convergence_flags: Vec<bool>,
    pub guard_flags: Vec<GuardFlag>,
    pub iterations_performed: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum GuardFlag {
    Normal,
    SlowConvergence,
    Oscillation,
    Divergence,
}

/// Run surgery loop on mesh
pub fn run_surgery_loop(
    mesh: &U5dMesh,
    params: &SurgeryParams,
    operators: &OperatorFamily,
) -> SurgeryResult {
    let mut current_mesh = mesh.clone();
    let mut j_evolution = Vec::new();
    let mut guard_flags = Vec::new();

    for iter in 0..params.max_iterations {
        // Compute target functional J
        let j = compute_target_functional(&current_mesh);
        j_evolution.push(j);

        // Check convergence
        if iter > 0 {
            let prev_j = j_evolution[iter - 1];
            if (j - prev_j).abs() < params.convergence_threshold {
                guard_flags.push(GuardFlag::Normal);
                break;
            }

            // Check for oscillation
            if iter > 2 {
                let j_2 = j_evolution[iter - 2];
                if (j - j_2).abs() < params.convergence_threshold * 10.0
                    && (j - prev_j).abs() > params.convergence_threshold
                {
                    guard_flags.push(GuardFlag::Oscillation);
                }
            }

            // Check for divergence
            if j > prev_j * 2.0 {
                guard_flags.push(GuardFlag::Divergence);
                break;
            }
        }

        // Apply operator sequence to all points
        current_mesh = apply_surgery_step(&current_mesh, params, operators, iter);
    }

    // Apply final nullpoint operator
    current_mesh = apply_nullpoint_closure(&current_mesh, operators);

    let iterations_performed = j_evolution.len();

    SurgeryResult {
        final_mesh: current_mesh,
        j_evolution,
        convergence_flags: vec![true; mesh.points.len()],
        guard_flags,
        iterations_performed,
    }
}

fn compute_target_functional(mesh: &U5dMesh) -> f64 {
    // Target functional J: measures mesh "quality"
    // Combination of spread, symmetry, and regularity

    if mesh.points.is_empty() {
        return 0.0;
    }

    let centroid = mesh.centroid();
    let mut total_distance = 0.0;
    let mut total_variance = 0.0;

    for point in &mesh.points {
        let dx = point.psi - centroid.psi;
        let dy = point.rho - centroid.rho;
        let dz = point.omega - centroid.omega;
        let dw = point.chi - centroid.chi;
        let dt = point.tau - centroid.tau;

        let dist = (dx * dx + dy * dy + dz * dz + dw * dw + dt * dt).sqrt();
        total_distance += dist;
        total_variance += dist * dist;
    }

    let n = mesh.points.len() as f64;
    let mean_distance = total_distance / n;
    let variance = (total_variance / n) - (mean_distance * mean_distance);

    // J combines mean distance (spread) and variance (regularity)
    mean_distance + variance.sqrt() * 0.5
}

fn apply_surgery_step(
    mesh: &U5dMesh,
    params: &SurgeryParams,
    operators: &OperatorFamily,
    iter: usize,
) -> U5dMesh {
    let mut new_points = Vec::new();

    for point in &mesh.points {
        let param = params.step_size * (1.0 + iter as f64 * 0.01);
        let new_point = operators.apply_sequence(point, &params.operator_sequence, param);
        new_points.push(new_point);
    }

    let mut new_mesh = mesh.clone();
    new_mesh.points = new_points;
    new_mesh
}

fn apply_nullpoint_closure(mesh: &U5dMesh, operators: &OperatorFamily) -> U5dMesh {
    let mut new_points = Vec::new();

    for point in &mesh.points {
        // Apply nullpoint operator (index 4 in default family)
        let closed_point = operators.apply(point, 4, 0.0);
        new_points.push(closed_point);
    }

    let mut new_mesh = mesh.clone();
    new_mesh.points = new_points;
    new_mesh
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::State5D;

    #[test]
    fn test_surgery_loop() {
        let points = vec![
            State5D::new(1.0, 0.0, 0.0, 0.0, 0.0),
            State5D::new(0.0, 1.0, 0.0, 0.0, 0.0),
            State5D::new(0.0, 0.0, 1.0, 0.0, 0.0),
        ];

        let mesh = U5dMesh::new(points);
        let params = SurgeryParams::default();
        let operators = OperatorFamily::new();

        let result = run_surgery_loop(&mesh, &params, &operators);

        assert!(!result.j_evolution.is_empty());
        assert_eq!(result.final_mesh.points.len(), mesh.points.len());
    }

    #[test]
    fn test_target_functional() {
        let points = vec![
            State5D::new(1.0, 0.0, 0.0, 0.0, 0.0),
            State5D::new(-1.0, 0.0, 0.0, 0.0, 0.0),
        ];

        let mesh = U5dMesh::new(points);
        let j = compute_target_functional(&mesh);

        assert!(j > 0.0);
    }
}
