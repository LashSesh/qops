use crate::mesh::U5dMesh;
use crate::types::State5D;
use serde::{Deserialize, Serialize};

/// A detected singularity in the 5D mesh
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Singularity {
    pub kind: SingularityKind,
    pub location: State5D,
    pub strength: f64,
    pub topological_charge: i32,
    pub spectral_signature: Vec<f64>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SingularityKind {
    Vortex,
    Saddle,
    Attractor,
    Repeller,
    Complex,
}

/// Detect singularities in the mesh
pub fn detect_singularities_impl(mesh: &U5dMesh) -> Vec<Singularity> {
    let mut singularities = Vec::new();

    if mesh.points.len() < 3 {
        return singularities;
    }

    // Look for regions of high curvature or density
    let centroid = mesh.centroid();

    // Detect central singularity
    let central_strength = compute_local_density(mesh, &centroid);
    if central_strength > 0.5 {
        singularities.push(Singularity {
            kind: SingularityKind::Attractor,
            location: centroid,
            strength: central_strength,
            topological_charge: 1,
            spectral_signature: compute_spectral_signature(mesh, &centroid),
        });
    }

    // Detect vortices (high angular momentum regions)
    for (i, point) in mesh.points.iter().enumerate() {
        if i % 7 == 0 {
            // Sample every 7th point
            let vorticity = compute_vorticity(mesh, point);
            if vorticity > 0.3 {
                singularities.push(Singularity {
                    kind: SingularityKind::Vortex,
                    location: *point,
                    strength: vorticity,
                    topological_charge: if vorticity > 0.6 { 2 } else { 1 },
                    spectral_signature: compute_spectral_signature(mesh, point),
                });
            }
        }
    }

    // Detect saddle points (regions with mixed curvature)
    if mesh.points.len() > 10 {
        for i in 0..3.min(mesh.points.len() / 5) {
            let idx = i * mesh.points.len() / 3;
            let point = &mesh.points[idx];
            let curvature_mix = compute_curvature_mix(mesh, point);

            if curvature_mix > 0.4 {
                singularities.push(Singularity {
                    kind: SingularityKind::Saddle,
                    location: *point,
                    strength: curvature_mix,
                    topological_charge: 0,
                    spectral_signature: compute_spectral_signature(mesh, point),
                });
            }
        }
    }

    singularities
}

fn compute_local_density(mesh: &U5dMesh, center: &State5D) -> f64 {
    let radius = 0.5;
    let mut count = 0;

    for point in &mesh.points {
        let dist = distance_5d(center, point);
        if dist < radius {
            count += 1;
        }
    }

    count as f64 / mesh.points.len() as f64
}

fn compute_vorticity(mesh: &U5dMesh, center: &State5D) -> f64 {
    // Measure angular momentum around this point
    let mut angular_sum = 0.0;
    let radius = 1.0;

    for point in &mesh.points {
        let dist = distance_5d(center, point);
        if dist < radius && dist > 1e-6 {
            // Compute cross product in psi-rho-omega space
            let dx = point.psi - center.psi;
            let dy = point.rho - center.rho;
            let dz = point.omega - center.omega;

            let angular = (dx * dy - dy * dx).abs() + dz.abs();
            angular_sum += angular / dist;
        }
    }

    (angular_sum / mesh.points.len() as f64).min(1.0)
}

fn compute_curvature_mix(mesh: &U5dMesh, center: &State5D) -> f64 {
    // Measure local variation in different dimensions
    let radius = 0.7;
    let mut var_psi = 0.0;
    let mut var_rho = 0.0;
    let mut var_omega = 0.0;
    let mut count = 0;

    for point in &mesh.points {
        let dist = distance_5d(center, point);
        if dist < radius {
            var_psi += (point.psi - center.psi).powi(2);
            var_rho += (point.rho - center.rho).powi(2);
            var_omega += (point.omega - center.omega).powi(2);
            count += 1;
        }
    }

    if count == 0 {
        return 0.0;
    }

    let n = count as f64;
    let v1 = var_psi / n;
    let v2 = var_rho / n;
    let v3 = var_omega / n;

    // Mix score is high when variances differ significantly
    let mean_var = (v1 + v2 + v3) / 3.0;
    if mean_var < 1e-6 {
        return 0.0;
    }

    let mix = ((v1 - mean_var).abs() + (v2 - mean_var).abs() + (v3 - mean_var).abs())
        / (3.0 * mean_var);

    mix.min(1.0)
}

fn compute_spectral_signature(mesh: &U5dMesh, center: &State5D) -> Vec<f64> {
    // Simple spectral signature: energy distribution across dimensions
    let mut signature = vec![0.0; 5];
    let radius = 0.8;
    let mut count = 0;

    for point in &mesh.points {
        let dist = distance_5d(center, point);
        if dist < radius {
            signature[0] += point.psi.abs();
            signature[1] += point.rho.abs();
            signature[2] += point.omega.abs();
            signature[3] += point.chi.abs();
            signature[4] += point.tau.abs();
            count += 1;
        }
    }

    if count > 0 {
        let n = count as f64;
        for s in &mut signature {
            *s /= n;
        }
    }

    signature
}

fn distance_5d(a: &State5D, b: &State5D) -> f64 {
    let dx = a.psi - b.psi;
    let dy = a.rho - b.rho;
    let dz = a.omega - b.omega;
    let dw = a.chi - b.chi;
    let dt = a.tau - b.tau;

    (dx * dx + dy * dy + dz * dz + dw * dw + dt * dt).sqrt()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::State5D;

    #[test]
    fn test_singularity_detection() {
        let points = vec![
            State5D::new(0.0, 0.0, 0.0, 0.0, 0.0),
            State5D::new(0.1, 0.1, 0.1, 0.1, 0.1),
            State5D::new(-0.1, -0.1, -0.1, -0.1, -0.1),
            State5D::new(1.0, 0.0, 0.0, 0.0, 0.0),
            State5D::new(0.0, 1.0, 0.0, 0.0, 0.0),
        ];

        let mesh = U5dMesh::new(points);
        let singularities = detect_singularities_impl(&mesh);

        // Should detect at least the central attractor
        assert!(!singularities.is_empty());
    }
}
