use serde::{Deserialize, Serialize};

/// Tripol - 3-dimensional state (ψ, ρ, ω)
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Tripol {
    pub psi: f64,   // Phase/wave component
    pub rho: f64,   // Density/amplitude component
    pub omega: f64, // Frequency/rotation component
}

impl Tripol {
    pub fn new(psi: f64, rho: f64, omega: f64) -> Self {
        Self { psi, rho, omega }
    }

    pub fn zero() -> Self {
        Self {
            psi: 0.0,
            rho: 0.0,
            omega: 0.0,
        }
    }

    pub fn norm(&self) -> f64 {
        (self.psi * self.psi + self.rho * self.rho + self.omega * self.omega).sqrt()
    }
}

/// State5D - 5-dimensional state extending Tripol
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct State5D {
    pub psi: f64,
    pub rho: f64,
    pub omega: f64,
    pub chi: f64,   // Curvature component
    pub tau: f64,   // Time/evolution component
}

impl State5D {
    pub fn new(psi: f64, rho: f64, omega: f64, chi: f64, tau: f64) -> Self {
        Self {
            psi,
            rho,
            omega,
            chi,
            tau,
        }
    }

    pub fn from_tripol(tripol: Tripol, chi: f64, tau: f64) -> Self {
        Self {
            psi: tripol.psi,
            rho: tripol.rho,
            omega: tripol.omega,
            chi,
            tau,
        }
    }

    pub fn zero() -> Self {
        Self {
            psi: 0.0,
            rho: 0.0,
            omega: 0.0,
            chi: 0.0,
            tau: 0.0,
        }
    }

    pub fn to_tripol(&self) -> Tripol {
        Tripol {
            psi: self.psi,
            rho: self.rho,
            omega: self.omega,
        }
    }

    pub fn norm(&self) -> f64 {
        (self.psi * self.psi
            + self.rho * self.rho
            + self.omega * self.omega
            + self.chi * self.chi
            + self.tau * self.tau)
            .sqrt()
    }
}

/// DTL (Discrete-Topological-Logic) Mode
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DTLMode {
    L0, // Discrete logic
    L1, // Topological logic
    LD, // Differential/continuous logic
}

/// Algorithm family classification
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AlgorithmFamily {
    // Original Families (8)
    GroverLikeSearch,
    QuantumWalk,
    QAOA,
    VQE,
    VQC_QML,
    BosonSamplingLike,
    MetatronResonator,
    HybridAnalogCustom,

    // Optimization Families (4)
    QUBOSolver,
    MaxCutSpecialized,
    TSPQuantum,
    PortfolioOptimization,

    // Machine Learning Families (3)
    QSVM,
    QuantumBoltzmannMachine,
    QuantumKernelMethod,

    // Chemistry/Simulation Families (3)
    HamiltonianSimulation,
    QuantumPhaseEstimation,
    LatticeSurgery,

    // Hybrid Families (3)
    QAOAAdaptive,
    VQEAnsatzZoo,
    QuantumClassicalHybridNN,

    // Exotic Families (2)
    AdiabaticQuantumComputing,
    MeasurementBasedQC,
}

impl AlgorithmFamily {
    /// Get a human-readable description of this algorithm family
    pub fn description(&self) -> &'static str {
        match self {
            // Original
            Self::GroverLikeSearch => "Grover-inspired amplitude amplification for unstructured search",
            Self::QuantumWalk => "Quantum walk on graph with oracle-based navigation",
            Self::QAOA => "Quantum Approximate Optimization Algorithm for combinatorial problems",
            Self::VQE => "Variational Quantum Eigensolver for ground state energy",
            Self::VQC_QML => "Variational Quantum Classifier for supervised learning",
            Self::BosonSamplingLike => "Gaussian Boson Sampling for specific computational tasks",
            Self::MetatronResonator => "Custom Metatron-specific resonator pattern",
            Self::HybridAnalogCustom => "Hybrid analog-digital quantum algorithm",

            // Optimization
            Self::QUBOSolver => "Specialized solver for Quadratic Unconstrained Binary Optimization",
            Self::MaxCutSpecialized => "Graph partitioning via quantum MaxCut algorithm",
            Self::TSPQuantum => "Quantum-enhanced Traveling Salesman Problem solver",
            Self::PortfolioOptimization => "Financial portfolio optimization with quantum speedup",

            // Machine Learning
            Self::QSVM => "Quantum Support Vector Machine for classification",
            Self::QuantumBoltzmannMachine => "Generative quantum model for unsupervised learning",
            Self::QuantumKernelMethod => "Quantum feature mapping for kernel-based ML",

            // Chemistry/Simulation
            Self::HamiltonianSimulation => "Trotter-based Hamiltonian evolution simulation",
            Self::QuantumPhaseEstimation => "Eigenvalue estimation via QPE algorithm",
            Self::LatticeSurgery => "Topological quantum computing via lattice surgery",

            // Hybrid
            Self::QAOAAdaptive => "QAOA with adaptive layer depth and classical optimization",
            Self::VQEAnsatzZoo => "VQE with multiple ansatz strategies",
            Self::QuantumClassicalHybridNN => "Quantum-classical hybrid neural network",

            // Exotic
            Self::AdiabaticQuantumComputing => "Adiabatic evolution for optimization",
            Self::MeasurementBasedQC => "Measurement-based quantum computation on cluster states",
        }
    }

    /// Get typical qubit range for this family
    pub fn typical_qubit_range(&self) -> (usize, usize) {
        match self {
            // Original
            Self::GroverLikeSearch => (8, 20),
            Self::QuantumWalk => (10, 25),
            Self::QAOA => (8, 30),
            Self::VQE => (4, 20),
            Self::VQC_QML => (4, 16),
            Self::BosonSamplingLike => (10, 50),
            Self::MetatronResonator => (6, 18),
            Self::HybridAnalogCustom => (10, 40),

            // Optimization
            Self::QUBOSolver => (8, 30),
            Self::MaxCutSpecialized => (10, 50),
            Self::TSPQuantum => (12, 30),
            Self::PortfolioOptimization => (8, 25),

            // Machine Learning
            Self::QSVM => (4, 16),
            Self::QuantumBoltzmannMachine => (6, 20),
            Self::QuantumKernelMethod => (4, 12),

            // Chemistry/Simulation
            Self::HamiltonianSimulation => (6, 30),
            Self::QuantumPhaseEstimation => (8, 25),
            Self::LatticeSurgery => (12, 50),

            // Hybrid
            Self::QAOAAdaptive => (8, 30),
            Self::VQEAnsatzZoo => (4, 20),
            Self::QuantumClassicalHybridNN => (6, 24),

            // Exotic
            Self::AdiabaticQuantumComputing => (10, 100),
            Self::MeasurementBasedQC => (8, 40),
        }
    }

    /// Get recommended use cases
    pub fn use_cases(&self) -> &'static str {
        match self {
            Self::GroverLikeSearch => "Database search, SAT solving, collision finding",
            Self::QuantumWalk => "Graph problems, spatial search, element distinctness",
            Self::QAOA => "MaxCut, graph coloring, scheduling, general QUBO problems",
            Self::VQE => "Molecular energies, quantum chemistry, materials science",
            Self::VQC_QML => "Classification, pattern recognition, supervised learning",
            Self::BosonSamplingLike => "Molecular vibronic spectra, graph problems",
            Self::MetatronResonator => "Custom problems with S7 symmetries",
            Self::HybridAnalogCustom => "Continuous optimization, analog simulation",

            Self::QUBOSolver => "Binary optimization, Ising models, constraint satisfaction",
            Self::MaxCutSpecialized => "Network partitioning, clustering, community detection",
            Self::TSPQuantum => "Route optimization, logistics, delivery planning",
            Self::PortfolioOptimization => "Asset allocation, risk management, financial planning",

            Self::QSVM => "Binary/multi-class classification, anomaly detection",
            Self::QuantumBoltzmannMachine => "Generative modeling, sampling, unsupervised learning",
            Self::QuantumKernelMethod => "Non-linear classification, feature learning",

            Self::HamiltonianSimulation => "Molecular dynamics, material properties, quantum systems",
            Self::QuantumPhaseEstimation => "Eigenvalue problems, Shor's algorithm, HHL",
            Self::LatticeSurgery => "Fault-tolerant quantum computing, error correction",

            Self::QAOAAdaptive => "Complex combinatorial optimization with classical co-optimization",
            Self::VQEAnsatzZoo => "Chemistry with uncertain optimal ansatz structure",
            Self::QuantumClassicalHybridNN => "Deep learning with quantum layers",

            Self::AdiabaticQuantumComputing => "Optimization via quantum annealing",
            Self::MeasurementBasedQC => "Fault-tolerant computing on cluster states",
        }
    }
}

/// Hybrid state space description
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HybridStateSpace {
    pub continuous_space: ContinuousSpace,
    pub discrete_registers: Vec<DiscreteRegister>,
    pub estimated_dimension: Option<u128>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContinuousSpace {
    pub kind: ContinuousKind,
    pub dim: u32,
    pub notes: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ContinuousKind {
    None,
    ParameterSpace,
    Geometry,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiscreteRegister {
    pub name: String,
    pub dimension: u32,
    pub role: String,
}

/// Operator specification
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorSpec {
    pub id: String,
    pub role: OperatorRole,
    pub parametrization: String,
    pub composition: CompositionType,
    pub notes: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum OperatorRole {
    Cost,
    Mixer,
    WalkKernel,
    Oracle,
    AnsatzLayer,
    Regularizer,
    RouterSymmetry,
    Custom,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CompositionType {
    Single,
    TensorProduct,
    Sum,
    ProductSequence,
}

/// Spectral goal for the algorithm
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpectralGoal {
    pub pattern: SpectralPattern,
    pub target_gap: Option<f64>,
    pub notes: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SpectralPattern {
    TwoLevel,
    UniqueGroundState,
    BandStructure,
    Custom,
}

/// Scorpio synchronization schedule (for analog/continuous evolution)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScorpioSyncSchedule {
    pub delta_theta: f64,
    pub num_cycles: u32,
    pub windows: Vec<ScheduleWindow>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScheduleWindow {
    pub phase_center: f64,
    pub width: f64,
    pub operator_id: String,
}

/// Feedback configuration (Seraphic calibration)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FeedbackConfig {
    pub alpha_spec: f64,
    pub alpha_struct: f64,
    pub alpha_reg: f64,
    pub max_iterations: u32,
    pub max_recursion_depth: u32,
}

impl Default for FeedbackConfig {
    fn default() -> Self {
        Self {
            alpha_spec: 0.1,
            alpha_struct: 0.05,
            alpha_reg: 0.01,
            max_iterations: 100,
            max_recursion_depth: 5,
        }
    }
}

/// Complete algorithm specification
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AlgorithmSpec {
    pub id: String,
    pub name: String,
    pub description: String,
    pub problem_spec: metatron_core::ProblemSpec,
    pub family: AlgorithmFamily,
    pub tripol: Tripol,
    pub state5d: State5D,
    pub dtl_mode: DTLMode,
    pub state_space: HybridStateSpace,
    pub operators: Vec<OperatorSpec>,
    pub spectral_goal: SpectralGoal,
    pub schedule: Option<ScorpioSyncSchedule>,
    pub feedback: FeedbackConfig,
    pub metatron_signature: String,
    pub fuq_metadata: String,
    pub seraphic_hint: String,
    pub notes_for_user: String,
}

/// Algorithm scoring
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AlgorithmScore {
    pub quality_score: f64,
    pub robustness_score: f64,
    pub novelty_score: f64,
    pub family_match_score: f64,
    pub estimated_cost: f64,
    pub label: ScoreLabel,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ScoreLabel {
    Miss,
    Okay,
    Good,
    Jackpot,
}

impl AlgorithmScore {
    pub fn compute_label(&mut self) {
        let total = (self.quality_score
            + self.robustness_score
            + self.novelty_score
            + self.family_match_score)
            / 4.0;

        self.label = if total >= 0.8 {
            ScoreLabel::Jackpot
        } else if total >= 0.6 {
            ScoreLabel::Good
        } else if total >= 0.4 {
            ScoreLabel::Okay
        } else {
            ScoreLabel::Miss
        };
    }
}
