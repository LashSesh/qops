use crate::singularity::{Singularity, SingularityKind};
use crate::types::*;
use metatron_core::ProblemSpec;
use uuid::Uuid;

/// Convert a singularity and problem spec into an AlgorithmSpec
pub fn quantum_bridge_impl(
    problem_spec: &ProblemSpec,
    singularity: &Singularity,
    metatron_sig: &str,
) -> AlgorithmSpec {
    // Determine algorithm family based on problem type and singularity
    let family = select_algorithm_family(problem_spec, singularity);

    // Extract Tripol and State5D from singularity location
    let state5d = singularity.location;
    let tripol = state5d.to_tripol();

    // Determine DTL mode
    let dtl_mode = select_dtl_mode(problem_spec, singularity);

    // Construct state space
    let state_space = construct_state_space(problem_spec, &family, singularity);

    // Generate operators
    let operators = generate_operators(&family, singularity);

    // Set spectral goal
    let spectral_goal = determine_spectral_goal(&family, singularity);

    // Optional schedule for analog/hybrid families
    let schedule = if matches!(
        family,
        AlgorithmFamily::HybridAnalogCustom | AlgorithmFamily::MetatronResonator
    ) {
        Some(generate_schedule(singularity))
    } else {
        None
    };

    // Feedback config
    let feedback = FeedbackConfig {
        alpha_spec: 0.1 * singularity.strength,
        alpha_struct: 0.05,
        alpha_reg: 0.01,
        max_iterations: 100,
        max_recursion_depth: (singularity.topological_charge.abs() as u32 + 3).min(10),
    };

    // Generate metadata and notes
    let fuq_metadata = format!(
        "Singularity: {:?}, Strength: {:.3}, Charge: {}",
        singularity.kind, singularity.strength, singularity.topological_charge
    );

    let seraphic_hint = generate_seraphic_hint(singularity);
    let notes_for_user = generate_user_notes(problem_spec, &family, singularity);

    let name = format!("{:?} Candidate", family);
    let description = format!(
        "Quantum algorithm template for {} derived from {:?} singularity",
        problem_spec.problem_type as u8, singularity.kind
    );

    AlgorithmSpec {
        id: Uuid::new_v4().to_string(),
        name,
        description,
        problem_spec: problem_spec.clone(),
        family,
        tripol,
        state5d,
        dtl_mode,
        state_space,
        operators,
        spectral_goal,
        schedule,
        feedback,
        metatron_signature: metatron_sig.to_string(),
        fuq_metadata,
        seraphic_hint,
        notes_for_user,
    }
}

fn select_algorithm_family(
    problem_spec: &ProblemSpec,
    singularity: &Singularity,
) -> AlgorithmFamily {
    use metatron_core::ProblemType;

    // Analyze problem text for specific keywords
    let text_lower = problem_spec.raw_text.to_lowercase();
    let has_graph = text_lower.contains("graph") || text_lower.contains("network");
    let has_tsp = text_lower.contains("traveling") || text_lower.contains("salesman") || text_lower.contains("route");
    let has_maxcut = text_lower.contains("maxcut") || text_lower.contains("partition") || text_lower.contains("cut");
    let has_portfolio = text_lower.contains("portfolio") || text_lower.contains("asset") || text_lower.contains("finance");
    let has_chemistry = text_lower.contains("molecul") || text_lower.contains("chemical") || text_lower.contains("hamiltonian");
    let has_svm = text_lower.contains("svm") || text_lower.contains("classification") || text_lower.contains("kernel");
    let has_energy = text_lower.contains("energy") || text_lower.contains("eigenvalue") || text_lower.contains("ground state");

    match problem_spec.problem_type {
        ProblemType::Search => {
            // Search problems: Grover or QuantumWalk
            if singularity.topological_charge > 0 {
                AlgorithmFamily::GroverLikeSearch
            } else {
                AlgorithmFamily::QuantumWalk
            }
        }

        ProblemType::CombinatorialOptimization => {
            // Differentiate based on problem characteristics
            if has_maxcut {
                AlgorithmFamily::MaxCutSpecialized
            } else if has_tsp {
                AlgorithmFamily::TSPQuantum
            } else if has_portfolio {
                AlgorithmFamily::PortfolioOptimization
            } else if has_graph && singularity.strength > 0.7 {
                AlgorithmFamily::QUBOSolver
            } else if singularity.strength > 0.6 && singularity.topological_charge.abs() > 1 {
                // Complex optimization → Adaptive QAOA
                AlgorithmFamily::QAOAAdaptive
            } else if singularity.strength > 0.6 {
                // High strength → standard QAOA
                AlgorithmFamily::QAOA
            } else if matches!(singularity.kind, SingularityKind::Attractor) {
                // Attractor structure → VQE-style
                AlgorithmFamily::VQE
            } else {
                // Default: QUBO solver
                AlgorithmFamily::QUBOSolver
            }
        }

        ProblemType::Classification => {
            // ML Classification
            if has_svm || singularity.strength > 0.7 {
                AlgorithmFamily::QSVM
            } else if matches!(singularity.kind, SingularityKind::Complex) {
                AlgorithmFamily::QuantumClassicalHybridNN
            } else if singularity.topological_charge.abs() > 1 {
                AlgorithmFamily::QuantumKernelMethod
            } else {
                AlgorithmFamily::VQC_QML
            }
        }

        ProblemType::Regression => {
            // ML Regression
            if singularity.strength > 0.65 {
                AlgorithmFamily::QuantumKernelMethod
            } else if matches!(singularity.kind, SingularityKind::Complex) {
                AlgorithmFamily::QuantumClassicalHybridNN
            } else {
                AlgorithmFamily::VQC_QML
            }
        }

        ProblemType::Simulation => {
            // Quantum simulation
            if has_chemistry || has_energy {
                if has_energy && singularity.topological_charge > 0 {
                    AlgorithmFamily::QuantumPhaseEstimation
                } else if singularity.strength > 0.6 {
                    AlgorithmFamily::VQEAnsatzZoo
                } else {
                    AlgorithmFamily::HamiltonianSimulation
                }
            } else if matches!(singularity.kind, SingularityKind::Vortex) {
                AlgorithmFamily::MetatronResonator
            } else if singularity.topological_charge.abs() > 2 {
                // High topological charge → exotic methods
                AlgorithmFamily::LatticeSurgery
            } else if matches!(singularity.kind, SingularityKind::Attractor) && singularity.strength > 0.7 {
                // Strong attractor → adiabatic
                AlgorithmFamily::AdiabaticQuantumComputing
            } else {
                AlgorithmFamily::HybridAnalogCustom
            }
        }

        ProblemType::Custom => {
            // Custom problems: choose based on singularity characteristics
            if singularity.topological_charge.abs() > 2 {
                AlgorithmFamily::MetatronResonator
            } else if matches!(singularity.kind, SingularityKind::Complex) {
                if singularity.strength > 0.7 {
                    AlgorithmFamily::MeasurementBasedQC
                } else {
                    AlgorithmFamily::QuantumBoltzmannMachine
                }
            } else if singularity.strength > 0.65 {
                AlgorithmFamily::AdiabaticQuantumComputing
            } else {
                AlgorithmFamily::HybridAnalogCustom
            }
        }
    }
}

fn select_dtl_mode(_problem_spec: &ProblemSpec, singularity: &Singularity) -> DTLMode {
    match singularity.kind {
        SingularityKind::Vortex | SingularityKind::Complex => DTLMode::L1,
        SingularityKind::Attractor | SingularityKind::Repeller => DTLMode::LD,
        SingularityKind::Saddle => DTLMode::L0,
    }
}

fn construct_state_space(
    problem_spec: &ProblemSpec,
    family: &AlgorithmFamily,
    singularity: &Singularity,
) -> HybridStateSpace {
    let (cont_kind, cont_dim) = match family {
        // Original
        AlgorithmFamily::GroverLikeSearch => (ContinuousKind::None, 0),
        AlgorithmFamily::QuantumWalk => (ContinuousKind::Geometry, 2),
        AlgorithmFamily::QAOA | AlgorithmFamily::VQE => (ContinuousKind::ParameterSpace, 10),
        AlgorithmFamily::VQC_QML => (ContinuousKind::ParameterSpace, 20),
        AlgorithmFamily::BosonSamplingLike => (ContinuousKind::None, 0),
        AlgorithmFamily::MetatronResonator => (ContinuousKind::Geometry, 5),
        AlgorithmFamily::HybridAnalogCustom => (ContinuousKind::Geometry, 3),

        // Optimization
        AlgorithmFamily::QUBOSolver => (ContinuousKind::ParameterSpace, 8),
        AlgorithmFamily::MaxCutSpecialized => (ContinuousKind::ParameterSpace, 12),
        AlgorithmFamily::TSPQuantum => (ContinuousKind::ParameterSpace, 15),
        AlgorithmFamily::PortfolioOptimization => (ContinuousKind::ParameterSpace, 10),

        // Machine Learning
        AlgorithmFamily::QSVM => (ContinuousKind::ParameterSpace, 16),
        AlgorithmFamily::QuantumBoltzmannMachine => (ContinuousKind::ParameterSpace, 12),
        AlgorithmFamily::QuantumKernelMethod => (ContinuousKind::ParameterSpace, 8),

        // Chemistry/Simulation
        AlgorithmFamily::HamiltonianSimulation => (ContinuousKind::Geometry, 10),
        AlgorithmFamily::QuantumPhaseEstimation => (ContinuousKind::None, 0),
        AlgorithmFamily::LatticeSurgery => (ContinuousKind::Geometry, 15),

        // Hybrid
        AlgorithmFamily::QAOAAdaptive => (ContinuousKind::ParameterSpace, 20),
        AlgorithmFamily::VQEAnsatzZoo => (ContinuousKind::ParameterSpace, 25),
        AlgorithmFamily::QuantumClassicalHybridNN => (ContinuousKind::ParameterSpace, 30),

        // Exotic
        AlgorithmFamily::AdiabaticQuantumComputing => (ContinuousKind::Geometry, 5),
        AlgorithmFamily::MeasurementBasedQC => (ContinuousKind::Geometry, 8),
    };

    let continuous_space = ContinuousSpace {
        kind: cont_kind,
        dim: cont_dim,
        notes: format!("Derived from {:?} singularity", singularity.kind),
    };

    // Estimate qubit count from problem description
    let qubit_estimate = estimate_qubit_count(problem_spec, singularity);

    let discrete_registers = vec![
        DiscreteRegister {
            name: "main".to_string(),
            dimension: qubit_estimate,
            role: "Primary computational register".to_string(),
        },
        DiscreteRegister {
            name: "ancilla".to_string(),
            dimension: (qubit_estimate / 4).max(1),
            role: "Ancillary qubits for operations".to_string(),
        },
    ];

    let estimated_dimension = Some(2u128.pow(qubit_estimate));

    HybridStateSpace {
        continuous_space,
        discrete_registers,
        estimated_dimension,
    }
}

fn estimate_qubit_count(problem_spec: &ProblemSpec, singularity: &Singularity) -> u32 {
    use metatron_core::ProblemType;

    let base = match problem_spec.problem_type {
        ProblemType::Search => 10,
        ProblemType::CombinatorialOptimization => 12,
        ProblemType::Classification => 8,
        ProblemType::Regression => 8,
        ProblemType::Simulation => 15,
        ProblemType::Custom => 10,
    };

    let modifier = (singularity.strength * 5.0) as u32;
    (base + modifier).min(30)
}

fn generate_operators(family: &AlgorithmFamily, singularity: &Singularity) -> Vec<OperatorSpec> {
    let mut operators = Vec::new();

    match family {
        // Original Families
        AlgorithmFamily::GroverLikeSearch => {
            operators.push(OperatorSpec {
                id: "oracle".to_string(),
                role: OperatorRole::Oracle,
                parametrization: "Problem-specific marking oracle".to_string(),
                composition: CompositionType::Single,
                notes: "Marks solution states".to_string(),
            });
            operators.push(OperatorSpec {
                id: "diffusion".to_string(),
                role: OperatorRole::Mixer,
                parametrization: "Grover diffusion operator".to_string(),
                composition: CompositionType::Single,
                notes: "Amplitude amplification".to_string(),
            });
        }

        AlgorithmFamily::QAOA => {
            let depth = singularity.topological_charge.abs() + 1;
            operators.push(OperatorSpec {
                id: "cost_hamiltonian".to_string(),
                role: OperatorRole::Cost,
                parametrization: format!("γ ∈ [0, 2π], depth p={}", depth),
                composition: CompositionType::ProductSequence,
                notes: "Problem Hamiltonian".to_string(),
            });
            operators.push(OperatorSpec {
                id: "mixer_hamiltonian".to_string(),
                role: OperatorRole::Mixer,
                parametrization: format!("β ∈ [0, π], depth p={}", depth),
                composition: CompositionType::ProductSequence,
                notes: "Transverse field mixer".to_string(),
            });
        }

        AlgorithmFamily::VQE | AlgorithmFamily::VQC_QML => {
            let depth = 3 + (singularity.strength * 3.0) as usize;
            for layer in 0..depth {
                operators.push(OperatorSpec {
                    id: format!("ansatz_layer_{}", layer),
                    role: OperatorRole::AnsatzLayer,
                    parametrization: format!("Rotation angles θ_{}", layer),
                    composition: CompositionType::TensorProduct,
                    notes: format!("Variational layer {}", layer),
                });
            }
        }

        AlgorithmFamily::QuantumWalk => {
            operators.push(OperatorSpec {
                id: "walk_kernel".to_string(),
                role: OperatorRole::WalkKernel,
                parametrization: "Graph adjacency based".to_string(),
                composition: CompositionType::Sum,
                notes: "Quantum walk evolution".to_string(),
            });
        }

        AlgorithmFamily::MetatronResonator => {
            operators.push(OperatorSpec {
                id: "s7_router".to_string(),
                role: OperatorRole::RouterSymmetry,
                parametrization: "S7 permutation symmetries".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Metatron symmetry routing".to_string(),
            });
        }

        AlgorithmFamily::BosonSamplingLike => {
            operators.push(OperatorSpec {
                id: "gaussian_transformation".to_string(),
                role: OperatorRole::Custom,
                parametrization: "Linear optics network".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Gaussian boson sampling circuit".to_string(),
            });
        }

        AlgorithmFamily::HybridAnalogCustom => {
            operators.push(OperatorSpec {
                id: "analog_evolution".to_string(),
                role: OperatorRole::Custom,
                parametrization: "Continuous-time Hamiltonian".to_string(),
                composition: CompositionType::Single,
                notes: "Analog quantum evolution".to_string(),
            });
        }

        // Optimization Families
        AlgorithmFamily::QUBOSolver => {
            operators.push(OperatorSpec {
                id: "qubo_cost".to_string(),
                role: OperatorRole::Cost,
                parametrization: "Ising model encoding".to_string(),
                composition: CompositionType::Sum,
                notes: "QUBO cost function".to_string(),
            });
            operators.push(OperatorSpec {
                id: "x_mixer".to_string(),
                role: OperatorRole::Mixer,
                parametrization: "Transverse field X-basis".to_string(),
                composition: CompositionType::Sum,
                notes: "Standard X mixer".to_string(),
            });
        }

        AlgorithmFamily::MaxCutSpecialized => {
            operators.push(OperatorSpec {
                id: "maxcut_hamiltonian".to_string(),
                role: OperatorRole::Cost,
                parametrization: "Edge-weight based".to_string(),
                composition: CompositionType::Sum,
                notes: "MaxCut problem Hamiltonian".to_string(),
            });
            operators.push(OperatorSpec {
                id: "partition_mixer".to_string(),
                role: OperatorRole::Mixer,
                parametrization: "Graph partition preserving".to_string(),
                composition: CompositionType::Sum,
                notes: "Constrained mixer for partitions".to_string(),
            });
        }

        AlgorithmFamily::TSPQuantum => {
            operators.push(OperatorSpec {
                id: "route_cost".to_string(),
                role: OperatorRole::Cost,
                parametrization: "Distance matrix encoding".to_string(),
                composition: CompositionType::Sum,
                notes: "TSP tour cost".to_string(),
            });
            operators.push(OperatorSpec {
                id: "swap_mixer".to_string(),
                role: OperatorRole::Mixer,
                parametrization: "City swap operations".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Permutation-preserving mixer".to_string(),
            });
        }

        AlgorithmFamily::PortfolioOptimization => {
            operators.push(OperatorSpec {
                id: "portfolio_cost".to_string(),
                role: OperatorRole::Cost,
                parametrization: "Risk-return objective".to_string(),
                composition: CompositionType::Sum,
                notes: "Portfolio cost function".to_string(),
            });
            operators.push(OperatorSpec {
                id: "asset_mixer".to_string(),
                role: OperatorRole::Mixer,
                parametrization: "Asset selection mixer".to_string(),
                composition: CompositionType::Sum,
                notes: "Portfolio rebalancing".to_string(),
            });
        }

        // Machine Learning Families
        AlgorithmFamily::QSVM => {
            operators.push(OperatorSpec {
                id: "feature_map".to_string(),
                role: OperatorRole::AnsatzLayer,
                parametrization: "ZZ-feature map".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Quantum feature embedding".to_string(),
            });
            operators.push(OperatorSpec {
                id: "kernel_measurement".to_string(),
                role: OperatorRole::Custom,
                parametrization: "Swap test based".to_string(),
                composition: CompositionType::Single,
                notes: "Kernel estimation circuit".to_string(),
            });
        }

        AlgorithmFamily::QuantumBoltzmannMachine => {
            operators.push(OperatorSpec {
                id: "visible_layer".to_string(),
                role: OperatorRole::AnsatzLayer,
                parametrization: "Visible unit interactions".to_string(),
                composition: CompositionType::Sum,
                notes: "Observable layer".to_string(),
            });
            operators.push(OperatorSpec {
                id: "hidden_layer".to_string(),
                role: OperatorRole::AnsatzLayer,
                parametrization: "Hidden unit interactions".to_string(),
                composition: CompositionType::Sum,
                notes: "Latent representation".to_string(),
            });
        }

        AlgorithmFamily::QuantumKernelMethod => {
            operators.push(OperatorSpec {
                id: "data_encoding".to_string(),
                role: OperatorRole::AnsatzLayer,
                parametrization: "Amplitude encoding".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Classical data encoding".to_string(),
            });
            operators.push(OperatorSpec {
                id: "kernel_feature_map".to_string(),
                role: OperatorRole::AnsatzLayer,
                parametrization: "Parameterized feature map".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Quantum kernel transformation".to_string(),
            });
        }

        // Chemistry/Simulation Families
        AlgorithmFamily::HamiltonianSimulation => {
            operators.push(OperatorSpec {
                id: "trotter_step".to_string(),
                role: OperatorRole::Custom,
                parametrization: "Product formula, Suzuki-Trotter".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Time evolution step".to_string(),
            });
        }

        AlgorithmFamily::QuantumPhaseEstimation => {
            operators.push(OperatorSpec {
                id: "controlled_unitary".to_string(),
                role: OperatorRole::Custom,
                parametrization: "Controlled-U^(2^k)".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Phase kickback circuit".to_string(),
            });
            operators.push(OperatorSpec {
                id: "inverse_qft".to_string(),
                role: OperatorRole::Custom,
                parametrization: "Quantum Fourier Transform".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Phase readout".to_string(),
            });
        }

        AlgorithmFamily::LatticeSurgery => {
            operators.push(OperatorSpec {
                id: "surface_code_patch".to_string(),
                role: OperatorRole::Custom,
                parametrization: "Stabilizer measurements".to_string(),
                composition: CompositionType::TensorProduct,
                notes: "Topological code patch".to_string(),
            });
            operators.push(OperatorSpec {
                id: "lattice_merge".to_string(),
                role: OperatorRole::Custom,
                parametrization: "Patch merge operations".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Logical gate via surgery".to_string(),
            });
        }

        // Hybrid Families
        AlgorithmFamily::QAOAAdaptive => {
            let depth = 2 + (singularity.strength * 5.0) as usize;
            for layer in 0..depth {
                operators.push(OperatorSpec {
                    id: format!("adaptive_cost_{}", layer),
                    role: OperatorRole::Cost,
                    parametrization: format!("γ_{} (layer-dependent)", layer),
                    composition: CompositionType::ProductSequence,
                    notes: format!("Adaptive layer {} cost", layer),
                });
                operators.push(OperatorSpec {
                    id: format!("adaptive_mixer_{}", layer),
                    role: OperatorRole::Mixer,
                    parametrization: format!("β_{} (layer-dependent)", layer),
                    composition: CompositionType::ProductSequence,
                    notes: format!("Adaptive layer {} mixer", layer),
                });
            }
        }

        AlgorithmFamily::VQEAnsatzZoo => {
            // Multiple ansatz strategies
            let strategies = vec!["Hardware-efficient", "UCCSD", "k-UpCCGSD"];
            for (i, strategy) in strategies.iter().enumerate() {
                operators.push(OperatorSpec {
                    id: format!("ansatz_{}", i),
                    role: OperatorRole::AnsatzLayer,
                    parametrization: format!("{} parametrization", strategy),
                    composition: CompositionType::ProductSequence,
                    notes: format!("{} ansatz", strategy),
                });
            }
        }

        AlgorithmFamily::QuantumClassicalHybridNN => {
            operators.push(OperatorSpec {
                id: "quantum_layer".to_string(),
                role: OperatorRole::AnsatzLayer,
                parametrization: "Variational quantum circuit".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Quantum neural network layer".to_string(),
            });
            operators.push(OperatorSpec {
                id: "measurement_readout".to_string(),
                role: OperatorRole::Custom,
                parametrization: "Expectation value readout".to_string(),
                composition: CompositionType::Single,
                notes: "Quantum-to-classical interface".to_string(),
            });
        }

        // Exotic Families
        AlgorithmFamily::AdiabaticQuantumComputing => {
            operators.push(OperatorSpec {
                id: "initial_hamiltonian".to_string(),
                role: OperatorRole::Mixer,
                parametrization: "Easy ground state".to_string(),
                composition: CompositionType::Sum,
                notes: "Starting Hamiltonian".to_string(),
            });
            operators.push(OperatorSpec {
                id: "problem_hamiltonian".to_string(),
                role: OperatorRole::Cost,
                parametrization: "Problem encoding".to_string(),
                composition: CompositionType::Sum,
                notes: "Target Hamiltonian".to_string(),
            });
            operators.push(OperatorSpec {
                id: "adiabatic_schedule".to_string(),
                role: OperatorRole::Custom,
                parametrization: "H(t) = (1-s(t))H_0 + s(t)H_p".to_string(),
                composition: CompositionType::Single,
                notes: "Time-dependent interpolation".to_string(),
            });
        }

        AlgorithmFamily::MeasurementBasedQC => {
            operators.push(OperatorSpec {
                id: "cluster_state_prep".to_string(),
                role: OperatorRole::Custom,
                parametrization: "Graph state generation".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Resource state preparation".to_string(),
            });
            operators.push(OperatorSpec {
                id: "adaptive_measurements".to_string(),
                role: OperatorRole::Custom,
                parametrization: "Measurement pattern".to_string(),
                composition: CompositionType::ProductSequence,
                notes: "Computation via measurement".to_string(),
            });
        }
    }

    // Add regularizer for complex singularities
    if singularity.topological_charge.abs() > 1 {
        operators.push(OperatorSpec {
            id: "regularizer".to_string(),
            role: OperatorRole::Regularizer,
            parametrization: "λ = 0.01".to_string(),
            composition: CompositionType::Sum,
            notes: "Stabilization term".to_string(),
        });
    }

    operators
}

fn determine_spectral_goal(family: &AlgorithmFamily, singularity: &Singularity) -> SpectralGoal {
    let pattern = match family {
        // Original
        AlgorithmFamily::GroverLikeSearch => SpectralPattern::TwoLevel,
        AlgorithmFamily::QAOA | AlgorithmFamily::VQE => SpectralPattern::UniqueGroundState,
        AlgorithmFamily::VQC_QML => SpectralPattern::Custom,
        AlgorithmFamily::QuantumWalk => SpectralPattern::BandStructure,
        AlgorithmFamily::BosonSamplingLike => SpectralPattern::Custom,
        AlgorithmFamily::MetatronResonator => SpectralPattern::Custom,
        AlgorithmFamily::HybridAnalogCustom => SpectralPattern::Custom,

        // Optimization
        AlgorithmFamily::QUBOSolver => SpectralPattern::UniqueGroundState,
        AlgorithmFamily::MaxCutSpecialized => SpectralPattern::UniqueGroundState,
        AlgorithmFamily::TSPQuantum => SpectralPattern::UniqueGroundState,
        AlgorithmFamily::PortfolioOptimization => SpectralPattern::UniqueGroundState,

        // Machine Learning
        AlgorithmFamily::QSVM => SpectralPattern::Custom,
        AlgorithmFamily::QuantumBoltzmannMachine => SpectralPattern::BandStructure,
        AlgorithmFamily::QuantumKernelMethod => SpectralPattern::Custom,

        // Chemistry/Simulation
        AlgorithmFamily::HamiltonianSimulation => SpectralPattern::BandStructure,
        AlgorithmFamily::QuantumPhaseEstimation => SpectralPattern::TwoLevel,
        AlgorithmFamily::LatticeSurgery => SpectralPattern::Custom,

        // Hybrid
        AlgorithmFamily::QAOAAdaptive => SpectralPattern::UniqueGroundState,
        AlgorithmFamily::VQEAnsatzZoo => SpectralPattern::UniqueGroundState,
        AlgorithmFamily::QuantumClassicalHybridNN => SpectralPattern::Custom,

        // Exotic
        AlgorithmFamily::AdiabaticQuantumComputing => SpectralPattern::UniqueGroundState,
        AlgorithmFamily::MeasurementBasedQC => SpectralPattern::Custom,
    };

    let target_gap = Some(0.1 * singularity.strength);

    SpectralGoal {
        pattern,
        target_gap,
        notes: format!("Based on {:?} singularity", singularity.kind),
    }
}

fn generate_schedule(singularity: &Singularity) -> ScorpioSyncSchedule {
    let num_cycles = (10.0 * singularity.strength) as u32 + 5;
    let delta_theta = 2.0 * std::f64::consts::PI / num_cycles as f64;

    let mut windows = Vec::new();
    for i in 0..num_cycles.min(5) {
        let phase = i as f64 * delta_theta;
        windows.push(ScheduleWindow {
            phase_center: phase,
            width: delta_theta * 0.8,
            operator_id: format!("op_{}", i),
        });
    }

    ScorpioSyncSchedule {
        delta_theta,
        num_cycles,
        windows,
    }
}

fn generate_seraphic_hint(singularity: &Singularity) -> String {
    match singularity.kind {
        SingularityKind::Attractor => {
            "Strong convergence expected. Consider gradient-based optimization.".to_string()
        }
        SingularityKind::Vortex => {
            "Rotational structure detected. Exploit angular momentum conservation.".to_string()
        }
        SingularityKind::Saddle => {
            "Mixed curvature. May need careful initialization or basin hopping.".to_string()
        }
        SingularityKind::Repeller => {
            "Divergent region. Consider inverse dynamics or barrier methods.".to_string()
        }
        SingularityKind::Complex => {
            "High-order structure. Deep parametrization recommended.".to_string()
        }
    }
}

fn generate_user_notes(
    problem_spec: &ProblemSpec,
    family: &AlgorithmFamily,
    singularity: &Singularity,
) -> String {
    format!(
        "This {:?} template is designed for your {} problem. \
        The algorithm exploits a {:?} structure with strength {:.2}. \
        Expected to work well with problems of similar topological character.",
        family,
        format!("{:?}", problem_spec.problem_type).to_lowercase(),
        singularity.kind,
        singularity.strength
    )
}
