use crate::graph::MetatronGraph;
use crate::types::{MetatronRoute, NodeId, S7Permutation};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// A concrete structure derived from a MetatronRoute
/// This represents the "wiring" or "layout" after applying the route transformations
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetatronStructure {
    pub route_signature: String,
    pub node_mapping: HashMap<NodeId, NodeId>,
    pub permuted_adjacency: Vec<(NodeId, NodeId, f64)>,
    pub structural_features: StructuralFeatures,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StructuralFeatures {
    pub symmetry_score: f64,
    pub connectivity_score: f64,
    pub depth_score: f64,
    pub complexity_score: f64,
}

/// Convert a MetatronRoute to a MetatronStructure
pub fn route_to_structure_impl(
    graph: &MetatronGraph,
    route: &MetatronRoute,
) -> MetatronStructure {
    let final_perm = route.final_permutation();

    // Create node mapping based on final permutation
    // Map the first 7 nodes using the permutation, rest stay fixed
    let mut node_mapping = HashMap::new();
    for i in 0..13u8 {
        if i < 7 {
            let mapped = NodeId::new(final_perm.elements[i as usize]);
            node_mapping.insert(NodeId::new(i), mapped);
        } else {
            node_mapping.insert(NodeId::new(i), NodeId::new(i));
        }
    }

    // Compute permuted adjacency
    let permuted_adjacency = compute_permuted_adjacency(graph, &node_mapping);

    // Compute structural features
    let structural_features = compute_structural_features(route, &permuted_adjacency);

    MetatronStructure {
        route_signature: route.signature.clone(),
        node_mapping,
        permuted_adjacency,
        structural_features,
    }
}

fn compute_permuted_adjacency(
    graph: &MetatronGraph,
    node_mapping: &HashMap<NodeId, NodeId>,
) -> Vec<(NodeId, NodeId, f64)> {
    let mut adjacency = Vec::new();

    for edge in &graph.edges {
        let from_mapped = node_mapping.get(&edge.from).unwrap_or(&edge.from);
        let to_mapped = node_mapping.get(&edge.to).unwrap_or(&edge.to);

        adjacency.push((*from_mapped, *to_mapped, edge.weight));
    }

    adjacency
}

fn compute_structural_features(
    route: &MetatronRoute,
    permuted_adjacency: &[(NodeId, NodeId, f64)],
) -> StructuralFeatures {
    // Symmetry score: how "balanced" is the permutation
    let symmetry_score = compute_symmetry_score(route.final_permutation());

    // Connectivity score: average edge weight after permutation
    let connectivity_score = if !permuted_adjacency.is_empty() {
        permuted_adjacency.iter().map(|(_, _, w)| w).sum::<f64>()
            / permuted_adjacency.len() as f64
    } else {
        0.0
    };

    // Depth score: based on route length
    let depth_score = (route.moves.len() as f64 / 10.0).min(1.0);

    // Complexity score: combination of all factors
    let complexity_score = (symmetry_score + connectivity_score + depth_score) / 3.0;

    StructuralFeatures {
        symmetry_score,
        connectivity_score,
        depth_score,
        complexity_score,
    }
}

fn compute_symmetry_score(perm: &S7Permutation) -> f64 {
    // Count fixed points and cycles
    let mut fixed_points = 0;
    let mut visited = [false; 7];
    let mut cycle_count = 0;

    for i in 0..7 {
        if perm.elements[i] == i as u8 {
            fixed_points += 1;
        }

        if !visited[i] {
            let mut current = i;
            let mut cycle_length = 0;

            while !visited[current] {
                visited[current] = true;
                current = perm.elements[current] as usize;
                cycle_length += 1;
            }

            if cycle_length > 1 {
                cycle_count += 1;
            }
        }
    }

    // Higher score for more structure (either fixed points or clean cycles)
    let fixed_score = fixed_points as f64 / 7.0;
    let cycle_score = cycle_count as f64 / 3.0;

    (fixed_score + cycle_score) / 2.0
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::MetatronRoute;

    #[test]
    fn test_route_to_structure() {
        let graph = MetatronGraph::new();
        let route = MetatronRoute::new();

        let structure = route_to_structure_impl(&graph, &route);

        assert!(!structure.route_signature.is_empty());
        assert_eq!(structure.node_mapping.len(), 13);
        assert!(structure.structural_features.symmetry_score >= 0.0);
        assert!(structure.structural_features.symmetry_score <= 1.0);
    }
}
