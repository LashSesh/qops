use crate::types::{MetatronMove, MetatronRoute};
use crate::{MetatronModel, ProblemSpec, ProblemType};
use rand::Rng;
use rand::distributions::WeightedIndex;
use rand::prelude::*;

/// Sample a MetatronRoute based on problem specification
/// This implements "postsymbolic cognition" - routes are meaning-preserving
/// transformations rather than random shuffles
pub fn sample_route_impl<R: Rng>(
    _model: &MetatronModel,
    problem_spec: &ProblemSpec,
    rng: &mut R,
) -> MetatronRoute {
    let mut route = MetatronRoute::new();

    // Determine route length based on problem type
    let route_length = match problem_spec.problem_type {
        ProblemType::Search => 3 + rng.gen_range(0..3),
        ProblemType::CombinatorialOptimization => 5 + rng.gen_range(0..5),
        ProblemType::Classification => 2 + rng.gen_range(0..2),
        ProblemType::Regression => 2 + rng.gen_range(0..2),
        ProblemType::Simulation => 4 + rng.gen_range(0..4),
        ProblemType::Custom => 3 + rng.gen_range(0..5),
    };

    // Generate moves based on problem characteristics
    for i in 0..route_length {
        let move_type = choose_move_type(problem_spec, i, route_length, rng);
        route.add_move(move_type);
    }

    // Generate signature
    route.signature = generate_signature(&route);

    route
}

fn choose_move_type<R: Rng>(
    _problem_spec: &ProblemSpec,
    step: usize,
    total_steps: usize,
    rng: &mut R,
) -> MetatronMove {
    // Use problem characteristics to bias move selection
    let progress = step as f64 / total_steps as f64;

    // Early steps: more Inversions and Mirrors (structure setup)
    // Middle steps: Rotations (exploration)
    // Late steps: Conversions (refinement)

    let choice: f64 = rng.gen();

    if progress < 0.3 {
        // Early: Inversion or Mirror
        if choice < 0.5 {
            MetatronMove::Invert {
                axis: rng.gen_range(0..7),
            }
        } else {
            MetatronMove::Mirror {
                plane: rng.gen_range(0..7),
            }
        }
    } else if progress < 0.7 {
        // Middle: Rotation
        MetatronMove::Rotate {
            axis: rng.gen_range(0..7),
            angle: rng.gen_range(-3..4),
        }
    } else {
        // Late: Conversion or Rotation
        if choice < 0.6 {
            MetatronMove::Convert {
                phase: rng.gen_range(0..7),
            }
        } else {
            MetatronMove::Rotate {
                axis: rng.gen_range(0..7),
                angle: rng.gen_range(-2..3),
            }
        }
    }
}

fn generate_signature(route: &MetatronRoute) -> String {
    let final_perm = route.final_permutation();
    format!(
        "M{}_P{:?}",
        route.moves.len(),
        &final_perm.elements[..3]
    )
}

/// Routing bias for adaptive learning
#[derive(Debug, Clone)]
pub struct RoutingBias {
    /// Probability weights for move types [Invert, Rotate, Mirror, Convert]
    pub move_type_weights: [f64; 4],

    /// Preferred route lengths
    pub preferred_length_mean: f64,
    pub preferred_length_std: f64,

    /// Axis preferences (for S7 operations)
    pub axis_weights: [f64; 7],
}

/// Sample a route with bias from Seraphic Calibration
pub fn sample_route_biased<R: Rng>(
    _model: &MetatronModel,
    problem_spec: &ProblemSpec,
    bias: &RoutingBias,
    rng: &mut R,
) -> MetatronRoute {
    let mut route = MetatronRoute::new();

    // Use biased route length (normal distribution around preferred length)
    let base_length = match problem_spec.problem_type {
        ProblemType::Search => 3 + rng.gen_range(0..3),
        ProblemType::CombinatorialOptimization => 5 + rng.gen_range(0..5),
        ProblemType::Classification => 2 + rng.gen_range(0..2),
        ProblemType::Regression => 2 + rng.gen_range(0..2),
        ProblemType::Simulation => 4 + rng.gen_range(0..4),
        ProblemType::Custom => 3 + rng.gen_range(0..5),
    };

    // Apply bias to route length
    let route_length = if bias.preferred_length_mean > 1.0 {
        // Sample from normal distribution
        let offset: f64 = rng.gen_range(-1.0..1.0) * bias.preferred_length_std;
        let biased_length = (bias.preferred_length_mean + offset).round() as usize;
        biased_length.max(1).min(20) // Clamp to reasonable range
    } else {
        base_length
    };

    // Generate moves using weighted move type selection
    for _ in 0..route_length {
        let move_type = choose_move_type_biased(bias, rng);
        route.add_move(move_type);
    }

    // Generate signature
    route.signature = generate_signature(&route);

    route
}

fn choose_move_type_biased<R: Rng>(
    bias: &RoutingBias,
    rng: &mut R,
) -> MetatronMove {
    // Normalize weights to ensure they sum to 1.0
    let total: f64 = bias.move_type_weights.iter().sum();
    let normalized_weights: Vec<f64> = if total > 0.0 {
        bias.move_type_weights.iter().map(|w| w / total).collect()
    } else {
        vec![0.25, 0.25, 0.25, 0.25]
    };

    // Sample move type using weights
    let dist = WeightedIndex::new(&normalized_weights).unwrap();
    let move_type_idx = dist.sample(rng);

    // Sample axis using axis weights
    let axis_total: f64 = bias.axis_weights.iter().sum();
    let axis_dist = if axis_total > 0.0 {
        WeightedIndex::new(&bias.axis_weights).unwrap()
    } else {
        WeightedIndex::new(&[1.0/7.0; 7]).unwrap()
    };
    let axis = axis_dist.sample(rng);

    match move_type_idx {
        0 => MetatronMove::Invert { axis: axis as u8 },
        1 => MetatronMove::Rotate {
            axis: axis as u8,
            angle: rng.gen_range(-3..4)
        },
        2 => MetatronMove::Mirror { plane: axis as u8 },
        3 => MetatronMove::Convert { phase: axis as u8 },
        _ => unreachable!(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{ProblemType, SolutionQuality};

    #[test]
    fn test_sample_route() {
        let model = MetatronModel::new();
        let mut rng = rand::thread_rng();

        let problem_spec = ProblemSpec {
            id: String::from("test"),
            raw_text: String::from("test problem"),
            problem_type: ProblemType::Search,
            input_structure: String::new(),
            objective_description: String::new(),
            constraints: Vec::new(),
            solution_quality: SolutionQuality {
                target_accuracy: None,
                target_gap: None,
                resource_budget: None,
            },
        };

        let route = model.sample_route(&problem_spec, &mut rng);
        assert!(!route.moves.is_empty());
        assert!(!route.signature.is_empty());
    }
}
