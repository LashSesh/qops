use crate::types::S7Permutation;
use serde::{Deserialize, Serialize};

/// Configuration for S7 symmetric group operations
/// Based on Metatron_TripolarQSO.pdf S7 symmetries
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct S7Config {
    pub generators: Vec<S7Permutation>,
    pub max_composition_depth: usize,
}

impl S7Config {
    pub fn new() -> Self {
        Self {
            generators: Self::create_generators(),
            max_composition_depth: 5,
        }
    }

    /// Create basic generators for S7
    /// We use standard generators: transpositions and cycles
    fn create_generators() -> Vec<S7Permutation> {
        vec![
            // Adjacent transpositions
            S7Permutation { elements: [1, 0, 2, 3, 4, 5, 6] },
            S7Permutation { elements: [0, 2, 1, 3, 4, 5, 6] },
            S7Permutation { elements: [0, 1, 3, 2, 4, 5, 6] },
            S7Permutation { elements: [0, 1, 2, 4, 3, 5, 6] },
            S7Permutation { elements: [0, 1, 2, 3, 5, 4, 6] },
            S7Permutation { elements: [0, 1, 2, 3, 4, 6, 5] },
            // 7-cycle
            S7Permutation { elements: [1, 2, 3, 4, 5, 6, 0] },
            // Reflection-like permutation
            S7Permutation { elements: [6, 5, 4, 3, 2, 1, 0] },
        ]
    }

    pub fn get_generator(&self, index: usize) -> &S7Permutation {
        &self.generators[index % self.generators.len()]
    }

    pub fn generator_count(&self) -> usize {
        self.generators.len()
    }
}

impl Default for S7Config {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_s7_config() {
        let config = S7Config::new();
        assert!(config.generator_count() > 0);
        assert_eq!(config.max_composition_depth, 5);
    }

    #[test]
    fn test_permutation_composition() {
        let p1 = S7Permutation { elements: [1, 0, 2, 3, 4, 5, 6] };
        let p2 = S7Permutation { elements: [0, 2, 1, 3, 4, 5, 6] };
        let composed = p1.compose(&p2);

        // Should produce a different permutation
        assert_ne!(composed, p1);
        assert_ne!(composed, p2);
    }

    #[test]
    fn test_permutation_inverse() {
        let p = S7Permutation { elements: [1, 2, 3, 4, 5, 6, 0] };
        let inv = p.inverse();
        let identity = p.compose(&inv);

        assert_eq!(identity.elements, [0, 1, 2, 3, 4, 5, 6]);
    }
}
