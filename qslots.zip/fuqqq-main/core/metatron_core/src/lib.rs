pub mod types;
pub mod graph;
pub mod s7;
pub mod routing;
pub mod structure;

pub use types::*;
pub use graph::*;
pub use s7::*;
pub use routing::*;
pub use structure::*;

use rand::Rng;
use serde::{Deserialize, Serialize};

/// Main entry point for Metatron QSO layer
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetatronModel {
    pub graph: MetatronGraph,
    pub s7_config: S7Config,
}

impl MetatronModel {
    pub fn new() -> Self {
        Self {
            graph: MetatronGraph::new(),
            s7_config: S7Config::new(),
        }
    }

    /// Sample a route based on problem specification
    pub fn sample_route<R: Rng>(
        &self,
        problem_spec: &ProblemSpec,
        rng: &mut R,
    ) -> MetatronRoute {
        sample_route_impl(self, problem_spec, rng)
    }

    /// Convert route to structure
    pub fn route_to_structure(&self, route: &MetatronRoute) -> MetatronStructure {
        route_to_structure_impl(&self.graph, route)
    }
}

impl Default for MetatronModel {
    fn default() -> Self {
        Self::new()
    }
}

/// Load the Metatron model (for now, just creates a new one)
pub fn load_metatron_model() -> MetatronModel {
    MetatronModel::new()
}

/// Problem specification types (simplified version for metatron_core)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProblemSpec {
    pub id: String,
    pub raw_text: String,
    pub problem_type: ProblemType,
    pub input_structure: String,
    pub objective_description: String,
    pub constraints: Vec<String>,
    pub solution_quality: SolutionQuality,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum ProblemType {
    Search,
    CombinatorialOptimization,
    Classification,
    Regression,
    Simulation,
    Custom,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SolutionQuality {
    pub target_accuracy: Option<f64>,
    pub target_gap: Option<f64>,
    pub resource_budget: Option<String>,
}
