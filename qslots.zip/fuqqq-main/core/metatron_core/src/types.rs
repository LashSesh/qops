use serde::{Deserialize, Serialize};

/// Core Metatron types

/// A node in the Metatron H13 graph
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct NodeId(pub u8);

impl NodeId {
    pub fn new(id: u8) -> Self {
        assert!(id < 13, "NodeId must be < 13 for H13 graph");
        Self(id)
    }

    pub fn as_usize(&self) -> usize {
        self.0 as usize
    }
}

/// An edge in the Metatron graph
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Edge {
    pub from: NodeId,
    pub to: NodeId,
    pub weight: f64,
}

/// S7 permutation represented as array of 7 elements
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct S7Permutation {
    pub elements: [u8; 7],
}

impl S7Permutation {
    /// Identity permutation
    pub fn identity() -> Self {
        Self {
            elements: [0, 1, 2, 3, 4, 5, 6],
        }
    }

    /// Compose two permutations
    pub fn compose(&self, other: &S7Permutation) -> S7Permutation {
        let mut result = [0u8; 7];
        for i in 0..7 {
            result[i] = self.elements[other.elements[i] as usize];
        }
        S7Permutation { elements: result }
    }

    /// Inverse of this permutation
    pub fn inverse(&self) -> S7Permutation {
        let mut result = [0u8; 7];
        for i in 0..7 {
            result[self.elements[i] as usize] = i as u8;
        }
        S7Permutation { elements: result }
    }

    /// Apply permutation to a value
    pub fn apply(&self, i: usize) -> usize {
        assert!(i < 7);
        self.elements[i] as usize
    }
}

/// A move in the Metatron Cube (like a Rubik's cube move)
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum MetatronMove {
    /// Inversion (flip)
    Invert { axis: u8 },
    /// Rotation
    Rotate { axis: u8, angle: i8 },
    /// Mirror
    Mirror { plane: u8 },
    /// Conversion (phase shift)
    Convert { phase: u8 },
}

/// A route through the Metatron structure
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetatronRoute {
    pub moves: Vec<MetatronMove>,
    pub permutations: Vec<S7Permutation>,
    pub signature: String,
}

impl MetatronRoute {
    pub fn new() -> Self {
        Self {
            moves: Vec::new(),
            permutations: vec![S7Permutation::identity()],
            signature: String::from("identity"),
        }
    }

    pub fn add_move(&mut self, m: MetatronMove) {
        self.moves.push(m);
        // Convert move to permutation and compose
        let perm = move_to_permutation(m);
        let last = self.permutations.last().unwrap();
        let new_perm = last.compose(&perm);
        self.permutations.push(new_perm);
    }

    pub fn final_permutation(&self) -> &S7Permutation {
        self.permutations.last().unwrap()
    }
}

impl Default for MetatronRoute {
    fn default() -> Self {
        Self::new()
    }
}

/// Convert a MetatronMove to an S7 permutation
fn move_to_permutation(m: MetatronMove) -> S7Permutation {
    match m {
        MetatronMove::Invert { axis } => {
            // Swap two elements based on axis - now uses full range for 21 unique swaps
            let mut perm = S7Permutation::identity();
            let a = (axis % 7) as usize;
            let b = ((axis / 7) % 6) as usize;
            // Ensure b != a by offsetting
            let b = if b >= a { (b + 1) % 7 } else { b };
            perm.elements.swap(a, b);
            perm
        }
        MetatronMove::Rotate { axis, angle } => {
            // Partial cyclic rotation - axis determines which subset to rotate
            let mut perm = S7Permutation::identity();
            let start = (axis % 7) as usize;
            let len = 3 + (axis / 7) as usize % 4; // Rotate 3-6 elements
            let steps = ((angle % 7 + 7) % 7) as usize;

            if steps > 0 {
                // Rotate only elements in range [start, start+len) (wrapping)
                let indices: Vec<usize> = (0..len).map(|i| (start + i) % 7).collect();
                let values: Vec<u8> = indices.iter().map(|&i| perm.elements[i]).collect();
                for (i, &idx) in indices.iter().enumerate() {
                    perm.elements[idx] = values[(i + steps) % len];
                }
            }
            perm
        }
        MetatronMove::Mirror { plane } => {
            // Reflection - swap element at plane with its mirror position
            let mut perm = S7Permutation::identity();
            let p = (plane % 7) as usize;
            let mirror = 6 - p; // Mirror around center
            if p != mirror {
                perm.elements.swap(p, mirror);
            }
            perm
        }
        MetatronMove::Convert { phase } => {
            // Phase shift rotation - full cyclic rotation
            let mut perm = S7Permutation::identity();
            let shift = (phase % 7) as usize;
            for i in 0..7 {
                perm.elements[i] = ((i + shift) % 7) as u8;
            }
            perm
        }
    }
}
