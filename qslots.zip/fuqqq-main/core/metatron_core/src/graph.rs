use crate::types::{Edge, NodeId};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// The Metatron H13 graph with 13 nodes and 78 edges
/// Based on Cube_Zoom.pdf and Metatron_TripolarQSO.pdf
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetatronGraph {
    pub nodes: Vec<NodeId>,
    pub edges: Vec<Edge>,
    pub adjacency: HashMap<NodeId, Vec<NodeId>>,
}

impl MetatronGraph {
    pub fn new() -> Self {
        let nodes: Vec<NodeId> = (0..13).map(NodeId::new).collect();
        let edges = Self::create_edges();
        let adjacency = Self::build_adjacency(&edges);

        Self {
            nodes,
            edges,
            adjacency,
        }
    }

    /// Create the 78 edges of the Metatron Cube
    /// This is a simplified model based on the theoretical structure:
    /// - Central node (0) connects to all others (12 edges)
    /// - Inner hexagon nodes (1-6) form a cycle (6 edges)
    /// - Outer hexagon nodes (7-12) form a cycle (6 edges)
    /// - Inner to outer connections (6*6 = 36 edges)
    /// - Additional structural edges (18 edges)
    /// Total: 12 + 6 + 6 + 36 + 18 = 78 edges
    fn create_edges() -> Vec<Edge> {
        let mut edges = Vec::new();

        // Central node (0) to all others (12 edges)
        for i in 1..13 {
            edges.push(Edge {
                from: NodeId::new(0),
                to: NodeId::new(i),
                weight: 1.0,
            });
        }

        // Inner hexagon (1-6) cycle
        for i in 1..7 {
            let next = if i == 6 { 1 } else { i + 1 };
            edges.push(Edge {
                from: NodeId::new(i),
                to: NodeId::new(next),
                weight: 0.866, // cos(30°) for hexagon
            });
        }

        // Outer hexagon (7-12) cycle
        for i in 7..13 {
            let next = if i == 12 { 7 } else { i + 1 };
            edges.push(Edge {
                from: NodeId::new(i),
                to: NodeId::new(next),
                weight: 0.866,
            });
        }

        // Inner to outer connections (each inner node to 6 outer nodes)
        for i in 1..7 {
            for j in 7..13 {
                edges.push(Edge {
                    from: NodeId::new(i),
                    to: NodeId::new(j),
                    weight: 0.5,
                });
            }
        }

        // Additional structural edges (diagonals and cross-connections)
        // Inner hexagon diagonals
        for i in 1..7 {
            let opp = ((i - 1 + 3) % 6) + 1;
            edges.push(Edge {
                from: NodeId::new(i),
                to: NodeId::new(opp),
                weight: 0.7,
            });
        }

        // Outer hexagon diagonals
        for i in 7..13 {
            let opp = ((i - 7 + 3) % 6) + 7;
            edges.push(Edge {
                from: NodeId::new(i),
                to: NodeId::new(opp),
                weight: 0.7,
            });
        }

        edges
    }

    fn build_adjacency(edges: &[Edge]) -> HashMap<NodeId, Vec<NodeId>> {
        let mut adj: HashMap<NodeId, Vec<NodeId>> = HashMap::new();

        for edge in edges {
            adj.entry(edge.from).or_insert_with(Vec::new).push(edge.to);
            // Make graph undirected
            adj.entry(edge.to).or_insert_with(Vec::new).push(edge.from);
        }

        adj
    }

    pub fn neighbors(&self, node: NodeId) -> &[NodeId] {
        self.adjacency.get(&node).map(|v| v.as_slice()).unwrap_or(&[])
    }

    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }

    pub fn edge_count(&self) -> usize {
        self.edges.len()
    }
}

impl Default for MetatronGraph {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_metatron_graph_structure() {
        let graph = MetatronGraph::new();
        assert_eq!(graph.node_count(), 13);
        assert_eq!(graph.edge_count(), 78);

        // Central node should connect to all others
        let central_neighbors = graph.neighbors(NodeId::new(0));
        assert!(central_neighbors.len() >= 12);
    }
}
