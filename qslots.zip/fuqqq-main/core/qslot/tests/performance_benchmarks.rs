use qslot::{ParallelSlotEngine, QSlotEngine};
use std::time::Instant;

#[test]
fn test_sequential_performance() {
    let mut engine = QSlotEngine::new();

    let problem = "Find shortest path in a graph with 10 nodes";

    let start = Instant::now();
    let result = engine.design_algorithm_batch(problem, 5, 1);
    let duration = start.elapsed();

    assert!(result.is_ok());
    println!(
        "Sequential: 5 candidates in {:?} (avg: {:?}/candidate)",
        duration,
        duration / 5
    );
}

#[test]
fn test_parallel_performance() {
    let engine = ParallelSlotEngine::with_threads(4);

    let problem = "Find shortest path in a graph with 10 nodes";

    let start = Instant::now();
    let result = engine.design_algorithm_batch(problem, 5, 1);
    let duration = start.elapsed();

    assert!(result.is_ok());
    println!(
        "Parallel: 5 candidates in {:?} (avg: {:?}/candidate)",
        duration,
        duration / 5
    );
}

#[test]
fn test_cache_effectiveness() {
    let engine = ParallelSlotEngine::with_threads(2);

    let problem = "Optimize delivery routes for 100 trucks";

    // First batch - cold cache
    let start = Instant::now();
    let result1 = engine.design_algorithm_batch(problem, 10, 1);
    let cold_duration = start.elapsed();

    assert!(result1.is_ok());
    let stats1 = engine.cache_statistics();

    println!("Cold cache: {:?} for 10 candidates", cold_duration);
    println!("Cache stats after first batch: {:?}", stats1);

    // Second batch - warm cache (same problem type, different seed)
    let start = Instant::now();
    let result2 = engine.design_algorithm_batch(problem, 10, 2);
    let warm_duration = start.elapsed();

    assert!(result2.is_ok());
    let stats2 = engine.cache_statistics();

    println!("Warm cache: {:?} for 10 candidates", warm_duration);
    println!("Cache stats after second batch: {:?}", stats2);

    // Cache should have improved performance
    println!(
        "Speedup: {:.2}x",
        cold_duration.as_secs_f64() / warm_duration.as_secs_f64()
    );

    // We should see cache queries
    assert!(stats2.total_queries > stats1.total_queries);
}

#[test]
fn test_parallel_throughput() {
    let engine = ParallelSlotEngine::with_threads(4);

    let problem = "Solve traveling salesman problem with 20 cities";

    let start = Instant::now();
    let result = engine.design_algorithm_batch(problem, 20, 1);
    let duration = start.elapsed();

    assert!(result.is_ok());
    let result = result.unwrap();

    println!(
        "Parallel throughput: {} candidates in {:?} ({:.2} candidates/sec)",
        result.total_candidates,
        duration,
        result.total_candidates as f64 / duration.as_secs_f64()
    );

    // Should complete in reasonable time with parallelism
    // (exact time depends on hardware)
    assert!(duration.as_secs() < 60);
}

#[test]
fn test_cache_hit_rate() {
    let engine = ParallelSlotEngine::with_threads(2);

    let problem = "Search for optimal configuration";

    // Generate several batches with the same problem
    for i in 0..5 {
        engine.design_algorithm_batch(problem, 5, i).unwrap();
    }

    let stats = engine.cache_statistics();
    println!("Cache statistics after 25 candidates:");
    println!("  Total queries: {}", stats.total_queries);
    println!("  Score hits: {}", stats.score_hits);
    println!("  Score misses: {}", stats.score_misses);
    println!("  Overall hit rate: {:.1}%", stats.hit_rate() * 100.0);
    println!("  Score hit rate: {:.1}%", stats.score_hit_rate() * 100.0);

    // We should see some cache activity
    assert!(stats.total_queries > 0);
}

#[test]
fn test_seraphic_learning_with_parallelism() {
    let engine = ParallelSlotEngine::with_threads(2);

    let problem = "Find optimal tour through cities";

    // Generate several batches to accumulate experience
    for i in 0..3 {
        engine.design_algorithm_batch(problem, 5, i).unwrap();
    }

    // Seraphic should have accumulated experience
    let stats = engine.calibration_stats();
    println!("Seraphic stats after 15 candidates:");
    println!("  Total experiences: {}", stats.total_experiences);
    println!("  Quality trend: {:.3}", engine.quality_trend());

    assert!(stats.total_experiences > 0);
}

#[test]
fn test_sequential_cache_integration() {
    let mut engine = QSlotEngine::new();

    let problem = "Optimize factory scheduling";

    // First batch
    engine.design_algorithm_batch(problem, 5, 1).unwrap();
    let stats1 = engine.cache_statistics();

    println!("After first batch: {:?}", stats1);

    // Second batch
    engine.design_algorithm_batch(problem, 5, 2).unwrap();
    let stats2 = engine.cache_statistics();

    println!("After second batch: {:?}", stats2);

    // Cache should be growing
    assert!(stats2.total_queries >= stats1.total_queries);
}
