use qslot::{MetricsCollector, ParallelSlotEngine, QSlotEngine};
use std::sync::Arc;
use std::thread;
use std::time::Duration;

/// Stress test: Generate large number of algorithms
#[test]
fn test_large_batch_generation() {
    let engine = ParallelSlotEngine::with_threads(4);

    let problem = "Optimize complex supply chain with 1000 nodes";

    // Generate large batch
    let result = engine.design_algorithm_batch(problem, 50, 1);

    assert!(result.is_ok());
    let batch_result = result.unwrap();

    println!("Generated {} algorithms", batch_result.batch.candidates.len());
    println!("Cache hits: {}", batch_result.cache_hits);

    assert!(batch_result.batch.candidates.len() > 0);
}

/// Stress test: Sequential generation stress
#[test]
fn test_sequential_stress() {
    let mut engine = QSlotEngine::new();

    let problem = "Find optimal configuration for distributed system";

    // Generate many batches sequentially
    for i in 0..20 {
        let result = engine.design_algorithm_batch(problem, 5, i);

        assert!(result.is_ok(), "Batch {} failed", i);
    }

    println!("Successfully completed 20 sequential batches");

    // Check accumulated state
    let stats = engine.get_calibration_stats();
    println!("Seraphic stats: {:?}", stats);
    assert!(stats.total_experiences > 0);
}

/// Stress test: Parallel stress with multiple threads
#[test]
fn test_parallel_stress() {
    let engine = Arc::new(ParallelSlotEngine::with_threads(8));
    let num_threads = 10;
    let batches_per_thread = 5;

    let mut handles = vec![];

    for thread_id in 0..num_threads {
        let engine_clone = Arc::clone(&engine);

        let handle = thread::spawn(move || {
            let problem = format!("Optimize system configuration variant {}", thread_id);

            for batch_id in 0..batches_per_thread {
                let result = engine_clone.design_algorithm_batch(
                    &problem,
                    3,
                    (thread_id * batches_per_thread + batch_id) as u64,
                );

                assert!(
                    result.is_ok(),
                    "Thread {} batch {} failed",
                    thread_id,
                    batch_id
                );
            }
        });

        handles.push(handle);
    }

    // Wait for all threads
    for handle in handles {
        handle.join().unwrap();
    }

    println!(
        "Successfully completed {} batches across {} threads",
        num_threads * batches_per_thread,
        num_threads
    );

    let cache_stats = engine.cache_statistics();
    println!("Cache stats: {:?}", cache_stats);
}

/// Stress test: Memory stability with cache limits
#[test]
fn test_cache_memory_stability() {
    let engine = ParallelSlotEngine::with_threads(4);

    // Generate many batches to test cache LRU eviction
    for i in 0..100 {
        let problem = format!("Problem variant {}", i);
        let result = engine.design_algorithm_batch(&problem, 3, i);

        assert!(result.is_ok());
    }

    let cache_stats = engine.cache_statistics();
    println!("Cache stats after 100 batches: {:?}", cache_stats);

    // Cache should have bounded size (LRU eviction working)
    let (route_size, algo_size, score_size) = cache_stats.sizes();
    println!(
        "Cache sizes: routes={}, algorithms={}, scores={}",
        route_size, algo_size, score_size
    );

    // Should not grow unbounded
    assert!(score_size <= 200); // Max cache size
}

/// Stress test: Long-running session
#[test]
#[ignore] // Slow test - run with --ignored flag
fn test_long_running_session() {
    let mut engine = QSlotEngine::new();
    let metrics = Arc::new(MetricsCollector::new());

    let problems = vec![
        "Optimize delivery routes",
        "Schedule manufacturing tasks",
        "Allocate network bandwidth",
        "Configure load balancers",
        "Manage database sharding",
    ];

    let duration = Duration::from_secs(60); // 1 minute stress test
    let start = std::time::Instant::now();
    let mut iteration = 0;

    while start.elapsed() < duration {
        let problem = &problems[iteration % problems.len()];

        let _timer = metrics.start_timer("batch_generation");
        let result = engine.design_algorithm_batch(problem, 5, iteration as u64);

        assert!(result.is_ok(), "Iteration {} failed", iteration);

        iteration += 1;

        if iteration % 10 == 0 {
            println!("Completed {} iterations...", iteration);
        }
    }

    println!("Stress test completed: {} iterations in {:?}", iteration, start.elapsed());

    let snapshot = metrics.snapshot();
    println!("Metrics: {:?}", snapshot);

    // Should have no errors
    assert_eq!(snapshot.total_errors, 0);
}

/// Stress test: Rapid repeated access
#[test]
fn test_rapid_repeated_access() {
    let engine = ParallelSlotEngine::with_threads(4);

    let problem = "Find shortest path in large graph";

    // Rapidly generate many small batches
    for i in 0..50 {
        let result = engine.design_algorithm_batch(problem, 2, i);
        assert!(result.is_ok());
    }

    println!("Successfully completed 50 rapid batches");

    let stats = engine.cache_statistics();
    println!("Cache hit rate: {:.1}%", stats.hit_rate() * 100.0);

    // Should see cache hits due to repeated problem
    assert!(stats.total_queries > 0);
}

/// Stress test: Circuit breaker under failures
#[test]
fn test_circuit_breaker_stress() {
    use qslot::{ErrorRecoveryManager, QSlotError, RecoveryResult};

    let mut recovery = ErrorRecoveryManager::new();
    let mut failure_count = 0;

    // Simulate many consecutive failures
    for i in 0..10 {
        let result = recovery.execute_with_recovery(
            || {
                failure_count += 1;
                Err(QSlotError::GenerationError("simulated failure".to_string()))
            },
            "algorithm_generation",
        );

        match result {
            RecoveryResult::CircuitOpen => {
                println!("Circuit breaker opened at iteration {}", i);
                break;
            }
            RecoveryResult::Failed { .. } => {
                println!("Attempt {} failed", i);
            }
            RecoveryResult::Success(_) => {
                panic!("Should not succeed");
            }
        }

        // Small delay between failures
        thread::sleep(Duration::from_millis(10));
    }

    println!("Total failures before circuit break: {}", failure_count);

    // Circuit breaker should have opened
    assert!(failure_count <= 20); // Should break before exhausting all iterations
}

/// Stress test: Memory leak detection
#[test]
fn test_memory_leak_detection() {
    use std::sync::Arc;

    let engine = Arc::new(ParallelSlotEngine::with_threads(4));

    // Generate many batches and ensure no memory leaks
    for i in 0..50 {
        let problem = format!("Problem {}", i % 10);

        let result = engine.design_algorithm_batch(&problem, 3, i);
        assert!(result.is_ok());

        // Occasionally clear cache to test cleanup
        if i % 20 == 0 {
            engine.clear_cache();
        }
    }

    println!("Memory leak test completed successfully");
}

/// Stress test: Error recovery under stress
#[test]
fn test_error_recovery_stress() {
    use qslot::{ErrorRecoveryManager, QSlotError, RecoveryResult};

    let mut recovery = ErrorRecoveryManager::new();
    let mut successes = 0;
    let mut failures = 0;

    // Simulate intermittent failures
    for i in 0..50 {
        let mut attempt = 0;

        let result = recovery.execute_with_recovery(
            || {
                attempt += 1;
                // Fail first 2 attempts, succeed on 3rd
                if attempt < 3 {
                    Err(QSlotError::GenerationError("transient error".to_string()))
                } else {
                    Ok(i)
                }
            },
            "algorithm_generation",
        );

        match result {
            RecoveryResult::Success(_) => successes += 1,
            RecoveryResult::Failed { .. } => failures += 1,
            RecoveryResult::CircuitOpen => {
                println!("Circuit opened at iteration {}", i);
                break;
            }
        }

        // Small delay
        thread::sleep(Duration::from_millis(5));
    }

    println!("Successes: {}, Failures: {}", successes, failures);

    // Most should succeed with retries
    assert!(successes > failures);
}

/// Stress test: Persistence under heavy load
#[test]
fn test_persistence_stress() {
    use tempfile::tempdir;

    let temp_dir = tempdir().unwrap();
    let db_path = temp_dir.path().join("stress.db");

    let mut engine = QSlotEngine::with_persistence(&db_path).unwrap();

    // Generate many batches with persistence
    for i in 0..30 {
        let problem = format!("Optimization problem variant {}", i % 5);

        let result = engine.design_algorithm_batch(&problem, 4, i);
        assert!(result.is_ok(), "Batch {} failed", i);

        // Periodically save state
        if i % 10 == 0 {
            assert!(engine.save_seraphic_state().is_ok());
        }
    }

    let db_stats = engine.get_database_stats();
    assert!(db_stats.is_some());

    let stats = db_stats.unwrap();
    println!("Database stats: {:?}", stats);

    assert!(stats.total_spins > 0);
    assert!(stats.total_sessions > 0);
}

/// Stress test: Input validation stress
#[test]
fn test_input_validation_stress() {
    use qslot::InputValidator;

    let validator = InputValidator::new();

    // Test many inputs rapidly
    for i in 0..1000 {
        let input = format!(
            "Optimize system configuration with {} parameters and {} constraints",
            i % 100,
            i % 50
        );

        let result = validator.validate_input(&input);
        assert!(result.is_valid);

        let sanitized = validator.sanitize_input(&input);
        assert!(!sanitized.is_empty());
    }

    println!("Successfully validated 1000 inputs");
}

/// Stress test: Metrics collection under load
#[test]
fn test_metrics_collection_stress() {
    use std::sync::Arc;

    let metrics = Arc::new(MetricsCollector::new());
    let num_threads = 10;

    let mut handles = vec![];

    for thread_id in 0..num_threads {
        let metrics_clone = Arc::clone(&metrics);

        let handle = thread::spawn(move || {
            for i in 0..100 {
                let op_name = format!("operation_{}", thread_id);

                let _timer = metrics_clone.start_timer(&op_name);
                thread::sleep(Duration::from_micros(100 + i as u64));
            }
        });

        handles.push(handle);
    }

    for handle in handles {
        handle.join().unwrap();
    }

    let snapshot = metrics.snapshot();
    println!("Metrics snapshot: {:?}", snapshot);

    assert_eq!(snapshot.total_operations, 1000);
}

/// Stress test: System stability under varied loads
#[test]
fn test_varied_load_stability() {
    let engine = ParallelSlotEngine::with_threads(4);

    let loads = vec![1, 5, 10, 20, 10, 5, 1]; // Vary the load

    for (i, &load) in loads.iter().enumerate() {
        let problem = format!("Problem with load {}", load);

        let result = engine.design_algorithm_batch(&problem, load, i as u64);
        assert!(result.is_ok(), "Failed at load {}", load);

        println!("Completed batch with load {}", load);
    }

    println!("Varied load stability test completed");
}
