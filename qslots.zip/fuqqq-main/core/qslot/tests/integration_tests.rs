use qslot::{
    ErrorRecoveryManager, InputValidator, MetricsCollector, ParallelSlotEngine, QSlotEngine,
    QSlotError, RecoveryResult,
};
use std::sync::Arc;
use std::time::Duration;

/// Integration test: Full pipeline from problem description to algorithm generation
#[test]
fn test_end_to_end_algorithm_generation() {
    let mut engine = QSlotEngine::new();
    let validator = InputValidator::new();

    let problem = "Find the shortest path in a weighted directed graph with 100 nodes and 500 edges";

    // Validate input
    assert!(validator.validate_problem_description(problem).is_ok());

    // Generate algorithms
    let result = engine.design_algorithm_batch(problem, 5, 1);

    assert!(result.is_ok());
    let batch = result.unwrap();

    // Verify batch contents
    assert!(!batch.candidates.is_empty());
    assert_eq!(batch.spin_id, 1);

    // Verify each candidate has valid scores
    for candidate in &batch.candidates {
        assert!(candidate.score.quality_score >= 0.0);
        assert!(candidate.score.quality_score <= 1.0);
        assert!(candidate.score.robustness_score >= 0.0);
        assert!(candidate.score.robustness_score <= 1.0);
    }
}

/// Integration test: Input validation and sanitization
#[test]
fn test_input_validation_pipeline() {
    let validator = InputValidator::new();

    // Test valid inputs
    let valid_inputs = vec![
        "Optimize delivery routes for 50 trucks across 10 cities",
        "Classify handwritten digits into 10 categories",
        "Search for optimal molecular configurations in drug design",
    ];

    for input in valid_inputs {
        let result = validator.validate_input(input);
        assert!(
            result.is_valid,
            "Expected valid for: {}",
            input
        );
    }

    // Test invalid inputs
    let invalid_inputs = vec![
        "short",                                           // Too short
        "<script>alert('xss')</script>",                   // Malicious content
        "../../etc/passwd",                                 // Path traversal
        "SELECT * FROM users",                              // SQL-like
    ];

    for input in invalid_inputs {
        let result = validator.validate_input(input);
        assert!(
            !result.is_valid || !result.warnings.is_empty(),
            "Expected invalid for: {}",
            input
        );
    }

    // Test sanitization
    let dirty_input = "Hello\x00World   with\tspaces";
    let clean = validator.sanitize_input(dirty_input);
    assert!(!clean.contains('\x00'));
    assert_eq!(clean, "Hello World with spaces");
}

/// Integration test: Error recovery with retries
#[test]
fn test_error_recovery_integration() {
    let mut recovery_manager = ErrorRecoveryManager::new();
    let mut attempt_count = 0;

    // Simulate operation that fails twice then succeeds
    let result = recovery_manager.execute_with_recovery(
        || {
            attempt_count += 1;
            if attempt_count < 3 {
                Err(QSlotError::GenerationError("transient error".to_string()))
            } else {
                Ok(42)
            }
        },
        "algorithm_generation",
    );

    match result {
        RecoveryResult::Success(value) => {
            assert_eq!(value, 42);
            assert_eq!(attempt_count, 3);
        }
        _ => panic!("Expected successful recovery"),
    }
}

/// Integration test: Metrics collection throughout pipeline
#[test]
fn test_metrics_integration() {
    let metrics = Arc::new(MetricsCollector::new());
    let engine = ParallelSlotEngine::with_threads(2);

    let problem = "Optimize factory scheduling with 20 machines and 100 jobs";

    // Generate algorithms and measure
    {
        let _timer = metrics.start_timer("algorithm_generation");
        engine.design_algorithm_batch(problem, 3, 1).unwrap();
    }

    // Check metrics
    let snapshot = metrics.snapshot();
    assert_eq!(snapshot.total_operations, 1);
    assert!(snapshot.operation_stats.contains_key("algorithm_generation"));

    let stats = &snapshot.operation_stats["algorithm_generation"];
    assert_eq!(stats.count, 1);
    assert!(stats.mean_duration_ms > 0.0);
}

/// Integration test: Parallel engine with caching
#[test]
fn test_parallel_with_caching() {
    let engine = ParallelSlotEngine::with_threads(4);

    let problem = "Find optimal tour through 30 cities (traveling salesman)";

    // First batch - cold cache
    let result1 = engine.design_algorithm_batch(problem, 10, 1);
    assert!(result1.is_ok());

    let stats1 = engine.cache_statistics();
    println!("Cache stats after batch 1: {:?}", stats1);

    // Second batch - potentially warm cache
    let result2 = engine.design_algorithm_batch(problem, 10, 2);
    assert!(result2.is_ok());

    let stats2 = engine.cache_statistics();
    println!("Cache stats after batch 2: {:?}", stats2);

    // Cache should have been queried
    assert!(stats2.total_queries >= stats1.total_queries);
}

/// Integration test: Seraphic learning accumulation
#[test]
fn test_seraphic_learning_integration() {
    let mut engine = QSlotEngine::new();

    let problem = "Optimize resource allocation across distributed systems";

    // Generate multiple batches to accumulate learning
    for i in 0..5 {
        engine.design_algorithm_batch(problem, 3, i).unwrap();
    }

    // Check that Seraphic has accumulated experience
    let stats = engine.get_calibration_stats();
    assert!(stats.total_experiences > 0);

    println!("Seraphic stats: {:?}", stats);
    println!("Quality trend: {:.3}", engine.get_quality_trend());
}

/// Integration test: Persistence layer
#[test]
fn test_persistence_integration() {
    use tempfile::tempdir;

    let temp_dir = tempdir().unwrap();
    let db_path = temp_dir.path().join("test.db");

    // Create engine with persistence
    let mut engine = QSlotEngine::with_persistence(&db_path).unwrap();

    let problem = "Optimize network routing with quality of service constraints";

    // Generate algorithms
    engine.design_algorithm_batch(problem, 5, 1).unwrap();

    // Check database stats
    let db_stats = engine.get_database_stats();
    assert!(db_stats.is_some());

    let stats = db_stats.unwrap();
    assert!(stats.total_spins > 0);

    println!("Database stats: {:?}", stats);

    // Save Seraphic state
    assert!(engine.save_seraphic_state().is_ok());

    drop(engine);

    // Reload engine - should restore Seraphic state
    let engine2 = QSlotEngine::with_persistence(&db_path).unwrap();
    let stats2 = engine2.get_calibration_stats();

    // Should have loaded previous state
    assert!(stats2.total_experiences > 0);
}

/// Integration test: Validation, generation, and export pipeline
#[test]
fn test_validation_generation_export() {
    let validator = InputValidator::new();
    let mut engine = QSlotEngine::new();

    let problem = "Design quantum circuit for integer factorization";

    // Step 1: Validate
    assert!(validator.validate_problem_description(problem).is_ok());

    // Step 2: Sanitize
    let clean_problem = validator.sanitize_input(problem);

    // Step 3: Generate
    let batch = engine
        .design_algorithm_batch(&clean_problem, 3, 1)
        .unwrap();

    // Step 4: Export analytics
    let analytics_json = engine.export_analytics_json();
    assert!(analytics_json.is_ok());

    let json = analytics_json.unwrap();
    assert!(json.contains("session_id"));

    println!("Generated {} algorithms", batch.candidates.len());
}

/// Integration test: Error handling across components
#[test]
fn test_error_handling_integration() {
    let mut engine = QSlotEngine::new();
    let validator = InputValidator::new();

    // Try invalid input
    let invalid = "x"; // Too short
    assert!(validator.validate_problem_description(invalid).is_err());

    // Try with engine (should fail gracefully)
    let result = engine.design_algorithm_batch(invalid, 5, 1);
    assert!(result.is_err());

    match result {
        Err(QSlotError::ParseError(_)) => {
            // Expected error type
        }
        Err(e) => panic!("Unexpected error type: {:?}", e),
        Ok(_) => panic!("Should have failed"),
    }
}

/// Integration test: Concurrent access to parallel engine
#[test]
fn test_concurrent_access() {
    use std::sync::Arc;
    use std::thread;

    let engine = Arc::new(ParallelSlotEngine::with_threads(4));
    let problems = vec![
        "Find shortest path in graph",
        "Optimize delivery routes",
        "Classify data points",
        "Search for patterns",
    ];

    let mut handles = vec![];

    for (i, problem) in problems.iter().enumerate() {
        let engine_clone = Arc::clone(&engine);
        let problem = problem.to_string();

        let handle = thread::spawn(move || {
            engine_clone
                .design_algorithm_batch(&problem, 3, i as u64)
                .unwrap()
        });

        handles.push(handle);
    }

    // Wait for all threads
    let results: Vec<_> = handles.into_iter().map(|h| h.join().unwrap()).collect();

    assert_eq!(results.len(), 4);
    for result in results {
        assert!(!result.batch.candidates.is_empty());
    }
}

/// Integration test: Parameter validation
#[test]
fn test_parameter_validation() {
    let validator = InputValidator::new();

    // Valid candidate counts
    assert!(validator.validate_candidate_count(1).is_ok());
    assert!(validator.validate_candidate_count(50).is_ok());

    // Invalid candidate counts
    assert!(validator.validate_candidate_count(0).is_err());
    assert!(validator.validate_candidate_count(1000).is_err());

    // Numeric parameter validation
    assert!(validator.validate_numeric_param(0.5, 0.0, 1.0, "test").is_ok());
    assert!(validator
        .validate_numeric_param(-0.1, 0.0, 1.0, "test")
        .is_err());
    assert!(validator
        .validate_numeric_param(1.1, 0.0, 1.0, "test")
        .is_err());
}

/// Integration test: Full system reliability
#[test]
fn test_system_reliability() {
    let engine = ParallelSlotEngine::with_threads(2);
    let validator = InputValidator::new();
    let metrics = Arc::new(MetricsCollector::new());

    let problems = vec![
        "Optimize warehouse layout",
        "Schedule tasks across processors",
        "Allocate resources efficiently",
        "Find optimal configurations",
        "Minimize energy consumption",
    ];

    let mut total_algorithms = 0;

    for (i, problem) in problems.iter().enumerate() {
        // Validate
        assert!(validator.validate_problem_description(problem).is_ok());

        // Generate with metrics
        let _timer = metrics.start_timer("batch_generation");
        let result = engine.design_algorithm_batch(problem, 4, i as u64);

        // Should never crash
        assert!(result.is_ok());

        let batch = result.unwrap();
        total_algorithms += batch.batch.candidates.len();
    }

    println!("Total algorithms generated: {}", total_algorithms);
    assert!(total_algorithms >= 5 * 4); // At least 4 per problem

    let snapshot = metrics.snapshot();
    println!("Final metrics: {:?}", snapshot);
}
