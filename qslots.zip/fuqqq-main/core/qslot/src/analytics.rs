use serde::{Deserialize, Serialize};
use metatron_core::ProblemType;
use chrono::{DateTime, Utc};
use std::collections::HashMap;

/// Session analytics for tracking learning progress
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SessionAnalytics {
    /// Session ID
    pub session_id: String,

    /// Session start time
    pub session_start: DateTime<Utc>,

    /// Last update time
    pub last_update: DateTime<Utc>,

    /// Total spins performed in this session
    pub total_spins: usize,

    /// Quality history over time (timestamp, quality)
    pub quality_timeline: Vec<QualityDataPoint>,

    /// Performance per problem type
    pub problem_type_stats: HashMap<ProblemType, ProblemTypeStats>,

    /// Surgery parameter evolution
    pub surgery_param_history: Vec<SurgeryParamSnapshot>,

    /// Best algorithm found so far
    pub best_quality: Option<BestAlgorithmRecord>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QualityDataPoint {
    pub timestamp: DateTime<Utc>,
    pub spin_index: usize,
    pub quality: f64,
    pub problem_type: ProblemType,
    pub algorithm_family: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProblemTypeStats {
    pub problem_type: ProblemType,
    pub total_attempts: usize,
    pub mean_quality: f64,
    pub best_quality: f64,
    pub worst_quality: f64,
    pub quality_improvement: f64,  // Delta from first to last
    pub learned_route_length: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SurgeryParamSnapshot {
    pub timestamp: DateTime<Utc>,
    pub spin_index: usize,
    pub step_size_multiplier: f64,
    pub max_iters_multiplier: f64,
    pub convergence_threshold_multiplier: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BestAlgorithmRecord {
    pub quality: f64,
    pub algorithm_family: String,
    pub problem_type: ProblemType,
    pub spin_index: usize,
    pub timestamp: DateTime<Utc>,
}

impl SessionAnalytics {
    pub fn new(session_id: String) -> Self {
        let now = Utc::now();
        Self {
            session_id,
            session_start: now,
            last_update: now,
            total_spins: 0,
            quality_timeline: Vec::new(),
            problem_type_stats: HashMap::new(),
            surgery_param_history: Vec::new(),
            best_quality: None,
        }
    }

    /// Add a quality data point
    pub fn add_quality_point(
        &mut self,
        spin_index: usize,
        quality: f64,
        problem_type: ProblemType,
        algorithm_family: String,
    ) {
        let now = Utc::now();
        self.last_update = now;
        self.total_spins += 1;

        // Add to timeline
        self.quality_timeline.push(QualityDataPoint {
            timestamp: now,
            spin_index,
            quality,
            problem_type,
            algorithm_family: algorithm_family.clone(),
        });

        // Update problem type stats
        let stats = self.problem_type_stats
            .entry(problem_type)
            .or_insert_with(|| ProblemTypeStats {
                problem_type,
                total_attempts: 0,
                mean_quality: 0.0,
                best_quality: quality,
                worst_quality: quality,
                quality_improvement: 0.0,
                learned_route_length: 5.0,
            });

        stats.total_attempts += 1;
        stats.best_quality = stats.best_quality.max(quality);
        stats.worst_quality = stats.worst_quality.min(quality);

        // Update running mean
        let old_mean = stats.mean_quality;
        stats.mean_quality = (old_mean * (stats.total_attempts - 1) as f64 + quality)
            / stats.total_attempts as f64;

        // Update best algorithm record
        if self.best_quality.as_ref().map_or(true, |b| quality > b.quality) {
            self.best_quality = Some(BestAlgorithmRecord {
                quality,
                algorithm_family,
                problem_type,
                spin_index,
                timestamp: now,
            });
        }
    }

    /// Add surgery parameter snapshot
    pub fn add_surgery_snapshot(
        &mut self,
        spin_index: usize,
        step_size_multiplier: f64,
        max_iters_multiplier: f64,
        convergence_threshold_multiplier: f64,
    ) {
        self.surgery_param_history.push(SurgeryParamSnapshot {
            timestamp: Utc::now(),
            spin_index,
            step_size_multiplier,
            max_iters_multiplier,
            convergence_threshold_multiplier,
        });
    }

    /// Update problem type routing stats
    pub fn update_routing_stats(&mut self, problem_type: ProblemType, route_length: f64) {
        if let Some(stats) = self.problem_type_stats.get_mut(&problem_type) {
            stats.learned_route_length = route_length;
        }
    }

    /// Get quality improvement trend (linear regression slope)
    pub fn get_quality_trend(&self, problem_type: Option<ProblemType>) -> f64 {
        let points: Vec<&QualityDataPoint> = if let Some(pt) = problem_type {
            self.quality_timeline.iter()
                .filter(|p| p.problem_type == pt)
                .collect()
        } else {
            self.quality_timeline.iter().collect()
        };

        if points.len() < 2 {
            return 0.0;
        }

        // Simple linear regression
        let n = points.len() as f64;
        let x_mean = (n - 1.0) / 2.0;
        let y_mean: f64 = points.iter().map(|p| p.quality).sum::<f64>() / n;

        let mut numerator = 0.0;
        let mut denominator = 0.0;

        for (i, point) in points.iter().enumerate() {
            let x = i as f64;
            numerator += (x - x_mean) * (point.quality - y_mean);
            denominator += (x - x_mean).powi(2);
        }

        if denominator == 0.0 {
            0.0
        } else {
            numerator / denominator
        }
    }

    /// Get summary report
    pub fn get_summary(&self) -> AnalyticsSummary {
        let quality_trend = self.get_quality_trend(None);
        let session_duration = Utc::now()
            .signed_duration_since(self.session_start)
            .num_seconds();

        let mean_quality = if self.quality_timeline.is_empty() {
            0.0
        } else {
            self.quality_timeline.iter()
                .map(|p| p.quality)
                .sum::<f64>() / self.quality_timeline.len() as f64
        };

        AnalyticsSummary {
            session_id: self.session_id.clone(),
            session_duration_seconds: session_duration,
            total_spins: self.total_spins,
            mean_quality,
            quality_trend,
            best_quality: self.best_quality.as_ref().map(|b| b.quality),
            problem_types_explored: self.problem_type_stats.len(),
        }
    }

    /// Export to JSON string
    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string_pretty(self)
    }

    /// Export summary to JSON string
    pub fn summary_to_json(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string_pretty(&self.get_summary())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalyticsSummary {
    pub session_id: String,
    pub session_duration_seconds: i64,
    pub total_spins: usize,
    pub mean_quality: f64,
    pub quality_trend: f64,
    pub best_quality: Option<f64>,
    pub problem_types_explored: usize,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_session_analytics_new() {
        let analytics = SessionAnalytics::new("test-session".to_string());
        assert_eq!(analytics.total_spins, 0);
        assert_eq!(analytics.session_id, "test-session");
    }

    #[test]
    fn test_add_quality_point() {
        let mut analytics = SessionAnalytics::new("test".to_string());
        analytics.add_quality_point(
            0,
            0.75,
            ProblemType::Search,
            "QAOA".to_string(),
        );

        assert_eq!(analytics.total_spins, 1);
        assert_eq!(analytics.quality_timeline.len(), 1);
        assert!(analytics.best_quality.is_some());
        assert_eq!(analytics.best_quality.as_ref().unwrap().quality, 0.75);
    }

    #[test]
    fn test_quality_trend() {
        let mut analytics = SessionAnalytics::new("test".to_string());

        // Add improving quality points
        for i in 0..5 {
            analytics.add_quality_point(
                i,
                0.3 + (i as f64 * 0.1),
                ProblemType::Search,
                "QAOA".to_string(),
            );
        }

        let trend = analytics.get_quality_trend(None);
        assert!(trend > 0.0, "Expected positive trend for improving quality");
    }
}
