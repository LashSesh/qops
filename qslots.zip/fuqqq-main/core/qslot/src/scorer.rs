use crate::QSlotContext;
use fuq_core::{AlgorithmScore, AlgorithmSpec, ScoreLabel, SurgeryResult};
use fuq_core::singularity::Singularity;

/// Compute score for an algorithm specification
pub fn compute_algorithm_score(
    spec: &AlgorithmSpec,
    singularity: &Singularity,
    surgery_result: &SurgeryResult,
    context: &QSlotContext,
) -> AlgorithmScore {
    let quality_score = compute_quality_score(spec, singularity, surgery_result);
    let robustness_score = compute_robustness_score(spec, surgery_result);
    let novelty_score = compute_novelty_score(spec, context);
    let family_match_score = compute_family_match_score(spec, singularity);
    let estimated_cost = estimate_computational_cost(spec);

    let mut score = AlgorithmScore {
        quality_score,
        robustness_score,
        novelty_score,
        family_match_score,
        estimated_cost,
        label: ScoreLabel::Miss,
    };

    score.compute_label();

    score
}

fn compute_quality_score(
    spec: &AlgorithmSpec,
    singularity: &Singularity,
    surgery_result: &SurgeryResult,
) -> f64 {
    let mut score = 0.0;

    // Singularity strength contributes to quality
    score += singularity.strength * 0.4;

    // Surgery convergence contributes
    if !surgery_result.j_evolution.is_empty() {
        let final_j = surgery_result.j_evolution.last().unwrap();
        let initial_j = surgery_result.j_evolution.first().unwrap();

        // Good if J increased (improved mesh quality)
        if final_j > initial_j {
            let improvement = (final_j - initial_j) / initial_j.abs().max(1.0);
            score += improvement.min(0.3);
        }
    }

    // Guard flags penalize
    let guard_penalty = surgery_result.guard_flags.len() as f64 * 0.05;
    score -= guard_penalty;

    // Number of operators (more sophisticated = potentially better)
    let operator_score = (spec.operators.len() as f64 / 10.0).min(0.3);
    score += operator_score;

    score.max(0.0).min(1.0)
}

fn compute_robustness_score(spec: &AlgorithmSpec, surgery_result: &SurgeryResult) -> f64 {
    let mut score = 0.5; // Base score

    // Fewer guard flags = more robust
    if surgery_result.guard_flags.is_empty() {
        score += 0.3;
    } else {
        score -= surgery_result.guard_flags.len() as f64 * 0.1;
    }

    // Feedback configuration depth indicates potential robustness
    let feedback_score =
        (spec.feedback.max_iterations as f64 / 200.0).min(0.2);
    score += feedback_score;

    // Topological charge > 0 suggests structural stability
    if spec.state5d.chi.abs() > 0.1 {
        score += 0.1;
    }

    score.max(0.0).min(1.0)
}

fn compute_novelty_score(spec: &AlgorithmSpec, context: &QSlotContext) -> f64 {
    let mut score = 0.5;

    // Metatron signature contributes novelty
    // Longer signatures = more complex routes = more novel
    let sig_length = spec.metatron_signature.len() as f64;
    score += (sig_length / 50.0).min(0.2);

    // Less common families get novelty boost
    match spec.family {
        fuq_core::AlgorithmFamily::MetatronResonator
        | fuq_core::AlgorithmFamily::HybridAnalogCustom => {
            score += 0.2;
        }
        _ => {}
    }

    // Context adaptation: if we've seen many candidates, reduce novelty slightly
    if context.total_candidates > 50 {
        score *= 0.9;
    }

    score.max(0.0).min(1.0)
}

fn compute_family_match_score(spec: &AlgorithmSpec, singularity: &Singularity) -> f64 {
    use fuq_core::singularity::SingularityKind;
    use fuq_core::AlgorithmFamily;

    let mut score: f64 = 0.5;

    // Match algorithm family to singularity kind
    let good_match = match (&spec.family, &singularity.kind) {
        (AlgorithmFamily::GroverLikeSearch, SingularityKind::Attractor) => true,
        (AlgorithmFamily::QAOA, SingularityKind::Saddle) => true,
        (AlgorithmFamily::VQE, SingularityKind::Attractor) => true,
        (AlgorithmFamily::MetatronResonator, SingularityKind::Vortex) => true,
        (AlgorithmFamily::QuantumWalk, SingularityKind::Vortex) => true,
        _ => false,
    };

    if good_match {
        score += 0.4;
    }

    // Problem type match
    use metatron_core::ProblemType;
    let type_match = match (&spec.problem_spec.problem_type, &spec.family) {
        (ProblemType::Search, AlgorithmFamily::GroverLikeSearch)
        | (ProblemType::Search, AlgorithmFamily::QuantumWalk) => true,
        (ProblemType::CombinatorialOptimization, AlgorithmFamily::QAOA)
        | (ProblemType::CombinatorialOptimization, AlgorithmFamily::VQE) => true,
        (ProblemType::Classification, AlgorithmFamily::VQC_QML)
        | (ProblemType::Regression, AlgorithmFamily::VQC_QML) => true,
        _ => false,
    };

    if type_match {
        score += 0.1;
    }

    score.max(0.0).min(1.0)
}

fn estimate_computational_cost(spec: &AlgorithmSpec) -> f64 {
    // Estimate based on state space dimension and operator count

    let mut cost = 100.0; // Base cost

    // Qubit-based cost (exponential)
    if let Some(dim) = spec.state_space.estimated_dimension {
        if dim > 0 {
            cost += (dim as f64).log2() * 50.0;
        }
    }

    // Operator count cost
    cost += spec.operators.len() as f64 * 20.0;

    // Feedback iterations cost
    cost += spec.feedback.max_iterations as f64 * 5.0;

    // Schedule complexity (if analog)
    if let Some(ref schedule) = spec.schedule {
        cost += schedule.num_cycles as f64 * 10.0;
    }

    cost
}

#[cfg(test)]
mod tests {
    use super::*;
    use fuq_core::singularity::*;
    use fuq_core::*;

    #[test]
    fn test_compute_quality_score() {
        let spec = create_test_spec();
        let singularity = Singularity {
            kind: SingularityKind::Attractor,
            location: State5D::zero(),
            strength: 0.8,
            topological_charge: 1,
            spectral_signature: vec![0.5; 5],
        };

        let surgery_result = SurgeryResult {
            final_mesh: create_test_mesh(),
            j_evolution: vec![1.0, 1.2, 1.5],
            convergence_flags: vec![true],
            guard_flags: vec![],
            iterations_performed: 3,
        };

        let context = QSlotContext::new();
        let score = compute_algorithm_score(&spec, &singularity, &surgery_result, &context);

        assert!(score.quality_score >= 0.0);
        assert!(score.quality_score <= 1.0);
    }

    fn create_test_spec() -> AlgorithmSpec {
        AlgorithmSpec {
            id: "test".to_string(),
            name: "Test".to_string(),
            description: "Test spec".to_string(),
            problem_spec: metatron_core::ProblemSpec {
                id: "test".to_string(),
                raw_text: "test".to_string(),
                problem_type: metatron_core::ProblemType::Search,
                input_structure: "test".to_string(),
                objective_description: "test".to_string(),
                constraints: vec![],
                solution_quality: metatron_core::SolutionQuality {
                    target_accuracy: None,
                    target_gap: None,
                    resource_budget: None,
                },
            },
            family: AlgorithmFamily::GroverLikeSearch,
            tripol: Tripol::zero(),
            state5d: State5D::zero(),
            dtl_mode: DTLMode::L0,
            state_space: HybridStateSpace {
                continuous_space: ContinuousSpace {
                    kind: ContinuousKind::None,
                    dim: 0,
                    notes: "test".to_string(),
                },
                discrete_registers: vec![],
                estimated_dimension: Some(1024),
            },
            operators: vec![],
            spectral_goal: SpectralGoal {
                pattern: SpectralPattern::TwoLevel,
                target_gap: None,
                notes: "test".to_string(),
            },
            schedule: None,
            feedback: FeedbackConfig::default(),
            metatron_signature: "test".to_string(),
            fuq_metadata: "test".to_string(),
            seraphic_hint: "test".to_string(),
            notes_for_user: "test".to_string(),
        }
    }

    fn create_test_mesh() -> fuq_core::U5dMesh {
        fuq_core::U5dMesh::new(vec![State5D::zero()])
    }
}
