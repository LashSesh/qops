use crate::QSlotError;
use regex::Regex;
use std::collections::HashSet;

/// Input validator for problem descriptions and user inputs
///
/// Provides comprehensive validation and sanitization to prevent:
/// - Malicious content injection
/// - Buffer overflow attacks
/// - Resource exhaustion
/// - Invalid input formats
pub struct InputValidator {
    dangerous_patterns: Vec<Regex>,
    max_description_length: usize,
    min_description_length: usize,
    blocked_keywords: HashSet<String>,
}

/// Validation result with detailed error information
#[derive(Debug)]
pub struct ValidationResult {
    pub is_valid: bool,
    pub errors: Vec<InputValidationError>,
    pub warnings: Vec<String>,
}

#[derive(Debug, Clone)]
pub enum InputValidationError {
    TooShort { min: usize, actual: usize },
    TooLong { max: usize, actual: usize },
    MaliciousContent { pattern: String },
    BlockedKeyword { keyword: String },
    InvalidCharacters { description: String },
    EmptyInput,
}

impl Default for InputValidator {
    fn default() -> Self {
        Self::new()
    }
}

impl InputValidator {
    pub fn new() -> Self {
        let dangerous_patterns = vec![
            // Script injection
            Regex::new(r"(?i)<script").unwrap(),
            Regex::new(r"(?i)javascript:").unwrap(),
            Regex::new(r"(?i)data:text/html").unwrap(),
            Regex::new(r"(?i)eval\s*\(").unwrap(),
            // Path traversal
            Regex::new(r"\.\./").unwrap(),
            Regex::new(r"\.\.\\").unwrap(),
            // Command injection
            Regex::new(r";\s*(rm|del|format)").unwrap(),
            Regex::new(r"\|\s*(nc|netcat|wget|curl)").unwrap(),
            // SQL injection patterns
            Regex::new(r"(?i)(union|select|insert|update|delete|drop)\s+(all|from|into|table)").unwrap(),
        ];

        let mut blocked_keywords = HashSet::new();
        blocked_keywords.insert("__proto__".to_string());
        blocked_keywords.insert("constructor".to_string());
        blocked_keywords.insert("prototype".to_string());

        Self {
            dangerous_patterns,
            max_description_length: 10_000,
            min_description_length: 10,
            blocked_keywords,
        }
    }

    /// Validate problem description
    pub fn validate_problem_description(&self, desc: &str) -> Result<(), QSlotError> {
        let result = self.validate_input(desc);

        if !result.is_valid {
            let error_messages: Vec<String> = result
                .errors
                .iter()
                .map(|e| format!("{:?}", e))
                .collect();

            return Err(QSlotError::InvalidParameters(format!(
                "Invalid problem description: {}",
                error_messages.join(", ")
            )));
        }

        Ok(())
    }

    /// Comprehensive input validation
    pub fn validate_input(&self, input: &str) -> ValidationResult {
        let mut errors = Vec::new();
        let mut warnings = Vec::new();

        // Check if empty
        if input.trim().is_empty() {
            errors.push(InputValidationError::EmptyInput);
            return ValidationResult {
                is_valid: false,
                errors,
                warnings,
            };
        }

        // Check length
        let len = input.len();
        if len < self.min_description_length {
            errors.push(InputValidationError::TooShort {
                min: self.min_description_length,
                actual: len,
            });
        }

        if len > self.max_description_length {
            errors.push(InputValidationError::TooLong {
                max: self.max_description_length,
                actual: len,
            });
        }

        // Check for dangerous patterns
        for pattern in &self.dangerous_patterns {
            if pattern.is_match(input) {
                errors.push(InputValidationError::MaliciousContent {
                    pattern: pattern.as_str().to_string(),
                });
            }
        }

        // Check for blocked keywords
        let lower_input = input.to_lowercase();
        for keyword in &self.blocked_keywords {
            if lower_input.contains(keyword) {
                errors.push(InputValidationError::BlockedKeyword {
                    keyword: keyword.clone(),
                });
            }
        }

        // Check for excessive special characters (potential obfuscation)
        let special_char_count = input.chars().filter(|c| !c.is_alphanumeric() && !c.is_whitespace()).count();
        let special_char_ratio = special_char_count as f64 / len as f64;
        if special_char_ratio > 0.3 {
            warnings.push(format!(
                "High ratio of special characters ({:.1}%)",
                special_char_ratio * 100.0
            ));
        }

        // Check for excessive repetition
        if self.has_excessive_repetition(input) {
            warnings.push("Excessive character repetition detected".to_string());
        }

        ValidationResult {
            is_valid: errors.is_empty(),
            errors,
            warnings,
        }
    }

    /// Sanitize user input
    pub fn sanitize_input(&self, input: &str) -> String {
        // Remove control characters (except newline and tab)
        let sanitized: String = input
            .chars()
            .filter(|c| !c.is_control() || *c == '\n' || *c == '\t')
            .collect();

        // Normalize whitespace
        let normalized = sanitized
            .split_whitespace()
            .collect::<Vec<_>>()
            .join(" ");

        // Truncate if too long
        if normalized.len() > self.max_description_length {
            normalized
                .chars()
                .take(self.max_description_length)
                .collect()
        } else {
            normalized
        }
    }

    /// Validate numeric parameter
    pub fn validate_numeric_param(
        &self,
        value: f64,
        min: f64,
        max: f64,
        param_name: &str,
    ) -> Result<(), QSlotError> {
        if value < min || value > max {
            return Err(QSlotError::InvalidParameters(format!(
                "{} must be between {} and {}, got {}",
                param_name, min, max, value
            )));
        }
        Ok(())
    }

    /// Validate integer parameter
    pub fn validate_int_param(
        &self,
        value: usize,
        min: usize,
        max: usize,
        param_name: &str,
    ) -> Result<(), QSlotError> {
        if value < min || value > max {
            return Err(QSlotError::InvalidParameters(format!(
                "{} must be between {} and {}, got {}",
                param_name, min, max, value
            )));
        }
        Ok(())
    }

    /// Check for excessive character repetition
    fn has_excessive_repetition(&self, input: &str) -> bool {
        let mut max_repetition = 0;
        let mut current_char = '\0';
        let mut current_count = 0;

        for c in input.chars() {
            if c == current_char {
                current_count += 1;
                max_repetition = max_repetition.max(current_count);
            } else {
                current_char = c;
                current_count = 1;
            }
        }

        max_repetition > 20
    }

    /// Validate candidate count for batch generation
    pub fn validate_candidate_count(&self, count: usize) -> Result<(), QSlotError> {
        self.validate_int_param(count, 1, 100, "candidate_count")
    }

    /// Validate spin index
    pub fn validate_spin_index(&self, index: u64) -> Result<(), QSlotError> {
        if index > 1_000_000 {
            return Err(QSlotError::InvalidParameters(format!(
                "Spin index {} exceeds maximum (1,000,000)",
                index
            )));
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid_input() {
        let validator = InputValidator::new();
        let result = validator.validate_input("Find shortest path in a graph with 100 nodes");

        assert!(result.is_valid);
        assert!(result.errors.is_empty());
    }

    #[test]
    fn test_too_short() {
        let validator = InputValidator::new();
        let result = validator.validate_input("Short");

        assert!(!result.is_valid);
        assert!(matches!(
            result.errors.first(),
            Some(InputValidationError::TooShort { .. })
        ));
    }

    #[test]
    fn test_too_long() {
        let validator = InputValidator::new();
        let long_input = "a".repeat(20_000);
        let result = validator.validate_input(&long_input);

        assert!(!result.is_valid);
        assert!(matches!(
            result.errors.first(),
            Some(InputValidationError::TooLong { .. })
        ));
    }

    #[test]
    fn test_script_injection() {
        let validator = InputValidator::new();
        let malicious = "Find path <script>alert('xss')</script>";
        let result = validator.validate_input(malicious);

        assert!(!result.is_valid);
        assert!(matches!(
            result.errors.first(),
            Some(InputValidationError::MaliciousContent { .. })
        ));
    }

    #[test]
    fn test_path_traversal() {
        let validator = InputValidator::new();
        let malicious = "../../etc/passwd";
        let result = validator.validate_input(malicious);

        assert!(!result.is_valid);
    }

    #[test]
    fn test_sanitization() {
        let validator = InputValidator::new();

        let input = "Hello\x00World\x01with\tcontrol\nchars";
        let sanitized = validator.sanitize_input(input);

        // Control chars except \t and \n should be removed
        assert!(!sanitized.contains('\x00'));
        assert!(!sanitized.contains('\x01'));
        assert!(sanitized.contains("Hello"));
        assert!(sanitized.contains("World"));
    }

    #[test]
    fn test_whitespace_normalization() {
        let validator = InputValidator::new();

        let input = "Multiple    spaces   and\n\nnewlines";
        let sanitized = validator.sanitize_input(input);

        // Should normalize to single spaces
        assert_eq!(sanitized, "Multiple spaces and newlines");
    }

    #[test]
    fn test_excessive_repetition() {
        let validator = InputValidator::new();

        let input = "aaaaaaaaaaaaaaaaaaaaaaaaa"; // 25 a's
        let result = validator.validate_input(input);

        assert!(!result.warnings.is_empty());
    }

    #[test]
    fn test_numeric_validation() {
        let validator = InputValidator::new();

        // Valid
        assert!(validator.validate_numeric_param(5.0, 0.0, 10.0, "test").is_ok());

        // Too low
        assert!(validator
            .validate_numeric_param(-1.0, 0.0, 10.0, "test")
            .is_err());

        // Too high
        assert!(validator
            .validate_numeric_param(11.0, 0.0, 10.0, "test")
            .is_err());
    }

    #[test]
    fn test_candidate_count_validation() {
        let validator = InputValidator::new();

        // Valid
        assert!(validator.validate_candidate_count(10).is_ok());

        // Too low
        assert!(validator.validate_candidate_count(0).is_err());

        // Too high
        assert!(validator.validate_candidate_count(1000).is_err());
    }

    #[test]
    fn test_empty_input() {
        let validator = InputValidator::new();

        let result = validator.validate_input("");
        assert!(!result.is_valid);
        assert!(matches!(
            result.errors.first(),
            Some(InputValidationError::EmptyInput)
        ));

        let result = validator.validate_input("   ");
        assert!(!result.is_valid);
        assert!(matches!(
            result.errors.first(),
            Some(InputValidationError::EmptyInput)
        ));
    }

    #[test]
    fn test_problem_description_validation() {
        let validator = InputValidator::new();

        // Valid
        assert!(validator
            .validate_problem_description("Optimize delivery routes for 50 trucks")
            .is_ok());

        // Invalid - too short
        assert!(validator.validate_problem_description("short").is_err());

        // Invalid - malicious
        assert!(validator
            .validate_problem_description("<script>alert(1)</script>")
            .is_err());
    }
}
