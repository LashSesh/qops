use fuq_core::SurgeryParams;
use metatron_core::ProblemSpec;
use rand::Rng;
use serde::{Deserialize, Serialize};
use tracing::{debug, info};

/// Algorithm parameter tuning system
#[derive(Debug, Clone)]
pub struct AlgorithmTuner {
    pub iterations: usize,
    pub exploration_rate: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TuningResult {
    pub original_score: f64,
    pub tuned_score: f64,
    pub improvement: f64,
    pub improvement_percent: f64,
    pub iterations_performed: usize,
    pub best_params: SurgeryParams,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TuningSession {
    pub problem_spec: ProblemSpec,
    pub history: Vec<TuningStep>,
    pub best_result: Option<TuningResult>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TuningStep {
    pub iteration: usize,
    pub params: SurgeryParams,
    pub score: f64,
}

impl AlgorithmTuner {
    pub fn new(iterations: usize) -> Self {
        Self {
            iterations,
            exploration_rate: 0.3,
        }
    }

    /// Tune surgery parameters to improve algorithm quality
    ///
    /// This performs local search in the parameter space to find
    /// better surgery parameters that improve the resulting algorithm.
    pub fn tune_surgery_params(
        &self,
        base_params: &SurgeryParams,
        _problem_spec: &ProblemSpec,
        score_fn: impl Fn(&SurgeryParams) -> f64,
    ) -> TuningResult {
        info!("Starting parameter tuning for {} iterations", self.iterations);

        let mut current_params = base_params.clone();
        let mut current_score = score_fn(&current_params);
        let original_score = current_score;

        let mut best_params = current_params.clone();
        let mut best_score = current_score;

        let mut rng = rand::thread_rng();

        for iter in 0..self.iterations {
            // Generate parameter variants
            let variants = self.generate_param_variants(&current_params, &mut rng);

            // Evaluate each variant
            for variant in variants {
                let score = score_fn(&variant);

                if score > best_score {
                    best_score = score;
                    best_params = variant.clone();
                    debug!("Iteration {}: New best score: {:.4}", iter + 1, best_score);
                }

                // Simulated annealing: accept worse solutions with some probability
                if score > current_score
                    || rng.gen::<f64>()
                        < self.acceptance_probability(current_score, score, iter as f64)
                {
                    current_params = variant;
                    current_score = score;
                }
            }
        }

        let improvement = best_score - original_score;
        let improvement_percent = if original_score > 0.0 {
            (improvement / original_score) * 100.0
        } else {
            0.0
        };

        info!(
            "Tuning complete: {:.4} → {:.4} ({:+.2}%)",
            original_score, best_score, improvement_percent
        );

        TuningResult {
            original_score,
            tuned_score: best_score,
            improvement,
            improvement_percent,
            iterations_performed: self.iterations,
            best_params,
        }
    }

    /// Generate variants of surgery parameters
    fn generate_param_variants<R: Rng>(
        &self,
        base: &SurgeryParams,
        rng: &mut R,
    ) -> Vec<SurgeryParams> {
        let mut variants = Vec::new();

        // Generate 5 variants with different perturbations
        for _ in 0..5 {
            let mut variant = base.clone();

            // Perturb step_size
            if rng.gen::<f64>() < self.exploration_rate {
                let factor = 1.0 + (rng.gen::<f64>() - 0.5) * 0.2; // ±10%
                variant.step_size = (base.step_size * factor).clamp(0.001, 1.0);
            }

            // Perturb max_iterations
            if rng.gen::<f64>() < self.exploration_rate {
                let delta = rng.gen_range(-10..=10);
                variant.max_iterations =
                    ((base.max_iterations as i32 + delta).max(10).min(1000)) as usize;
            }

            // Perturb convergence_threshold
            if rng.gen::<f64>() < self.exploration_rate {
                let factor = 1.0 + (rng.gen::<f64>() - 0.5) * 0.4; // ±20%
                variant.convergence_threshold =
                    (base.convergence_threshold * factor).clamp(1e-6, 1e-2);
            }

            variants.push(variant);
        }

        variants
    }

    /// Simulated annealing acceptance probability
    fn acceptance_probability(&self, current: f64, new: f64, iteration: f64) -> f64 {
        if new > current {
            1.0
        } else {
            let temperature = 1.0 / (1.0 + iteration / self.iterations as f64);
            ((new - current) / temperature).exp()
        }
    }

    /// Create a tuning session for tracking
    pub fn create_session(&self, problem_spec: ProblemSpec) -> TuningSession {
        TuningSession {
            problem_spec,
            history: Vec::new(),
            best_result: None,
        }
    }
}

/// Simplified tuning for when you have access to the full engine
///
/// This is a higher-level interface that requires the QSlotEngine
/// to re-generate algorithms with different parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TuningSuggestion {
    pub parameter_name: String,
    pub current_value: f64,
    pub suggested_value: f64,
    pub expected_improvement: f64,
    pub confidence: f64,
}

impl TuningSuggestion {
    /// Generate tuning suggestions based on historical data
    pub fn from_history(
        param_name: &str,
        param_values: &[f64],
        scores: &[f64],
    ) -> Option<Self> {
        if param_values.len() != scores.len() || param_values.is_empty() {
            return None;
        }

        // Find the parameter value that gave the best score
        let (best_idx, &best_score) = scores
            .iter()
            .enumerate()
            .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal))?;

        let best_param = param_values[best_idx];
        let current_param = param_values.last().copied()?;
        let current_score = scores.last().copied()?;

        let expected_improvement = best_score - current_score;
        let confidence = if param_values.len() < 3 {
            0.3
        } else {
            (scores.len() as f64 / 100.0).min(0.9)
        };

        Some(TuningSuggestion {
            parameter_name: param_name.to_string(),
            current_value: current_param,
            suggested_value: best_param,
            expected_improvement,
            confidence,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tuner_creation() {
        let tuner = AlgorithmTuner::new(50);
        assert_eq!(tuner.iterations, 50);
        assert!(tuner.exploration_rate > 0.0);
    }

    #[test]
    fn test_param_variant_generation() {
        let tuner = AlgorithmTuner::new(10);
        let base_params = SurgeryParams::default();
        let mut rng = rand::thread_rng();

        let variants = tuner.generate_param_variants(&base_params, &mut rng);

        assert_eq!(variants.len(), 5);
        // At least some variants should be different from base
        let different = variants
            .iter()
            .any(|v| (v.step_size - base_params.step_size).abs() > 1e-6);
        assert!(different);
    }

    #[test]
    fn test_tuning_with_mock_score_fn() {
        let tuner = AlgorithmTuner::new(10);
        let base_params = SurgeryParams::default();

        // Mock score function: higher step_size = better score (simplified)
        let score_fn = |params: &SurgeryParams| params.step_size * 10.0;

        let result = tuner.tune_surgery_params(
            &base_params,
            &ProblemSpec {
                id: "test".to_string(),
                raw_text: "test".to_string(),
                problem_type: metatron_core::ProblemType::Search,
                input_structure: String::new(),
                objective_description: String::new(),
                constraints: Vec::new(),
                solution_quality: metatron_core::SolutionQuality::default(),
            },
            score_fn,
        );

        assert!(result.improvement >= 0.0);
        assert_eq!(result.iterations_performed, 10);
    }

    #[test]
    fn test_tuning_suggestion() {
        let param_values = vec![0.1, 0.2, 0.3, 0.4, 0.5];
        let scores = vec![0.5, 0.6, 0.9, 0.7, 0.8];

        let suggestion =
            TuningSuggestion::from_history("step_size", &param_values, &scores).unwrap();

        assert_eq!(suggestion.suggested_value, 0.3); // Best score was at 0.3
        assert!(suggestion.expected_improvement > 0.0);
    }
}
