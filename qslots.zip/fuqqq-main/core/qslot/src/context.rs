use crate::AlgorithmBatch;
use fuq_core::ScoreLabel;
use serde::{Deserialize, Serialize};

/// QSlot context - maintains state across spins for Seraphic calibration
/// This implements the "double-kick" feedback mechanism
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QSlotContext {
    pub total_spins: u64,
    pub total_candidates: u64,
    pub score_statistics: ScoreStatistics,
    pub adaptation_params: AdaptationParams,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScoreStatistics {
    pub count_miss: u64,
    pub count_okay: u64,
    pub count_good: u64,
    pub count_jackpot: u64,
    pub avg_quality: f64,
    pub avg_robustness: f64,
    pub avg_novelty: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AdaptationParams {
    /// Biases for route sampling
    pub route_length_bias: f64,
    pub complexity_bias: f64,
    pub exploration_rate: f64,
}

impl QSlotContext {
    pub fn new() -> Self {
        Self {
            total_spins: 0,
            total_candidates: 0,
            score_statistics: ScoreStatistics {
                count_miss: 0,
                count_okay: 0,
                count_good: 0,
                count_jackpot: 0,
                avg_quality: 0.0,
                avg_robustness: 0.0,
                avg_novelty: 0.0,
            },
            adaptation_params: AdaptationParams {
                route_length_bias: 1.0,
                complexity_bias: 1.0,
                exploration_rate: 0.8,
            },
        }
    }

    /// Update context based on batch results
    pub fn update_from_batch(&mut self, batch: &AlgorithmBatch) {
        self.total_spins += 1;
        self.total_candidates += batch.candidates.len() as u64;

        // Update statistics
        let mut total_quality = 0.0;
        let mut total_robustness = 0.0;
        let mut total_novelty = 0.0;

        for candidate in &batch.candidates {
            match candidate.score.label {
                ScoreLabel::Miss => self.score_statistics.count_miss += 1,
                ScoreLabel::Okay => self.score_statistics.count_okay += 1,
                ScoreLabel::Good => self.score_statistics.count_good += 1,
                ScoreLabel::Jackpot => self.score_statistics.count_jackpot += 1,
            }

            total_quality += candidate.score.quality_score;
            total_robustness += candidate.score.robustness_score;
            total_novelty += candidate.score.novelty_score;
        }

        let n = batch.candidates.len() as f64;
        if n > 0.0 {
            // Running average update
            let alpha = 0.3; // Smoothing factor
            let batch_avg_quality = total_quality / n;
            let batch_avg_robustness = total_robustness / n;
            let batch_avg_novelty = total_novelty / n;

            self.score_statistics.avg_quality = self.score_statistics.avg_quality * (1.0 - alpha)
                + batch_avg_quality * alpha;
            self.score_statistics.avg_robustness =
                self.score_statistics.avg_robustness * (1.0 - alpha)
                    + batch_avg_robustness * alpha;
            self.score_statistics.avg_novelty = self.score_statistics.avg_novelty * (1.0 - alpha)
                + batch_avg_novelty * alpha;
        }

        // Seraphic adaptation: adjust parameters based on performance
        self.adapt_parameters();
    }

    fn adapt_parameters(&mut self) {
        if self.total_candidates < 10 {
            return; // Not enough data yet
        }

        let total = (self.score_statistics.count_miss
            + self.score_statistics.count_okay
            + self.score_statistics.count_good
            + self.score_statistics.count_jackpot) as f64;

        if total < 1.0 {
            return;
        }

        let jackpot_rate = self.score_statistics.count_jackpot as f64 / total;
        let good_or_better_rate = (self.score_statistics.count_good
            + self.score_statistics.count_jackpot) as f64
            / total;

        // If we're getting too many misses, increase exploration
        if good_or_better_rate < 0.3 {
            self.adaptation_params.exploration_rate =
                (self.adaptation_params.exploration_rate + 0.05).min(1.0);
            self.adaptation_params.complexity_bias =
                (self.adaptation_params.complexity_bias - 0.05).max(0.5);
        }

        // If we're getting lots of jackpots, exploit more
        if jackpot_rate > 0.2 {
            self.adaptation_params.exploration_rate =
                (self.adaptation_params.exploration_rate - 0.05).max(0.3);
        }

        // Adjust route length based on quality
        if self.score_statistics.avg_quality < 0.5 {
            // Try different route lengths
            self.adaptation_params.route_length_bias =
                (self.adaptation_params.route_length_bias + 0.1).min(2.0);
        } else if self.score_statistics.avg_quality > 0.7 {
            // Current route lengths working well
            self.adaptation_params.route_length_bias =
                (self.adaptation_params.route_length_bias * 0.95).max(0.8);
        }
    }

    pub fn get_adaptation_hint(&self) -> String {
        if self.total_spins < 3 {
            return "Building initial data...".to_string();
        }

        let total = (self.score_statistics.count_miss
            + self.score_statistics.count_okay
            + self.score_statistics.count_good
            + self.score_statistics.count_jackpot) as f64;

        if total < 1.0 {
            return "Awaiting results...".to_string();
        }

        let good_rate = (self.score_statistics.count_good + self.score_statistics.count_jackpot)
            as f64
            / total;

        if good_rate > 0.5 {
            "System is generating high-quality candidates. Keep spinning!".to_string()
        } else if good_rate > 0.3 {
            "Moderate quality. System is adapting parameters.".to_string()
        } else {
            "Lower quality batch. System increasing exploration.".to_string()
        }
    }
}

impl Default for QSlotContext {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_context_creation() {
        let ctx = QSlotContext::new();
        assert_eq!(ctx.total_spins, 0);
        assert_eq!(ctx.total_candidates, 0);
    }
}
