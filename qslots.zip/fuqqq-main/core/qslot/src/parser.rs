use crate::QSlotError;
use metatron_core::{ProblemSpec, ProblemType, SolutionQuality};
use uuid::Uuid;

/// Parse raw problem text into ProblemSpec
pub fn parse_problem_spec(raw_text: &str) -> Result<ProblemSpec, QSlotError> {
    if raw_text.trim().is_empty() {
        return Err(QSlotError::ParseError(
            "Problem text cannot be empty".to_string(),
        ));
    }

    let text_lower = raw_text.to_lowercase();

    // Detect problem type using keywords
    let problem_type = detect_problem_type(&text_lower);

    // Extract input structure hints
    let input_structure = extract_input_structure(&text_lower);

    // Extract objective
    let objective_description = extract_objective(&raw_text);

    // Extract constraints
    let constraints = extract_constraints(&text_lower);

    // Extract solution quality hints
    let solution_quality = extract_solution_quality(&text_lower);

    Ok(ProblemSpec {
        id: Uuid::new_v4().to_string(),
        raw_text: raw_text.to_string(),
        problem_type,
        input_structure,
        objective_description,
        constraints,
        solution_quality,
    })
}

fn detect_problem_type(text: &str) -> ProblemType {
    // Search keywords
    if text.contains("search")
        || text.contains("find")
        || text.contains("locate")
        || text.contains("discover")
    {
        return ProblemType::Search;
    }

    // Optimization keywords
    if text.contains("optim")
        || text.contains("minimize")
        || text.contains("maximize")
        || text.contains("best")
        || text.contains("shortest")
        || text.contains("longest")
        || text.contains("tsp")
        || text.contains("knapsack")
    {
        return ProblemType::CombinatorialOptimization;
    }

    // Classification keywords
    if text.contains("classif")
        || text.contains("categor")
        || text.contains("label")
        || text.contains("predict class")
    {
        return ProblemType::Classification;
    }

    // Regression keywords
    if text.contains("regress")
        || text.contains("predict value")
        || text.contains("estimate")
        || text.contains("forecast")
    {
        return ProblemType::Regression;
    }

    // Simulation keywords
    if text.contains("simulat") || text.contains("model") || text.contains("evolv") {
        return ProblemType::Simulation;
    }

    // Default
    ProblemType::Custom
}

fn extract_input_structure(text: &str) -> String {
    let mut hints = Vec::new();

    if text.contains("graph") {
        hints.push("graph");
    }
    if text.contains("tree") {
        hints.push("tree");
    }
    if text.contains("matrix") || text.contains("array") {
        hints.push("matrix");
    }
    if text.contains("vector") {
        hints.push("vector");
    }
    if text.contains("string") || text.contains("sequence") {
        hints.push("sequence");
    }

    // Look for numbers indicating size
    if text.contains("node") {
        hints.push("nodes");
    }
    if text.contains("edge") {
        hints.push("edges");
    }

    if hints.is_empty() {
        String::from("unstructured")
    } else {
        hints.join(", ")
    }
}

fn extract_objective(text: &str) -> String {
    // Try to extract the first sentence or up to 200 chars
    let trimmed = text.trim();

    if let Some(pos) = trimmed.find('.') {
        if pos < 200 {
            return trimmed[..=pos].to_string();
        }
    }

    if trimmed.len() <= 200 {
        trimmed.to_string()
    } else {
        format!("{}...", &trimmed[..200])
    }
}

fn extract_constraints(text: &str) -> Vec<String> {
    let mut constraints = Vec::new();

    if text.contains("constraint") || text.contains("must") || text.contains("require") {
        constraints.push("Has explicit constraints".to_string());
    }

    if text.contains("time limit") || text.contains("deadline") {
        constraints.push("Time-constrained".to_string());
    }

    if text.contains("budget") || text.contains("resource") {
        constraints.push("Resource-constrained".to_string());
    }

    if text.contains("feasib") || text.contains("valid") {
        constraints.push("Feasibility constraints".to_string());
    }

    constraints
}

fn extract_solution_quality(text: &str) -> SolutionQuality {
    let mut target_accuracy = None;
    let mut target_gap = None;
    let mut resource_budget = None;

    // Look for accuracy percentages
    if text.contains("99%") || text.contains("0.99") {
        target_accuracy = Some(0.99);
    } else if text.contains("95%") || text.contains("0.95") {
        target_accuracy = Some(0.95);
    } else if text.contains("90%") || text.contains("0.9") {
        target_accuracy = Some(0.90);
    }

    // Look for optimality gap mentions
    if text.contains("optimal") && !text.contains("sub") && !text.contains("near") {
        target_gap = Some(0.01); // Want exact optimum
    } else if text.contains("near-optimal") {
        target_gap = Some(0.05);
    } else if text.contains("good") || text.contains("reasonable") {
        target_gap = Some(0.1);
    }

    // Extract resource budget if mentioned
    if text.contains("budget") || text.contains("resource") {
        resource_budget = Some("Limited resources".to_string());
    }

    SolutionQuality {
        target_accuracy,
        target_gap,
        resource_budget,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_search_problem() {
        let text = "Find the shortest path in a graph with 100 nodes";
        let spec = parse_problem_spec(text).unwrap();

        assert_eq!(spec.problem_type, ProblemType::Search);
        assert!(spec.input_structure.contains("graph"));
    }

    #[test]
    fn test_parse_optimization_problem() {
        let text = "Optimize the delivery route to minimize cost";
        let spec = parse_problem_spec(text).unwrap();

        assert_eq!(spec.problem_type, ProblemType::CombinatorialOptimization);
    }

    #[test]
    fn test_parse_classification_problem() {
        let text = "Classify images into categories";
        let spec = parse_problem_spec(text).unwrap();

        assert_eq!(spec.problem_type, ProblemType::Classification);
    }
}
