use fuq_core::AlgorithmSpec;
use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Error, Debug, Clone, Serialize, Deserialize)]
pub enum ValidationError {
    #[error("Invalid qubit count: {0}")]
    InvalidQubitCount(String),

    #[error("Invalid operator configuration: {0}")]
    InvalidOperator(String),

    #[error("Inconsistent state space: {0}")]
    InconsistentStateSpace(String),

    #[error("Resource constraint violation: {0}")]
    ResourceConstraintViolation(String),

    #[error("Invalid schedule: {0}")]
    InvalidSchedule(String),

    #[error("General validation error: {0}")]
    GeneralError(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ValidationReport {
    pub is_valid: bool,
    pub errors: Vec<ValidationError>,
    pub warnings: Vec<String>,
    pub info: Vec<String>,
}

impl ValidationReport {
    pub fn new() -> Self {
        Self {
            is_valid: true,
            errors: Vec::new(),
            warnings: Vec::new(),
            info: Vec::new(),
        }
    }

    pub fn add_error(&mut self, error: ValidationError) {
        self.is_valid = false;
        self.errors.push(error);
    }

    pub fn add_warning(&mut self, warning: String) {
        self.warnings.push(warning);
    }

    pub fn add_info(&mut self, info: String) {
        self.info.push(info);
    }

    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string_pretty(self)
    }
}

impl Default for ValidationReport {
    fn default() -> Self {
        Self::new()
    }
}

/// Algorithm validator
pub struct AlgorithmValidator {
    pub max_qubits: u32,
    pub max_operators: usize,
    pub strict_mode: bool,
}

impl Default for AlgorithmValidator {
    fn default() -> Self {
        Self {
            max_qubits: 100,
            max_operators: 10000,
            strict_mode: false,
        }
    }
}

impl AlgorithmValidator {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_strict_mode(mut self) -> Self {
        self.strict_mode = true;
        self
    }

    pub fn with_max_qubits(mut self, max: u32) -> Self {
        self.max_qubits = max;
        self
    }

    /// Validate an algorithm specification
    pub fn validate(&self, spec: &AlgorithmSpec) -> ValidationReport {
        let mut report = ValidationReport::new();

        // 1. Validate qubit counts
        self.validate_qubits(spec, &mut report);

        // 2. Validate operators
        self.validate_operators(spec, &mut report);

        // 3. Validate state space
        self.validate_state_space(spec, &mut report);

        // 4. Validate schedule
        self.validate_schedule(spec, &mut report);

        // 5. Validate algorithm family consistency
        self.validate_family_consistency(spec, &mut report);

        // 6. Resource checks
        self.validate_resources(spec, &mut report);

        report
    }

    fn validate_qubits(&self, spec: &AlgorithmSpec, report: &mut ValidationReport) {
        let total_qubits: u32 = spec
            .state_space
            .discrete_registers
            .iter()
            .map(|r| r.dimension)
            .sum();

        if total_qubits == 0 {
            report.add_error(ValidationError::InvalidQubitCount(
                "Algorithm has zero qubits".to_string(),
            ));
        }

        if total_qubits > self.max_qubits {
            if self.strict_mode {
                report.add_error(ValidationError::InvalidQubitCount(format!(
                    "Qubit count {} exceeds maximum {}",
                    total_qubits, self.max_qubits
                )));
            } else {
                report.add_warning(format!(
                    "Qubit count {} is high (max recommended: {})",
                    total_qubits, self.max_qubits
                ));
            }
        }

        report.add_info(format!("Total qubits: {}", total_qubits));
    }

    fn validate_operators(&self, spec: &AlgorithmSpec, report: &mut ValidationReport) {
        let operator_count = spec.operators.len();

        if operator_count == 0 {
            report.add_warning("Algorithm has no operators".to_string());
        }

        if operator_count > self.max_operators {
            if self.strict_mode {
                report.add_error(ValidationError::InvalidOperator(format!(
                    "Operator count {} exceeds maximum {}",
                    operator_count, self.max_operators
                )));
            } else {
                report.add_warning(format!(
                    "Operator count {} is very high",
                    operator_count
                ));
            }
        }

        // Check operator validity
        for (idx, op) in spec.operators.iter().enumerate() {
            // Check operator ID is not empty
            if op.id.is_empty() {
                report.add_error(ValidationError::InvalidOperator(format!(
                    "Operator {} has empty ID",
                    idx
                )));
            }

            // Check parametrization is not empty for certain roles
            if matches!(op.role, fuq_core::OperatorRole::AnsatzLayer)
                && op.parametrization.is_empty()
            {
                report.add_warning(format!(
                    "Operator {} (AnsatzLayer) has no parametrization specified",
                    idx
                ));
            }
        }

        report.add_info(format!("Total operators: {}", operator_count));
    }

    fn validate_state_space(&self, spec: &AlgorithmSpec, report: &mut ValidationReport) {
        // Check discrete registers
        if spec.state_space.discrete_registers.is_empty() {
            report.add_error(ValidationError::InconsistentStateSpace(
                "No discrete registers defined".to_string(),
            ));
        }

        for (idx, reg) in spec.state_space.discrete_registers.iter().enumerate() {
            if reg.dimension == 0 {
                report.add_error(ValidationError::InconsistentStateSpace(format!(
                    "Register {} has zero dimension",
                    idx
                )));
            }

            if reg.dimension > 1000 {
                report.add_warning(format!(
                    "Register {} has very large dimension: {}",
                    idx, reg.dimension
                ));
            }
        }

        // Check continuous space
        use fuq_core::ContinuousKind;
        match spec.state_space.continuous_space.kind {
            ContinuousKind::None => {
                report.add_info("No continuous parameters".to_string());
            }
            ContinuousKind::ParameterSpace => {
                if spec.state_space.continuous_space.dim == 0 {
                    report.add_warning("Parameter space has zero dimensions".to_string());
                }
            }
            ContinuousKind::Geometry => {
                if spec.state_space.continuous_space.dim < 2 {
                    report.add_warning("Geometry space has very low dimension".to_string());
                }
            }
        }
    }

    fn validate_schedule(&self, spec: &AlgorithmSpec, report: &mut ValidationReport) {
        if let Some(ref schedule) = spec.schedule {
            // Validate Scorpio schedule
            if schedule.windows.is_empty() {
                report.add_warning("Schedule has no windows defined".to_string());
            }

            // Check operator_ids reference existing operators
            for (idx, window) in schedule.windows.iter().enumerate() {
                let operator_exists = spec
                    .operators
                    .iter()
                    .any(|op| op.id == window.operator_id);

                if !operator_exists {
                    report.add_error(ValidationError::InvalidSchedule(format!(
                        "Schedule window {} references non-existent operator '{}'",
                        idx, window.operator_id
                    )));
                }
            }

            report.add_info(format!(
                "Scorpio schedule: {} cycles, {} windows",
                schedule.num_cycles,
                schedule.windows.len()
            ));
        } else {
            report.add_info("No Scorpio schedule defined (discrete algorithm)".to_string());
        }
    }

    fn validate_family_consistency(&self, spec: &AlgorithmSpec, report: &mut ValidationReport) {
        use fuq_core::{AlgorithmFamily, ContinuousKind};

        // Family-specific validation
        match spec.family {
            AlgorithmFamily::GroverLikeSearch => {
                // Grover typically needs 2^n qubits for search
                let total_qubits: u32 = spec
                    .state_space
                    .discrete_registers
                    .iter()
                    .map(|r| r.dimension)
                    .sum();

                if !total_qubits.is_power_of_two() {
                    report.add_warning(format!(
                        "Grover-like search typically uses power-of-2 qubits, got {}",
                        total_qubits
                    ));
                }
            }
            AlgorithmFamily::QAOA | AlgorithmFamily::QAOAAdaptive => {
                // QAOA needs operators
                if spec.operators.is_empty() {
                    report.add_warning("QAOA algorithm should have mixing and problem operators".to_string());
                }
            }
            AlgorithmFamily::VQE | AlgorithmFamily::VQEAnsatzZoo => {
                // VQE needs continuous parameters
                if spec.state_space.continuous_space.kind == ContinuousKind::None {
                    report.add_warning(
                        "VQE algorithm typically needs continuous parameter space".to_string(),
                    );
                }
            }
            _ => {
                // Other families: no specific checks
            }
        }

        report.add_info(format!("Algorithm family: {:?}", spec.family));
    }

    fn validate_resources(&self, spec: &AlgorithmSpec, report: &mut ValidationReport) {
        // Estimate resource requirements
        let total_qubits: u32 = spec
            .state_space
            .discrete_registers
            .iter()
            .map(|r| r.dimension)
            .sum();

        if total_qubits > 30 {
            report.add_warning(format!(
                "{} qubits requires > 8GB memory for statevector simulation",
                total_qubits
            ));
        }

        if total_qubits > 40 {
            report.add_error(ValidationError::ResourceConstraintViolation(format!(
                "{} qubits is beyond classical simulation capacity",
                total_qubits
            )));
        }

        let estimated_gates = spec.operators.len();
        if estimated_gates > 100000 {
            report.add_warning(format!(
                "{} gates may take very long to execute",
                estimated_gates
            ));
        }
    }

    /// Quick validation (basic checks only)
    pub fn validate_quick(&self, spec: &AlgorithmSpec) -> bool {
        let total_qubits: u32 = spec
            .state_space
            .discrete_registers
            .iter()
            .map(|r| r.dimension)
            .sum();

        total_qubits > 0 && total_qubits <= self.max_qubits && !spec.operators.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use fuq_core::AlgorithmFamily;

    #[test]
    fn test_validator_creation() {
        let validator = AlgorithmValidator::new();
        assert_eq!(validator.max_qubits, 100);
        assert!(!validator.strict_mode);
    }

    #[test]
    fn test_valid_algorithm() {
        let validator = AlgorithmValidator::new();
        let spec = AlgorithmSpec::new_empty(AlgorithmFamily::GroverLikeSearch);

        let report = validator.validate(&spec);
        // May have warnings but should not have critical errors for empty spec
        assert!(report.errors.is_empty() || !report.errors.iter().any(|e| matches!(e, ValidationError::InvalidQubitCount(_))));
    }

    #[test]
    fn test_quick_validation() {
        let validator = AlgorithmValidator::new();
        let spec = AlgorithmSpec::new_empty(AlgorithmFamily::QAOA);

        // Quick validation should pass for reasonable specs
        let _is_valid = validator.validate_quick(&spec);
        // Allow it to pass or fail - just test that it doesn't panic
    }

    #[test]
    fn test_validation_report_json() {
        let mut report = ValidationReport::new();
        report.add_info("Test info".to_string());
        report.add_warning("Test warning".to_string());

        let json = report.to_json().unwrap();
        assert!(json.contains("Test info"));
        assert!(json.contains("Test warning"));
    }
}
