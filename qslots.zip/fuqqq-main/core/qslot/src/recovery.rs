use crate::QSlotError;
use std::collections::HashMap;
use std::time::Duration;
use tracing::{debug, warn};

/// Error recovery manager with configurable retry policies
///
/// Handles transient errors with intelligent retry strategies including
/// exponential backoff and circuit breaker patterns.
pub struct ErrorRecoveryManager {
    retry_policies: HashMap<String, RetryPolicy>,
    circuit_breakers: HashMap<String, CircuitBreaker>,
}

/// Retry policy for error recovery
#[derive(Debug, Clone)]
pub struct RetryPolicy {
    pub max_retries: usize,
    pub backoff_strategy: BackoffStrategy,
    pub retryable_errors: Vec<ErrorClass>,
}

/// Backoff strategy for retries
#[derive(Debug, Clone)]
pub enum BackoffStrategy {
    /// Fixed delay between retries
    Constant(Duration),

    /// Linearly increasing delay
    Linear { base: Duration, increment: Duration },

    /// Exponentially increasing delay
    Exponential { base: Duration, multiplier: f64 },
}

/// Classification of errors for retry logic
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ErrorClass {
    /// Transient errors that may succeed on retry
    Transient,

    /// Errors that are unlikely to succeed on retry
    Permanent,

    /// Resource exhaustion errors
    ResourceExhaustion,

    /// Validation errors (should not retry)
    Validation,
}

/// Circuit breaker state machine
#[derive(Debug, Clone)]
pub struct CircuitBreaker {
    state: CircuitState,
    failure_threshold: usize,
    success_threshold: usize,
    timeout: Duration,
    failure_count: usize,
    success_count: usize,
    last_failure_time: Option<std::time::Instant>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CircuitState {
    Closed,    // Normal operation
    Open,      // Failing, reject requests
    HalfOpen,  // Testing if service recovered
}

/// Result of a recovery attempt
#[derive(Debug)]
pub enum RecoveryResult<T> {
    /// Operation succeeded
    Success(T),

    /// Operation failed after all retries
    Failed {
        last_error: QSlotError,
        attempts: usize,
    },

    /// Circuit breaker is open
    CircuitOpen,
}

impl Default for RetryPolicy {
    fn default() -> Self {
        Self {
            max_retries: 3,
            backoff_strategy: BackoffStrategy::Exponential {
                base: Duration::from_millis(100),
                multiplier: 2.0,
            },
            retryable_errors: vec![ErrorClass::Transient, ErrorClass::ResourceExhaustion],
        }
    }
}

impl BackoffStrategy {
    /// Calculate delay for given attempt number
    pub fn delay(&self, attempt: usize) -> Duration {
        match self {
            BackoffStrategy::Constant(d) => *d,
            BackoffStrategy::Linear { base, increment } => *base + *increment * attempt as u32,
            BackoffStrategy::Exponential { base, multiplier } => {
                let factor = multiplier.powi(attempt as i32);
                Duration::from_millis((base.as_millis() as f64 * factor) as u64)
            }
        }
    }
}

impl CircuitBreaker {
    pub fn new(failure_threshold: usize, timeout: Duration) -> Self {
        Self {
            state: CircuitState::Closed,
            failure_threshold,
            success_threshold: 2,
            timeout,
            failure_count: 0,
            success_count: 0,
            last_failure_time: None,
        }
    }

    /// Check if circuit breaker allows operation
    pub fn can_execute(&mut self) -> bool {
        match self.state {
            CircuitState::Closed => true,
            CircuitState::Open => {
                if let Some(last_failure) = self.last_failure_time {
                    if last_failure.elapsed() > self.timeout {
                        debug!("Circuit breaker transitioning to HalfOpen");
                        self.state = CircuitState::HalfOpen;
                        self.success_count = 0;
                        true
                    } else {
                        false
                    }
                } else {
                    false
                }
            }
            CircuitState::HalfOpen => true,
        }
    }

    /// Record successful operation
    pub fn record_success(&mut self) {
        match self.state {
            CircuitState::HalfOpen => {
                self.success_count += 1;
                if self.success_count >= self.success_threshold {
                    debug!("Circuit breaker closing after successful recovery");
                    self.state = CircuitState::Closed;
                    self.failure_count = 0;
                    self.success_count = 0;
                }
            }
            CircuitState::Closed => {
                self.failure_count = 0;
            }
            CircuitState::Open => {}
        }
    }

    /// Record failed operation
    pub fn record_failure(&mut self) {
        self.last_failure_time = Some(std::time::Instant::now());

        match self.state {
            CircuitState::Closed => {
                self.failure_count += 1;
                if self.failure_count >= self.failure_threshold {
                    warn!(
                        "Circuit breaker opening after {} failures",
                        self.failure_count
                    );
                    self.state = CircuitState::Open;
                }
            }
            CircuitState::HalfOpen => {
                warn!("Circuit breaker reopening after failure in HalfOpen state");
                self.state = CircuitState::Open;
                self.success_count = 0;
            }
            CircuitState::Open => {}
        }
    }
}

impl ErrorRecoveryManager {
    pub fn new() -> Self {
        let mut retry_policies = HashMap::new();

        // Default policies for different operation types
        retry_policies.insert(
            "algorithm_generation".to_string(),
            RetryPolicy {
                max_retries: 3,
                backoff_strategy: BackoffStrategy::Exponential {
                    base: Duration::from_millis(100),
                    multiplier: 2.0,
                },
                retryable_errors: vec![ErrorClass::Transient],
            },
        );

        retry_policies.insert(
            "surgery_loop".to_string(),
            RetryPolicy {
                max_retries: 2,
                backoff_strategy: BackoffStrategy::Linear {
                    base: Duration::from_millis(50),
                    increment: Duration::from_millis(50),
                },
                retryable_errors: vec![ErrorClass::Transient, ErrorClass::ResourceExhaustion],
            },
        );

        retry_policies.insert(
            "persistence".to_string(),
            RetryPolicy {
                max_retries: 5,
                backoff_strategy: BackoffStrategy::Exponential {
                    base: Duration::from_millis(50),
                    multiplier: 1.5,
                },
                retryable_errors: vec![ErrorClass::Transient],
            },
        );

        let mut circuit_breakers = HashMap::new();
        circuit_breakers.insert(
            "algorithm_generation".to_string(),
            CircuitBreaker::new(5, Duration::from_secs(30)),
        );

        Self {
            retry_policies,
            circuit_breakers,
        }
    }

    /// Execute operation with retry and circuit breaker protection
    pub fn execute_with_recovery<F, T>(
        &mut self,
        mut operation: F,
        operation_name: &str,
    ) -> RecoveryResult<T>
    where
        F: FnMut() -> Result<T, QSlotError>,
    {
        // Check circuit breaker
        if let Some(breaker) = self.circuit_breakers.get_mut(operation_name) {
            if !breaker.can_execute() {
                warn!("Circuit breaker open for operation: {}", operation_name);
                return RecoveryResult::CircuitOpen;
            }
        }

        let policy = self
            .retry_policies
            .get(operation_name)
            .cloned()
            .unwrap_or_default();

        let mut attempts = 0;
        let mut last_error = None;

        while attempts <= policy.max_retries {
            match operation() {
                Ok(result) => {
                    debug!(
                        "Operation '{}' succeeded on attempt {}",
                        operation_name,
                        attempts + 1
                    );

                    // Record success in circuit breaker
                    if let Some(breaker) = self.circuit_breakers.get_mut(operation_name) {
                        breaker.record_success();
                    }

                    return RecoveryResult::Success(result);
                }
                Err(e) => {
                    attempts += 1;
                    last_error = Some(e);

                    if attempts <= policy.max_retries {
                        let delay = policy.backoff_strategy.delay(attempts - 1);
                        debug!(
                            "Operation '{}' failed on attempt {}, retrying after {:?}",
                            operation_name, attempts, delay
                        );
                        std::thread::sleep(delay);
                    }
                }
            }
        }

        // All retries exhausted - record failure
        if let Some(breaker) = self.circuit_breakers.get_mut(operation_name) {
            breaker.record_failure();
        }

        RecoveryResult::Failed {
            last_error: last_error.unwrap(),
            attempts,
        }
    }

    /// Classify error for retry decision
    pub fn classify_error(error: &QSlotError) -> ErrorClass {
        match error {
            QSlotError::ParseError(_) => ErrorClass::Validation,
            QSlotError::InvalidParameters(_) => ErrorClass::Validation,
            QSlotError::GenerationError(msg) => {
                if msg.contains("convergence") || msg.contains("timeout") {
                    ErrorClass::Transient
                } else {
                    ErrorClass::Permanent
                }
            }
        }
    }
}

impl Default for ErrorRecoveryManager {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_constant_backoff() {
        let strategy = BackoffStrategy::Constant(Duration::from_millis(100));
        assert_eq!(strategy.delay(0), Duration::from_millis(100));
        assert_eq!(strategy.delay(5), Duration::from_millis(100));
    }

    #[test]
    fn test_linear_backoff() {
        let strategy = BackoffStrategy::Linear {
            base: Duration::from_millis(100),
            increment: Duration::from_millis(50),
        };
        assert_eq!(strategy.delay(0), Duration::from_millis(100));
        assert_eq!(strategy.delay(1), Duration::from_millis(150));
        assert_eq!(strategy.delay(2), Duration::from_millis(200));
    }

    #[test]
    fn test_exponential_backoff() {
        let strategy = BackoffStrategy::Exponential {
            base: Duration::from_millis(100),
            multiplier: 2.0,
        };
        assert_eq!(strategy.delay(0), Duration::from_millis(100));
        assert_eq!(strategy.delay(1), Duration::from_millis(200));
        assert_eq!(strategy.delay(2), Duration::from_millis(400));
    }

    #[test]
    fn test_circuit_breaker_states() {
        let mut breaker = CircuitBreaker::new(3, Duration::from_millis(100));

        // Initially closed
        assert_eq!(breaker.state, CircuitState::Closed);
        assert!(breaker.can_execute());

        // Record failures
        breaker.record_failure();
        assert_eq!(breaker.state, CircuitState::Closed);
        breaker.record_failure();
        assert_eq!(breaker.state, CircuitState::Closed);
        breaker.record_failure();

        // Should open after threshold
        assert_eq!(breaker.state, CircuitState::Open);
        assert!(!breaker.can_execute());

        // Wait for timeout
        std::thread::sleep(Duration::from_millis(150));
        assert!(breaker.can_execute());
        assert_eq!(breaker.state, CircuitState::HalfOpen);

        // Success should close
        breaker.record_success();
        breaker.record_success();
        assert_eq!(breaker.state, CircuitState::Closed);
    }

    #[test]
    fn test_recovery_manager_success() {
        let mut manager = ErrorRecoveryManager::new();

        let result = manager.execute_with_recovery(|| Ok::<_, QSlotError>(42), "test_operation");

        match result {
            RecoveryResult::Success(value) => assert_eq!(value, 42),
            _ => panic!("Expected success"),
        }
    }

    #[test]
    fn test_recovery_manager_retry() {
        let mut manager = ErrorRecoveryManager::new();
        let mut attempt_count = 0;

        let result = manager.execute_with_recovery(
            || {
                attempt_count += 1;
                if attempt_count < 3 {
                    Err(QSlotError::GenerationError("timeout".to_string()))
                } else {
                    Ok(42)
                }
            },
            "algorithm_generation",
        );

        match result {
            RecoveryResult::Success(value) => {
                assert_eq!(value, 42);
                assert_eq!(attempt_count, 3);
            }
            _ => panic!("Expected success after retries"),
        }
    }

    #[test]
    fn test_recovery_manager_failure() {
        let mut manager = ErrorRecoveryManager::new();

        let result = manager.execute_with_recovery(
            || Err(QSlotError::GenerationError("permanent".to_string())),
            "algorithm_generation",
        );

        match result {
            RecoveryResult::Failed { attempts, .. } => {
                assert_eq!(attempts, 4); // 1 initial + 3 retries
            }
            _ => panic!("Expected failure"),
        }
    }
}
