use fuq_core::{AlgorithmScore, SurgeryParams};
use metatron_core::{MetatronRoute, ProblemSpec, ProblemType};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use tracing::{debug, info, warn};

/// Seraphic Calibration: Feedback-based adaptation
///
/// This is the core learning mechanism of Metatron Q⊗DASH.
/// It learns from experience (scores) and adapts routing and surgery parameters.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SeraphicCalibrator {
    /// Experience buffer: Track (Problem, Route, Score)
    experience: Vec<Experience>,

    /// Learned biases for routing per problem type
    routing_biases: HashMap<ProblemType, RoutingBias>,

    /// Adaptive surgery parameters
    surgery_params: AdaptiveSurgeryParams,

    /// Convergence statistics
    convergence_stats: ConvergenceStats,

    /// Learning rate (how fast to adapt)
    learning_rate: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Experience {
    problem_signature: String,
    problem_type: ProblemType,
    route_signature: String,
    route_length: usize,
    score: AlgorithmScore,
    timestamp: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoutingBias {
    /// Probability weights for move types [Invert, Rotate, Mirror, Convert]
    pub move_type_weights: [f64; 4],

    /// Preferred route lengths
    pub preferred_length_mean: f64,
    pub preferred_length_std: f64,

    /// Axis preferences (for S7 operations)
    pub axis_weights: [f64; 7],

    /// Number of experiences used to compute this bias
    experience_count: usize,
}

impl Default for RoutingBias {
    fn default() -> Self {
        Self {
            move_type_weights: [0.25, 0.25, 0.25, 0.25], // Uniform
            preferred_length_mean: 5.0,
            preferred_length_std: 2.0,
            axis_weights: [1.0 / 7.0; 7], // Uniform
            experience_count: 0,
        }
    }
}

impl RoutingBias {
    /// Convert to metatron_core routing bias for route sampling
    pub fn to_metatron_bias(&self) -> metatron_core::routing::RoutingBias {
        metatron_core::routing::RoutingBias {
            move_type_weights: self.move_type_weights,
            preferred_length_mean: self.preferred_length_mean,
            preferred_length_std: self.preferred_length_std,
            axis_weights: self.axis_weights,
        }
    }

    /// Get the number of experiences used to compute this bias
    pub fn experience_count(&self) -> usize {
        self.experience_count
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct AdaptiveSurgeryParams {
    base_params: SurgeryParams,

    /// Learned adjustments
    step_size_multiplier: f64,      // Surgery step size
    max_iters_multiplier: f64,      // Iterations
    convergence_threshold_multiplier: f64,  // Convergence threshold
}

impl Default for AdaptiveSurgeryParams {
    fn default() -> Self {
        Self {
            base_params: SurgeryParams::default(),
            step_size_multiplier: 1.0,
            max_iters_multiplier: 1.0,
            convergence_threshold_multiplier: 1.0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ConvergenceStats {
    total_spins: usize,
    quality_history: Vec<f64>,
}

impl Default for ConvergenceStats {
    fn default() -> Self {
        Self {
            total_spins: 0,
            quality_history: Vec::new(),
        }
    }
}

impl SeraphicCalibrator {
    pub fn new() -> Self {
        Self {
            experience: Vec::new(),
            routing_biases: HashMap::new(),
            surgery_params: AdaptiveSurgeryParams::default(),
            convergence_stats: ConvergenceStats::default(),
            learning_rate: 0.1,
        }
    }

    /// Add experience from a spin
    pub fn add_experience(
        &mut self,
        problem_spec: &ProblemSpec,
        route: &MetatronRoute,
        score: &AlgorithmScore,
    ) {
        let exp = Experience {
            problem_signature: Self::compute_problem_signature(problem_spec),
            problem_type: problem_spec.problem_type,
            route_signature: route.signature.clone(),
            route_length: route.moves.len(),
            score: score.clone(),
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_secs(),
        };

        debug!("Adding experience: problem_type={:?}, quality={:.3}",
               exp.problem_type, exp.score.quality_score);

        self.experience.push(exp);
        self.convergence_stats.total_spins += 1;
        self.convergence_stats.quality_history.push(score.quality_score);

        // Update biases
        self.update_routing_biases(problem_spec.problem_type);
        self.update_surgery_params();
    }

    fn compute_problem_signature(problem_spec: &ProblemSpec) -> String {
        // Simple hash: Type + Constraints count + Text length
        format!(
            "{:?}_{}_{}",
            problem_spec.problem_type,
            problem_spec.constraints.len(),
            problem_spec.raw_text.len() / 100
        )
    }

    fn update_routing_biases(&mut self, problem_type: ProblemType) {
        // Get recent experiences for this problem type
        let relevant_exp: Vec<&Experience> = self
            .experience
            .iter()
            .rev()
            .take(100) // Look at last 100 experiences
            .filter(|e| e.problem_type == problem_type)
            .collect();

        if relevant_exp.is_empty() {
            debug!("No experiences yet for {:?}", problem_type);
            return;
        }

        debug!("Updating routing bias for {:?} with {} experiences",
               problem_type, relevant_exp.len());

        // Compute weighted statistics based on scores
        let mut total_weight = 0.0;
        let mut length_sum = 0.0;
        let mut length_sq_sum = 0.0;

        // Simple heuristic: Use route length as signal
        // Better routes tend to have certain lengths
        for exp in &relevant_exp {
            let weight = exp.score.quality_score.max(0.01); // Higher quality → more weight
            total_weight += weight;

            length_sum += weight * exp.route_length as f64;
            length_sq_sum += weight * (exp.route_length as f64).powi(2);
        }

        if total_weight > 0.0 {
            // Update bias
            let bias = self.routing_biases.entry(problem_type).or_default();

            // Update preferred length (weighted mean and std)
            let new_mean = length_sum / total_weight;
            let variance = (length_sq_sum / total_weight) - new_mean.powi(2);
            let new_std = variance.max(0.0).sqrt().max(1.0);

            // Exponential moving average
            let alpha = self.learning_rate;
            bias.preferred_length_mean =
                (1.0 - alpha) * bias.preferred_length_mean + alpha * new_mean;
            bias.preferred_length_std =
                (1.0 - alpha) * bias.preferred_length_std + alpha * new_std;

            bias.experience_count = relevant_exp.len();

            info!("Updated routing bias for {:?}: mean_length={:.2}, std={:.2}, experiences={}",
                  problem_type, bias.preferred_length_mean, bias.preferred_length_std,
                  bias.experience_count);
        }
    }

    fn update_surgery_params(&mut self) {
        // Analyze recent convergence behavior
        if self.convergence_stats.quality_history.len() < 10 {
            return;
        }

        let recent: Vec<f64> = self
            .convergence_stats
            .quality_history
            .iter()
            .rev()
            .take(20)
            .copied()
            .collect();

        let mean: f64 = recent.iter().sum::<f64>() / recent.len() as f64;

        // Compute trend (simple linear regression slope)
        let trend = self.compute_quality_trend(&recent);

        debug!("Quality stats: mean={:.3}, trend={:.4}", mean, trend);

        // Adaptive strategy:
        // If quality is stagnating (low trend) and mean is low → increase exploration
        // If quality is high → can reduce iterations (faster)

        if trend.abs() < 0.01 && mean < 0.5 {
            // Stagnation → increase exploration
            self.surgery_params.max_iters_multiplier *= 1.05;
            self.surgery_params.step_size_multiplier *= 0.98; // Smaller steps, more careful
            warn!("Quality stagnating, increasing surgery exploration");
        } else if mean > 0.7 && trend > 0.0 {
            // High quality and improving → can optimize for speed
            self.surgery_params.max_iters_multiplier *= 0.98;
            info!("High quality achieved, optimizing for speed");
        } else if trend < -0.02 {
            // Quality degrading → reset to defaults
            self.surgery_params.max_iters_multiplier =
                self.surgery_params.max_iters_multiplier * 0.95 + 1.0 * 0.05;
            warn!("Quality degrading, resetting surgery parameters");
        }

        // Clamp multipliers to reasonable ranges
        self.surgery_params.max_iters_multiplier =
            self.surgery_params.max_iters_multiplier.clamp(0.5, 2.0);
        self.surgery_params.step_size_multiplier =
            self.surgery_params.step_size_multiplier.clamp(0.5, 1.5);
        self.surgery_params.convergence_threshold_multiplier =
            self.surgery_params.convergence_threshold_multiplier.clamp(0.5, 2.0);
    }

    fn compute_quality_trend(&self, recent: &[f64]) -> f64 {
        if recent.len() < 2 {
            return 0.0;
        }

        // Simple linear regression slope
        let n = recent.len() as f64;
        let x_mean = (n - 1.0) / 2.0;
        let y_mean: f64 = recent.iter().sum::<f64>() / n;

        let mut numerator = 0.0;
        let mut denominator = 0.0;

        for (i, &y) in recent.iter().enumerate() {
            let x = i as f64;
            numerator += (x - x_mean) * (y - y_mean);
            denominator += (x - x_mean).powi(2);
        }

        if denominator == 0.0 {
            0.0
        } else {
            numerator / denominator
        }
    }

    /// Get routing bias for problem type
    pub fn get_routing_bias(&self, problem_type: ProblemType) -> RoutingBias {
        self.routing_biases
            .get(&problem_type)
            .cloned()
            .unwrap_or_else(|| {
                debug!("No bias learned yet for {:?}, using default", problem_type);
                RoutingBias::default()
            })
    }

    /// Get adapted surgery parameters
    pub fn get_surgery_params(&self) -> SurgeryParams {
        let mut params = self.surgery_params.base_params.clone();
        params.step_size *= self.surgery_params.step_size_multiplier;
        params.max_iterations =
            (params.max_iterations as f64 * self.surgery_params.max_iters_multiplier) as usize;
        params.convergence_threshold *= self.surgery_params.convergence_threshold_multiplier;
        params
    }

    /// Get quality trend (positive = improving)
    pub fn quality_trend(&self) -> f64 {
        if self.convergence_stats.quality_history.len() < 10 {
            return 0.0;
        }

        let recent: Vec<f64> = self
            .convergence_stats
            .quality_history
            .iter()
            .rev()
            .take(20)
            .copied()
            .collect();

        self.compute_quality_trend(&recent)
    }

    /// Get statistics for reporting
    pub fn get_stats(&self) -> CalibrationStats {
        let mean_quality = if self.convergence_stats.quality_history.is_empty() {
            0.0
        } else {
            self.convergence_stats.quality_history.iter().sum::<f64>()
                / self.convergence_stats.quality_history.len() as f64
        };

        CalibrationStats {
            total_experiences: self.experience.len(),
            total_spins: self.convergence_stats.total_spins,
            mean_quality,
            quality_trend: self.quality_trend(),
            learned_biases: self.routing_biases.len(),
        }
    }

    /// Get number of experiences
    pub fn experience_count(&self) -> usize {
        self.experience.len()
    }
}

impl Default for SeraphicCalibrator {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CalibrationStats {
    pub total_experiences: usize,
    pub total_spins: usize,
    pub mean_quality: f64,
    pub quality_trend: f64,
    pub learned_biases: usize,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_seraphic_calibrator_new() {
        let calibrator = SeraphicCalibrator::new();
        assert_eq!(calibrator.experience_count(), 0);
    }

    #[test]
    fn test_routing_bias_default() {
        let bias = RoutingBias::default();
        assert_eq!(bias.move_type_weights.iter().sum::<f64>(), 1.0);
    }

    #[test]
    fn test_quality_trend_computation() {
        let calibrator = SeraphicCalibrator::new();

        // Improving trend
        let improving = vec![0.3, 0.35, 0.4, 0.45, 0.5];
        let trend = calibrator.compute_quality_trend(&improving);
        assert!(trend > 0.0, "Expected positive trend for improving quality");

        // Declining trend
        let declining = vec![0.5, 0.45, 0.4, 0.35, 0.3];
        let trend = calibrator.compute_quality_trend(&declining);
        assert!(trend < 0.0, "Expected negative trend for declining quality");
    }
}
