use fuq_core::AlgorithmScore;
use lru::LruCache;
use metatron_core::{MetatronRoute, ProblemSpec, ProblemType};
use serde::{Deserialize, Serialize};
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};
use std::num::NonZeroUsize;
use std::sync::{Arc, RwLock};

/// Signature types for different cache levels
pub type RouteSignature = u64;
pub type ProblemSignature = u64;
pub type AlgorithmSignature = u64;

/// Multi-tier caching system for algorithm generation
///
/// This cache implements three levels:
/// 1. Route cache: Maps problem characteristics to MetatronRoutes
/// 2. Problem cache: Maps problem signatures to algorithm candidates
/// 3. Score cache: Maps algorithm signatures to quality scores
pub struct AlgorithmCache {
    /// Cache for MetatronRoutes indexed by problem signature
    route_cache: Arc<RwLock<LruCache<ProblemSignature, Vec<MetatronRoute>>>>,

    /// Cache for generated algorithm candidates
    algorithm_cache: Arc<RwLock<LruCache<AlgorithmSignature, CachedAlgorithm>>>,

    /// Cache for quality scores
    score_cache: Arc<RwLock<LruCache<AlgorithmSignature, AlgorithmScore>>>,

    /// Statistics tracking
    stats: Arc<RwLock<CacheStatistics>>,
}

/// Cached algorithm with metadata
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CachedAlgorithm {
    pub route_signature: String,
    pub problem_type: ProblemType,
    pub family_name: String,
    pub num_qubits: u32,
    pub timestamp: chrono::DateTime<chrono::Utc>,
}

/// Cache performance statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CacheStatistics {
    pub route_hits: usize,
    pub route_misses: usize,
    pub algorithm_hits: usize,
    pub algorithm_misses: usize,
    pub score_hits: usize,
    pub score_misses: usize,
    pub total_queries: usize,
}

impl Default for CacheStatistics {
    fn default() -> Self {
        Self {
            route_hits: 0,
            route_misses: 0,
            algorithm_hits: 0,
            algorithm_misses: 0,
            score_hits: 0,
            score_misses: 0,
            total_queries: 0,
        }
    }
}

impl CacheStatistics {
    /// Calculate overall hit rate
    pub fn hit_rate(&self) -> f64 {
        if self.total_queries == 0 {
            0.0
        } else {
            let total_hits = self.route_hits + self.algorithm_hits + self.score_hits;
            total_hits as f64 / self.total_queries as f64
        }
    }

    /// Calculate route cache hit rate
    pub fn route_hit_rate(&self) -> f64 {
        let total = self.route_hits + self.route_misses;
        if total == 0 {
            0.0
        } else {
            self.route_hits as f64 / total as f64
        }
    }

    /// Calculate algorithm cache hit rate
    pub fn algorithm_hit_rate(&self) -> f64 {
        let total = self.algorithm_hits + self.algorithm_misses;
        if total == 0 {
            0.0
        } else {
            self.algorithm_hits as f64 / total as f64
        }
    }

    /// Calculate score cache hit rate
    pub fn score_hit_rate(&self) -> f64 {
        let total = self.score_hits + self.score_misses;
        if total == 0 {
            0.0
        } else {
            self.score_hits as f64 / total as f64
        }
    }

    /// Export to JSON
    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string_pretty(self)
    }
}

impl AlgorithmCache {
    /// Create a new cache with default capacity
    pub fn new() -> Self {
        Self::with_capacity(1000, 500, 200)
    }

    /// Create a new cache with custom capacities
    pub fn with_capacity(
        route_capacity: usize,
        algorithm_capacity: usize,
        score_capacity: usize,
    ) -> Self {
        Self {
            route_cache: Arc::new(RwLock::new(LruCache::new(
                NonZeroUsize::new(route_capacity).unwrap(),
            ))),
            algorithm_cache: Arc::new(RwLock::new(LruCache::new(
                NonZeroUsize::new(algorithm_capacity).unwrap(),
            ))),
            score_cache: Arc::new(RwLock::new(LruCache::new(
                NonZeroUsize::new(score_capacity).unwrap(),
            ))),
            stats: Arc::new(RwLock::new(CacheStatistics::default())),
        }
    }

    /// Compute signature for a problem spec
    pub fn problem_signature(problem: &ProblemSpec) -> ProblemSignature {
        let mut hasher = DefaultHasher::new();

        // Hash problem type
        format!("{:?}", problem.problem_type).hash(&mut hasher);

        // Hash key characteristics of the problem
        problem.objective_description.hash(&mut hasher);
        problem.input_structure.hash(&mut hasher);

        // Hash constraints
        for constraint in &problem.constraints {
            constraint.hash(&mut hasher);
        }

        hasher.finish()
    }

    /// Compute signature for an algorithm (route + problem combo)
    pub fn algorithm_signature(route: &MetatronRoute, problem: &ProblemSpec) -> AlgorithmSignature {
        let mut hasher = DefaultHasher::new();

        route.signature.hash(&mut hasher);
        Self::problem_signature(problem).hash(&mut hasher);

        hasher.finish()
    }

    /// Get cached routes for a problem
    pub fn get_routes(&self, problem: &ProblemSpec) -> Option<Vec<MetatronRoute>> {
        let sig = Self::problem_signature(problem);

        let mut cache = self.route_cache.write().unwrap();
        let mut stats = self.stats.write().unwrap();
        stats.total_queries += 1;

        if let Some(routes) = cache.get(&sig) {
            stats.route_hits += 1;
            Some(routes.clone())
        } else {
            stats.route_misses += 1;
            None
        }
    }

    /// Cache routes for a problem
    pub fn put_routes(&self, problem: &ProblemSpec, routes: Vec<MetatronRoute>) {
        let sig = Self::problem_signature(problem);
        let mut cache = self.route_cache.write().unwrap();
        cache.put(sig, routes);
    }

    /// Get cached algorithm
    pub fn get_algorithm(
        &self,
        route: &MetatronRoute,
        problem: &ProblemSpec,
    ) -> Option<CachedAlgorithm> {
        let sig = Self::algorithm_signature(route, problem);

        let mut cache = self.algorithm_cache.write().unwrap();
        let mut stats = self.stats.write().unwrap();
        stats.total_queries += 1;

        if let Some(algorithm) = cache.get(&sig) {
            stats.algorithm_hits += 1;
            Some(algorithm.clone())
        } else {
            stats.algorithm_misses += 1;
            None
        }
    }

    /// Cache algorithm
    pub fn put_algorithm(
        &self,
        route: &MetatronRoute,
        problem: &ProblemSpec,
        algorithm: CachedAlgorithm,
    ) {
        let sig = Self::algorithm_signature(route, problem);
        let mut cache = self.algorithm_cache.write().unwrap();
        cache.put(sig, algorithm);
    }

    /// Get cached score
    pub fn get_score(
        &self,
        route: &MetatronRoute,
        problem: &ProblemSpec,
    ) -> Option<AlgorithmScore> {
        let sig = Self::algorithm_signature(route, problem);

        let mut cache = self.score_cache.write().unwrap();
        let mut stats = self.stats.write().unwrap();
        stats.total_queries += 1;

        if let Some(score) = cache.get(&sig) {
            stats.score_hits += 1;
            Some(score.clone())
        } else {
            stats.score_misses += 1;
            None
        }
    }

    /// Cache score
    pub fn put_score(
        &self,
        route: &MetatronRoute,
        problem: &ProblemSpec,
        score: AlgorithmScore,
    ) {
        let sig = Self::algorithm_signature(route, problem);
        let mut cache = self.score_cache.write().unwrap();
        cache.put(sig, score);
    }

    /// Get statistics
    pub fn statistics(&self) -> CacheStatistics {
        self.stats.read().unwrap().clone()
    }

    /// Clear all caches
    pub fn clear(&self) {
        self.route_cache.write().unwrap().clear();
        self.algorithm_cache.write().unwrap().clear();
        self.score_cache.write().unwrap().clear();
        *self.stats.write().unwrap() = CacheStatistics::default();
    }

    /// Get cache sizes
    pub fn sizes(&self) -> (usize, usize, usize) {
        (
            self.route_cache.read().unwrap().len(),
            self.algorithm_cache.read().unwrap().len(),
            self.score_cache.read().unwrap().len(),
        )
    }

    /// Clone for thread-safe sharing
    pub fn clone_shared(&self) -> Self {
        Self {
            route_cache: Arc::clone(&self.route_cache),
            algorithm_cache: Arc::clone(&self.algorithm_cache),
            score_cache: Arc::clone(&self.score_cache),
            stats: Arc::clone(&self.stats),
        }
    }
}

impl Default for AlgorithmCache {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use metatron_core::MetatronMove;

    fn create_test_problem() -> ProblemSpec {
        ProblemSpec {
            id: "test".to_string(),
            raw_text: "test problem".to_string(),
            problem_type: ProblemType::Search,
            input_structure: "graph".to_string(),
            objective_description: "find shortest path".to_string(),
            constraints: vec![],
            solution_quality: metatron_core::SolutionQuality::default(),
        }
    }

    fn create_test_route() -> MetatronRoute {
        MetatronRoute {
            moves: vec![
                MetatronMove::Invert { axis: 0 },
                MetatronMove::Rotate { axis: 1, angle: 1 },
            ],
            permutations: vec![metatron_core::S7Permutation::identity()],
            signature: "test_route".to_string(),
        }
    }

    #[test]
    fn test_cache_creation() {
        let cache = AlgorithmCache::new();
        let stats = cache.statistics();

        assert_eq!(stats.total_queries, 0);
        assert_eq!(stats.hit_rate(), 0.0);
    }

    #[test]
    fn test_route_caching() {
        let cache = AlgorithmCache::new();
        let problem = create_test_problem();
        let routes = vec![create_test_route()];

        // Cache miss
        assert!(cache.get_routes(&problem).is_none());

        // Store routes
        cache.put_routes(&problem, routes.clone());

        // Cache hit
        let cached = cache.get_routes(&problem).unwrap();
        assert_eq!(cached.len(), routes.len());
    }

    #[test]
    fn test_algorithm_caching() {
        let cache = AlgorithmCache::new();
        let problem = create_test_problem();
        let route = create_test_route();

        let algorithm = CachedAlgorithm {
            route_signature: "test".to_string(),
            problem_type: ProblemType::Search,
            family_name: "QAOA".to_string(),
            num_qubits: 4,
            timestamp: chrono::Utc::now(),
        };

        // Cache miss
        assert!(cache.get_algorithm(&route, &problem).is_none());

        // Store algorithm
        cache.put_algorithm(&route, &problem, algorithm.clone());

        // Cache hit
        let cached = cache.get_algorithm(&route, &problem).unwrap();
        assert_eq!(cached.family_name, algorithm.family_name);
    }

    #[test]
    fn test_statistics() {
        let cache = AlgorithmCache::new();
        let problem = create_test_problem();
        let route = create_test_route();

        // Generate some cache misses
        cache.get_routes(&problem);
        cache.get_algorithm(&route, &problem);
        cache.get_score(&route, &problem);

        let stats = cache.statistics();
        assert_eq!(stats.total_queries, 3);
        assert_eq!(stats.route_misses, 1);
        assert_eq!(stats.algorithm_misses, 1);
        assert_eq!(stats.score_misses, 1);
        assert_eq!(stats.hit_rate(), 0.0);

        // Store and retrieve for hits
        cache.put_routes(&problem, vec![route.clone()]);
        cache.get_routes(&problem);

        let stats = cache.statistics();
        assert_eq!(stats.route_hits, 1);
        assert!(stats.route_hit_rate() > 0.0);
    }

    #[test]
    fn test_clear() {
        let cache = AlgorithmCache::new();
        let problem = create_test_problem();
        let routes = vec![create_test_route()];

        cache.put_routes(&problem, routes);
        assert!(cache.get_routes(&problem).is_some());

        cache.clear();
        assert!(cache.get_routes(&problem).is_none());

        let stats = cache.statistics();
        assert_eq!(stats.total_queries, 0);
    }

    #[test]
    fn test_hit_rate_calculation() {
        let cache = AlgorithmCache::new();
        let problem = create_test_problem();
        let routes = vec![create_test_route()];

        // 3 misses
        cache.get_routes(&problem);
        cache.get_routes(&problem);
        cache.get_routes(&problem);

        // Store routes
        cache.put_routes(&problem, routes);

        // 7 hits
        for _ in 0..7 {
            cache.get_routes(&problem);
        }

        let stats = cache.statistics();
        assert_eq!(stats.route_hits, 7);
        assert_eq!(stats.route_misses, 3);

        // Hit rate should be 70%
        let hit_rate = stats.route_hit_rate();
        assert!((hit_rate - 0.7).abs() < 0.01);
    }
}
