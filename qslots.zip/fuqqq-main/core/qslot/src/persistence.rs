use crate::{SeraphicCalibrator, SessionAnalytics};
use fuq_core::AlgorithmScore;
use metatron_core::ProblemType;
use rusqlite::{params, Connection, Result as SqlResult};
use std::path::Path;
use tracing::{debug, info, warn};

/// Session persistence using SQLite
pub struct SessionStore {
    conn: Connection,
}

impl SessionStore {
    /// Open or create a new session store
    pub fn open<P: AsRef<Path>>(path: P) -> SqlResult<Self> {
        let path_str = path.as_ref().display();
        info!("Opening session store: {}", path_str);

        let conn = Connection::open(path)?;

        // Enable foreign keys
        conn.execute("PRAGMA foreign_keys = ON", [])?;

        // Create tables
        Self::create_tables(&conn)?;

        Ok(Self { conn })
    }

    fn create_tables(conn: &Connection) -> SqlResult<()> {
        debug!("Creating database tables");

        // Sessions table
        conn.execute(
            "CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL UNIQUE,
                timestamp INTEGER NOT NULL,
                problem_text TEXT NOT NULL,
                problem_type TEXT NOT NULL
            )",
            [],
        )?;

        // Spins table
        conn.execute(
            "CREATE TABLE IF NOT EXISTS spins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                spin_index INTEGER NOT NULL,
                route_signature TEXT NOT NULL,
                algorithm_family TEXT NOT NULL,
                num_qubits INTEGER NOT NULL,
                score_quality REAL NOT NULL,
                score_robustness REAL NOT NULL,
                score_novelty REAL NOT NULL,
                score_label TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                FOREIGN KEY(session_id) REFERENCES sessions(session_id)
            )",
            [],
        )?;

        // Seraphic state table
        conn.execute(
            "CREATE TABLE IF NOT EXISTS seraphic_state (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                state_json TEXT NOT NULL
            )",
            [],
        )?;

        // Analytics snapshots table
        conn.execute(
            "CREATE TABLE IF NOT EXISTS analytics_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                analytics_json TEXT NOT NULL,
                FOREIGN KEY(session_id) REFERENCES sessions(session_id)
            )",
            [],
        )?;

        // Create indexes
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_spins_session
             ON spins(session_id)",
            [],
        )?;

        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_seraphic_timestamp
             ON seraphic_state(timestamp DESC)",
            [],
        )?;

        info!("Database tables created successfully");
        Ok(())
    }

    /// Save a new session
    pub fn save_session(
        &self,
        session_id: &str,
        problem_text: &str,
        problem_type: ProblemType,
    ) -> SqlResult<()> {
        let timestamp = current_timestamp();

        self.conn.execute(
            "INSERT INTO sessions (session_id, timestamp, problem_text, problem_type)
             VALUES (?1, ?2, ?3, ?4)",
            params![session_id, timestamp, problem_text, format!("{:?}", problem_type)],
        )?;

        debug!("Session saved: {}", session_id);
        Ok(())
    }

    /// Save a spin result
    pub fn save_spin(
        &self,
        session_id: &str,
        spin_index: usize,
        route_signature: &str,
        algorithm_family: &str,
        num_qubits: u32,
        score: &AlgorithmScore,
    ) -> SqlResult<()> {
        let timestamp = current_timestamp();

        self.conn.execute(
            "INSERT INTO spins (
                session_id, spin_index, route_signature, algorithm_family,
                num_qubits, score_quality, score_robustness, score_novelty,
                score_label, timestamp
            ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)",
            params![
                session_id,
                spin_index as i64,
                route_signature,
                algorithm_family,
                num_qubits as i64,
                score.quality_score,
                score.robustness_score,
                score.novelty_score,
                format!("{:?}", score.label),
                timestamp,
            ],
        )?;

        debug!("Spin {} saved for session {}", spin_index, session_id);
        Ok(())
    }

    /// Save Seraphic Calibrator state
    pub fn save_seraphic_state(&self, calibrator: &SeraphicCalibrator) -> SqlResult<()> {
        let json = serde_json::to_string(calibrator)
            .map_err(|e| rusqlite::Error::ToSqlConversionFailure(Box::new(e)))?;
        let timestamp = current_timestamp();

        self.conn.execute(
            "INSERT INTO seraphic_state (timestamp, state_json) VALUES (?1, ?2)",
            params![timestamp, json],
        )?;

        info!("Seraphic state saved (experience_count: {})", calibrator.experience_count());
        Ok(())
    }

    /// Load the most recent Seraphic Calibrator state
    pub fn load_latest_seraphic_state(&self) -> SqlResult<Option<SeraphicCalibrator>> {
        let mut stmt = self.conn.prepare(
            "SELECT state_json FROM seraphic_state ORDER BY timestamp DESC LIMIT 1"
        )?;

        let result = stmt.query_row([], |row| {
            let json: String = row.get(0)?;
            Ok(json)
        });

        match result {
            Ok(json) => {
                match serde_json::from_str::<SeraphicCalibrator>(&json) {
                    Ok(cal) => {
                        info!("Loaded Seraphic state (experience_count: {})", cal.experience_count());
                        Ok(Some(cal))
                    }
                    Err(e) => {
                        warn!("Failed to deserialize Seraphic state: {}", e);
                        Ok(None)
                    }
                }
            }
            Err(rusqlite::Error::QueryReturnedNoRows) => {
                debug!("No Seraphic state found in database");
                Ok(None)
            }
            Err(e) => Err(e),
        }
    }

    /// Save analytics snapshot
    pub fn save_analytics(&self, session_id: &str, analytics: &SessionAnalytics) -> SqlResult<()> {
        let json = serde_json::to_string(analytics)
            .map_err(|e| rusqlite::Error::ToSqlConversionFailure(Box::new(e)))?;
        let timestamp = current_timestamp();

        self.conn.execute(
            "INSERT INTO analytics_snapshots (session_id, timestamp, analytics_json)
             VALUES (?1, ?2, ?3)",
            params![session_id, timestamp, json],
        )?;

        debug!("Analytics snapshot saved for session {}", session_id);
        Ok(())
    }

    /// Get session history
    pub fn get_session_history(&self, limit: usize) -> SqlResult<Vec<SessionRecord>> {
        let mut stmt = self.conn.prepare(
            "SELECT session_id, timestamp, problem_text, problem_type
             FROM sessions
             ORDER BY timestamp DESC
             LIMIT ?1"
        )?;

        let rows = stmt.query_map(params![limit], |row| {
            Ok(SessionRecord {
                session_id: row.get(0)?,
                timestamp: row.get(1)?,
                problem_text: row.get(2)?,
                problem_type: row.get(3)?,
            })
        })?;

        rows.collect()
    }

    /// Get spin history for a session
    pub fn get_spin_history(&self, session_id: &str) -> SqlResult<Vec<SpinRecord>> {
        let mut stmt = self.conn.prepare(
            "SELECT spin_index, route_signature, algorithm_family, num_qubits,
                    score_quality, score_robustness, score_novelty, score_label, timestamp
             FROM spins
             WHERE session_id = ?1
             ORDER BY spin_index ASC"
        )?;

        let rows = stmt.query_map(params![session_id], |row| {
            Ok(SpinRecord {
                spin_index: row.get::<_, i64>(0)? as usize,
                route_signature: row.get(1)?,
                algorithm_family: row.get(2)?,
                num_qubits: row.get::<_, i64>(3)? as u32,
                score_quality: row.get(4)?,
                score_robustness: row.get(5)?,
                score_novelty: row.get(6)?,
                score_label: row.get(7)?,
                timestamp: row.get(8)?,
            })
        })?;

        rows.collect()
    }

    /// Get database statistics
    pub fn get_stats(&self) -> SqlResult<DatabaseStats> {
        let session_count: i64 = self.conn.query_row(
            "SELECT COUNT(*) FROM sessions",
            [],
            |row| row.get(0),
        )?;

        let spin_count: i64 = self.conn.query_row(
            "SELECT COUNT(*) FROM spins",
            [],
            |row| row.get(0),
        )?;

        let seraphic_state_count: i64 = self.conn.query_row(
            "SELECT COUNT(*) FROM seraphic_state",
            [],
            |row| row.get(0),
        )?;

        Ok(DatabaseStats {
            total_sessions: session_count as usize,
            total_spins: spin_count as usize,
            seraphic_snapshots: seraphic_state_count as usize,
        })
    }
}

/// Get current Unix timestamp
fn current_timestamp() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_secs() as i64
}

#[derive(Debug, Clone)]
pub struct SessionRecord {
    pub session_id: String,
    pub timestamp: i64,
    pub problem_text: String,
    pub problem_type: String,
}

#[derive(Debug, Clone)]
pub struct SpinRecord {
    pub spin_index: usize,
    pub route_signature: String,
    pub algorithm_family: String,
    pub num_qubits: u32,
    pub score_quality: f64,
    pub score_robustness: f64,
    pub score_novelty: f64,
    pub score_label: String,
    pub timestamp: i64,
}

#[derive(Debug, Clone)]
pub struct DatabaseStats {
    pub total_sessions: usize,
    pub total_spins: usize,
    pub seraphic_snapshots: usize,
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    #[test]
    fn test_session_store_creation() {
        let dir = tempdir().unwrap();
        let db_path = dir.path().join("test.db");

        let store = SessionStore::open(&db_path).unwrap();
        let stats = store.get_stats().unwrap();

        assert_eq!(stats.total_sessions, 0);
        assert_eq!(stats.total_spins, 0);
    }

    #[test]
    fn test_save_and_load_seraphic() {
        let dir = tempdir().unwrap();
        let db_path = dir.path().join("test.db");
        let store = SessionStore::open(&db_path).unwrap();

        let calibrator = SeraphicCalibrator::new();
        store.save_seraphic_state(&calibrator).unwrap();

        let loaded = store.load_latest_seraphic_state().unwrap();
        assert!(loaded.is_some());
    }
}
