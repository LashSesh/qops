use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

/// Performance metrics collector
///
/// Tracks operational metrics for monitoring and optimization:
/// - Operation latencies
/// - Throughput rates
/// - Error rates
/// - Resource utilization
pub struct MetricsCollector {
    operation_timings: Arc<Mutex<HashMap<String, Vec<Duration>>>>,
    operation_counts: Arc<Mutex<HashMap<String, usize>>>,
    error_counts: Arc<Mutex<HashMap<String, usize>>>,
    start_time: Instant,
}

/// Snapshot of current metrics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetricsSnapshot {
    pub uptime_secs: u64,
    pub operation_stats: HashMap<String, OperationStats>,
    pub error_rates: HashMap<String, f64>,
    pub total_operations: usize,
    pub total_errors: usize,
    pub timestamp: chrono::DateTime<chrono::Utc>,
}

/// Statistics for a specific operation type
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperationStats {
    pub count: usize,
    pub mean_duration_ms: f64,
    pub median_duration_ms: f64,
    pub p95_duration_ms: f64,
    pub p99_duration_ms: f64,
    pub min_duration_ms: f64,
    pub max_duration_ms: f64,
    pub throughput_per_sec: f64,
}

/// Timer for measuring operation duration
pub struct Timer {
    operation_name: String,
    start: Instant,
    collector: Arc<MetricsCollector>,
}

impl MetricsCollector {
    pub fn new() -> Self {
        Self {
            operation_timings: Arc::new(Mutex::new(HashMap::new())),
            operation_counts: Arc::new(Mutex::new(HashMap::new())),
            error_counts: Arc::new(Mutex::new(HashMap::new())),
            start_time: Instant::now(),
        }
    }

    /// Start timing an operation
    pub fn start_timer(self: &Arc<Self>, operation_name: impl Into<String>) -> Timer {
        Timer {
            operation_name: operation_name.into(),
            start: Instant::now(),
            collector: Arc::clone(self),
        }
    }

    /// Record operation duration
    pub fn record_duration(&self, operation_name: &str, duration: Duration) {
        let mut timings = self.operation_timings.lock().unwrap();
        timings
            .entry(operation_name.to_string())
            .or_insert_with(Vec::new)
            .push(duration);

        // Keep only last 1000 measurements to avoid unbounded memory growth
        if let Some(measurements) = timings.get_mut(operation_name) {
            if measurements.len() > 1000 {
                measurements.drain(0..measurements.len() - 1000);
            }
        }

        let mut counts = self.operation_counts.lock().unwrap();
        *counts.entry(operation_name.to_string()).or_insert(0) += 1;
    }

    /// Record operation error
    pub fn record_error(&self, operation_name: &str) {
        let mut errors = self.error_counts.lock().unwrap();
        *errors.entry(operation_name.to_string()).or_insert(0) += 1;
    }

    /// Get metrics snapshot
    pub fn snapshot(&self) -> MetricsSnapshot {
        let timings = self.operation_timings.lock().unwrap();
        let counts = self.operation_counts.lock().unwrap();
        let errors = self.error_counts.lock().unwrap();

        let uptime = self.start_time.elapsed();
        let uptime_secs = uptime.as_secs();

        let mut operation_stats = HashMap::new();
        let mut total_operations = 0;

        for (op_name, durations) in timings.iter() {
            if durations.is_empty() {
                continue;
            }

            let count = *counts.get(op_name).unwrap_or(&0);
            total_operations += count;

            let stats = Self::calculate_stats(durations, count, uptime_secs);
            operation_stats.insert(op_name.clone(), stats);
        }

        let total_errors: usize = errors.values().sum();

        let error_rates: HashMap<String, f64> = errors
            .iter()
            .map(|(op_name, &error_count)| {
                let op_count = *counts.get(op_name).unwrap_or(&1).max(&1);
                let rate = error_count as f64 / op_count as f64;
                (op_name.clone(), rate)
            })
            .collect();

        MetricsSnapshot {
            uptime_secs,
            operation_stats,
            error_rates,
            total_operations,
            total_errors,
            timestamp: chrono::Utc::now(),
        }
    }

    /// Calculate statistics from duration samples
    fn calculate_stats(durations: &[Duration], count: usize, uptime_secs: u64) -> OperationStats {
        let mut sorted: Vec<f64> = durations.iter().map(|d| d.as_secs_f64() * 1000.0).collect();
        sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());

        let mean = sorted.iter().sum::<f64>() / sorted.len() as f64;

        let median = if sorted.is_empty() {
            0.0
        } else {
            sorted[sorted.len() / 2]
        };

        let p95 = if sorted.is_empty() {
            0.0
        } else {
            sorted[(sorted.len() as f64 * 0.95) as usize]
        };

        let p99 = if sorted.is_empty() {
            0.0
        } else {
            sorted[(sorted.len() as f64 * 0.99) as usize]
        };

        let min = sorted.first().copied().unwrap_or(0.0);
        let max = sorted.last().copied().unwrap_or(0.0);

        let throughput = if uptime_secs > 0 {
            count as f64 / uptime_secs as f64
        } else {
            0.0
        };

        OperationStats {
            count,
            mean_duration_ms: mean,
            median_duration_ms: median,
            p95_duration_ms: p95,
            p99_duration_ms: p99,
            min_duration_ms: min,
            max_duration_ms: max,
            throughput_per_sec: throughput,
        }
    }

    /// Reset all metrics
    pub fn reset(&self) {
        self.operation_timings.lock().unwrap().clear();
        self.operation_counts.lock().unwrap().clear();
        self.error_counts.lock().unwrap().clear();
    }

    /// Export metrics to JSON
    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        let snapshot = self.snapshot();
        serde_json::to_string_pretty(&snapshot)
    }
}

impl Default for MetricsCollector {
    fn default() -> Self {
        Self::new()
    }
}

impl Timer {
    /// Stop the timer and record the duration
    pub fn stop(self) {
        let duration = self.start.elapsed();
        self.collector
            .record_duration(&self.operation_name, duration);
    }
}

impl Drop for Timer {
    fn drop(&mut self) {
        // Auto-record if not explicitly stopped
        let duration = self.start.elapsed();
        self.collector
            .record_duration(&self.operation_name, duration);
    }
}

/// Helper macro for timing operations
#[macro_export]
macro_rules! time_operation {
    ($collector:expr, $name:expr, $code:block) => {{
        let _timer = $collector.start_timer($name);
        let result = $code;
        result
    }};
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;

    #[test]
    fn test_metrics_collector() {
        let collector = Arc::new(MetricsCollector::new());

        // Record some operations
        collector.record_duration("test_op", Duration::from_millis(100));
        collector.record_duration("test_op", Duration::from_millis(150));
        collector.record_duration("test_op", Duration::from_millis(200));

        let snapshot = collector.snapshot();

        assert_eq!(snapshot.total_operations, 3);
        assert!(snapshot.operation_stats.contains_key("test_op"));

        let stats = &snapshot.operation_stats["test_op"];
        assert_eq!(stats.count, 3);
        assert!(stats.mean_duration_ms > 100.0);
        assert!(stats.mean_duration_ms < 200.0);
    }

    #[test]
    fn test_timer() {
        let collector = Arc::new(MetricsCollector::new());

        {
            let _timer = collector.start_timer("sleep_test");
            thread::sleep(Duration::from_millis(50));
        } // Timer drops here and records

        let snapshot = collector.snapshot();
        assert_eq!(snapshot.total_operations, 1);

        let stats = &snapshot.operation_stats["sleep_test"];
        assert!(stats.mean_duration_ms >= 50.0);
    }

    #[test]
    fn test_error_recording() {
        let collector = MetricsCollector::new();

        collector.record_duration("test_op", Duration::from_millis(100));
        collector.record_duration("test_op", Duration::from_millis(100));
        collector.record_error("test_op");

        let snapshot = collector.snapshot();

        assert_eq!(snapshot.total_errors, 1);
        assert_eq!(snapshot.error_rates["test_op"], 0.5); // 1 error / 2 operations
    }

    #[test]
    fn test_percentiles() {
        let collector = MetricsCollector::new();

        // Record 100 operations with increasing durations
        for i in 1..=100 {
            collector.record_duration("test_op", Duration::from_millis(i));
        }

        let snapshot = collector.snapshot();
        let stats = &snapshot.operation_stats["test_op"];

        assert_eq!(stats.count, 100);
        assert!(stats.p95_duration_ms >= 95.0);
        assert!(stats.p99_duration_ms >= 99.0);
        assert!(stats.min_duration_ms >= 1.0);
        assert!(stats.max_duration_ms >= 100.0);
    }

    #[test]
    fn test_throughput() {
        let collector = MetricsCollector::new();

        // Wait a bit to get meaningful throughput
        thread::sleep(Duration::from_millis(100));

        for _ in 0..10 {
            collector.record_duration("test_op", Duration::from_millis(1));
        }

        let snapshot = collector.snapshot();
        let stats = &snapshot.operation_stats["test_op"];

        // Should have some throughput (operations per second)
        assert!(stats.throughput_per_sec > 0.0);
    }

    #[test]
    fn test_multiple_operations() {
        let collector = MetricsCollector::new();

        collector.record_duration("op1", Duration::from_millis(100));
        collector.record_duration("op2", Duration::from_millis(200));
        collector.record_duration("op1", Duration::from_millis(150));

        let snapshot = collector.snapshot();

        assert_eq!(snapshot.total_operations, 3);
        assert_eq!(snapshot.operation_stats["op1"].count, 2);
        assert_eq!(snapshot.operation_stats["op2"].count, 1);
    }

    #[test]
    fn test_reset() {
        let collector = MetricsCollector::new();

        collector.record_duration("test_op", Duration::from_millis(100));
        assert_eq!(collector.snapshot().total_operations, 1);

        collector.reset();
        assert_eq!(collector.snapshot().total_operations, 0);
    }

    #[test]
    fn test_json_export() {
        let collector = MetricsCollector::new();

        collector.record_duration("test_op", Duration::from_millis(100));

        let json = collector.to_json();
        assert!(json.is_ok());

        let json_str = json.unwrap();
        assert!(json_str.contains("test_op"));
        assert!(json_str.contains("mean_duration_ms"));
    }
}
