use crate::CandidateWithScore;
use fuq_core::AlgorithmScore;
use serde::{Deserialize, Serialize};
use std::cmp::Ordering;

/// Algorithm comparison and ranking system
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ComparisonMatrix {
    pub candidates: Vec<RankedCandidate>,
    pub sort_by: SortCriterion,
    pub filter_family: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RankedCandidate {
    pub rank: usize,
    pub candidate: CandidateWithScore,
    pub composite_score: f64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SortCriterion {
    Quality,
    Robustness,
    Novelty,
    FamilyMatch,
    Composite,
}

impl ComparisonMatrix {
    /// Create a new comparison matrix from candidates
    pub fn new(mut candidates: Vec<CandidateWithScore>) -> Self {
        // Default: sort by composite score
        candidates.sort_by(|a, b| {
            Self::composite_score(&b.score)
                .partial_cmp(&Self::composite_score(&a.score))
                .unwrap_or(Ordering::Equal)
        });

        let ranked: Vec<RankedCandidate> = candidates
            .into_iter()
            .enumerate()
            .map(|(idx, candidate)| RankedCandidate {
                rank: idx + 1,
                composite_score: Self::composite_score(&candidate.score),
                candidate,
            })
            .collect();

        Self {
            candidates: ranked,
            sort_by: SortCriterion::Composite,
            filter_family: None,
        }
    }

    /// Compute composite score (weighted average)
    fn composite_score(score: &AlgorithmScore) -> f64 {
        score.quality_score * 0.5
            + score.robustness_score * 0.3
            + score.novelty_score * 0.2
    }

    /// Re-sort the matrix by a different criterion
    pub fn sort_by(&mut self, criterion: SortCriterion) {
        self.sort_by = criterion;

        let mut candidates = std::mem::take(&mut self.candidates);

        candidates.sort_by(|a, b| {
            let score_a = self.extract_score(&a.candidate.score, criterion);
            let score_b = self.extract_score(&b.candidate.score, criterion);
            score_b.partial_cmp(&score_a).unwrap_or(Ordering::Equal)
        });

        // Re-rank after sorting
        for (idx, candidate) in candidates.iter_mut().enumerate() {
            candidate.rank = idx + 1;
        }

        self.candidates = candidates;
    }

    fn extract_score(&self, score: &AlgorithmScore, criterion: SortCriterion) -> f64 {
        match criterion {
            SortCriterion::Quality => score.quality_score,
            SortCriterion::Robustness => score.robustness_score,
            SortCriterion::Novelty => score.novelty_score,
            SortCriterion::FamilyMatch => score.family_match_score,
            SortCriterion::Composite => Self::composite_score(score),
        }
    }

    /// Filter by algorithm family
    pub fn filter_by_family(&mut self, family: Option<String>) {
        self.filter_family = family;
    }

    /// Get filtered candidates
    pub fn get_filtered(&self) -> Vec<&RankedCandidate> {
        if let Some(ref family) = self.filter_family {
            self.candidates
                .iter()
                .filter(|c| format!("{:?}", c.candidate.spec.family) == *family)
                .collect()
        } else {
            self.candidates.iter().collect()
        }
    }

    /// Get top N algorithms
    pub fn get_top_n(&self, n: usize) -> Vec<&RankedCandidate> {
        self.get_filtered().into_iter().take(n).collect()
    }

    /// Get best algorithm (rank 1)
    pub fn get_best(&self) -> Option<&RankedCandidate> {
        self.get_filtered().first().copied()
    }

    /// Get summary statistics
    pub fn get_statistics(&self) -> ComparisonStatistics {
        let filtered = self.get_filtered();

        if filtered.is_empty() {
            return ComparisonStatistics::default();
        }

        let quality_scores: Vec<f64> = filtered
            .iter()
            .map(|c| c.candidate.score.quality_score)
            .collect();
        let robustness_scores: Vec<f64> = filtered
            .iter()
            .map(|c| c.candidate.score.robustness_score)
            .collect();
        let novelty_scores: Vec<f64> = filtered
            .iter()
            .map(|c| c.candidate.score.novelty_score)
            .collect();

        ComparisonStatistics {
            total_candidates: filtered.len(),
            mean_quality: mean(&quality_scores),
            std_quality: std_dev(&quality_scores),
            mean_robustness: mean(&robustness_scores),
            std_robustness: std_dev(&robustness_scores),
            mean_novelty: mean(&novelty_scores),
            std_novelty: std_dev(&novelty_scores),
            best_quality: quality_scores.iter().copied().fold(f64::NEG_INFINITY, f64::max),
            worst_quality: quality_scores.iter().copied().fold(f64::INFINITY, f64::min),
        }
    }

    /// Compare two specific algorithms
    pub fn compare_pair(&self, idx_a: usize, idx_b: usize) -> Option<PairwiseComparison> {
        let a = self.candidates.get(idx_a)?;
        let b = self.candidates.get(idx_b)?;

        Some(PairwiseComparison {
            algorithm_a: format!("{:?}", a.candidate.spec.family),
            algorithm_b: format!("{:?}", b.candidate.spec.family),
            quality_diff: a.candidate.score.quality_score - b.candidate.score.quality_score,
            robustness_diff: a.candidate.score.robustness_score
                - b.candidate.score.robustness_score,
            novelty_diff: a.candidate.score.novelty_score - b.candidate.score.novelty_score,
            composite_diff: a.composite_score - b.composite_score,
        })
    }

    /// Export to JSON
    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string_pretty(self)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ComparisonStatistics {
    pub total_candidates: usize,
    pub mean_quality: f64,
    pub std_quality: f64,
    pub mean_robustness: f64,
    pub std_robustness: f64,
    pub mean_novelty: f64,
    pub std_novelty: f64,
    pub best_quality: f64,
    pub worst_quality: f64,
}

impl Default for ComparisonStatistics {
    fn default() -> Self {
        Self {
            total_candidates: 0,
            mean_quality: 0.0,
            std_quality: 0.0,
            mean_robustness: 0.0,
            std_robustness: 0.0,
            mean_novelty: 0.0,
            std_novelty: 0.0,
            best_quality: 0.0,
            worst_quality: 0.0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PairwiseComparison {
    pub algorithm_a: String,
    pub algorithm_b: String,
    pub quality_diff: f64,
    pub robustness_diff: f64,
    pub novelty_diff: f64,
    pub composite_diff: f64,
}

// Helper functions
fn mean(values: &[f64]) -> f64 {
    if values.is_empty() {
        0.0
    } else {
        values.iter().sum::<f64>() / values.len() as f64
    }
}

fn std_dev(values: &[f64]) -> f64 {
    if values.len() < 2 {
        0.0
    } else {
        let m = mean(values);
        let variance = values.iter().map(|v| (v - m).powi(2)).sum::<f64>() / values.len() as f64;
        variance.sqrt()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use fuq_core::{AlgorithmFamily, AlgorithmSpec, AlgorithmScore, QualityLabel};
    use metatron_core::ProblemType;

    fn create_test_candidate(family: AlgorithmFamily, quality: f64) -> CandidateWithScore {
        CandidateWithScore {
            spec: AlgorithmSpec::new_empty(family),
            score: AlgorithmScore {
                quality_score: quality,
                robustness_score: 0.5,
                novelty_score: 0.5,
                family_match_score: 0.8,
                label: QualityLabel::Good,
                metadata: Default::default(),
            },
        }
    }

    #[test]
    fn test_comparison_matrix_creation() {
        let candidates = vec![
            create_test_candidate(AlgorithmFamily::QAOA, 0.7),
            create_test_candidate(AlgorithmFamily::GroverLikeSearch, 0.9),
            create_test_candidate(AlgorithmFamily::VQE, 0.5),
        ];

        let matrix = ComparisonMatrix::new(candidates);
        assert_eq!(matrix.candidates.len(), 3);

        // Should be sorted by composite score (quality * 0.5 + robustness * 0.3 + novelty * 0.2)
        assert_eq!(matrix.candidates[0].rank, 1);
        assert!(matrix.candidates[0].candidate.score.quality_score > 0.8);
    }

    #[test]
    fn test_sorting() {
        let candidates = vec![
            create_test_candidate(AlgorithmFamily::QAOA, 0.7),
            create_test_candidate(AlgorithmFamily::GroverLikeSearch, 0.5),
        ];

        let mut matrix = ComparisonMatrix::new(candidates);
        matrix.sort_by(SortCriterion::Quality);

        assert_eq!(matrix.candidates[0].candidate.score.quality_score, 0.7);
    }

    #[test]
    fn test_statistics() {
        let candidates = vec![
            create_test_candidate(AlgorithmFamily::QAOA, 0.7),
            create_test_candidate(AlgorithmFamily::GroverLikeSearch, 0.9),
            create_test_candidate(AlgorithmFamily::VQE, 0.5),
        ];

        let matrix = ComparisonMatrix::new(candidates);
        let stats = matrix.get_statistics();

        assert_eq!(stats.total_candidates, 3);
        assert!(stats.mean_quality > 0.6 && stats.mean_quality < 0.8);
        assert_eq!(stats.best_quality, 0.9);
        assert_eq!(stats.worst_quality, 0.5);
    }
}
