pub mod parser;
pub mod context;
pub mod batch;
pub mod scorer;
pub mod export;
pub mod seraphic;
pub mod analytics;
pub mod persistence;
pub mod comparison;
pub mod tuning;
pub mod evolution;
pub mod validation;
pub mod cache;
pub mod parallel;
pub mod recovery;
pub mod input_validation;
pub mod metrics;
pub mod visualization;

pub use parser::*;
pub use context::*;
pub use batch::*;
pub use scorer::*;
pub use export::*;
pub use seraphic::*;
pub use analytics::*;
pub use persistence::*;
pub use comparison::*;
pub use tuning::*;
pub use evolution::*;
pub use validation::*;
pub use cache::*;
pub use parallel::*;
pub use recovery::*;
pub use input_validation::*;
pub use metrics::*;
pub use visualization::*;

use fuq_core::{AlgorithmScore, AlgorithmSpec, FuqEngine};
use metatron_core::{load_metatron_model, MetatronModel, ProblemSpec};
use rand::rngs::StdRng;
use rand::SeedableRng;
use serde::{Deserialize, Serialize};
use thiserror::Error;
use tracing::{debug, error, info, instrument, warn};

// Import biased routing
use metatron_core::routing::sample_route_biased;

#[derive(Error, Debug)]
pub enum QSlotError {
    #[error("Failed to parse problem specification: {0}")]
    ParseError(String),

    #[error("Algorithm generation failed: {0}")]
    GenerationError(String),

    #[error("Invalid parameters: {0}")]
    InvalidParameters(String),
}

/// Main entry point for Q⊗DASH algorithm generation
pub struct QSlotEngine {
    metatron: MetatronModel,
    fuq: FuqEngine,
    context: QSlotContext,
    seraphic: SeraphicCalibrator,
    analytics: SessionAnalytics,
    persistence: Option<SessionStore>,
    cache: AlgorithmCache,
}

impl QSlotEngine {
    /// Create a new QSlotEngine without persistence
    pub fn new() -> Self {
        let session_id = uuid::Uuid::new_v4().to_string();
        info!("Creating new QSlot session: {}", session_id);

        Self {
            metatron: load_metatron_model(),
            fuq: FuqEngine::new(),
            context: QSlotContext::new(),
            seraphic: SeraphicCalibrator::new(),
            analytics: SessionAnalytics::new(session_id),
            persistence: None,
            cache: AlgorithmCache::new(),
        }
    }

    /// Create a new QSlotEngine with persistence
    pub fn with_persistence<P: AsRef<std::path::Path>>(db_path: P) -> Result<Self, QSlotError> {
        let session_id = uuid::Uuid::new_v4().to_string();
        info!("Creating new QSlot session with persistence: {}", session_id);

        let persistence = SessionStore::open(db_path)
            .map_err(|e| QSlotError::InvalidParameters(format!("Failed to open database: {}", e)))?;

        // Try to load previous Seraphic state
        let seraphic = match persistence.load_latest_seraphic_state() {
            Ok(Some(state)) => {
                info!("Loaded previous Seraphic state from database");
                state
            }
            Ok(None) => {
                info!("No previous Seraphic state found, starting fresh");
                SeraphicCalibrator::new()
            }
            Err(e) => {
                warn!("Failed to load Seraphic state: {}, starting fresh", e);
                SeraphicCalibrator::new()
            }
        };

        Ok(Self {
            metatron: load_metatron_model(),
            fuq: FuqEngine::new(),
            context: QSlotContext::new(),
            seraphic,
            analytics: SessionAnalytics::new(session_id),
            persistence: Some(persistence),
            cache: AlgorithmCache::new(),
        })
    }

    /// Design a batch of algorithm candidates
    #[instrument(skip(self, problem_text), fields(n_candidates, spin_index))]
    pub fn design_algorithm_batch(
        &mut self,
        problem_text: &str,
        n_candidates: usize,
        spin_index: u64,
    ) -> Result<AlgorithmBatch, QSlotError> {
        info!("Starting algorithm batch design: {} candidates, spin {}", n_candidates, spin_index);

        // Parse problem specification
        debug!("Parsing problem specification");
        let problem_spec = parse_problem_spec(problem_text)?;
        info!("Problem type: {:?}", problem_spec.problem_type);

        // Generate candidates
        let mut candidates = Vec::new();
        let mut rng = StdRng::seed_from_u64(spin_index);

        for i in 0..n_candidates {
            debug!("Generating candidate {}/{}", i + 1, n_candidates);
            match self.generate_single_candidate(&problem_spec, &mut rng, i) {
                Ok((spec, score, route)) => {
                    info!("Candidate {} generated: {:?}, score: {:.3}", i, spec.family, score.quality_score);

                    // Add experience to Seraphic Calibrator
                    self.seraphic.add_experience(&problem_spec, &route, &score);
                    debug!("Added experience to Seraphic Calibrator");

                    // Track in analytics
                    self.analytics.add_quality_point(
                        spin_index as usize + i,
                        score.quality_score,
                        problem_spec.problem_type,
                        format!("{:?}", spec.family),
                    );

                    // Save to persistence if available
                    if let Some(ref persistence) = self.persistence {
                        let num_qubits: u32 = spec.state_space.discrete_registers
                            .iter()
                            .map(|r| r.dimension)
                            .sum();

                        if let Err(e) = persistence.save_spin(
                            &self.analytics.session_id,
                            spin_index as usize + i,
                            &route.signature,
                            &format!("{:?}", spec.family),
                            num_qubits,
                            &score,
                        ) {
                            warn!("Failed to save spin to database: {}", e);
                        }
                    }

                    candidates.push(CandidateWithScore { spec, score });
                },
                Err(e) => {
                    warn!("Failed to generate candidate {}: {}", i, e);
                    // Continue with other candidates
                }
            }
        }

        info!("Generated {} candidates successfully", candidates.len());

        // Build batch
        debug!("Building algorithm batch");
        let batch = build_algorithm_batch(problem_spec, candidates, spin_index);

        // Update context with batch results
        debug!("Updating context");
        self.context.update_from_batch(&batch);

        // Save Seraphic state every 10 spins
        if let Some(ref persistence) = self.persistence {
            if spin_index % 10 == 0 {
                if let Err(e) = persistence.save_seraphic_state(&self.seraphic) {
                    warn!("Failed to save Seraphic state: {}", e);
                } else {
                    debug!("Seraphic state saved at spin {}", spin_index);
                }
            }
        }

        info!("Batch design complete: {} algorithms", batch.candidates.len());
        Ok(batch)
    }

    /// Get Seraphic Calibration statistics
    pub fn get_calibration_stats(&self) -> CalibrationStats {
        self.seraphic.get_stats()
    }

    /// Get quality trend from Seraphic Calibration
    pub fn get_quality_trend(&self) -> f64 {
        self.seraphic.quality_trend()
    }

    /// Get session analytics
    pub fn get_analytics(&self) -> &SessionAnalytics {
        &self.analytics
    }

    /// Get analytics summary
    pub fn get_analytics_summary(&self) -> AnalyticsSummary {
        self.analytics.get_summary()
    }

    /// Export analytics to JSON
    pub fn export_analytics_json(&self) -> Result<String, serde_json::Error> {
        self.analytics.to_json()
    }

    /// Get database statistics (if persistence is enabled)
    pub fn get_database_stats(&self) -> Option<DatabaseStats> {
        self.persistence.as_ref().and_then(|p| p.get_stats().ok())
    }

    /// Get session history (if persistence is enabled)
    pub fn get_session_history(&self, limit: usize) -> Option<Vec<SessionRecord>> {
        self.persistence.as_ref().and_then(|p| p.get_session_history(limit).ok())
    }

    /// Manually save Seraphic state (if persistence is enabled)
    pub fn save_seraphic_state(&self) -> Result<(), String> {
        if let Some(ref persistence) = self.persistence {
            persistence.save_seraphic_state(&self.seraphic)
                .map_err(|e| format!("Failed to save Seraphic state: {}", e))
        } else {
            Err("Persistence not enabled".to_string())
        }
    }

    /// Get session ID
    pub fn session_id(&self) -> &str {
        &self.analytics.session_id
    }

    /// Get cache statistics
    pub fn cache_statistics(&self) -> CacheStatistics {
        self.cache.statistics()
    }

    /// Clear the cache (for testing or manual control)
    pub fn clear_cache(&self) {
        self.cache.clear();
    }

    #[instrument(skip(self, problem_spec, rng))]
    fn generate_single_candidate(
        &self,
        problem_spec: &ProblemSpec,
        rng: &mut StdRng,
        _candidate_index: usize,
    ) -> Result<(AlgorithmSpec, AlgorithmScore, metatron_core::MetatronRoute), QSlotError> {
        // 1. Sample Metatron route (with bias if available)
        debug!("Sampling Metatron route");
        let routing_bias = self.seraphic.get_routing_bias(problem_spec.problem_type);
        let route = if routing_bias.experience_count() > 0 {
            info!("Using biased routing (experience_count: {})", routing_bias.experience_count());
            sample_route_biased(&self.metatron, problem_spec, &routing_bias.to_metatron_bias(), rng)
        } else {
            debug!("No experience yet, using default routing");
            self.metatron.sample_route(problem_spec, rng)
        };
        debug!("Route: {} moves, signature: {}", route.moves.len(), route.signature);

        // 2. Convert to structure
        debug!("Converting route to structure");
        let structure = self.metatron.route_to_structure(&route);
        debug!("Structure symmetry: {:.3}", structure.structural_features.symmetry_score);

        // 3. Create 5D mesh
        debug!("Creating 5D mesh");
        let mesh = self.fuq.create_mesh(&structure, problem_spec);
        debug!("Mesh created with {} points", mesh.points.len());

        // 4. Run surgery loop (with adaptive parameters)
        debug!("Running FUQ surgery loop");
        let surgery_params = self.seraphic.get_surgery_params();
        debug!("Surgery params: step_size={:.4}, max_iters={}",
               surgery_params.step_size, surgery_params.max_iterations);
        let surgery_result = self.fuq.run_surgery(&mesh, &surgery_params);
        debug!("Surgery completed in {} iterations",
               surgery_result.iterations_performed);

        // Check for warnings in guard flags
        for flag in &surgery_result.guard_flags {
            match flag {
                fuq_core::GuardFlag::SlowConvergence => warn!("Surgery showed slow convergence"),
                fuq_core::GuardFlag::Oscillation => warn!("Surgery oscillated"),
                fuq_core::GuardFlag::Divergence => warn!("Surgery diverged"),
                _ => {}
            }
        }

        // 5. Detect singularities
        debug!("Detecting singularities");
        let singularities = self.fuq.detect_singularities(&surgery_result.final_mesh);
        debug!("Detected {} singularities", singularities.len());

        // 6. Select best singularity (highest strength)
        let singularity = singularities
            .iter()
            .max_by(|a, b| {
                a.strength
                    .partial_cmp(&b.strength)
                    .unwrap_or(std::cmp::Ordering::Equal)
            })
            .ok_or_else(|| {
                error!("No singularities detected");
                QSlotError::GenerationError("No singularities detected".to_string())
            })?;

        debug!("Selected singularity: {:?}, strength: {:.3}",
               singularity.kind, singularity.strength);

        // 7. Quantum bridge to AlgorithmSpec
        debug!("Bridging to quantum algorithm");
        let spec = self
            .fuq
            .quantum_bridge(problem_spec, singularity, &structure.route_signature);
        info!("Generated {:?} algorithm with {} qubits",
              spec.family, spec.state_space.discrete_registers.iter().map(|r| r.dimension).sum::<u32>());

        // 8. Compute score
        debug!("Computing algorithm score");
        let score = compute_algorithm_score(&spec, singularity, &surgery_result, &self.context);
        info!("Score: quality={:.3}, robustness={:.3}, novelty={:.3}, label={:?}",
              score.quality_score, score.robustness_score, score.novelty_score, score.label);

        // 9. Cache the score for future lookups
        self.cache.put_score(&route, problem_spec, score.clone());
        debug!("Cached score for route: {}", route.signature);

        Ok((spec, score, route))
    }
}

impl Default for QSlotEngine {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CandidateWithScore {
    pub spec: AlgorithmSpec,
    pub score: AlgorithmScore,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_qslot_engine() {
        let mut engine = QSlotEngine::new();

        let problem_text = "Find the optimal path through a graph with 100 nodes";
        let result = engine.design_algorithm_batch(problem_text, 3, 1);

        assert!(result.is_ok());
        let batch = result.unwrap();
        assert!(batch.candidates.len() > 0);
    }
}
