use metatron_core::{MetatronMove, MetatronRoute};
use serde::{Deserialize, Serialize};
use std::time::Instant;

/// Real-time visualization data for 3D rendering
///
/// Provides structured data for frontend visualization of the algorithm
/// generation process in real-time.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VisualizationFrame {
    pub timestamp_ms: u64,
    pub frame_id: u64,
    pub state: VisualizationState,
    pub metatron_data: Option<MetatronVisualizationData>,
    pub surgery_data: Option<SurgeryVisualizationData>,
    pub progress: f64, // 0.0 to 1.0
}

/// Current state of visualization
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum VisualizationState {
    Idle,
    Parsing,
    RoutingMetatron,
    PerformingSurgery,
    DetectingSingularities,
    BridgingToQuantum,
    Scoring,
    Complete,
}

/// Metatron routing visualization data
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetatronVisualizationData {
    pub current_move_index: usize,
    pub total_moves: usize,
    pub route_signature: String,
    pub moves: Vec<MoveVisualization>,
    pub symmetry_score: f64,
}

/// Individual move visualization
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MoveVisualization {
    pub move_type: String,
    pub axis: Option<usize>,
    pub angle: Option<i32>,
    pub intensity: f64, // For visual effects
}

/// Surgery visualization data
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SurgeryVisualizationData {
    pub iteration: usize,
    pub max_iterations: usize,
    pub convergence: f64,
    pub energy: f64,
    pub mesh_points_count: usize,
    pub guard_flags: Vec<String>,
}

/// Frame timing tracker for 60 FPS target
pub struct FrameTimer {
    target_fps: f64,
    frame_budget_ns: u128,
    last_frame: Instant,
    frame_count: u64,
    dropped_frames: u64,
}

/// Visualization stream manager
pub struct VisualizationStream {
    frames: Vec<VisualizationFrame>,
    current_state: VisualizationState,
    start_time: Instant,
    frame_counter: u64,
    max_frames: usize,
}

impl FrameTimer {
    pub fn new(target_fps: f64) -> Self {
        let frame_budget_ns = (1_000_000_000.0 / target_fps) as u128;

        Self {
            target_fps,
            frame_budget_ns,
            last_frame: Instant::now(),
            frame_count: 0,
            dropped_frames: 0,
        }
    }

    /// Start timing a new frame
    pub fn start_frame(&mut self) {
        self.last_frame = Instant::now();
    }

    /// Check if we're within frame budget
    pub fn is_within_budget(&self) -> bool {
        self.last_frame.elapsed().as_nanos() < self.frame_budget_ns
    }

    /// Get current FPS
    pub fn current_fps(&self) -> f64 {
        if self.frame_count == 0 {
            return 0.0;
        }

        1_000_000_000.0 / self.last_frame.elapsed().as_nanos() as f64
    }

    /// Complete frame and check for drops
    pub fn end_frame(&mut self) -> FrameTimingResult {
        let elapsed = self.last_frame.elapsed();
        self.frame_count += 1;

        let within_budget = elapsed.as_nanos() < self.frame_budget_ns;

        if !within_budget {
            self.dropped_frames += 1;
        }

        FrameTimingResult {
            frame_time_ms: elapsed.as_millis() as f64,
            budget_ms: (self.frame_budget_ns / 1_000_000) as f64,
            within_budget,
            current_fps: self.current_fps(),
        }
    }

    /// Get statistics
    pub fn stats(&self) -> FrameTimingStats {
        let drop_rate = if self.frame_count > 0 {
            self.dropped_frames as f64 / self.frame_count as f64
        } else {
            0.0
        };

        FrameTimingStats {
            total_frames: self.frame_count,
            dropped_frames: self.dropped_frames,
            drop_rate,
            target_fps: self.target_fps,
        }
    }
}

/// Result of a single frame timing
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FrameTimingResult {
    pub frame_time_ms: f64,
    pub budget_ms: f64,
    pub within_budget: bool,
    pub current_fps: f64,
}

/// Frame timing statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FrameTimingStats {
    pub total_frames: u64,
    pub dropped_frames: u64,
    pub drop_rate: f64,
    pub target_fps: f64,
}

impl VisualizationStream {
    pub fn new(max_frames: usize) -> Self {
        Self {
            frames: Vec::with_capacity(max_frames),
            current_state: VisualizationState::Idle,
            start_time: Instant::now(),
            frame_counter: 0,
            max_frames,
        }
    }

    /// Push a new frame
    pub fn push_frame(&mut self, mut frame: VisualizationFrame) {
        frame.frame_id = self.frame_counter;
        frame.timestamp_ms = self.start_time.elapsed().as_millis() as u64;

        self.frames.push(frame);
        self.frame_counter += 1;

        // Limit frame buffer size
        if self.frames.len() > self.max_frames {
            self.frames.remove(0);
        }
    }

    /// Create frame from route
    pub fn frame_from_route(&mut self, route: &MetatronRoute, progress: f64) {
        let moves: Vec<MoveVisualization> = route
            .moves
            .iter()
            .enumerate()
            .map(|(_i, mv)| {
                let (move_type, axis, angle, intensity) = match mv {
                    MetatronMove::Invert { axis } => {
                        ("Invert".to_string(), Some(*axis as usize), None, 0.8)
                    }
                    MetatronMove::Rotate { axis, angle } => {
                        ("Rotate".to_string(), Some(*axis as usize), Some(*angle as i32), 0.6)
                    }
                    MetatronMove::Mirror { plane } => {
                        ("Mirror".to_string(), Some(*plane as usize), None, 0.9)
                    }
                    MetatronMove::Convert { phase } => (
                        format!("Convert(phase={})", phase),
                        None,
                        None,
                        0.7,
                    ),
                };

                MoveVisualization {
                    move_type,
                    axis,
                    angle,
                    intensity,
                }
            })
            .collect();

        let metatron_data = MetatronVisualizationData {
            current_move_index: (route.moves.len() as f64 * progress) as usize,
            total_moves: route.moves.len(),
            route_signature: route.signature.clone(),
            moves,
            symmetry_score: 0.5, // Placeholder
        };

        let frame = VisualizationFrame {
            timestamp_ms: 0,
            frame_id: 0,
            state: VisualizationState::RoutingMetatron,
            metatron_data: Some(metatron_data),
            surgery_data: None,
            progress,
        };

        self.push_frame(frame);
    }

    /// Create frame from surgery iteration
    pub fn frame_from_surgery(
        &mut self,
        iteration: usize,
        max_iterations: usize,
        convergence: f64,
        energy: f64,
        mesh_points: usize,
    ) {
        let surgery_data = SurgeryVisualizationData {
            iteration,
            max_iterations,
            convergence,
            energy,
            mesh_points_count: mesh_points,
            guard_flags: vec![],
        };

        let progress = iteration as f64 / max_iterations as f64;

        let frame = VisualizationFrame {
            timestamp_ms: 0,
            frame_id: 0,
            state: VisualizationState::PerformingSurgery,
            metatron_data: None,
            surgery_data: Some(surgery_data),
            progress,
        };

        self.push_frame(frame);
    }

    /// Update state
    pub fn set_state(&mut self, state: VisualizationState, progress: f64) {
        self.current_state = state.clone();

        let frame = VisualizationFrame {
            timestamp_ms: 0,
            frame_id: 0,
            state,
            metatron_data: None,
            surgery_data: None,
            progress,
        };

        self.push_frame(frame);
    }

    /// Get all frames
    pub fn frames(&self) -> &[VisualizationFrame] {
        &self.frames
    }

    /// Get latest frame
    pub fn latest_frame(&self) -> Option<&VisualizationFrame> {
        self.frames.last()
    }

    /// Clear frames
    pub fn clear(&mut self) {
        self.frames.clear();
        self.frame_counter = 0;
        self.start_time = Instant::now();
    }

    /// Export to JSON
    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string(&self.frames)
    }
}

impl Default for FrameTimer {
    fn default() -> Self {
        Self::new(60.0)
    }
}

impl Default for VisualizationStream {
    fn default() -> Self {
        Self::new(1000)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;

    #[test]
    fn test_frame_timer() {
        let mut timer = FrameTimer::new(60.0);

        timer.start_frame();
        thread::sleep(Duration::from_millis(10)); // Simulate work
        let result = timer.end_frame();

        assert!(result.frame_time_ms >= 10.0);
        assert_eq!(timer.frame_count, 1);
    }

    #[test]
    fn test_frame_timer_budget() {
        let timer = FrameTimer::new(60.0);

        // 60 FPS = ~16.67ms per frame
        let budget_ms = (timer.frame_budget_ns / 1_000_000) as f64;
        assert!((budget_ms - 16.67).abs() < 0.1);
    }

    #[test]
    fn test_visualization_stream() {
        let mut stream = VisualizationStream::new(10);

        stream.set_state(VisualizationState::Parsing, 0.1);
        stream.set_state(VisualizationState::RoutingMetatron, 0.5);
        stream.set_state(VisualizationState::Complete, 1.0);

        assert_eq!(stream.frames().len(), 3);
        assert_eq!(stream.latest_frame().unwrap().state, VisualizationState::Complete);
    }

    #[test]
    fn test_visualization_stream_max_frames() {
        let mut stream = VisualizationStream::new(5);

        for i in 0..10 {
            stream.set_state(VisualizationState::Idle, i as f64 / 10.0);
        }

        // Should only keep last 5 frames
        assert_eq!(stream.frames().len(), 5);
    }

    #[test]
    fn test_json_export() {
        let mut stream = VisualizationStream::new(10);
        stream.set_state(VisualizationState::Parsing, 0.1);

        let json = stream.to_json();
        assert!(json.is_ok());

        let json_str = json.unwrap();
        assert!(json_str.contains("Parsing"));
    }

    #[test]
    fn test_frame_timing_stats() {
        let mut timer = FrameTimer::new(60.0);

        for _ in 0..10 {
            timer.start_frame();
            thread::sleep(Duration::from_millis(5));
            timer.end_frame();
        }

        let stats = timer.stats();
        assert_eq!(stats.total_frames, 10);
        assert_eq!(stats.target_fps, 60.0);
    }
}
