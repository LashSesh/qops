use crate::CandidateWithScore;
use fuq_core::ScoreLabel;
use metatron_core::ProblemSpec;
use serde::{Deserialize, Serialize};

/// A batch of algorithm candidates generated from a single SPIN
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AlgorithmBatch {
    pub problem_spec: ProblemSpec,
    pub spin_index: u64,
    pub generated_at: String,
    pub candidates: Vec<CandidateWithScore>,
    pub summary: BatchSummary,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatchSummary {
    pub num_candidates: u32,
    pub num_miss: u32,
    pub num_okay: u32,
    pub num_good: u32,
    pub num_jackpot: u32,
    pub best_score: f64,
    pub avg_score: f64,
}

/// Build an algorithm batch from candidates
pub fn build_algorithm_batch(
    problem_spec: ProblemSpec,
    candidates: Vec<CandidateWithScore>,
    spin_index: u64,
) -> AlgorithmBatch {
    let summary = compute_batch_summary(&candidates);

    AlgorithmBatch {
        problem_spec,
        spin_index,
        generated_at: chrono::Utc::now().to_rfc3339(),
        candidates,
        summary,
    }
}

fn compute_batch_summary(candidates: &[CandidateWithScore]) -> BatchSummary {
    let mut num_miss = 0u32;
    let mut num_okay = 0u32;
    let mut num_good = 0u32;
    let mut num_jackpot = 0u32;

    let mut total_score = 0.0;
    let mut best_score = 0.0;

    for candidate in candidates {
        match candidate.score.label {
            ScoreLabel::Miss => num_miss += 1,
            ScoreLabel::Okay => num_okay += 1,
            ScoreLabel::Good => num_good += 1,
            ScoreLabel::Jackpot => num_jackpot += 1,
        }

        let score = (candidate.score.quality_score
            + candidate.score.robustness_score
            + candidate.score.novelty_score
            + candidate.score.family_match_score)
            / 4.0;

        total_score += score;
        if score > best_score {
            best_score = score;
        }
    }

    let num_candidates = candidates.len() as u32;
    let avg_score = if num_candidates > 0 {
        total_score / num_candidates as f64
    } else {
        0.0
    };

    BatchSummary {
        num_candidates,
        num_miss,
        num_okay,
        num_good,
        num_jackpot,
        best_score,
        avg_score,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use fuq_core::{AlgorithmScore, AlgorithmSpec, ScoreLabel};
    use metatron_core::{ProblemType, SolutionQuality};

    fn create_test_spec() -> AlgorithmSpec {
        AlgorithmSpec {
            id: "test".to_string(),
            name: "test".to_string(),
            description: "test".to_string(),
            problem_spec: ProblemSpec {
                id: "test".to_string(),
                raw_text: "test".to_string(),
                problem_type: ProblemType::Search,
                input_structure: "test".to_string(),
                objective_description: "test".to_string(),
                constraints: vec![],
                solution_quality: SolutionQuality {
                    target_accuracy: None,
                    target_gap: None,
                    resource_budget: None,
                },
            },
            family: fuq_core::AlgorithmFamily::GroverLikeSearch,
            tripol: fuq_core::Tripol::zero(),
            state5d: fuq_core::State5D::zero(),
            dtl_mode: fuq_core::DTLMode::L0,
            state_space: fuq_core::HybridStateSpace {
                continuous_space: fuq_core::ContinuousSpace {
                    kind: fuq_core::ContinuousKind::None,
                    dim: 0,
                    notes: "test".to_string(),
                },
                discrete_registers: vec![],
                estimated_dimension: None,
            },
            operators: vec![],
            spectral_goal: fuq_core::SpectralGoal {
                pattern: fuq_core::SpectralPattern::TwoLevel,
                target_gap: None,
                notes: "test".to_string(),
            },
            schedule: None,
            feedback: fuq_core::FeedbackConfig::default(),
            metatron_signature: "test".to_string(),
            fuq_metadata: "test".to_string(),
            seraphic_hint: "test".to_string(),
            notes_for_user: "test".to_string(),
        }
    }

    #[test]
    fn test_batch_summary() {
        let candidates = vec![
            CandidateWithScore {
                spec: create_test_spec(),
                score: AlgorithmScore {
                    quality_score: 0.9,
                    robustness_score: 0.8,
                    novelty_score: 0.7,
                    family_match_score: 0.9,
                    estimated_cost: 100.0,
                    label: ScoreLabel::Jackpot,
                },
            },
            CandidateWithScore {
                spec: create_test_spec(),
                score: AlgorithmScore {
                    quality_score: 0.3,
                    robustness_score: 0.4,
                    novelty_score: 0.5,
                    family_match_score: 0.3,
                    estimated_cost: 50.0,
                    label: ScoreLabel::Miss,
                },
            },
        ];

        let summary = compute_batch_summary(&candidates);

        assert_eq!(summary.num_candidates, 2);
        assert_eq!(summary.num_jackpot, 1);
        assert_eq!(summary.num_miss, 1);
    }
}
