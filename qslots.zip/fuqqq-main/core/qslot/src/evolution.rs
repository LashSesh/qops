use fuq_core::SurgeryParams;
use metatron_core::{MetatronMove, MetatronRoute};
use rand::prelude::*;
use serde::{Deserialize, Serialize};
use tracing::{debug, info};

/// Algorithm evolution engine using genetic algorithm principles
#[derive(Debug, Clone)]
pub struct EvolutionEngine {
    pub population_size: usize,
    pub mutation_rate: f64,
    pub crossover_rate: f64,
    pub elitism_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvolutionConfig {
    pub generations: usize,
    pub population_size: usize,
    pub mutation_rate: f64,
    pub crossover_rate: f64,
    pub tournament_size: usize,
}

impl Default for EvolutionConfig {
    fn default() -> Self {
        Self {
            generations: 20,
            population_size: 20,
            mutation_rate: 0.2,
            crossover_rate: 0.7,
            tournament_size: 3,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvolutionResult {
    pub generations_completed: usize,
    pub best_score: f64,
    pub initial_score: f64,
    pub improvement: f64,
    pub improvement_percent: f64,
    pub final_population_size: usize,
}

#[derive(Debug, Clone)]
pub struct Individual {
    pub route: MetatronRoute,
    pub surgery_params: SurgeryParams,
    pub fitness: f64,
}

impl EvolutionEngine {
    pub fn new(config: EvolutionConfig) -> Self {
        Self {
            population_size: config.population_size,
            mutation_rate: config.mutation_rate,
            crossover_rate: config.crossover_rate,
            elitism_count: (config.population_size / 10).max(1),
        }
    }

    /// Evolve MetatronRoutes to find better algorithm configurations
    ///
    /// This is a genetic algorithm that:
    /// 1. Maintains a population of routes
    /// 2. Evaluates fitness (quality score)
    /// 3. Selects best routes (tournament selection)
    /// 4. Breeds new routes (crossover)
    /// 5. Mutates routes for diversity
    /// 6. Repeats for N generations
    pub fn evolve_routes(
        &self,
        initial_population: Vec<Individual>,
        generations: usize,
        fitness_fn: impl Fn(&MetatronRoute, &SurgeryParams) -> f64,
    ) -> (Vec<Individual>, EvolutionResult) {
        info!(
            "Starting evolution: {} generations, population {}",
            generations, self.population_size
        );

        let mut population = initial_population;
        let initial_best_fitness = population
            .iter()
            .map(|ind| ind.fitness)
            .fold(f64::NEG_INFINITY, f64::max);

        let mut rng = rand::thread_rng();

        for gen in 0..generations {
            // Evaluate fitness for all individuals
            for individual in &mut population {
                individual.fitness = fitness_fn(&individual.route, &individual.surgery_params);
            }

            // Sort by fitness (descending)
            population.sort_by(|a, b| b.fitness.partial_cmp(&a.fitness).unwrap());

            let best_fitness = population[0].fitness;
            debug!("Generation {}: Best fitness = {:.4}", gen + 1, best_fitness);

            // Selection
            let selected = self.tournament_selection(&population, &mut rng);

            // Crossover
            let offspring = self.crossover_routes(&selected, &mut rng);

            // Mutation
            let mutated = self.mutate_routes(offspring, &mut rng);

            // Elitism: keep best individuals
            let mut new_population = Vec::new();
            for i in 0..self.elitism_count.min(population.len()) {
                new_population.push(population[i].clone());
            }

            // Add mutated offspring
            new_population.extend(mutated);

            // Trim to population size
            new_population.truncate(self.population_size);

            population = new_population;
        }

        // Final fitness evaluation
        for individual in &mut population {
            individual.fitness = fitness_fn(&individual.route, &individual.surgery_params);
        }
        population.sort_by(|a, b| b.fitness.partial_cmp(&a.fitness).unwrap());

        let final_best_fitness = population[0].fitness;
        let improvement = final_best_fitness - initial_best_fitness;
        let improvement_percent = if initial_best_fitness > 0.0 {
            (improvement / initial_best_fitness) * 100.0
        } else {
            0.0
        };

        info!(
            "Evolution complete: {:.4} → {:.4} ({:+.2}%)",
            initial_best_fitness, final_best_fitness, improvement_percent
        );

        let result = EvolutionResult {
            generations_completed: generations,
            best_score: final_best_fitness,
            initial_score: initial_best_fitness,
            improvement,
            improvement_percent,
            final_population_size: population.len(),
        };

        (population, result)
    }

    /// Tournament selection
    fn tournament_selection<R: Rng>(
        &self,
        population: &[Individual],
        rng: &mut R,
    ) -> Vec<Individual> {
        let tournament_size = 3;
        let mut selected = Vec::new();

        for _ in 0..population.len() {
            // Run tournament
            let mut best: Option<&Individual> = None;
            let mut best_fitness = f64::NEG_INFINITY;

            for _ in 0..tournament_size {
                let idx = rng.gen_range(0..population.len());
                let individual = &population[idx];

                if individual.fitness > best_fitness {
                    best = Some(individual);
                    best_fitness = individual.fitness;
                }
            }

            if let Some(winner) = best {
                selected.push(winner.clone());
            }
        }

        selected
    }

    /// Crossover routes (single-point crossover)
    fn crossover_routes<R: Rng>(&self, parents: &[Individual], rng: &mut R) -> Vec<Individual> {
        let mut offspring = Vec::new();

        for chunk in parents.chunks(2) {
            if chunk.len() == 2 && rng.gen::<f64>() < self.crossover_rate {
                // Perform crossover
                let (child1, child2) = self.route_crossover(&chunk[0], &chunk[1], rng);
                offspring.push(child1);
                offspring.push(child2);
            } else {
                // No crossover, clone parents
                offspring.extend_from_slice(chunk);
            }
        }

        offspring
    }

    /// Single-point crossover for routes
    fn route_crossover<R: Rng>(
        &self,
        parent1: &Individual,
        parent2: &Individual,
        rng: &mut R,
    ) -> (Individual, Individual) {
        let len1 = parent1.route.moves.len();
        let len2 = parent2.route.moves.len();

        if len1 == 0 || len2 == 0 {
            return (parent1.clone(), parent2.clone());
        }

        let crossover_point1 = rng.gen_range(0..len1);
        let crossover_point2 = rng.gen_range(0..len2);

        let mut child1_moves = Vec::new();
        let mut child2_moves = Vec::new();

        // Child 1: first part of parent1 + second part of parent2
        child1_moves.extend_from_slice(&parent1.route.moves[..crossover_point1]);
        child1_moves.extend_from_slice(&parent2.route.moves[crossover_point2..]);

        // Child 2: first part of parent2 + second part of parent1
        child2_moves.extend_from_slice(&parent2.route.moves[..crossover_point2]);
        child2_moves.extend_from_slice(&parent1.route.moves[crossover_point1..]);

        let child1 = Individual {
            route: MetatronRoute {
                moves: child1_moves,
                permutations: vec![metatron_core::S7Permutation::identity()],
                signature: String::new(), // Will be regenerated
            },
            surgery_params: parent1.surgery_params.clone(),
            fitness: 0.0,
        };

        let child2 = Individual {
            route: MetatronRoute {
                moves: child2_moves,
                permutations: vec![metatron_core::S7Permutation::identity()],
                signature: String::new(),
            },
            surgery_params: parent2.surgery_params.clone(),
            fitness: 0.0,
        };

        (child1, child2)
    }

    /// Mutate routes
    fn mutate_routes<R: Rng>(&self, population: Vec<Individual>, rng: &mut R) -> Vec<Individual> {
        population
            .into_iter()
            .map(|mut individual| {
                if rng.gen::<f64>() < self.mutation_rate {
                    self.mutate_route(&mut individual.route, rng);
                }
                if rng.gen::<f64>() < self.mutation_rate * 0.5 {
                    self.mutate_surgery_params(&mut individual.surgery_params, rng);
                }
                individual
            })
            .collect()
    }

    /// Mutate a single route
    fn mutate_route<R: Rng>(&self, route: &mut MetatronRoute, rng: &mut R) {
        if route.moves.is_empty() {
            return;
        }

        let mutation_type = rng.gen_range(0..4);

        match mutation_type {
            0 => {
                // Add a random move
                let new_move = self.random_move(rng);
                let insert_pos = rng.gen_range(0..=route.moves.len());
                route.moves.insert(insert_pos, new_move);
            }
            1 => {
                // Remove a random move
                if !route.moves.is_empty() {
                    let remove_pos = rng.gen_range(0..route.moves.len());
                    route.moves.remove(remove_pos);
                }
            }
            2 => {
                // Replace a random move
                let replace_pos = rng.gen_range(0..route.moves.len());
                route.moves[replace_pos] = self.random_move(rng);
            }
            _ => {
                // Swap two random moves
                if route.moves.len() >= 2 {
                    let pos1 = rng.gen_range(0..route.moves.len());
                    let pos2 = rng.gen_range(0..route.moves.len());
                    route.moves.swap(pos1, pos2);
                }
            }
        }
    }

    /// Generate a random MetatronMove
    fn random_move<R: Rng>(&self, rng: &mut R) -> MetatronMove {
        match rng.gen_range(0..4) {
            0 => MetatronMove::Invert {
                axis: rng.gen_range(0..7),
            },
            1 => MetatronMove::Rotate {
                axis: rng.gen_range(0..7),
                angle: rng.gen_range(-3..4),
            },
            2 => MetatronMove::Mirror {
                plane: rng.gen_range(0..7),
            },
            _ => MetatronMove::Convert {
                phase: rng.gen_range(0..7),
            },
        }
    }

    /// Mutate surgery parameters
    fn mutate_surgery_params<R: Rng>(&self, params: &mut SurgeryParams, rng: &mut R) {
        // Mutate step_size
        if rng.gen::<f64>() < 0.5 {
            let factor = 1.0 + (rng.gen::<f64>() - 0.5) * 0.3; // ±15%
            params.step_size = (params.step_size * factor).clamp(0.001, 1.0);
        }

        // Mutate max_iterations
        if rng.gen::<f64>() < 0.5 {
            let delta = rng.gen_range(-20..=20);
            params.max_iterations =
                ((params.max_iterations as i32 + delta).max(10).min(1000)) as usize;
        }

        // Mutate convergence_threshold
        if rng.gen::<f64>() < 0.5 {
            let factor = 1.0 + (rng.gen::<f64>() - 0.5) * 0.5; // ±25%
            params.convergence_threshold =
                (params.convergence_threshold * factor).clamp(1e-6, 1e-2);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_evolution_engine_creation() {
        let config = EvolutionConfig::default();
        let engine = EvolutionEngine::new(config);

        assert_eq!(engine.population_size, 20);
        assert!(engine.mutation_rate > 0.0);
        assert!(engine.crossover_rate > 0.0);
    }

    #[test]
    fn test_route_mutation() {
        let config = EvolutionConfig::default();
        let engine = EvolutionEngine::new(config);
        let mut rng = rand::thread_rng();

        let mut route = MetatronRoute {
            moves: vec![
                MetatronMove::Invert { axis: 0 },
                MetatronMove::Rotate { axis: 1, angle: 1 },
            ],
            signature: String::new(),
        };

        let original_len = route.moves.len();
        engine.mutate_route(&mut route, &mut rng);

        // Route should have been mutated (length might change or moves might change)
        // Just check that it still exists and has moves
        assert!(!route.moves.is_empty());
    }

    #[test]
    fn test_crossover() {
        let config = EvolutionConfig::default();
        let engine = EvolutionEngine::new(config);
        let mut rng = rand::thread_rng();

        let parent1 = Individual {
            route: MetatronRoute {
                moves: vec![
                    MetatronMove::Invert { axis: 0 },
                    MetatronMove::Invert { axis: 1 },
                ],
                signature: String::new(),
            },
            surgery_params: SurgeryParams::default(),
            fitness: 0.5,
        };

        let parent2 = Individual {
            route: MetatronRoute {
                moves: vec![
                    MetatronMove::Rotate { axis: 0, angle: 1 },
                    MetatronMove::Rotate { axis: 1, angle: 2 },
                ],
                signature: String::new(),
            },
            surgery_params: SurgeryParams::default(),
            fitness: 0.6,
        };

        let (child1, child2) = engine.route_crossover(&parent1, &parent2, &mut rng);

        // Children should exist
        assert!(!child1.route.moves.is_empty());
        assert!(!child2.route.moves.is_empty());
    }
}
