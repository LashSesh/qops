// Prevents additional console window on Windows in release builds
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::{Deserialize, Serialize};
use std::sync::Mutex;
use tauri::State;

// Import core modules
use qslot::{AlgorithmBatch, QSlotEngine};

/// Application state
struct AppState {
    engine: Mutex<QSlotEngine>,
}

/// Spin request payload
#[derive(Debug, Deserialize)]
struct SpinRequest {
    problem_text: String,
    n_candidates: usize,
    spin_index: u64,
}

/// Spin response
#[derive(Debug, Serialize)]
struct SpinResponse {
    success: bool,
    batch: Option<AlgorithmBatch>,
    error: Option<String>,
}

/// Main SPIN command - generates algorithm candidates
#[tauri::command]
fn spin(request: SpinRequest, state: State<AppState>) -> SpinResponse {
    let mut engine = match state.engine.lock() {
        Ok(engine) => engine,
        Err(e) => {
            return SpinResponse {
                success: false,
                batch: None,
                error: Some(format!("Failed to lock engine: {}", e)),
            };
        }
    };

    match engine.design_algorithm_batch(
        &request.problem_text,
        request.n_candidates,
        request.spin_index,
    ) {
        Ok(batch) => SpinResponse {
            success: true,
            batch: Some(batch),
            error: None,
        },
        Err(e) => SpinResponse {
            success: false,
            batch: None,
            error: Some(format!("Algorithm generation failed: {}", e)),
        },
    }
}

/// Health check command
#[tauri::command]
fn health_check() -> String {
    "Metatron Q⊗DASH is running!".to_string()
}

fn main() {
    // Initialize Q⊗DASH engine
    let engine = QSlotEngine::new();

    tauri::Builder::default()
        .manage(AppState {
            engine: Mutex::new(engine),
        })
        .invoke_handler(tauri::generate_handler![spin, health_check])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
