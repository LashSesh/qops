import { useState } from "react";
import ProblemSetup from "./components/ProblemSetup";
import SlotMachine from "./components/SlotMachine";
import "./App.css";

export interface ProblemConfig {
  problemText: string;
  problemType: string;
}

function App() {
  const [problemConfig, setProblemConfig] = useState<ProblemConfig | null>(null);
  const [sessionStats, setSessionStats] = useState({
    totalSpins: 0,
    totalCandidates: 0,
    countMiss: 0,
    countOkay: 0,
    countGood: 0,
    countJackpot: 0,
  });

  const handleProblemLock = (config: ProblemConfig) => {
    setProblemConfig(config);
    // Reset session stats when locking new problem
    setSessionStats({
      totalSpins: 0,
      totalCandidates: 0,
      countMiss: 0,
      countOkay: 0,
      countGood: 0,
      countJackpot: 0,
    });
  };

  const handleReset = () => {
    setProblemConfig(null);
  };

  const updateSessionStats = (batchSummary: any) => {
    setSessionStats((prev) => ({
      totalSpins: prev.totalSpins + 1,
      totalCandidates: prev.totalCandidates + batchSummary.num_candidates,
      countMiss: prev.countMiss + batchSummary.num_miss,
      countOkay: prev.countOkay + batchSummary.num_okay,
      countGood: prev.countGood + batchSummary.num_good,
      countJackpot: prev.countJackpot + batchSummary.num_jackpot,
    }));
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1 className="app-title">
          Metatron Q⊗DASH
          <span className="subtitle">Quantum Algorithm Slot Machine</span>
        </h1>
      </header>

      <main className="app-main">
        {!problemConfig ? (
          <ProblemSetup onLock={handleProblemLock} />
        ) : (
          <SlotMachine
            problemConfig={problemConfig}
            sessionStats={sessionStats}
            onReset={handleReset}
            onUpdateStats={updateSessionStats}
          />
        )}
      </main>
    </div>
  );
}

export default App;
