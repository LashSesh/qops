import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';

interface MetatronRoute {
    moves: Array<{
        move_type: string;
        axis?: number;
        angle?: number;
        intensity: number;
    }>;
    signature: string;
}

interface MetatronCubeViewerProps {
    route?: MetatronRoute;
    animationState?: 'idle' | 'spinning' | 'converging';
    onAnimationComplete?: () => void;
}

/**
 * 3D Metatron Cube Visualization Component
 *
 * Renders a real-time 3D visualization of the Metatron Cube structure
 * with animated transformations based on algorithm generation routes.
 */
export const MetatronCubeViewer: React.FC<MetatronCubeViewerProps> = ({
    route,
    animationState = 'idle',
    onAnimationComplete
}) => {
    const mountRef = useRef<HTMLDivElement>(null);
    const sceneRef = useRef<THREE.Scene | null>(null);
    const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
    const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
    const cubeGroupRef = useRef<THREE.Group | null>(null);
    const [fps, setFps] = useState(60);

    useEffect(() => {
        if (!mountRef.current) return;

        // Setup scene
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x000510);
        scene.fog = new THREE.Fog(0x000510, 10, 50);
        sceneRef.current = scene;

        // Setup camera
        const camera = new THREE.PerspectiveCamera(
            75,
            mountRef.current.clientWidth / mountRef.current.clientHeight,
            0.1,
            1000
        );
        camera.position.set(0, 0, 8);
        cameraRef.current = camera;

        // Setup renderer
        const renderer = new THREE.WebGLRenderer({
            antialias: true,
            alpha: true,
            powerPreference: 'high-performance'
        });
        renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // Limit for performance
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        mountRef.current.appendChild(renderer.domElement);
        rendererRef.current = renderer;

        // Setup controls
        const controls = new OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        controls.minDistance = 5;
        controls.maxDistance = 20;
        controls.enablePan = false;

        // Create Metatron Cube geometry
        const cubeGroup = createMetatronCube();
        cubeGroupRef.current = cubeGroup;
        scene.add(cubeGroup);

        // Add lighting
        const ambientLight = new THREE.AmbientLight(0x404040, 1.5);
        scene.add(ambientLight);

        // Neon cyan light
        const light1 = new THREE.PointLight(0x00ffff, 2, 100);
        light1.position.set(5, 5, 5);
        light1.castShadow = true;
        scene.add(light1);

        // Neon purple light
        const light2 = new THREE.PointLight(0xff00ff, 2, 100);
        light2.position.set(-5, -5, 5);
        light2.castShadow = true;
        scene.add(light2);

        // Neon gold light
        const light3 = new THREE.PointLight(0xffd700, 1, 100);
        light3.position.set(0, 5, -5);
        scene.add(light3);

        // Animation loop with FPS tracking
        let lastTime = performance.now();
        let frameCount = 0;

        const animate = () => {
            requestAnimationFrame(animate);

            // FPS tracking
            const now = performance.now();
            frameCount++;
            if (now >= lastTime + 1000) {
                setFps(Math.round((frameCount * 1000) / (now - lastTime)));
                frameCount = 0;
                lastTime = now;
            }

            // Animate cube based on state
            if (cubeGroupRef.current) {
                switch (animationState) {
                    case 'spinning':
                        cubeGroupRef.current.rotation.y += 0.02;
                        cubeGroupRef.current.rotation.x += 0.01;
                        break;
                    case 'converging':
                        cubeGroupRef.current.rotation.y += 0.01;
                        // Pulse effect
                        const scale = 1 + Math.sin(now * 0.003) * 0.1;
                        cubeGroupRef.current.scale.set(scale, scale, scale);
                        break;
                    case 'idle':
                        // Gentle rotation
                        cubeGroupRef.current.rotation.y += 0.005;
                        break;
                }
            }

            // Animate lights
            light1.position.x = Math.sin(now * 0.001) * 5;
            light1.position.y = Math.cos(now * 0.001) * 5;

            light2.position.x = Math.cos(now * 0.0015) * 5;
            light2.position.z = Math.sin(now * 0.0015) * 5;

            controls.update();
            renderer.render(scene, camera);
        };
        animate();

        // Handle window resize
        const handleResize = () => {
            if (!mountRef.current || !camera || !renderer) return;

            const width = mountRef.current.clientWidth;
            const height = mountRef.current.clientHeight;

            camera.aspect = width / height;
            camera.updateProjectionMatrix();
            renderer.setSize(width, height);
        };

        window.addEventListener('resize', handleResize);

        // Cleanup
        return () => {
            window.removeEventListener('resize', handleResize);
            renderer.dispose();
            controls.dispose();
            mountRef.current?.removeChild(renderer.domElement);

            // Dispose geometries and materials
            scene.traverse((object) => {
                if (object instanceof THREE.Mesh) {
                    object.geometry?.dispose();
                    if (Array.isArray(object.material)) {
                        object.material.forEach(mat => mat.dispose());
                    } else {
                        object.material?.dispose();
                    }
                }
            });
        };
    }, []);

    // React to route changes
    useEffect(() => {
        if (route && cubeGroupRef.current) {
            applyRouteTransformations(cubeGroupRef.current, route);
        }
    }, [route]);

    return (
        <div style={{ position: 'relative', width: '100%', height: '100%' }}>
            <div
                ref={mountRef}
                className="metatron-cube-viewer"
                style={{ width: '100%', height: '600px' }}
            />
            <div
                style={{
                    position: 'absolute',
                    top: 10,
                    right: 10,
                    color: '#00ffff',
                    fontFamily: 'monospace',
                    fontSize: '14px',
                    textShadow: '0 0 10px rgba(0, 255, 255, 0.8)',
                    pointerEvents: 'none'
                }}
            >
                {fps} FPS
            </div>
            {route && (
                <div
                    style={{
                        position: 'absolute',
                        bottom: 10,
                        left: 10,
                        color: '#ffd700',
                        fontFamily: 'monospace',
                        fontSize: '12px',
                        textShadow: '0 0 10px rgba(255, 215, 0, 0.8)',
                        pointerEvents: 'none',
                        maxWidth: '300px'
                    }}
                >
                    Route: {route.signature}
                </div>
            )}
        </div>
    );
};

/**
 * Create the Metatron Cube geometry
 */
function createMetatronCube(): THREE.Group {
    const group = new THREE.Group();

    // Node positions for Metatron's Cube (sacred geometry)
    const nodePositions = [
        [0, 0, 0],          // Center
        [1, 0, 0],          // +X
        [-1, 0, 0],         // -X
        [0, 1, 0],          // +Y
        [0, -1, 0],         // -Y
        [0, 0, 1],          // +Z
        [0, 0, -1],         // -Z
        [0.707, 0.707, 0],  // Diagonal 1
        [-0.707, -0.707, 0],// Diagonal 2
        [0.707, 0, 0.707],  // Diagonal 3
        [-0.707, 0, -0.707],// Diagonal 4
        [0, 0.707, 0.707],  // Diagonal 5
        [0, -0.707, -0.707],// Diagonal 6
    ];

    // Create nodes (spheres) with neon glow
    const nodeMaterial = new THREE.MeshPhongMaterial({
        color: 0x00ffff,
        emissive: 0x00ffff,
        emissiveIntensity: 0.5,
        shininess: 100,
        transparent: true,
        opacity: 0.9
    });

    nodePositions.forEach((pos) => {
        const geometry = new THREE.SphereGeometry(0.15, 16, 16);
        const node = new THREE.Mesh(geometry, nodeMaterial);
        node.position.set(pos[0] * 2, pos[1] * 2, pos[2] * 2);
        node.castShadow = true;
        group.add(node);
    });

    // Create edges (lines) connecting nodes
    const edgeMaterial = new THREE.LineBasicMaterial({
        color: 0xff00ff,
        opacity: 0.6,
        transparent: true,
        linewidth: 2
    });

    // Connect center to all other nodes
    for (let i = 1; i < nodePositions.length; i++) {
        const points = [
            new THREE.Vector3(0, 0, 0),
            new THREE.Vector3(nodePositions[i][0] * 2, nodePositions[i][1] * 2, nodePositions[i][2] * 2)
        ];
        const geometry = new THREE.BufferGeometry().setFromPoints(points);
        const line = new THREE.Line(geometry, edgeMaterial);
        group.add(line);
    }

    // Add outer cube wireframe
    const cubeGeometry = new THREE.BoxGeometry(4, 4, 4);
    const cubeMaterial = new THREE.MeshBasicMaterial({
        color: 0xffd700,
        wireframe: true,
        transparent: true,
        opacity: 0.3
    });
    const cube = new THREE.Mesh(cubeGeometry, cubeMaterial);
    group.add(cube);

    return group;
}

/**
 * Apply route transformations to the cube
 */
function applyRouteTransformations(group: THREE.Group, route: MetatronRoute) {
    let totalRotation = 0;

    route.moves.forEach((move, index) => {
        const delay = index * 100; // Stagger animations

        setTimeout(() => {
            switch (move.move_type) {
                case 'Rotate':
                    if (move.axis !== undefined && move.angle !== undefined) {
                        const axis = getAxisVector(move.axis);
                        const angle = (move.angle * Math.PI) / 180;
                        group.rotateOnAxis(axis, angle * 0.1);
                        totalRotation += Math.abs(angle);
                    }
                    break;

                case 'Mirror':
                    if (move.axis !== undefined) {
                        const scale = new THREE.Vector3(1, 1, 1);
                        if (move.axis === 0) scale.x = -1;
                        else if (move.axis === 1) scale.y = -1;
                        else if (move.axis === 2) scale.z = -1;

                        group.scale.multiply(scale);
                    }
                    break;

                case 'Invert':
                    // Invert by rotating 180 degrees
                    if (move.axis !== undefined) {
                        const axis = getAxisVector(move.axis);
                        group.rotateOnAxis(axis, Math.PI);
                    }
                    break;
            }

            // Add glow effect based on intensity
            group.traverse((object) => {
                if (object instanceof THREE.Mesh && object.material instanceof THREE.MeshPhongMaterial) {
                    object.material.emissiveIntensity = move.intensity;
                }
            });
        }, delay);
    });
}

/**
 * Get THREE.Vector3 for axis index
 */
function getAxisVector(axis: number): THREE.Vector3 {
    switch (axis) {
        case 0: return new THREE.Vector3(1, 0, 0); // X
        case 1: return new THREE.Vector3(0, 1, 0); // Y
        case 2: return new THREE.Vector3(0, 0, 1); // Z
        default: return new THREE.Vector3(0, 1, 0);
    }
}

export default MetatronCubeViewer;
