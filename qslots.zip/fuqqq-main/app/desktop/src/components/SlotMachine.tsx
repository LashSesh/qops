import { useState } from "react";
import { invoke } from "@tauri-apps/api/tauri";
import type { ProblemConfig } from "../App";
import CandidateCard from "./CandidateCard";
import "./SlotMachine.css";

interface SlotMachineProps {
  problemConfig: ProblemConfig;
  sessionStats: {
    totalSpins: number;
    totalCandidates: number;
    countMiss: number;
    countOkay: number;
    countGood: number;
    countJackpot: number;
  };
  onReset: () => void;
  onUpdateStats: (summary: any) => void;
}

function SlotMachine({
  problemConfig,
  sessionStats,
  onReset,
  onUpdateStats,
}: SlotMachineProps) {
  const [isSpinning, setIsSpinning] = useState(false);
  const [candidates, setCandidates] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleSpin = async () => {
    setIsSpinning(true);
    setError(null);

    try {
      const response: any = await invoke("spin", {
        request: {
          problem_text: problemConfig.problemText,
          n_candidates: 5,
          spin_index: sessionStats.totalSpins + 1,
        },
      });

      if (response.success && response.batch) {
        setCandidates(response.batch.candidates || []);
        onUpdateStats(response.batch.summary);
      } else {
        setError(response.error || "Unknown error occurred");
      }
    } catch (err) {
      setError(`Failed to spin: ${err}`);
    } finally {
      setIsSpinning(false);
    }
  };

  return (
    <div className="slot-machine">
      <div className="slot-machine-header">
        <div className="problem-info">
          <h3>Active Problem:</h3>
          <p className="problem-text">
            {problemConfig.problemText.substring(0, 100)}
            {problemConfig.problemText.length > 100 ? "..." : ""}
          </p>
          <button className="reset-button" onClick={onReset}>
            Change Problem
          </button>
        </div>

        <div className="session-stats">
          <h3>Session Statistics</h3>
          <div className="stats-grid">
            <div className="stat-item">
              <span className="stat-value">{sessionStats.totalSpins}</span>
              <span className="stat-label">Total Spins</span>
            </div>
            <div className="stat-item">
              <span className="stat-value">{sessionStats.totalCandidates}</span>
              <span className="stat-label">Candidates</span>
            </div>
            <div className="stat-item jackpot">
              <span className="stat-value">{sessionStats.countJackpot}</span>
              <span className="stat-label">Jackpots</span>
            </div>
            <div className="stat-item good">
              <span className="stat-value">{sessionStats.countGood}</span>
              <span className="stat-label">Good</span>
            </div>
            <div className="stat-item okay">
              <span className="stat-value">{sessionStats.countOkay}</span>
              <span className="stat-label">Okay</span>
            </div>
            <div className="stat-item miss">
              <span className="stat-value">{sessionStats.countMiss}</span>
              <span className="stat-label">Miss</span>
            </div>
          </div>
        </div>
      </div>

      <div className="spin-section">
        <button
          className={`spin-button ${isSpinning ? "spinning" : ""}`}
          onClick={handleSpin}
          disabled={isSpinning}
        >
          {isSpinning ? "SPINNING..." : "SPIN"}
        </button>
        {error && <div className="error-message">{error}</div>}
      </div>

      <div className="candidates-section">
        {candidates.length > 0 && (
          <>
            <h3 className="candidates-title">
              Algorithm Candidates (Spin #{sessionStats.totalSpins})
            </h3>
            <div className="candidates-grid">
              {candidates.map((candidate, index) => (
                <CandidateCard key={index} candidate={candidate} index={index} />
              ))}
            </div>
          </>
        )}

        {candidates.length === 0 && !isSpinning && (
          <div className="empty-state">
            <p>Press the SPIN button to generate quantum algorithm candidates!</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default SlotMachine;
