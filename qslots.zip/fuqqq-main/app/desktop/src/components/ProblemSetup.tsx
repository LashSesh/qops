import { useState } from "react";
import type { ProblemConfig } from "../App";
import "./ProblemSetup.css";

interface ProblemSetupProps {
  onLock: (config: ProblemConfig) => void;
}

const PROBLEM_TYPES = [
  { value: "Search", label: "Search" },
  { value: "CombinatorialOptimization", label: "Combinatorial Optimization" },
  { value: "Classification", label: "Classification" },
  { value: "Regression", label: "Regression" },
  { value: "Simulation", label: "Simulation" },
  { value: "Custom", label: "Custom" },
];

function ProblemSetup({ onLock }: ProblemSetupProps) {
  const [problemText, setProblemText] = useState("");
  const [problemType, setProblemType] = useState("Search");

  const handleLock = () => {
    if (problemText.trim().length === 0) {
      alert("Please describe your problem before locking it.");
      return;
    }

    onLock({
      problemText: problemText.trim(),
      problemType,
    });
  };

  return (
    <div className="problem-setup">
      <div className="setup-card">
        <h2 className="setup-title">Problem Setup</h2>
        <p className="setup-description">
          Describe your problem in your own words. The quantum algorithm slot
          machine will generate tailored algorithm templates for you.
        </p>

        <div className="form-group">
          <label htmlFor="problem-text" className="form-label">
            Problem Description
          </label>
          <textarea
            id="problem-text"
            className="problem-textarea"
            placeholder="Example: Find the shortest path in a graph with 100 nodes and 500 edges..."
            value={problemText}
            onChange={(e) => setProblemText(e.target.value)}
            rows={8}
          />
        </div>

        <div className="form-group">
          <label htmlFor="problem-type" className="form-label">
            Problem Type (Optional)
          </label>
          <select
            id="problem-type"
            className="problem-select"
            value={problemType}
            onChange={(e) => setProblemType(e.target.value)}
          >
            {PROBLEM_TYPES.map((type) => (
              <option key={type.value} value={type.value}>
                {type.label}
              </option>
            ))}
          </select>
        </div>

        <button className="lock-button" onClick={handleLock}>
          Lock Problem & Open Slot Machine
        </button>
      </div>
    </div>
  );
}

export default ProblemSetup;
