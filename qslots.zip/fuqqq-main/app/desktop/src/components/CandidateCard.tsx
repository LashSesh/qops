import { useState } from "react";
import "./CandidateCard.css";

interface CandidateCardProps {
  candidate: {
    spec: any;
    score: {
      quality_score: number;
      robustness_score: number;
      novelty_score: number;
      family_match_score: number;
      estimated_cost: number;
      label: string;
    };
  };
  index: number;
}

function CandidateCard({ candidate, index }: CandidateCardProps) {
  const [showDetails, setShowDetails] = useState(false);

  const { spec, score } = candidate;
  const labelClass = score.label.toLowerCase();

  const getScoreBar = (value: number, label: string) => (
    <div className="score-bar-container">
      <span className="score-label">{label}</span>
      <div className="score-bar">
        <div
          className="score-fill"
          style={{ width: `${value * 100}%` }}
        />
      </div>
      <span className="score-value">{(value * 100).toFixed(0)}%</span>
    </div>
  );

  return (
    <div className={`candidate-card label-${labelClass}`}>
      <div className="card-header">
        <div className="card-title">
          <span className="candidate-number">#{index + 1}</span>
          <span className="algorithm-family">{spec.family}</span>
        </div>
        <span className={`score-label-badge label-${labelClass}`}>
          {score.label.toUpperCase()}
        </span>
      </div>

      <div className="card-body">
        <div className="score-bars">
          {getScoreBar(score.quality_score, "Quality")}
          {getScoreBar(score.robustness_score, "Robustness")}
          {getScoreBar(score.novelty_score, "Novelty")}
          {getScoreBar(score.family_match_score, "Match")}
        </div>

        <div className="user-notes">
          <p>{spec.notes_for_user}</p>
        </div>

        <div className="cost-estimate">
          <span className="cost-label">Est. Cost:</span>
          <span className="cost-value">{score.estimated_cost.toFixed(0)} units</span>
        </div>

        <button
          className="details-toggle"
          onClick={() => setShowDetails(!showDetails)}
        >
          {showDetails ? "Hide Details" : "Show Details"}
        </button>

        {showDetails && (
          <div className="details-panel">
            <div className="detail-section">
              <h4>Algorithm Configuration</h4>
              <div className="detail-item">
                <span className="detail-label">ID:</span>
                <span className="detail-value">{spec.id}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">DTL Mode:</span>
                <span className="detail-value">{spec.dtl_mode}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">Metatron Signature:</span>
                <span className="detail-value">{spec.metatron_signature}</span>
              </div>
            </div>

            <div className="detail-section">
              <h4>State Space</h4>
              <div className="detail-item">
                <span className="detail-label">Continuous Dim:</span>
                <span className="detail-value">
                  {spec.state_space.continuous_space.dim}
                </span>
              </div>
              <div className="detail-item">
                <span className="detail-label">Registers:</span>
                <span className="detail-value">
                  {spec.state_space.discrete_registers.length}
                </span>
              </div>
              {spec.state_space.estimated_dimension && (
                <div className="detail-item">
                  <span className="detail-label">State Space Size:</span>
                  <span className="detail-value">
                    2^{Math.log2(Number(spec.state_space.estimated_dimension)).toFixed(0)}
                  </span>
                </div>
              )}
            </div>

            <div className="detail-section">
              <h4>Operators</h4>
              <div className="operators-list">
                {spec.operators.map((op: any, idx: number) => (
                  <div key={idx} className="operator-item">
                    <span className="operator-role">{op.role}</span>
                    <span className="operator-id">{op.id}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="detail-section">
              <h4>Seraphic Hint</h4>
              <p className="seraphic-hint">{spec.seraphic_hint}</p>
            </div>

            <div className="detail-section">
              <h4>FUQ Metadata</h4>
              <p className="fuq-metadata">{spec.fuq_metadata}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default CandidateCard;
