import * as Tone from 'tone';

/**
 * Quantum Arcade Audio System
 *
 * Provides immersive audio feedback for algorithm generation with:
 * - Ambient soundscapes
 * - Reactive sound effects
 * - Musical feedback based on quality scores
 */
export class QuantumAudioSystem {
    private synth: Tone.PolySynth;
    private reverb: Tone.Reverb;
    private delay: Tone.FeedbackDelay;
    private filter: Tone.Filter;
    private ambientLoop: Tone.Loop | null = null;
    private isInitialized = false;
    private masterVolume: Tone.Volume;

    constructor() {
        // Create master volume control
        this.masterVolume = new Tone.Volume(-10).toDestination();

        // Create polyphonic synthesizer
        this.synth = new Tone.PolySynth(Tone.Synth, {
            oscillator: {
                type: 'triangle'
            },
            envelope: {
                attack: 0.02,
                decay: 0.1,
                sustain: 0.3,
                release: 1
            }
        });

        // Create reverb for spacious sound
        this.reverb = new Tone.Reverb({
            decay: 4,
            wet: 0.5,
            preDelay: 0.01
        }).connect(this.masterVolume);

        // Create feedback delay for echoes
        this.delay = new Tone.FeedbackDelay({
            delayTime: '8n',
            feedback: 0.3,
            wet: 0.3
        }).connect(this.reverb);

        // Create filter for tonal shaping
        this.filter = new Tone.Filter({
            type: 'lowpass',
            frequency: 2000,
            Q: 1
        }).connect(this.delay);

        // Connect synth to effect chain
        this.synth.connect(this.filter);
    }

    /**
     * Initialize audio system (requires user interaction)
     */
    async initialize(): Promise<void> {
        if (!this.isInitialized) {
            await Tone.start();
            this.startAmbientSoundscape();
            this.isInitialized = true;
            console.log('🎵 Quantum Audio System initialized');
        }
    }

    /**
     * Start ambient soundscape
     */
    private startAmbientSoundscape(): void {
        // Create ambient drone
        const ambientSynth = new Tone.Synth({
            oscillator: { type: 'sine' },
            envelope: {
                attack: 2,
                decay: 0,
                sustain: 1,
                release: 2
            }
        }).connect(this.masterVolume);

        ambientSynth.volume.value = -25;

        // Create ambient loop
        this.ambientLoop = new Tone.Loop((time) => {
            const notes = ['C2', 'G2', 'D3', 'A2', 'E2'];
            const note = notes[Math.floor(Math.random() * notes.length)];
            ambientSynth.triggerAttackRelease(note, '2n', time);
        }, '2n');

        this.ambientLoop.start(0);
        Tone.Transport.start();
    }

    /**
     * Play sound when starting algorithm generation
     */
    playSpinSound(): void {
        if (!this.isInitialized) return;

        const now = Tone.now();

        // Ascending arpeggio
        const notes = ['C4', 'E4', 'G4', 'C5', 'E5'];
        notes.forEach((note, i) => {
            this.synth.triggerAttackRelease(note, '32n', now + i * 0.05);
        });

        // Whoosh sound effect
        const noise = new Tone.Noise('pink').connect(this.masterVolume);
        noise.volume.value = -15;
        noise.start(now);
        noise.stop(now + 0.5);

        // Filter sweep
        this.filter.frequency.rampTo(5000, 0.5, now);
        setTimeout(() => {
            this.filter.frequency.rampTo(2000, 0.3);
        }, 500);
    }

    /**
     * Play sound based on algorithm quality label
     */
    playResultSound(label: 'Miss' | 'Okay' | 'Good' | 'Jackpot'): void {
        if (!this.isInitialized) return;

        const now = Tone.now();

        switch (label) {
            case 'Miss':
                // Descending minor chord
                this.synth.triggerAttackRelease(['C3', 'Eb3', 'G3'], '4n', now);
                this.filter.frequency.rampTo(500, 0.2, now);
                break;

            case 'Okay':
                // Simple major chord
                this.synth.triggerAttackRelease(['C4', 'E4', 'G4'], '4n', now);
                break;

            case 'Good':
                // Bright major 7th chord
                this.synth.triggerAttackRelease(['C4', 'E4', 'G4', 'B4'], '4n', now);
                this.filter.frequency.rampTo(3000, 0.2, now);
                break;

            case 'Jackpot':
                // Triumphant fanfare
                this.playJackpotFanfare(now);
                break;
        }

        // Reset filter after sound
        setTimeout(() => {
            this.filter.frequency.rampTo(2000, 0.3);
        }, 500);
    }

    /**
     * Play jackpot fanfare
     */
    private playJackpotFanfare(startTime: number): void {
        const fanfareChords = [
            ['C5', 'E5', 'G5'],
            ['E5', 'G5', 'C6'],
            ['G5', 'C6', 'E6']
        ];

        fanfareChords.forEach((chord, i) => {
            this.synth.triggerAttackRelease(chord, '8n', startTime + i * 0.1);
        });

        // Add bell-like metallic sound
        const metalSynth = new Tone.MetalSynth({
            frequency: 1000,
            envelope: {
                attack: 0.001,
                decay: 0.4,
                release: 0.4
            },
            harmonicity: 12,
            modulationIndex: 20,
            resonance: 3000,
            octaves: 1.5
        }).connect(this.masterVolume);

        metalSynth.volume.value = -10;
        metalSynth.triggerAttackRelease('C6', '2n', startTime);

        // Sparkle effect
        for (let i = 0; i < 8; i++) {
            const noteIndex = Math.floor(Math.random() * 12);
            const note = Tone.Frequency(1000 + noteIndex * 100, 'hz').toNote();
            setTimeout(() => {
                this.synth.triggerAttackRelease(note, '32n');
            }, i * 50);
        }
    }

    /**
     * Play sound during algorithm generation progress
     */
    playProgressTick(progress: number): void {
        if (!this.isInitialized) return;

        // Map progress (0-1) to pitch (lower = early, higher = late)
        const baseFreq = 400;
        const maxFreq = 1200;
        const freq = baseFreq + progress * (maxFreq - baseFreq);

        const note = Tone.Frequency(freq, 'hz').toNote();
        this.synth.triggerAttackRelease(note, '64n');
    }

    /**
     * Play error sound
     */
    playErrorSound(): void {
        if (!this.isInitialized) return;

        const now = Tone.now();

        // Dissonant chord
        this.synth.triggerAttackRelease(['C3', 'Db3', 'D3'], '4n', now);

        // Harsh noise burst
        const noise = new Tone.Noise('brown').connect(this.masterVolume);
        noise.volume.value = -20;
        noise.start(now);
        noise.stop(now + 0.15);
    }

    /**
     * Play cache hit sound (subtle positive feedback)
     */
    playCacheHitSound(): void {
        if (!this.isInitialized) return;

        // Quick ascending blip
        this.synth.triggerAttackRelease('E5', '64n');
        setTimeout(() => {
            this.synth.triggerAttackRelease('G5', '64n');
        }, 30);
    }

    /**
     * Play convergence sound during FUQ surgery
     */
    playConvergenceSound(convergenceValue: number): void {
        if (!this.isInitialized) return;

        // Map convergence (0-1) to pitch stability
        const baseNote = 'C4';
        const detune = (1 - convergenceValue) * 100; // More detuned = less converged

        this.synth.triggerAttackRelease(baseNote, '16n');

        // Add subtle detuning for non-converged states
        if (detune > 10) {
            const detuneOsc = new Tone.Oscillator({
                frequency: Tone.Frequency(baseNote).toFrequency() * (1 + detune / 100),
                type: 'sine'
            }).connect(this.masterVolume);

            detuneOsc.volume.value = -30;
            detuneOsc.start();
            detuneOsc.stop('+16n');
        }
    }

    /**
     * Set master volume (0-1)
     */
    setVolume(volume: number): void {
        const dbValue = Tone.gainToDb(volume);
        this.masterVolume.volume.value = dbValue;
    }

    /**
     * Mute/unmute
     */
    setMuted(muted: boolean): void {
        this.masterVolume.mute = muted;
    }

    /**
     * Stop all sounds and cleanup
     */
    dispose(): void {
        if (this.ambientLoop) {
            this.ambientLoop.stop();
            this.ambientLoop.dispose();
        }

        Tone.Transport.stop();
        this.synth.dispose();
        this.reverb.dispose();
        this.delay.dispose();
        this.filter.dispose();
        this.masterVolume.dispose();

        this.isInitialized = false;
    }
}

// Singleton instance
let audioSystemInstance: QuantumAudioSystem | null = null;

/**
 * Get global audio system instance
 */
export function getAudioSystem(): QuantumAudioSystem {
    if (!audioSystemInstance) {
        audioSystemInstance = new QuantumAudioSystem();
    }
    return audioSystemInstance;
}

export default QuantumAudioSystem;
