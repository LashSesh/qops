# Metatron Q⊗DASH – Revidierte Evolution Roadmap

## Von MVP zu Production-Grade Quantum Algorithm Synthesis Laboratory

**Version: Evolution Protocol 2.1 (Revised)**
**Datum: 2025-11-14**
**Basierend auf: Codebase-Analyse des aktuellen MVP**

---

## 📊 Aktueller Status: MVP-Analyse

### ✅ Bereits Implementiert (Starke Basis!)

**Core Funktionalität (80% MVP-Complete):**
- ✅ **Metatron Core**: S7-Permutationen, H13-Graph (13 Nodes, 78 Edges), Routing-Algorithmus
- ✅ **FUQ Core**: 5D State Space, Operator-Algebra, Surgery Loop, Singularity Detection
- ✅ **QSlot Engine**: Vollständige Pipeline (Problem → Algorithm)
- ✅ **8 Algorithm Families**: Grover, QAOA, VQE, VQC, QuantumWalk, BosonSampling, MetatronResonator, Hybrid
- ✅ **Tauri Desktop App**: Funktionsfähiges React-Frontend
- ✅ **Scoring System**: Quality, Robustness, Novelty, Family-Match
- ✅ **Basic Tests**: Unit-Tests in allen Core-Modulen

### ❌ Fehlende Kernfunktionen

**Konzeptuelle Lücken:**
- ❌ **Seraphic Calibration**: Context wird getracked, aber nicht für Feedback genutzt
- ❌ **Export System**: Keine Möglichkeit, Algorithmen zu speichern (JSON/YAML/Qiskit)
- ❌ **Persistence**: Keine Session-History, Lernen geht bei Neustart verloren
- ❌ **Advanced Parsing**: Problem-Type-Erkennung ist zu simpel

**Performance & Skalierung:**
- ❌ **Parallel Processing**: Single-threaded, keine Caching-Layer
- ❌ **10x Durchsatz**: Spin-Zeit ~2s, Ziel <200ms

**User Experience:**
- ❌ **3D Visualization**: Kein Metatron Cube Rendering
- ❌ **Audio System**: Keine Sound-Effekte
- ❌ **Arcade Animations**: Statische UI
- ❌ **Comparison Tools**: Kein Side-by-Side-Vergleich

**Production-Readiness:**
- ❌ **Logging & Monitoring**: Keine strukturierte Observability
- ❌ **Error Recovery**: Basic Error Handling, aber nicht umfassend
- ❌ **Security**: Keine Input-Sanitization

---

## 🎯 Revidierte Strategie: "Konzept vor Kosmetik"

### Kernproblem der Original-Roadmap

Die ursprüngliche Reihenfolge priorisierte:
```
Performance (Pack 1) → Visual (Pack 2) → Laboratory (Pack 3) → Learning (Pack 4)
```

**Fehler:** Das **konzeptuelle Herz** (Seraphic Calibration) kommt zu spät!

### Neue Reihenfolge: "Inside-Out"

```
Core Concepts (Pack 1A) → Learning (Pack 4) → Laboratory (Pack 3) →
Performance (Pack 1B) → Hardening (Pack 6) → Visual (Pack 2) → Advanced (Pack 5)
```

**Begründung:**
1. **Seraphic Calibration** ist das Alleinstellungsmerkmal → Priorität #1
2. **Export & Laboratory** machen das System praktisch nutzbar
3. **Performance** erst optimieren, wenn Features komplett sind
4. **Visual Overdrive** ist "nice-to-have", nicht "must-have"
5. **Advanced Features** (Pack 5) sind optional für Post-1.0

---

## 📦 Neue Pack-Struktur

---

# 🔧 UPGRADE PACK 1A: Kern-Features & Algorithm Library

## "Foundation Completeness" – Essentials First

### 🎯 Ziel

Das MVP-Konzept **vollständig** implementieren:
- 15 neue Algorithm Families (Total: 23)
- Export-System (JSON, YAML, OpenQASM, Qiskit, Cirq)
- Verbessertes Scoring (Multi-Objective)
- Basic Logging & Monitoring

### 📊 Success Metrics

- ✅ 23+ Algorithm Families verfügbar
- ✅ Export funktioniert für alle 5 Major-Formate
- ✅ Multi-Objective-Score mit Pareto-Fronts
- ✅ Structured Logging in allen Modulen
- ✅ <5% Fehlerrate bei Export-Validation

### ⏱️ Dauer: 2-3 Wochen

---

## 1A.1 Erweiterte Algorithm Library

### Neue Families (15 zusätzlich)

**Optimization:**
1. **QUBO-Solver** (Quadratic Unconstrained Binary Optimization)
2. **MaxCut-Specialized** (Graph Partitioning)
3. **TSP-Quantum** (Traveling Salesman mit Quantum Speedup)
4. **Portfolio-Optimization** (Finance-spezifisch)

**Machine Learning:**
5. **QSVM** (Quantum Support Vector Machine)
6. **Quantum-Boltzmann-Machine** (Generative Model)
7. **Quantum-Kernel-Method** (Feature Mapping)

**Chemistry/Simulation:**
8. **Hamiltonian-Simulation** (Trotter-basiert)
9. **Quantum-Phase-Estimation** (Eigenvalue Problems)
10. **Lattice-Surgery** (Topological QC)

**Hybrid:**
11. **QAOA-Adaptiv** (Mit klassischer Optimierung)
12. **VQE-Ansatz-Zoo** (Multiple Ansätze)
13. **Quantum-Classical-Hybrid-NN** (Neural Networks)

**Exotic:**
14. **Adiabatic-Quantum-Computing** (Analog-basiert)
15. **Measurement-Based-QC** (Cluster States)

### Implementation: `core/fuq_core/src/quantum_bridge.rs`

Ergänze `select_algorithm_family()`:

```rust
pub fn select_algorithm_family(
    problem_type: ProblemType,
    singularity_type: SingularityType,
    spectral_signature: &[f64; 5],
) -> AlgorithmFamily {
    use AlgorithmFamily::*;
    use ProblemType::*;
    use SingularityType::*;

    // Erweiterte Matching-Logic
    match (problem_type, singularity_type) {
        // Original Families (behalten)
        (Search, Vortex) => GroverLikeSearch,
        (CombinatorialOptimization, Attractor | Saddle) => {
            // Differenziere basierend auf Spektrum
            if spectral_signature[0] > 0.7 {
                QAOA_Standard
            } else if spectral_signature[1] > 0.6 {
                QUBOSolver
            } else {
                MaxCutSpecialized
            }
        },

        // Neue Families
        (CombinatorialOptimization, Complex) => TSPQuantum,
        (Regression | Classification, Vortex) => QSVM,
        (Regression | Classification, Attractor) => QuantumKernelMethod,
        (Simulation, Attractor) => HamiltonianSimulation,
        (Simulation, Saddle) => QuantumPhaseEstimation,

        // Hybrid für komplexe Fälle
        (Custom, _) => {
            if spectral_signature[2] > 0.8 {
                QAOAAdaptive
            } else {
                QuantumClassicalHybridNN
            }
        },

        // Fallback
        _ => MetatronResonator,
    }
}
```

### Neue Enum-Varianten: `core/fuq_core/src/types.rs`

```rust
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AlgorithmFamily {
    // Original (8)
    GroverLikeSearch,
    QuantumWalk,
    QAOA_Standard,
    VQE_Standard,
    VQC_QML,
    BosonSamplingLike,
    MetatronResonator,
    HybridAnalogCustom,

    // Optimization (4)
    QUBOSolver,
    MaxCutSpecialized,
    TSPQuantum,
    PortfolioOptimization,

    // Machine Learning (3)
    QSVM,
    QuantumBoltzmannMachine,
    QuantumKernelMethod,

    // Chemistry/Simulation (3)
    HamiltonianSimulation,
    QuantumPhaseEstimation,
    LatticeSurgery,

    // Hybrid (3)
    QAOAAdaptive,
    VQEAnsatzZoo,
    QuantumClassicalHybridNN,

    // Exotic (2)
    AdiabaticQuantumComputing,
    MeasurementBasedQC,
}

impl AlgorithmFamily {
    pub fn description(&self) -> &'static str {
        match self {
            Self::GroverLikeSearch => "Grover-inspired amplitude amplification for unstructured search",
            Self::QuantumWalk => "Quantum walk on graph with oracle-based navigation",
            Self::QAOA_Standard => "Quantum Approximate Optimization Algorithm for combinatorial problems",
            Self::VQE_Standard => "Variational Quantum Eigensolver for ground state energy",
            Self::VQC_QML => "Variational Quantum Classifier for supervised learning",
            Self::BosonSamplingLike => "Gaussian Boson Sampling for specific computational tasks",
            Self::MetatronResonator => "Custom Metatron-specific resonator pattern",
            Self::HybridAnalogCustom => "Hybrid analog-digital quantum algorithm",

            Self::QUBOSolver => "Specialized solver for Quadratic Unconstrained Binary Optimization",
            Self::MaxCutSpecialized => "Graph partitioning via quantum MaxCut algorithm",
            Self::TSPQuantum => "Quantum-enhanced Traveling Salesman Problem solver",
            Self::PortfolioOptimization => "Financial portfolio optimization with quantum speedup",

            Self::QSVM => "Quantum Support Vector Machine for classification",
            Self::QuantumBoltzmannMachine => "Generative quantum model for unsupervised learning",
            Self::QuantumKernelMethod => "Quantum feature mapping for kernel-based ML",

            Self::HamiltonianSimulation => "Trotter-based Hamiltonian evolution simulation",
            Self::QuantumPhaseEstimation => "Eigenvalue estimation via QPE algorithm",
            Self::LatticeSurgery => "Topological quantum computing via lattice surgery",

            Self::QAOAAdaptive => "QAOA with adaptive layer depth and classical optimization",
            Self::VQEAnsatzZoo => "VQE with multiple ansatz strategies",
            Self::QuantumClassicalHybridNN => "Quantum-classical hybrid neural network",

            Self::AdiabaticQuantumComputing => "Adiabatic evolution for optimization",
            Self::MeasurementBasedQC => "Measurement-based quantum computation on cluster states",
        }
    }

    pub fn typical_qubit_range(&self) -> (usize, usize) {
        match self {
            Self::GroverLikeSearch => (8, 20),
            Self::QuantumWalk => (10, 25),
            Self::QAOA_Standard => (8, 30),
            Self::VQE_Standard => (4, 20),
            Self::VQC_QML => (4, 16),
            Self::BosonSamplingLike => (10, 50),
            Self::MetatronResonator => (6, 18),
            Self::HybridAnalogCustom => (10, 40),

            Self::QUBOSolver => (8, 30),
            Self::MaxCutSpecialized => (10, 50),
            Self::TSPQuantum => (12, 30),
            Self::PortfolioOptimization => (8, 25),

            Self::QSVM => (4, 16),
            Self::QuantumBoltzmannMachine => (6, 20),
            Self::QuantumKernelMethod => (4, 12),

            Self::HamiltonianSimulation => (6, 30),
            Self::QuantumPhaseEstimation => (8, 25),
            Self::LatticeSurgery => (12, 50),

            Self::QAOAAdaptive => (8, 30),
            Self::VQEAnsatzZoo => (4, 20),
            Self::QuantumClassicalHybridNN => (6, 24),

            Self::AdiabaticQuantumComputing => (10, 100),
            Self::MeasurementBasedQC => (8, 40),
        }
    }
}
```

---

## 1A.2 Export System

### File: `core/qslot/src/export.rs` (NEU)

```rust
use serde::{Deserialize, Serialize};
use std::fs::File;
use std::io::Write;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum ExportError {
    #[error("Serialization failed: {0}")]
    SerializationError(String),

    #[error("File I/O error: {0}")]
    IoError(#[from] std::io::Error),

    #[error("Unsupported format: {0}")]
    UnsupportedFormat(String),

    #[error("Validation failed: {0}")]
    ValidationError(String),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ExportFormat {
    JSON,
    YAML,
    OpenQASM2,
    OpenQASM3,
    Qiskit,
    Cirq,
}

pub struct AlgorithmExporter;

impl AlgorithmExporter {
    pub fn export(
        spec: &fuq_core::AlgorithmSpec,
        format: ExportFormat,
        path: &str,
    ) -> Result<(), ExportError> {
        match format {
            ExportFormat::JSON => Self::export_json(spec, path),
            ExportFormat::YAML => Self::export_yaml(spec, path),
            ExportFormat::OpenQASM2 => Self::export_openqasm2(spec, path),
            ExportFormat::OpenQASM3 => Self::export_openqasm3(spec, path),
            ExportFormat::Qiskit => Self::export_qiskit(spec, path),
            ExportFormat::Cirq => Self::export_cirq(spec, path),
        }
    }

    fn export_json(spec: &fuq_core::AlgorithmSpec, path: &str) -> Result<(), ExportError> {
        let json = serde_json::to_string_pretty(spec)
            .map_err(|e| ExportError::SerializationError(e.to_string()))?;

        let mut file = File::create(path)?;
        file.write_all(json.as_bytes())?;

        Ok(())
    }

    fn export_yaml(spec: &fuq_core::AlgorithmSpec, path: &str) -> Result<(), ExportError> {
        let yaml = serde_yaml::to_string(spec)
            .map_err(|e| ExportError::SerializationError(e.to_string()))?;

        let mut file = File::create(path)?;
        file.write_all(yaml.as_bytes())?;

        Ok(())
    }

    fn export_openqasm2(spec: &fuq_core::AlgorithmSpec, path: &str) -> Result<(), ExportError> {
        let qasm = Self::to_openqasm2(spec)?;

        let mut file = File::create(path)?;
        file.write_all(qasm.as_bytes())?;

        Ok(())
    }

    fn export_openqasm3(spec: &fuq_core::AlgorithmSpec, path: &str) -> Result<(), ExportError> {
        let qasm = Self::to_openqasm3(spec)?;

        let mut file = File::create(path)?;
        file.write_all(qasm.as_bytes())?;

        Ok(())
    }

    fn export_qiskit(spec: &fuq_core::AlgorithmSpec, path: &str) -> Result<(), ExportError> {
        let python = Self::to_qiskit_python(spec)?;

        let mut file = File::create(path)?;
        file.write_all(python.as_bytes())?;

        Ok(())
    }

    fn export_cirq(spec: &fuq_core::AlgorithmSpec, path: &str) -> Result<(), ExportError> {
        let python = Self::to_cirq_python(spec)?;

        let mut file = File::create(path)?;
        file.write_all(python.as_bytes())?;

        Ok(())
    }

    fn to_openqasm2(spec: &fuq_core::AlgorithmSpec) -> Result<String, ExportError> {
        let mut qasm = String::new();
        qasm.push_str("OPENQASM 2.0;\n");
        qasm.push_str("include \"qelib1.inc\";\n\n");

        let num_qubits = spec.state_space.num_qubits;
        qasm.push_str(&format!("qreg q[{}];\n", num_qubits));
        qasm.push_str(&format!("creg c[{}];\n\n", num_qubits));

        // Convert operators to QASM gates
        for op in &spec.operators {
            qasm.push_str(&Self::operator_to_qasm2(op, num_qubits)?);
        }

        // Add measurement
        qasm.push_str(&format!("measure q -> c;\n"));

        Ok(qasm)
    }

    fn operator_to_qasm2(
        op: &fuq_core::AlgorithmOperator,
        num_qubits: usize,
    ) -> Result<String, ExportError> {
        use fuq_core::AlgorithmOperator::*;

        match op {
            Oracle { target_qubits } => {
                let mut qasm = String::new();
                qasm.push_str(&format!("// Oracle on qubits {:?}\n", target_qubits));
                // Simplified: Apply X gates
                for &q in target_qubits.iter().take(num_qubits) {
                    qasm.push_str(&format!("x q[{}];\n", q));
                }
                Ok(qasm)
            },
            Mixer { num_layers } => {
                let mut qasm = String::new();
                qasm.push_str(&format!("// Mixer with {} layers\n", num_layers));
                for layer in 0..*num_layers {
                    qasm.push_str(&format!("// Layer {}\n", layer));
                    for q in 0..num_qubits {
                        qasm.push_str(&format!("rx(pi/4) q[{}];\n", q));
                    }
                    for q in 0..(num_qubits - 1) {
                        qasm.push_str(&format!("cx q[{}],q[{}];\n", q, q + 1));
                    }
                }
                Ok(qasm)
            },
            // ... Weitere Operatoren
            _ => Ok(format!("// Operator {:?} not yet implemented in QASM2\n", op)),
        }
    }

    fn to_openqasm3(spec: &fuq_core::AlgorithmSpec) -> Result<String, ExportError> {
        // Ähnlich zu QASM2, aber mit QASM3-Syntax
        let mut qasm = String::new();
        qasm.push_str("OPENQASM 3.0;\n\n");

        let num_qubits = spec.state_space.num_qubits;
        qasm.push_str(&format!("qubit[{}] q;\n", num_qubits));
        qasm.push_str(&format!("bit[{}] c;\n\n", num_qubits));

        // Convert operators
        for op in &spec.operators {
            qasm.push_str(&Self::operator_to_qasm3(op, num_qubits)?);
        }

        qasm.push_str("c = measure q;\n");

        Ok(qasm)
    }

    fn operator_to_qasm3(
        op: &fuq_core::AlgorithmOperator,
        _num_qubits: usize,
    ) -> Result<String, ExportError> {
        // QASM3 Implementierung (vereinfacht)
        Ok(format!("// {:?}\n", op))
    }

    fn to_qiskit_python(spec: &fuq_core::AlgorithmSpec) -> Result<String, ExportError> {
        let mut python = String::new();
        python.push_str("from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister\n");
        python.push_str("from qiskit import transpile, assemble\n");
        python.push_str("from qiskit.providers.aer import AerSimulator\n\n");

        let num_qubits = spec.state_space.num_qubits;
        python.push_str(&format!("# Algorithm: {:?}\n", spec.family));
        python.push_str(&format!("# Metatron Signature: {}\n\n", spec.metatron_signature));

        python.push_str(&format!("qr = QuantumRegister({}, 'q')\n", num_qubits));
        python.push_str(&format!("cr = ClassicalRegister({}, 'c')\n", num_qubits));
        python.push_str("qc = QuantumCircuit(qr, cr)\n\n");

        // Convert operators to Qiskit gates
        for op in &spec.operators {
            python.push_str(&Self::operator_to_qiskit(op, num_qubits)?);
        }

        python.push_str("\nqc.measure(qr, cr)\n\n");
        python.push_str("# Simulate\n");
        python.push_str("simulator = AerSimulator()\n");
        python.push_str("compiled_circuit = transpile(qc, simulator)\n");
        python.push_str("qobj = assemble(compiled_circuit)\n");
        python.push_str("result = simulator.run(qobj).result()\n");
        python.push_str("counts = result.get_counts(qc)\n");
        python.push_str("print(counts)\n");

        Ok(python)
    }

    fn operator_to_qiskit(
        op: &fuq_core::AlgorithmOperator,
        _num_qubits: usize,
    ) -> Result<String, ExportError> {
        use fuq_core::AlgorithmOperator::*;

        match op {
            Oracle { target_qubits } => {
                let mut python = String::new();
                python.push_str("# Oracle\n");
                for &q in target_qubits {
                    python.push_str(&format!("qc.x(qr[{}])\n", q));
                }
                Ok(python)
            },
            Mixer { num_layers } => {
                let mut python = String::new();
                python.push_str(&format!("# Mixer ({} layers)\n", num_layers));
                python.push_str("# ... (implementation specific)\n");
                Ok(python)
            },
            _ => Ok(format!("# {:?}\n", op)),
        }
    }

    fn to_cirq_python(spec: &fuq_core::AlgorithmSpec) -> Result<String, ExportError> {
        let mut python = String::new();
        python.push_str("import cirq\n");
        python.push_str("import numpy as np\n\n");

        let num_qubits = spec.state_space.num_qubits;
        python.push_str(&format!("# Algorithm: {:?}\n", spec.family));
        python.push_str(&format!("# Metatron Signature: {}\n\n", spec.metatron_signature));

        python.push_str(&format!("qubits = [cirq.LineQubit(i) for i in range({})]\n", num_qubits));
        python.push_str("circuit = cirq.Circuit()\n\n");

        // Convert operators to Cirq gates
        for op in &spec.operators {
            python.push_str(&Self::operator_to_cirq(op, num_qubits)?);
        }

        python.push_str("\ncircuit.append(cirq.measure(*qubits, key='result'))\n\n");
        python.push_str("# Simulate\n");
        python.push_str("simulator = cirq.Simulator()\n");
        python.push_str("result = simulator.run(circuit, repetitions=1000)\n");
        python.push_str("print(result.histogram(key='result'))\n");

        Ok(python)
    }

    fn operator_to_cirq(
        op: &fuq_core::AlgorithmOperator,
        _num_qubits: usize,
    ) -> Result<String, ExportError> {
        use fuq_core::AlgorithmOperator::*;

        match op {
            Oracle { target_qubits } => {
                let mut python = String::new();
                python.push_str("# Oracle\n");
                for &q in target_qubits {
                    python.push_str(&format!("circuit.append(cirq.X(qubits[{}]))\n", q));
                }
                Ok(python)
            },
            _ => Ok(format!("# {:?}\n", op)),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_export_json() {
        // Test JSON export
    }

    #[test]
    fn test_export_qasm() {
        // Test QASM export
    }
}
```

### Tauri Command: `app/desktop/src-tauri/src/main.rs`

Ergänze:

```rust
#[tauri::command]
async fn export_algorithm(
    spec_json: String,
    format: String,
    path: String,
) -> Result<String, String> {
    use qslot::export::{AlgorithmExporter, ExportFormat};

    let spec: fuq_core::AlgorithmSpec = serde_json::from_str(&spec_json)
        .map_err(|e| format!("Failed to parse spec: {}", e))?;

    let export_format = match format.as_str() {
        "json" => ExportFormat::JSON,
        "yaml" => ExportFormat::YAML,
        "qasm2" => ExportFormat::OpenQASM2,
        "qasm3" => ExportFormat::OpenQASM3,
        "qiskit" => ExportFormat::Qiskit,
        "cirq" => ExportFormat::Cirq,
        _ => return Err(format!("Unsupported format: {}", format)),
    };

    AlgorithmExporter::export(&spec, export_format, &path)
        .map_err(|e| format!("Export failed: {}", e))?;

    Ok(format!("Exported to {}", path))
}
```

---

## 1A.3 Logging & Monitoring

### Setup: `Cargo.toml` (alle Core Crates)

```toml
[dependencies]
tracing = "0.1"
tracing-subscriber = { version = "0.3", features = ["env-filter"] }
```

### Implementierung: `core/qslot/src/lib.rs`

```rust
use tracing::{info, warn, error, debug, instrument};

impl QSlotEngine {
    #[instrument(skip(self, rng))]
    fn generate_single_candidate(
        &self,
        problem_spec: &ProblemSpec,
        rng: &mut StdRng,
        candidate_index: usize,
    ) -> Result<(AlgorithmSpec, AlgorithmScore), QSlotError> {
        info!("Generating candidate {} for problem type {:?}",
              candidate_index, problem_spec.problem_type);

        // 1. Sample Metatron route
        debug!("Sampling Metatron route");
        let route = self.metatron.sample_route(problem_spec, rng);
        info!("Metatron route: {} moves, signature: {}",
              route.moves.len(), route.signature);

        // 2. Convert to structure
        debug!("Converting route to structure");
        let structure = self.metatron.route_to_structure(&route);
        info!("Structure symmetry score: {:.3}",
              structure.structural_features.symmetry_score);

        // 3. Create 5D mesh
        debug!("Creating 5D mesh");
        let mesh = self.fuq.create_mesh(&structure, problem_spec);
        info!("Mesh created with {} points", mesh.points.len());

        // 4. Run surgery loop
        debug!("Running surgery loop");
        let surgery_params = fuq_core::SurgeryParams::default();
        let surgery_result = self.fuq.run_surgery(&mesh, &surgery_params);
        info!("Surgery converged in {} iterations, J_final: {:.3}",
              surgery_result.iterations, surgery_result.final_j);

        if surgery_result.guard_flags.slow_convergence {
            warn!("Surgery showed slow convergence");
        }
        if surgery_result.guard_flags.oscillation {
            warn!("Surgery oscillated");
        }

        // 5. Detect singularities
        debug!("Detecting singularities");
        let singularities = self.fuq.detect_singularities(&surgery_result.final_mesh);
        info!("Detected {} singularities", singularities.len());

        // 6. Select best singularity
        let singularity = singularities
            .iter()
            .max_by(|a, b| {
                a.strength
                    .partial_cmp(&b.strength)
                    .unwrap_or(std::cmp::Ordering::Equal)
            })
            .ok_or_else(|| {
                error!("No singularities detected!");
                QSlotError::GenerationError("No singularities detected".to_string())
            })?;

        info!("Selected singularity: {:?}, strength: {:.3}",
              singularity.singularity_type, singularity.strength);

        // 7. Quantum bridge
        debug!("Bridging to quantum algorithm");
        let spec = self
            .fuq
            .quantum_bridge(problem_spec, singularity, &structure.route_signature);
        info!("Generated {:?} algorithm with {} qubits",
              spec.family, spec.state_space.num_qubits);

        // 8. Compute score
        let score = compute_algorithm_score(&spec, singularity, &surgery_result, &self.context);
        info!("Score: Quality={:.3}, Robustness={:.3}, Novelty={:.3}, Label={:?}",
              score.quality, score.robustness, score.novelty, score.label);

        Ok((spec, score))
    }
}
```

### Initialization: `app/desktop/src-tauri/src/main.rs`

```rust
fn main() {
    // Setup tracing
    tracing_subscriber::fmt()
        .with_env_filter("info,qslot=debug,fuq_core=debug,metatron_core=debug")
        .init();

    tracing::info!("Starting Metatron Q⊗DASH Desktop App");

    tauri::Builder::default()
        // ...
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
```

---

## ✅ Pack 1A Exit Criteria

- [ ] 23 Algorithm Families implementiert und getestet
- [ ] Export-System funktioniert für JSON, YAML, OpenQASM2/3, Qiskit, Cirq
- [ ] Export-Validation: <5% Fehlerrate auf Test-Suite
- [ ] Tracing-Logging in allen Modulen
- [ ] Integration-Tests für Export-Pipeline
- [ ] Documentation: Algorithm Family Guide erstellt

---

# 🧠 UPGRADE PACK 4: Seraphic Learning Loop

## "Adaptive Intelligence" – Das konzeptuelle Herz

**WICHTIG:** Dies ist das **Alleinstellungsmerkmal** von Metatron Q⊗DASH!

### 🎯 Ziel

Echte Seraphic Calibration implementieren:
- Feedback von Scores → Routing Bias
- Adaptive Surgery Parameters
- Context-basierte Family Selection
- Session Analytics

### 📊 Success Metrics

- ✅ 30% Quality-Improvement über 100 Spins (messbar)
- ✅ Feedback-Loop nachweisbar (A/B-Test)
- ✅ Adaptive Parameter zeigen Konvergenz
- ✅ Session-Persistence (SQLite)

### ⏱️ Dauer: 2-3 Wochen

---

## 4.1 Seraphic Calibration Engine

### File: `core/qslot/src/seraphic.rs` (NEU)

```rust
use fuq_core::{AlgorithmScore, SurgeryParams};
use metatron_core::{ProblemSpec, ProblemType};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Seraphic Calibration: Feedback-based adaptation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SeraphicCalibrator {
    /// Experience buffer: Track (Problem, Route, Score)
    experience: Vec<Experience>,

    /// Learned biases for routing
    routing_biases: HashMap<ProblemType, RoutingBias>,

    /// Adaptive surgery parameters
    surgery_params: AdaptiveSurgeryParams,

    /// Convergence statistics
    convergence_stats: ConvergenceStats,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Experience {
    problem_signature: String,
    route_signature: String,
    score: AlgorithmScore,
    timestamp: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct RoutingBias {
    /// Probability weights for move types
    move_type_weights: [f64; 4], // [Invert, Rotate, Mirror, Convert]

    /// Preferred route lengths
    preferred_length_mean: f64,
    preferred_length_std: f64,

    /// Axis preferences (for S7 operations)
    axis_weights: [f64; 7],
}

impl Default for RoutingBias {
    fn default() -> Self {
        Self {
            move_type_weights: [0.25, 0.25, 0.25, 0.25], // Uniform
            preferred_length_mean: 5.0,
            preferred_length_std: 2.0,
            axis_weights: [1.0; 7], // Uniform
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct AdaptiveSurgeryParams {
    base_params: SurgeryParams,

    /// Learned adjustments
    alpha_multiplier: f64,      // Surgery step size
    max_iters_multiplier: f64,  // Iterations
    target_j_offset: f64,       // Target functional
}

impl Default for AdaptiveSurgeryParams {
    fn default() -> Self {
        Self {
            base_params: SurgeryParams::default(),
            alpha_multiplier: 1.0,
            max_iters_multiplier: 1.0,
            target_j_offset: 0.0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ConvergenceStats {
    total_spins: usize,
    quality_history: Vec<f64>,
    learning_rate: f64,
}

impl Default for ConvergenceStats {
    fn default() -> Self {
        Self {
            total_spins: 0,
            quality_history: Vec::new(),
            learning_rate: 0.1,
        }
    }
}

impl SeraphicCalibrator {
    pub fn new() -> Self {
        Self {
            experience: Vec::new(),
            routing_biases: HashMap::new(),
            surgery_params: AdaptiveSurgeryParams::default(),
            convergence_stats: ConvergenceStats::default(),
        }
    }

    /// Add experience from a spin
    pub fn add_experience(
        &mut self,
        problem_spec: &ProblemSpec,
        route_signature: String,
        score: AlgorithmScore,
    ) {
        let exp = Experience {
            problem_signature: Self::compute_problem_signature(problem_spec),
            route_signature,
            score,
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_secs(),
        };

        self.experience.push(exp);
        self.convergence_stats.total_spins += 1;
        self.convergence_stats.quality_history.push(score.quality);

        // Update biases
        self.update_routing_biases(problem_spec.problem_type);
        self.update_surgery_params();
    }

    fn compute_problem_signature(problem_spec: &ProblemSpec) -> String {
        // Simple hash: Type + Constraints count
        format!("{:?}_{}", problem_spec.problem_type, problem_spec.constraints.len())
    }

    fn update_routing_biases(&mut self, problem_type: ProblemType) {
        // Get recent experiences for this problem type
        let relevant_exp: Vec<&Experience> = self
            .experience
            .iter()
            .rev()
            .take(50)
            .filter(|e| e.problem_signature.starts_with(&format!("{:?}", problem_type)))
            .collect();

        if relevant_exp.is_empty() {
            return;
        }

        // Compute weighted averages based on scores
        let mut total_weight = 0.0;
        let mut move_type_accum = [0.0; 4];

        for exp in &relevant_exp {
            let weight = exp.score.quality; // Higher quality → more weight
            total_weight += weight;

            // Parse route signature to extract move types
            // (Simplified: assume signature encodes move info)
            // In reality, you'd need to parse the actual moves
        }

        if total_weight > 0.0 {
            // Update bias
            let bias = self.routing_biases.entry(problem_type).or_default();

            for i in 0..4 {
                move_type_accum[i] /= total_weight;
                bias.move_type_weights[i] =
                    0.9 * bias.move_type_weights[i] + 0.1 * move_type_accum[i];
            }

            // Normalize
            let sum: f64 = bias.move_type_weights.iter().sum();
            for w in &mut bias.move_type_weights {
                *w /= sum;
            }
        }
    }

    fn update_surgery_params(&mut self) {
        // Analyze recent convergence behavior
        if self.convergence_stats.quality_history.len() < 10 {
            return;
        }

        let recent: Vec<f64> = self
            .convergence_stats
            .quality_history
            .iter()
            .rev()
            .take(20)
            .copied()
            .collect();

        let mean: f64 = recent.iter().sum::<f64>() / recent.len() as f64;
        let trend = if recent.len() >= 2 {
            recent[0] - recent[recent.len() - 1]
        } else {
            0.0
        };

        // If quality is improving, keep parameters
        // If stagnating, increase surgery iterations
        if trend.abs() < 0.01 && mean < 0.5 {
            // Stagnation → increase exploration
            self.surgery_params.max_iters_multiplier *= 1.1;
            self.surgery_params.alpha_multiplier *= 0.95; // Smaller steps
        } else if mean > 0.7 {
            // High quality → can reduce iterations
            self.surgery_params.max_iters_multiplier *= 0.95;
        }

        // Clamp multipliers
        self.surgery_params.max_iters_multiplier =
            self.surgery_params.max_iters_multiplier.clamp(0.5, 2.0);
        self.surgery_params.alpha_multiplier =
            self.surgery_params.alpha_multiplier.clamp(0.5, 1.5);
    }

    /// Get routing bias for problem type
    pub fn get_routing_bias(&self, problem_type: ProblemType) -> RoutingBias {
        self.routing_biases
            .get(&problem_type)
            .cloned()
            .unwrap_or_default()
    }

    /// Get adapted surgery parameters
    pub fn get_surgery_params(&self) -> SurgeryParams {
        let mut params = self.surgery_params.base_params;
        params.alpha *= self.surgery_params.alpha_multiplier;
        params.max_iterations =
            (params.max_iterations as f64 * self.surgery_params.max_iters_multiplier) as usize;
        params.target_j += self.surgery_params.target_j_offset;
        params
    }

    /// Get quality trend (positive = improving)
    pub fn quality_trend(&self) -> f64 {
        if self.convergence_stats.quality_history.len() < 10 {
            return 0.0;
        }

        let recent: Vec<f64> = self
            .convergence_stats
            .quality_history
            .iter()
            .rev()
            .take(20)
            .copied()
            .collect();

        // Simple linear regression slope
        let n = recent.len() as f64;
        let x_mean = (n - 1.0) / 2.0;
        let y_mean: f64 = recent.iter().sum::<f64>() / n;

        let mut numerator = 0.0;
        let mut denominator = 0.0;

        for (i, &y) in recent.iter().enumerate() {
            let x = i as f64;
            numerator += (x - x_mean) * (y - y_mean);
            denominator += (x - x_mean).powi(2);
        }

        if denominator == 0.0 {
            0.0
        } else {
            numerator / denominator
        }
    }
}

impl Default for SeraphicCalibrator {
    fn default() -> Self {
        Self::new()
    }
}
```

### Integration: `core/qslot/src/lib.rs`

```rust
pub struct QSlotEngine {
    metatron: MetatronModel,
    fuq: FuqEngine,
    context: QSlotContext,
    seraphic: SeraphicCalibrator, // NEU
}

impl QSlotEngine {
    pub fn new() -> Self {
        Self {
            metatron: load_metatron_model(),
            fuq: FuqEngine::new(),
            context: QSlotContext::new(),
            seraphic: SeraphicCalibrator::new(), // NEU
        }
    }

    pub fn design_algorithm_batch(
        &mut self,
        problem_text: &str,
        n_candidates: usize,
        spin_index: u64,
    ) -> Result<AlgorithmBatch, QSlotError> {
        // Parse problem specification
        let problem_spec = parse_problem_spec(problem_text)?;

        // Get routing bias from Seraphic
        let routing_bias = self.seraphic.get_routing_bias(problem_spec.problem_type);

        // Get adapted surgery parameters
        let surgery_params = self.seraphic.get_surgery_params();

        // Generate candidates
        let mut candidates = Vec::new();
        let mut rng = StdRng::seed_from_u64(spin_index);

        for i in 0..n_candidates {
            match self.generate_single_candidate_adaptive(
                &problem_spec,
                &routing_bias,
                &surgery_params,
                &mut rng,
                i,
            ) {
                Ok((spec, score)) => {
                    // Add to Seraphic experience
                    self.seraphic.add_experience(
                        &problem_spec,
                        spec.metatron_signature.clone(),
                        score.clone(),
                    );

                    candidates.push(CandidateWithScore { spec, score });
                },
                Err(e) => {
                    eprintln!("Warning: Failed to generate candidate {}: {}", i, e);
                }
            }
        }

        // Build batch
        let batch = build_algorithm_batch(problem_spec, candidates, spin_index);

        // Update context
        self.context.update_from_batch(&batch);

        Ok(batch)
    }

    fn generate_single_candidate_adaptive(
        &self,
        problem_spec: &ProblemSpec,
        routing_bias: &RoutingBias,
        surgery_params: &SurgeryParams,
        rng: &mut StdRng,
        _candidate_index: usize,
    ) -> Result<(AlgorithmSpec, AlgorithmScore), QSlotError> {
        // Sample Metatron route WITH BIAS
        let route = sample_route_biased(&self.metatron, problem_spec, routing_bias, rng);

        // ... Rest wie vorher, aber mit surgery_params

        let structure = self.metatron.route_to_structure(&route);
        let mesh = self.fuq.create_mesh(&structure, problem_spec);

        // Use adaptive surgery params
        let surgery_result = self.fuq.run_surgery(&mesh, surgery_params);

        let singularities = self.fuq.detect_singularities(&surgery_result.final_mesh);

        let singularity = singularities
            .iter()
            .max_by(|a, b| {
                a.strength
                    .partial_cmp(&b.strength)
                    .unwrap_or(std::cmp::Ordering::Equal)
            })
            .ok_or_else(|| {
                QSlotError::GenerationError("No singularities detected".to_string())
            })?;

        let spec = self
            .fuq
            .quantum_bridge(problem_spec, singularity, &structure.route_signature);

        let score = compute_algorithm_score(&spec, singularity, &surgery_result, &self.context);

        Ok((spec, score))
    }
}

/// Sample route with bias
fn sample_route_biased<R: rand::Rng>(
    model: &MetatronModel,
    problem_spec: &ProblemSpec,
    bias: &RoutingBias,
    rng: &mut R,
) -> MetatronRoute {
    let mut route = MetatronRoute::new();

    // Determine route length using bias
    let route_length = {
        let mean = bias.preferred_length_mean;
        let std = bias.preferred_length_std;
        let length = mean + std * (rng.gen::<f64>() - 0.5) * 2.0;
        length.round().max(2.0).min(15.0) as usize
    };

    // Generate moves based on bias weights
    for _ in 0..route_length {
        let move_type = choose_move_type_biased(bias, rng);
        route.add_move(move_type);
    }

    route.signature = generate_signature(&route);

    route
}

fn choose_move_type_biased<R: rand::Rng>(
    bias: &RoutingBias,
    rng: &mut R,
) -> MetatronMove {
    use MetatronMove::*;

    // Sample from categorical distribution
    let p: f64 = rng.gen();
    let mut cumsum = 0.0;

    for (i, &weight) in bias.move_type_weights.iter().enumerate() {
        cumsum += weight;
        if p < cumsum {
            // Select axis based on bias
            let axis = sample_axis_biased(&bias.axis_weights, rng);

            return match i {
                0 => Invert { axis },
                1 => Rotate {
                    axis,
                    angle: rng.gen_range(-3..4)
                },
                2 => Mirror { plane: axis },
                3 => Convert { phase: axis },
                _ => Rotate { axis, angle: 0 },
            };
        }
    }

    // Fallback
    Rotate {
        axis: rng.gen_range(0..7),
        angle: rng.gen_range(-3..4)
    }
}

fn sample_axis_biased<R: rand::Rng>(
    axis_weights: &[f64; 7],
    rng: &mut R,
) -> u8 {
    let p: f64 = rng.gen();
    let sum: f64 = axis_weights.iter().sum();
    let mut cumsum = 0.0;

    for (i, &weight) in axis_weights.iter().enumerate() {
        cumsum += weight / sum;
        if p < cumsum {
            return i as u8;
        }
    }

    6 // Fallback
}
```

---

## 4.2 Session Persistence

### File: `core/qslot/src/persistence.rs` (NEU)

```rust
use rusqlite::{Connection, Result as SqlResult};
use std::path::Path;

pub struct SessionStore {
    conn: Connection,
}

impl SessionStore {
    pub fn open<P: AsRef<Path>>(path: P) -> SqlResult<Self> {
        let conn = Connection::open(path)?;

        // Create tables
        conn.execute(
            "CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY,
                timestamp INTEGER NOT NULL,
                problem_text TEXT NOT NULL,
                problem_type TEXT NOT NULL
            )",
            [],
        )?;

        conn.execute(
            "CREATE TABLE IF NOT EXISTS spins (
                id INTEGER PRIMARY KEY,
                session_id INTEGER NOT NULL,
                spin_index INTEGER NOT NULL,
                route_signature TEXT NOT NULL,
                algorithm_family TEXT NOT NULL,
                num_qubits INTEGER NOT NULL,
                score_quality REAL NOT NULL,
                score_robustness REAL NOT NULL,
                score_novelty REAL NOT NULL,
                score_label TEXT NOT NULL,
                FOREIGN KEY(session_id) REFERENCES sessions(id)
            )",
            [],
        )?;

        conn.execute(
            "CREATE TABLE IF NOT EXISTS seraphic_state (
                id INTEGER PRIMARY KEY,
                timestamp INTEGER NOT NULL,
                state_json TEXT NOT NULL
            )",
            [],
        )?;

        Ok(Self { conn })
    }

    pub fn save_seraphic_state(&self, calibrator: &SeraphicCalibrator) -> SqlResult<()> {
        let json = serde_json::to_string(calibrator).unwrap();
        let timestamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs();

        self.conn.execute(
            "INSERT INTO seraphic_state (timestamp, state_json) VALUES (?1, ?2)",
            [&timestamp.to_string(), &json],
        )?;

        Ok(())
    }

    pub fn load_latest_seraphic_state(&self) -> SqlResult<Option<SeraphicCalibrator>> {
        let mut stmt = self.conn.prepare(
            "SELECT state_json FROM seraphic_state ORDER BY timestamp DESC LIMIT 1"
        )?;

        let result = stmt.query_row([], |row| {
            let json: String = row.get(0)?;
            let calibrator: SeraphicCalibrator = serde_json::from_str(&json).unwrap();
            Ok(calibrator)
        });

        match result {
            Ok(cal) => Ok(Some(cal)),
            Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
            Err(e) => Err(e),
        }
    }

    // ... Additional methods for sessions/spins
}
```

### Integration: `core/qslot/Cargo.toml`

```toml
[dependencies]
rusqlite = { version = "0.29", features = ["bundled"] }
```

---

## ✅ Pack 4 Exit Criteria

- [ ] Seraphic Calibration funktioniert (Feedback-Loop nachweisbar)
- [ ] 30% Quality-Improvement über 100 Spins (A/B-Test vs. Random)
- [ ] Session Persistence mit SQLite
- [ ] Adaptive Routing zeigt Konvergenz (Plot Quality-Trend)
- [ ] Adaptive Surgery Parameters funktionieren
- [ ] Integration-Tests für Learning Loop

---

# 🧪 UPGRADE PACK 3: Synthesis Laboratory Layer

(Inhalt aus Original-Dokument übernehmen, aber nach Pack 4 priorisieren)

### ⏱️ Dauer: 2 Wochen

---

# ⚡ UPGRADE PACK 1B: Performance Optimization

## "Quantum Hypercore" – 10x Durchsatz

(Nur Performance-Features aus Pack 1: Parallel Processing, Caching)

### ⏱️ Dauer: 1 Woche

---

# 🏆 UPGRADE PACK 6: Production Hardening & Polish

(Aus Original-Dokument, aber erweitert um Logging-Integration)

### ⏱️ Dauer: 2 Wochen

---

# 🎮 UPGRADE PACK 2: Arcade Experience Overdrive

(Später priorisieren - Visual Overdrive ist "nice-to-have")

### ⏱️ Dauer: 3 Wochen

---

# ⚡ UPGRADE PACK 5: Alientechnology-Grade Tuning

(Optional, Post-1.0)

---

## 🎯 Revidierter Zeitplan

### Phase 1: Core Completeness (4-6 Wochen)
- **Woche 1-3**: Pack 1A (Algorithm Library + Export)
- **Woche 4-6**: Pack 4 (Seraphic Learning)

### Phase 2: Practical Usability (3-4 Wochen)
- **Woche 7-8**: Pack 3 (Laboratory Tools)
- **Woche 9**: Pack 1B (Performance)

### Phase 3: Production-Ready (2-3 Wochen)
- **Woche 10-12**: Pack 6 (Hardening + Monitoring)

### Phase 4: Visual Overdrive (3 Wochen)
- **Woche 13-15**: Pack 2 (3D + Audio + Particles)

### Phase 5: Advanced (Optional, Post-1.0)
- **Woche 16+**: Pack 5 (Multi-Objective, Circuit Opt, Fusion)

**Total: 12-15 Wochen für Production-Grade System (ohne Pack 5)**
**Total: 16-20 Wochen mit Pack 5**

---

## 🔬 Kritische Erkenntnisse

### Was die Original-Roadmap übersehen hat:

1. **Seraphic Calibration ist der USP**: Ohne Pack 4 ist das System nur ein "fancy Random Generator"
2. **Export ist essentiell**: Nutzer müssen Ergebnisse exportieren können (vor visuals!)
3. **Persistence ist kritisch**: Lernen ohne Speicher ist sinnlos
4. **Visuals können warten**: 3D/Audio sind schön, aber nicht funktional kritisch

### Was die Codebase-Analyse gezeigt hat:

1. **MVP ist sehr solide**: 80% der Basis-Funktionalität existiert bereits
2. **Mathematik ist korrekt**: S7, 5D-Mesh, Surgery Loop sind gut implementiert
3. **Aber vereinfacht**: Keine rigorose PDE, keine echte Postsymbolic Cognition
4. **Tests sind basic**: Keine Integration-Tests, keine Benchmarks

---

## 📈 Erfolgsmessung

### Objektive Metriken

| Metrik | MVP (jetzt) | Nach Pack 1A+4 | Nach Pack 3 | Nach Pack 6 |
|--------|-------------|----------------|-------------|-------------|
| Algorithm Families | 8 | 23 | 23 | 23 |
| Export-Formate | 0 | 5 | 6 | 6 |
| Spin-Zeit (P95) | ~2000ms | ~2000ms | ~1800ms | ~200ms |
| Learning-Effect | 0% | 30% | 35% | 40% |
| Test-Coverage | 30% | 50% | 65% | 95% |
| Logging | None | Structured | Structured | + Monitoring |
| Session-Persistence | No | Yes | Yes | Yes |
| UI-Immersion | 2/10 | 2/10 | 5/10 | 10/10 |

---

## 🚀 Nächste Schritte

### Sofort starten (Woche 1):

1. **Pack 1A.1**: Implementiere 15 neue Algorithm Families
2. **Pack 1A.2**: Export-System (JSON, YAML)
3. **Pack 1A.3**: Logging (tracing)

### Dann (Woche 2-3):

4. **Pack 1A.2**: Export-System (OpenQASM, Qiskit, Cirq)
5. **Pack 1A Tests**: Integration-Tests

### Danach (Woche 4-6):

6. **Pack 4.1**: Seraphic Calibration
7. **Pack 4.2**: Session Persistence
8. **Pack 4.3**: Adaptive Routing

---

**Fazit:** Die revidierte Roadmap priorisiert **konzeptuelle Vollständigkeit** und **praktische Nutzbarkeit** vor **Performance** und **Ästhetik**. Pack 4 (Seraphic Learning) ist das Herzstück und muss früh implementiert werden!
