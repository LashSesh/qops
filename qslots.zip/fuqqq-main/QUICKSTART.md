# Quick Start Guide – Metatron Q⊗DASH

## For First-Time Setup

### 1. Install Prerequisites (One Time Only)

**Install Rust:**
- Go to https://rustup.rs/
- Download and run installer
- Follow instructions

**Install Node.js:**
- Go to https://nodejs.org/
- Download LTS version
- Run installer

**Install System Libraries:**

- **macOS**: Open Terminal and run:
  ```bash
  xcode-select --install
  ```

- **Windows**: Install Visual Studio Build Tools from https://visualstudio.microsoft.com/downloads/
  - Select "Desktop development with C++"

- **Linux (Ubuntu/Debian)**: Open Terminal and run:
  ```bash
  sudo apt update
  sudo apt install -y libwebkit2gtk-4.0-dev build-essential curl wget \
    file libssl-dev libgtk-3-dev libayatana-appindicator3-dev librsvg2-dev
  ```

### 2. Run the App (First Time - Takes 5-10 Minutes)

Open Terminal/Command Prompt and run:

```bash
cd path/to/fuqqq/app/desktop
npm install
npm run tauri dev
```

A window will open with Metatron Q⊗DASH!

---

## For Daily Use (After Setup)

Just run:

```bash
cd path/to/fuqqq/app/desktop
npm run tauri dev
```

---

## How to Use

1. **Describe your problem** in the text box (e.g., "Find shortest path in a graph")
2. **Click "Lock Problem & Open Slot Machine"**
3. **Press the big SPIN button** to generate algorithm candidates
4. **Review the results** – each candidate is scored as Miss/Okay/Good/Jackpot
5. **Click "Show Details"** to see full algorithm specifications
6. **Keep spinning** to get more candidates (the system learns and improves!)

---

## Build Standalone App (Optional)

To create a double-clickable application:

```bash
cd app/desktop
npm run tauri build
```

Find the app in `src-tauri/target/release/bundle/`

---

## Need Help?

See full README.md for detailed documentation and troubleshooting.
