# Metatron Q⊗DASH – Quantum Algorithm Slot Machine Appliance

**Version 1.0 MVP**

A self-contained desktop application that generates quantum algorithm templates through an intuitive slot machine interface. No CLI interaction required for normal use.

---

## 🎯 What Is This?

Metatron Q⊗DASH is a **quantum-hybrid algorithm design appliance** that transforms problem descriptions into tailored quantum algorithm templates. Simply describe your problem, press SPIN, and watch as the system generates algorithm candidates scored from "Miss" to "Jackpot".

### Theoretical Foundation

The system integrates:
- **UAS_5D**: 5D information geometry with Tripol coordinates (ψ, ρ, ω) and FUQ operators
- **Metatron TripolarQSO**: S7 symmetry-based topological routing (Cube structure, 13 nodes, 78 edges)
- **SeraphicCalibrationModule**: Contractive feedback and fixpoint-oriented search
- **QLOGICTLE**: Domain-agnostic logic machine principles

All documentation is in the `docs/` folder.

---

## 🚀 Quick Start for Sebastian (No-Code User)

### Prerequisites (One-Time Setup)

You need to install these tools on your computer **once**:

1. **Rust** (programming language for the backend)
   - Visit: https://rustup.rs/
   - Download and run the installer
   - Follow the on-screen instructions
   - Verify: Open a terminal and type `rustc --version`

2. **Node.js** (for the frontend)
   - Visit: https://nodejs.org/
   - Download the LTS (Long Term Support) version
   - Run the installer
   - Verify: Open a terminal and type `node --version`

3. **System Dependencies** (varies by operating system)

   **On macOS:**
   ```bash
   # Install Xcode Command Line Tools
   xcode-select --install
   ```

   **On Windows:**
   - Install Visual Studio Build Tools: https://visualstudio.microsoft.com/downloads/
   - Select "Desktop development with C++" workload

   **On Linux (Ubuntu/Debian):**
   ```bash
   sudo apt update
   sudo apt install -y libwebkit2gtk-4.0-dev \
       build-essential \
       curl \
       wget \
       file \
       libssl-dev \
       libgtk-3-dev \
       libayatana-appindicator3-dev \
       librsvg2-dev
   ```

### Running the Application

Once prerequisites are installed, you only need **ONE command** to start the app:

1. Open a terminal/command prompt

2. Navigate to this folder:
   ```bash
   cd path/to/fuqqq
   ```

3. Run the app (first time will take 5-10 minutes to compile):
   ```bash
   cd app/desktop && npm install && npm run tauri dev
   ```

4. A window will open with the Slot Machine Dashboard!

### Daily Use (After First Setup)

After the first setup, you only need:

```bash
cd app/desktop && npm run tauri dev
```

The app will open in a new window. No CLI knowledge needed!

---

## 📖 How to Use the Slot Machine

### Step 1: Problem Setup Screen

1. **Describe Your Problem**: Write in plain English what you want to solve
   - Example: "Find the shortest path through a graph with 100 nodes"
   - Example: "Optimize delivery routes for 50 trucks"
   - Example: "Classify images into 10 categories"

2. **Select Problem Type** (optional): Choose from dropdown
   - Search, Optimization, Classification, Regression, Simulation, or Custom

3. **Click "Lock Problem & Open Slot Machine"**

### Step 2: Slot Machine Dashboard

Once your problem is locked, you'll see:

- **Your Problem**: Displayed at the top
- **Session Statistics**: Tracks your spins and results
- **Big SPIN Button**: Press it to generate algorithm candidates!

### Step 3: Spin for Algorithms

1. **Press SPIN**: The system will:
   - Route your problem through Metatron QSO (S7 symmetries)
   - Embed it in 5D FUQ space
   - Run surgery loops and detect singularities
   - Generate 5 algorithm candidates
   - Score each as **Miss**, **Okay**, **Good**, or **Jackpot**

2. **Review Candidates**: Each card shows:
   - Algorithm family (Grover, QAOA, VQE, Quantum Walk, etc.)
   - Quality, Robustness, Novelty, and Match scores
   - User-friendly explanation
   - Estimated computational cost

3. **View Details**: Click "Show Details" to see:
   - Algorithm configuration (DTL mode, Metatron signature)
   - State space structure (qubits, registers)
   - Operator specifications
   - Seraphic hints (optimization suggestions)
   - FUQ metadata

4. **Keep Spinning**: Each spin generates new candidates with different routes
   - The system **learns** from your spins (Seraphic calibration)
   - Quality improves over multiple spins

### Step 4: Change Problem

Click "Change Problem" to start over with a new problem description.

---

## 🏗️ Project Structure

```
fuqqq/
├── docs/                          # Theoretical documentation (PDFs)
│   ├── UAS_5D.pdf
│   ├── Metatron_TripolarQSO.pdf
│   ├── SeraphicCalibrationModule.pdf
│   ├── QLOGICTLE_v4_2.pdf
│   └── ...
│
├── core/                          # Rust core libraries
│   ├── metatron_core/            # S7 symmetries, Metatron graph, routes
│   ├── fuq_core/                 # 5D FUQ engine, surgery, singularities
│   └── qslot/                    # Orchestration (problem → algorithms)
│
├── app/desktop/                   # Tauri desktop application
│   ├── src/                      # React frontend (UI)
│   │   ├── components/           # UI components
│   │   │   ├── ProblemSetup.tsx
│   │   │   ├── SlotMachine.tsx
│   │   │   └── CandidateCard.tsx
│   │   ├── App.tsx
│   │   └── main.tsx
│   ├── src-tauri/                # Rust backend (Tauri)
│   │   ├── src/main.rs          # Backend logic
│   │   └── Cargo.toml
│   ├── package.json
│   └── vite.config.ts
│
├── Cargo.toml                     # Rust workspace configuration
└── README.md                      # This file
```

---

## 🔧 Building a Standalone Executable

To create a double-clickable app (no terminal needed):

```bash
cd app/desktop
npm run tauri build
```

The compiled app will be in:
- **macOS**: `app/desktop/src-tauri/target/release/bundle/dmg/`
- **Windows**: `app/desktop/src-tauri/target/release/bundle/msi/`
- **Linux**: `app/desktop/src-tauri/target/release/bundle/appimage/`

Double-click the app to run!

---

## 🧬 Core Algorithms

### Data Flow: Problem → Algorithm

1. **Parse Problem** (`qslot::parser`)
   - Extract problem type, structure hints, constraints from text

2. **Metatron Route** (`metatron_core`)
   - Sample S7 permutation sequence
   - Convert to MetatronStructure (graph wiring)

3. **5D Embedding** (`fuq_core::mesh`)
   - Map structure to 5D point cloud (U5dMesh)
   - Points are (ψ, ρ, ω, χ, τ) coordinates

4. **Surgery Loop** (`fuq_core::surgery`)
   - Apply FUQ operators (rotations, damping, transfer)
   - Optimize target functional J
   - Detect convergence or guard conditions

5. **Singularity Detection** (`fuq_core::singularity`)
   - Find vortices, attractors, saddles, repellers
   - Compute topological charge and spectral signatures

6. **Quantum Bridge** (`fuq_core::quantum_bridge`)
   - Convert singularity → AlgorithmSpec
   - Select family (Grover, QAOA, VQE, etc.)
   - Generate operators, state space, schedule

7. **Scoring** (`qslot::scorer`)
   - Compute quality, robustness, novelty, family-match
   - Assign label: Miss / Okay / Good / Jackpot

8. **Seraphic Adaptation** (`qslot::context`)
   - Track session statistics
   - Adjust sampling biases for better results

---

## 🎨 User Interface Features

### Problem Setup Screen
- Large text area for problem description
- Optional problem type selector
- Validation before locking

### Slot Machine Screen
- **Big SPIN button**: Main interaction (like a real slot machine!)
- **Candidate cards**: Visual display of algorithm templates
  - Color-coded by score label
  - Progress bars for multi-dimensional scores
  - Expandable details panel
- **Session stats**: Real-time tracking
  - Total spins, total candidates
  - Counts by label (Jackpot, Good, Okay, Miss)
- **Futuristic theme**: Quantum/cyberpunk aesthetic
  - Gradient colors (cyan, purple, gold)
  - Smooth animations
  - Responsive design

---

## 🧪 Testing the Core Libraries

To test the Rust core without the UI:

```bash
# Test all core crates
cargo test --workspace

# Test specific crate
cargo test -p metatron_core
cargo test -p fuq_core
cargo test -p qslot
```

---

## 📚 Advanced: Understanding the Theory

If you want to dive deeper into the mathematics and quantum theory:

1. Read `docs/UAS_5D.pdf` for the 5D FUQ framework
2. Read `docs/Metatron_TripolarQSO.pdf` for S7 symmetries
3. Read `docs/SeraphicCalibrationModule.pdf` for feedback loops
4. Read `docs/QLOGICTLE_v4_2.pdf` for domain-agnostic logic

The codebase is structured to reflect these papers as faithfully as possible within an MVP scope.

---

## 🐛 Troubleshooting

### "Command not found: cargo" or "Command not found: npm"
- You need to install Rust and Node.js (see Prerequisites above)
- After installation, restart your terminal

### "Failed to compile" errors on first run
- Make sure all system dependencies are installed (see Prerequisites)
- On Linux, you may need additional packages (webkit, gtk, etc.)
- Try running: `cargo clean` then try again

### App window is blank or crashes
- Check the terminal for error messages
- Make sure you're running from `app/desktop` directory
- Try: `npm install` again to refresh dependencies

### Spin button does nothing
- Check browser console (if in dev mode)
- Make sure Tauri backend compiled successfully
- Look for Rust errors in the terminal

---

## 🚧 Future Enhancements (Post-MVP)

- Export algorithm specs to JSON/YAML
- Direct integration with quantum simulators (Qiskit, Cirq)
- Save/load problem sessions
- Advanced visualization of 5D mesh evolution
- Parameter tuning interface for Seraphic calibration
- Multi-problem comparison mode
- Real-time 3D rendering of Metatron Cube transformations

---

## 📄 License

MIT License - See LICENSE file

---

## 👤 Author

**Sebastian** – No-code architect and quantum-hybrid algorithm designer

---

## 🙏 Acknowledgments

This project synthesizes ideas from:
- UAS_5D framework (5D information geometry)
- Metatron Cube sacred geometry (13 nodes, 78 edges)
- S7 symmetric group theory
- Quantum annealing and variational algorithms
- Seraphic calibration and fixpoint dynamics

All design documents are in the `docs/` folder.

---

**Enjoy spinning for quantum algorithms!** 🎰⚛️
