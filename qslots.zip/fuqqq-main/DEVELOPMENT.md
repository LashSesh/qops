# Development Guide – Metatron Q⊗DASH

This guide is for developers who want to extend or modify the codebase.

---

## Architecture Overview

### Core Libraries (Rust)

#### `core/metatron_core`
**Purpose**: Metatron QSO layer - S7 symmetries and topological routing

**Key Components**:
- `MetatronGraph`: H13 graph (13 nodes, 78 edges)
- `S7Permutation`: Symmetric group operations
- `MetatronRoute`: Sequence of Metatron moves (Invert, Rotate, Mirror, Convert)
- `MetatronStructure`: Concrete structure after route application

**Main Flow**:
```rust
let model = load_metatron_model();
let route = model.sample_route(&problem_spec, &mut rng);
let structure = model.route_to_structure(&route);
```

#### `core/fuq_core`
**Purpose**: 5D FUQ engine - surgery loops, singularities, quantum bridge

**Key Components**:
- `State5D`: (ψ, ρ, ω, χ, τ) coordinates
- `U5dMesh`: 5D point cloud and triangulation
- `OperatorFamily`: FUQ operators (rotations, damping, transfer, threshold, nullpoint)
- `Surgery`: Iterative optimization with target functional J
- `Singularity`: Vortices, attractors, saddles, repellers
- `AlgorithmSpec`: Complete quantum algorithm specification

**Main Flow**:
```rust
let engine = FuqEngine::new();
let mesh = engine.create_mesh(&structure, &problem_spec);
let surgery_result = engine.run_surgery(&mesh, &params);
let singularities = engine.detect_singularities(&surgery_result.final_mesh);
let spec = engine.quantum_bridge(&problem_spec, &singularity, &signature);
```

#### `core/qslot`
**Purpose**: Orchestration - connects Metatron → FUQ → Scoring

**Key Components**:
- `QSlotEngine`: Main entry point
- `ProblemSpec`: Parsed problem specification
- `AlgorithmBatch`: Collection of scored candidates
- `QSlotContext`: Seraphic calibration state (adaptive parameters)
- `Scorer`: Multi-dimensional scoring (quality, robustness, novelty, family-match)

**Main Flow**:
```rust
let mut engine = QSlotEngine::new();
let batch = engine.design_algorithm_batch(problem_text, n_candidates, spin_index)?;
```

### Desktop Application (Tauri + React)

#### Backend (`app/desktop/src-tauri`)
**Main file**: `src/main.rs`

**Tauri Commands**:
- `spin(request)`: Generates algorithm batch
- `health_check()`: Verifies backend is running

**State Management**:
- `AppState`: Holds `QSlotEngine` in a mutex
- Thread-safe access via Tauri's state management

#### Frontend (`app/desktop/src`)
**Framework**: React + TypeScript + Vite

**Components**:
- `App.tsx`: Main app, manages problem config and session stats
- `ProblemSetup.tsx`: Problem description screen
- `SlotMachine.tsx`: Main dashboard with SPIN button
- `CandidateCard.tsx`: Individual algorithm candidate display

**State Flow**:
1. User enters problem → `ProblemSetup` → locks config
2. `App` stores config and switches to `SlotMachine`
3. User clicks SPIN → `invoke("spin", ...)` → backend
4. Backend returns `AlgorithmBatch` → `SlotMachine` renders cards
5. Session stats updated in `App`

---

## Key Data Structures

### ProblemSpec
```rust
struct ProblemSpec {
    id: String,
    raw_text: String,
    problem_type: ProblemType,  // Search, Optimization, etc.
    input_structure: String,
    objective_description: String,
    constraints: Vec<String>,
    solution_quality: SolutionQuality,
}
```

### AlgorithmSpec
```rust
struct AlgorithmSpec {
    id: String,
    name: String,
    family: AlgorithmFamily,  // Grover, QAOA, VQE, etc.
    tripol: Tripol,
    state5d: State5D,
    dtl_mode: DTLMode,
    state_space: HybridStateSpace,
    operators: Vec<OperatorSpec>,
    spectral_goal: SpectralGoal,
    schedule: Option<ScorpioSyncSchedule>,
    feedback: FeedbackConfig,
    metatron_signature: String,
    fuq_metadata: String,
    seraphic_hint: String,
    notes_for_user: String,
}
```

### AlgorithmScore
```rust
struct AlgorithmScore {
    quality_score: f64,        // 0-1
    robustness_score: f64,     // 0-1
    novelty_score: f64,        // 0-1
    family_match_score: f64,   // 0-1
    estimated_cost: f64,
    label: ScoreLabel,         // Miss, Okay, Good, Jackpot
}
```

---

## Extending the System

### Adding a New Algorithm Family

1. Add variant to `AlgorithmFamily` enum in `core/fuq_core/src/types.rs`:
```rust
pub enum AlgorithmFamily {
    // ... existing variants
    MyNewFamily,
}
```

2. Update `select_algorithm_family()` in `core/fuq_core/src/quantum_bridge.rs`:
```rust
fn select_algorithm_family(problem_spec, singularity) -> AlgorithmFamily {
    match (problem_spec.problem_type, singularity.kind) {
        // Add your logic
        (ProblemType::Custom, SingularityKind::Complex) => AlgorithmFamily::MyNewFamily,
        // ...
    }
}
```

3. Update `generate_operators()` to create appropriate operators for your family

### Adding a New FUQ Operator

1. Add variant to `FuqOperator` in `core/fuq_core/src/operators.rs`:
```rust
pub enum FuqOperator {
    // ... existing variants
    MyOperator { param: f64 },
}
```

2. Implement `apply()` for your operator:
```rust
FuqOperator::MyOperator { param } => {
    // Transform State5D
    apply_my_operator(state, *param)
}
```

3. Add to default `OperatorFamily`

### Customizing the Scoring Function

Edit `core/qslot/src/scorer.rs`:

```rust
fn compute_quality_score(spec, singularity, surgery_result) -> f64 {
    let mut score = 0.0;

    // Add your scoring logic
    score += my_custom_metric(spec);

    score.max(0.0).min(1.0)
}
```

### Modifying the UI

**Change colors/theme**: Edit `app/desktop/src/styles.css` `:root` variables

**Add new UI elements**: Create new component in `app/desktop/src/components/`

**Modify candidate display**: Edit `CandidateCard.tsx` and `CandidateCard.css`

---

## Testing

### Unit Tests
```bash
# Run all tests
cargo test --workspace

# Run specific crate tests
cargo test -p metatron_core
cargo test -p fuq_core
cargo test -p qslot

# Run specific test
cargo test test_metatron_graph_structure
```

### Integration Tests

Create tests in `core/qslot/tests/`:

```rust
#[test]
fn test_full_pipeline() {
    let mut engine = QSlotEngine::new();
    let batch = engine.design_algorithm_batch(
        "Find shortest path in a graph",
        5,
        1
    ).unwrap();

    assert!(batch.candidates.len() > 0);
}
```

---

## Performance Optimization

### Current Performance
- Candidate generation: ~100-500ms per candidate (depends on surgery iterations)
- Batch of 5 candidates: ~1-2 seconds

### Optimization Opportunities

1. **Parallelize candidate generation**:
```rust
use rayon::prelude::*;

let candidates: Vec<_> = (0..n_candidates)
    .into_par_iter()
    .map(|i| self.generate_single_candidate(&problem_spec, i))
    .collect();
```

2. **Cache MetatronModel** (already done via struct field)

3. **Reduce surgery iterations** for faster (less accurate) results:
```rust
let params = SurgeryParams {
    max_iterations: 20,  // down from 50
    // ...
};
```

4. **Simplify singularity detection** (skip every Nth point)

---

## Debugging

### Backend Debugging

Add debug prints in Rust:
```rust
eprintln!("Debug: singularity strength = {}", singularity.strength);
```

Run in dev mode to see console output:
```bash
npm run tauri dev
```

### Frontend Debugging

Open browser dev tools (View → Developer → Toggle Developer Tools in Tauri window)

Add console logs:
```typescript
console.log("Candidates:", candidates);
```

---

## Code Style

### Rust
- Follow `rustfmt` defaults: `cargo fmt`
- Run `clippy` for lints: `cargo clippy`
- Use `Result<T, E>` for error handling
- Prefer `&str` over `String` for function parameters
- Document public APIs with `///` comments

### TypeScript/React
- Use functional components with hooks
- TypeScript strict mode enabled
- Props interfaces defined inline or exported
- CSS modules per component
- Avoid `any` type

---

## Project Conventions

### Naming
- **Rust modules**: snake_case
- **Rust types**: PascalCase
- **React components**: PascalCase
- **CSS classes**: kebab-case
- **Functions**: snake_case (Rust), camelCase (TS)

### File Organization
- One module per file (Rust)
- One component per file (React)
- Co-located CSS with components
- Tests in same file or `tests/` directory

---

## Building for Production

### Debug Build (Fast, Large)
```bash
cargo build
```

### Release Build (Slow, Optimized)
```bash
cargo build --release
```

### Tauri Production Bundle
```bash
cd app/desktop
npm run tauri build
```

Outputs:
- macOS: `.dmg` in `src-tauri/target/release/bundle/dmg/`
- Windows: `.msi` in `src-tauri/target/release/bundle/msi/`
- Linux: `.AppImage` in `src-tauri/target/release/bundle/appimage/`

---

## Common Gotchas

1. **Mutex deadlocks**: Always use scoped locks, drop early
2. **Tauri command signatures**: Must be `fn(State<T>) -> Result` pattern
3. **React state updates**: Use functional updates for derived state
4. **Rust borrow checker**: Clone when needed, but prefer references
5. **TypeScript `any`**: Avoid at all costs, define proper types

---

## Resources

### Rust
- https://doc.rust-lang.org/book/
- https://docs.rs/ (API docs)

### Tauri
- https://tauri.app/v1/guides/
- https://tauri.app/v1/api/js/

### React
- https://react.dev/
- https://www.typescriptlang.org/docs/

### Quantum Computing
- Papers in `docs/` folder
- Qiskit documentation (for quantum concepts)

---

## Future Roadmap

### Phase 2 (Post-MVP)
- [ ] Export algorithm specs to JSON/YAML
- [ ] Import/export problem sessions
- [ ] Advanced parameter tuning UI
- [ ] Real-time mesh visualization
- [ ] Persistent session storage

### Phase 3 (Integration)
- [ ] Qiskit integration for simulation
- [ ] Cirq support
- [ ] Cloud QPU connectors (IBM, Rigetti, IonQ)
- [ ] Batch processing mode

### Phase 4 (Advanced)
- [ ] 3D Metatron Cube visualization
- [ ] Interactive surgery loop controls
- [ ] Custom operator design UI
- [ ] Multi-problem comparison dashboard

---

Happy hacking! 🚀⚛️
