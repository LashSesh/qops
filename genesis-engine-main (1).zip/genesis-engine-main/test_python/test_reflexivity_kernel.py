#!/usr/bin/env python3
"""
Tests for Reflexivity Kernel with Hermitian Cluster Detection
"""

import pytest
import json
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from kernel.reflexivity_core import ReflexivityKernel


class TestReflexivityKernel:
    """Test suite for ReflexivityKernel."""

    @pytest.fixture
    def kernel(self):
        """Create a ReflexivityKernel instance with test data."""
        return ReflexivityKernel(ontology_path='data/operator_ontology.json')

    def test_kernel_initialization(self, kernel):
        """Test that kernel initializes correctly."""
        assert kernel is not None
        assert len(kernel.ops) > 0
        assert kernel.report_dir.exists()

    def test_compute_adjoint(self, kernel):
        """Test Hermitian adjoint computation."""
        # Test simple 2x2 matrix
        matrix = [[1+2j, 3-1j], [3+1j, 4+0j]]
        adjoint = kernel.compute_adjoint(matrix)

        # Verify it's a conjugate transpose
        # For sympy Matrix, H is conjugate transpose
        # adjoint[i][j] should equal conj(matrix[j][i])
        assert adjoint is not None

    def test_generate_operator_matrix(self, kernel):
        """Test operator matrix generation."""
        if not kernel.ops:
            pytest.skip("No operators in ontology")

        op = kernel.ops[0]
        matrix = kernel._generate_operator_matrix(op)

        assert matrix is not None
        assert len(matrix) == 2  # 2x2 matrix
        assert len(matrix[0]) == 2
        assert len(matrix[1]) == 2

    def test_analyze_clusters(self, kernel):
        """Test Hermitian cluster analysis."""
        result = kernel.analyze_clusters()

        assert 'total_analyzed' in result
        assert 'clusters' in result
        assert result['total_analyzed'] > 0

        # Check that clusters are created
        assert len(result['clusters']) > 0

        # Verify cluster report was saved
        cluster_report = kernel.report_dir / 'hermiticity_clusters.json'
        assert cluster_report.exists()

        # Load and validate cluster report
        with open(cluster_report, 'r') as f:
            cluster_data = json.load(f)

        assert len(cluster_data) > 0
        assert 'id' in cluster_data[0]
        assert 'cluster' in cluster_data[0]
        assert 'hermiticity' in cluster_data[0]

    def test_analyze(self, kernel):
        """Test comprehensive reflexivity analysis."""
        summary = kernel.analyze()

        assert 'total_analyzed' in summary
        assert 'hermitian_operators' in summary
        assert 'unitary_operators' in summary
        assert summary['total_analyzed'] > 0

        # Check that report was saved
        report_path = kernel.report_dir / 'reflexivity_report.json'
        assert report_path.exists()

    def test_hermiticity_scores(self, kernel):
        """Test that hermiticity scores are computed correctly."""
        cluster_result = kernel.analyze_clusters()

        for op_result in cluster_result['results']:
            # Hermiticity score should be between 0 and 1
            assert 0 <= op_result['hermiticity'] <= 1.0

            # Cluster ID should be 0-6 (7 clusters)
            assert 0 <= op_result['cluster'] <= 6

    def test_empty_ontology(self):
        """Test behavior with empty ontology."""
        kernel = ReflexivityKernel(ontology_path='data/nonexistent.json')

        assert len(kernel.ops) == 0

        result = kernel.analyze_clusters()
        assert result['total_analyzed'] == 0

    def test_cluster_statistics(self, kernel):
        """Test cluster statistics computation."""
        result = kernel.analyze_clusters()

        clusters = result['clusters']

        for cluster_id, stats in clusters.items():
            assert 'count' in stats
            assert 'avg_hermiticity' in stats
            assert 'operators' in stats
            assert stats['count'] > 0
            assert len(stats['operators']) == stats['count']
            assert 0 <= stats['avg_hermiticity'] <= 1.0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
