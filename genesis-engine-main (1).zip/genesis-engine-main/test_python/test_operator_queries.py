#!/usr/bin/env python3
"""
Tests for Operator Query Engine
"""

import pytest
import json
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from ontology.operator_queries import OperatorQueries


class TestOperatorQueries:
    """Test suite for OperatorQueries."""

    @pytest.fixture
    def queries(self):
        """Create an OperatorQueries instance with test data."""
        return OperatorQueries(ontology_path='data/operator_ontology.json')

    def test_queries_initialization(self, queries):
        """Test that query engine initializes correctly."""
        assert queries is not None
        assert len(queries.ops) > 0

    def test_find_by_symmetry(self, queries):
        """Test querying by symmetry class."""
        results = queries.find(symmetry='U(1)_COHERENT')

        assert len(results) > 0

        for op in results:
            assert op['symmetry_class'] == 'U(1)_COHERENT'

    def test_find_by_stability(self, queries):
        """Test querying by minimum stability."""
        min_stab = 0.8

        results = queries.find(min_stability=min_stab)

        assert len(results) > 0

        for op in results:
            assert op['stability'] >= min_stab

    def test_find_by_entropy(self, queries):
        """Test querying by maximum entropy."""
        max_ent = 0.1

        results = queries.find(max_entropy=max_ent)

        for op in results:
            assert abs(op['entropy']) <= max_ent

    def test_find_multi_criteria(self, queries):
        """Test querying with multiple criteria."""
        results = queries.find(
            symmetry='U(1)_COHERENT',
            min_stability=0.8,
            max_entropy=0.05
        )

        for op in results:
            assert op['symmetry_class'] == 'U(1)_COHERENT'
            assert op['stability'] >= 0.8
            assert abs(op['entropy']) <= 0.05

    def test_summary(self, queries):
        """Test ontology summary generation."""
        summary = queries.summary()

        assert 'total_operators' in summary
        assert 'avg_entropy' in summary
        assert 'avg_stability' in summary
        assert 'symmetry_distribution' in summary

        assert summary['total_operators'] > 0
        assert summary['avg_entropy'] >= 0
        assert summary['avg_stability'] >= 0

        # Check distributions
        assert len(summary['symmetry_distribution']) > 0

    def test_analyze_stability_landscape(self, queries):
        """Test stability landscape analysis."""
        analysis = queries.analyze_stability_landscape()

        assert 'total_operators' in analysis
        assert 'stable_count' in analysis
        assert 'unstable_count' in analysis
        assert 'stable_fraction' in analysis

        assert analysis['total_operators'] > 0
        assert 0 <= analysis['stable_fraction'] <= 1.0

    def test_find_correlations(self, queries):
        """Test correlation discovery."""
        correlations = queries.find_correlations()

        # Should have correlation coefficients
        assert 'stability_entropy' in correlations
        assert 'stability_delta_phi' in correlations
        assert 'entropy_delta_phi' in correlations

        # Correlations should be between -1 and 1
        for key, value in correlations.items():
            assert -1.0 <= value <= 1.0

    def test_get_top_operators(self, queries):
        """Test getting top operators by criterion."""
        # Get top 3 by stability
        top_stable = queries.get_top_operators(criterion='stability', n=3, reverse=True)

        assert len(top_stable) <= 3

        # Should be sorted in descending order
        for i in range(len(top_stable) - 1):
            assert top_stable[i]['stability'] >= top_stable[i + 1]['stability']

        # Get top 3 by entropy
        top_entropy = queries.get_top_operators(criterion='entropy', n=3, reverse=True)

        assert len(top_entropy) <= 3

        # Should be sorted in descending order
        for i in range(len(top_entropy) - 1):
            ent_i = abs(top_entropy[i].get('entropy', 0))
            ent_i1 = abs(top_entropy[i + 1].get('entropy', 0))
            assert ent_i >= ent_i1

    def test_export_query_results(self, queries):
        """Test exporting query results."""
        results = queries.find(min_stability=0.7)

        output_path = Path('reports/reflexivity/test_query_results.json')
        queries.export_query_results(results, str(output_path))

        assert output_path.exists()

        # Load and verify
        with open(output_path, 'r') as f:
            exported = json.load(f)

        assert len(exported) == len(results)

    def test_empty_ontology(self):
        """Test behavior with empty ontology."""
        queries = OperatorQueries(ontology_path='data/nonexistent.json')

        assert len(queries.ops) == 0

        summary = queries.summary()
        assert summary['total_operators'] == 0

        results = queries.find(min_stability=0.8)
        assert len(results) == 0

    def test_find_by_cluster(self, queries):
        """Test querying by cluster ID."""
        # First, we need to ensure clusters are assigned
        # This might require running reflexivity kernel first
        results = queries.find(cluster=0)

        # If clusters are assigned, verify
        if results:
            for op in results:
                assert op.get('cluster') == 0

    def test_semantic_state_query(self, queries):
        """Test querying by semantic state."""
        results = queries.find(semantic_state='STABLE')

        for op in results:
            assert op.get('semantic_state') == 'STABLE'


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
