"""Python test suite for ORIPHIEL framework."""
