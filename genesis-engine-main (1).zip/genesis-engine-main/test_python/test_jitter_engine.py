#!/usr/bin/env python3
"""
Tests for Δψ-Jitter Engine
"""

import pytest
import json
import sys
import shutil
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from entropy.jitter_engine import JitterEngine


class TestJitterEngine:
    """Test suite for JitterEngine."""

    @pytest.fixture
    def engine(self):
        """Create a JitterEngine instance with test data."""
        # Create backup of original ontology
        src = Path('data/operator_ontology.json')
        backup = Path('data/operator_ontology_backup.json')
        if src.exists():
            shutil.copy(src, backup)

        engine = JitterEngine(
            ontology_path='data/operator_ontology.json',
            sigma=0.03,
            epsilon=0.05,
            seed=42  # For reproducible tests
        )

        yield engine

        # Restore backup
        if backup.exists():
            shutil.copy(backup, src)
            backup.unlink()

    def test_engine_initialization(self, engine):
        """Test that engine initializes correctly."""
        assert engine is not None
        assert engine.sigma == 0.03
        assert engine.epsilon == 0.05
        assert len(engine.ops) > 0

    def test_apply_jitter_basic(self, engine):
        """Test basic jitter application."""
        # Record original Δψ values
        original_deltas = [op.get('Δψ') or op.get('delta_psi', 0.0) for op in engine.ops]

        # Apply jitter
        stats = engine.apply_jitter(adaptive=False)

        assert 'operators_modified' in stats
        assert stats['operators_modified'] > 0
        assert 'avg_jitter' in stats
        assert 'max_jitter' in stats
        assert 'min_jitter' in stats

        # Verify that Δψ values changed
        new_deltas = [op.get('Δψ') or op.get('delta_psi', 0.0) for op in engine.ops]

        changes = sum(1 for old, new in zip(original_deltas, new_deltas) if abs(old - new) > 1e-9)
        assert changes > 0  # At least some values should change

    def test_apply_jitter_adaptive(self, engine):
        """Test adaptive jitter application."""
        stats = engine.apply_jitter(adaptive=True)

        assert stats['operators_modified'] > 0
        assert stats['avg_jitter'] >= 0

        # Verify jitter history was recorded
        assert len(engine.jitter_history) > 0

        # Check jitter history entries
        for entry in engine.jitter_history:
            assert 'operator_id' in entry
            assert 'delta_psi_old' in entry
            assert 'delta_psi_new' in entry
            assert 'jitter' in entry
            assert 'sinusoidal' in entry
            assert 'gaussian' in entry

    def test_jitter_statistics(self, engine):
        """Test jitter statistics computation."""
        stats = engine.apply_jitter()

        # Check that statistics are reasonable
        assert stats['avg_jitter'] >= 0
        assert stats['max_jitter'] >= stats['min_jitter']
        assert stats['max_jitter'] >= stats['avg_jitter']
        assert stats['std_jitter'] >= 0

    def test_save_jitter_history(self, engine):
        """Test jitter history saving."""
        engine.apply_jitter()

        history_path = Path('reports/reflexivity/jitter_history.json')
        engine.save_jitter_history()

        assert history_path.exists()

        # Load and validate history
        with open(history_path, 'r') as f:
            history = json.load(f)

        assert len(history) > 0
        assert 'operator_id' in history[0]
        assert 'jitter' in history[0]

    def test_analyze_jitter_impact(self, engine):
        """Test jitter impact analysis."""
        engine.apply_jitter()

        analysis = engine.analyze_jitter_impact()

        assert 'total_jitters' in analysis
        assert 'delta_psi_old' in analysis
        assert 'delta_psi_new' in analysis
        assert 'entropy_increase' in analysis

        # Check that distributions are computed
        assert 'mean' in analysis['delta_psi_old']
        assert 'std' in analysis['delta_psi_old']
        assert 'mean' in analysis['delta_psi_new']
        assert 'std' in analysis['delta_psi_new']

    def test_empty_ontology(self):
        """Test behavior with empty ontology."""
        engine = JitterEngine(ontology_path='data/nonexistent.json')

        assert len(engine.ops) == 0

        stats = engine.apply_jitter()
        assert stats['operators_modified'] == 0

    def test_jitter_range(self, engine):
        """Test that jitter stays within reasonable bounds."""
        # Apply jitter multiple times
        for _ in range(5):
            engine.apply_jitter()

        # Check that Δψ values are still reasonable
        for op in engine.ops:
            delta_psi = op.get('Δψ', 0.0)
            # Should stay within reasonable range (-10, 10)
            assert -10 < delta_psi < 10

    def test_reproducibility(self):
        """Test that jitter is reproducible with seed."""
        # Create two engines with same seed
        engine1 = JitterEngine(
            ontology_path='data/operator_ontology.json',
            seed=123
        )
        engine2 = JitterEngine(
            ontology_path='data/operator_ontology.json',
            seed=123
        )

        # Apply jitter to both
        stats1 = engine1.apply_jitter()
        stats2 = engine2.apply_jitter()

        # Results should be identical
        assert abs(stats1['avg_jitter'] - stats2['avg_jitter']) < 1e-6


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
