# Metatron Operator Cosmos Stack - Deployment Guide

## Overview

This document describes the deployment architecture for the unified MOGE–Reasonate–InvariantCrystal system, including the Resonance Kernel, Operator Lexicon API, and UX Dashboard.

## Architecture

The Metatron Operator Cosmos Stack consists of four main services:

### 1. **Resonance Kernel** (Rust)
- Core computation engine executing operator mining and resonance dynamics
- Implements Gradient Resonance Descent (GRD) for operator discovery
- Exposes telemetry on port 7444
- Service port: 7000

### 2. **Lexicon API** (Python/FastAPI)
- HTTP/REST API exposing the Operator Lexicon and Ledger data
- WebSocket telemetry streaming for real-time metrics
- Service port: 8080
- Endpoints:
  - `GET /status` - API health check
  - `GET /operator` - List/search operators
  - `POST /operator` - Create operator
  - `GET /operator/{id}` - Get operator details
  - `GET /analytics` - System analytics
  - `GET /ledger` - List ledger entries
  - `WS /telemetry` - Real-time telemetry stream

### 3. **Dashboard UI** (React + TypeScript)
- Frontend interface for interactive operator exploration
- Built with React, D3, and Three.js
- Real-time telemetry visualization
- Service port: 3000

### 4. **PostgreSQL Database**
- Persistent JSONB/Document storage for operators and ledger
- Service port: 5432

## Network Architecture

```
                    ┌─────────────────┐
                    │  Dashboard UI   │
                    │   (port 3000)   │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │  Lexicon API    │
                    │   (port 8080)   │
                    └────┬────────┬───┘
                         │        │
              ┌──────────▼──┐  ┌─▼─────────┐
              │ Resonance   │  │ PostgreSQL│
              │   Kernel    │  │    DB     │
              │ (port 7000) │  │(port 5432)│
              └─────────────┘  └───────────┘
```

## Deployment Modes

### Local Development (Docker Compose)

**Prerequisites:**
- Docker 20.10+
- Docker Compose 2.0+

**Security Setup:**

Before starting, create a `.env` file from the template:

```bash
cp .env.example .env
```

Edit `.env` and set secure values:
- `POSTGRES_PASSWORD` - Strong database password
- `API_KEY` - Generate with: `openssl rand -hex 32`

**Quick Start:**

```bash
# 1. Clone the repository
git clone https://github.com/LashSesh/genesis-engine.git
cd genesis-engine

# 2. Set environment variables (optional)
export API_KEY="your-secure-key-here"

# 3. Start all services
docker-compose up -d

# 4. Wait for services to be ready (30-60 seconds)
docker-compose ps

# 5. Run the Genesis Routine to initialize the system
./genesis_routine.sh

# 6. Access the dashboard
open http://localhost:3000
```

**Access Points:**
- Dashboard: http://localhost:3000
- API: http://localhost:8080
- API Documentation: http://localhost:8080/docs
- Telemetry WebSocket: ws://localhost:8080/telemetry

**Stop Services:**
```bash
docker-compose down
```

**Clean Reset:**
```bash
docker-compose down -v
rm -rf data/
```

### Production Cluster (Kubernetes)

**Prerequisites:**
- Kubernetes 1.24+
- kubectl configured
- Persistent volume provisioner

**Deployment Steps:**

```bash
# 1. Build and tag container images
docker build -f kernel/Dockerfile -t metatron/resonance-kernel:latest .
docker build -f api/Dockerfile -t metatron/lexicon-api:latest .
docker build -f ui/Dockerfile -t metatron/dashboard-ui:latest .

# 2. Push images to your registry (adjust registry URL)
docker tag metatron/resonance-kernel:latest registry.example.com/metatron/resonance-kernel:latest
docker push registry.example.com/metatron/resonance-kernel:latest
# Repeat for other images...

# 3. Update image references in k8s/metatron-stack.yaml if needed

# 4. Deploy to Kubernetes
kubectl apply -f k8s/metatron-stack.yaml

# 5. Check deployment status
kubectl get pods -n metatron-cosmos
kubectl get services -n metatron-cosmos

# 6. Get external IPs
kubectl get svc -n metatron-cosmos

# 7. Run genesis routine (port-forward first)
kubectl port-forward -n metatron-cosmos svc/lexicon-api 8080:8080 &
kubectl port-forward -n metatron-cosmos svc/dashboard-ui 3000:3000 &
./genesis_routine.sh
```

**Scaling:**

The Kubernetes deployment includes Horizontal Pod Autoscalers (HPA) for:
- Resonance Kernel: 2-10 replicas
- Lexicon API: 3-20 replicas

Scale manually:
```bash
kubectl scale deployment resonance-kernel -n metatron-cosmos --replicas=5
```

## Genesis Routine

The Genesis Routine (`genesis_routine.sh`) initializes the Metatron Operator Cosmos through a 9-phase process:

1. **Environment Check** - Verify all services are reachable
2. **Resonance Kernel Bootstrap** - Calibrate kernel (500 cycles)
3. **Metatron Topology Activation** - Initialize 13-node topology
4. **Gabriel Cluster Alignment** - Spawn 256 Gabriel Cells
5. **Mandorla Field Equilibrium** - Stabilize dual-gate equilibrium
6. **Proof-of-Resonance** - Mine initial operators (2000 cycles)
7. **Lexicon Seed Generation** - Populate operator database
8. **Telemetry Activation** - Start real-time streaming
9. **Visualization Verification** - Ensure UI components render

**Run the routine:**
```bash
./genesis_routine.sh
```

**Custom API URL:**
```bash
API_URL=http://custom-api:8080 ./genesis_routine.sh
```

## Environment Variables

### Resonance Kernel
- `LEDGER_PATH` - Path to ledger storage (default: `/data/ledger/`)
- `TELEMETRY_PORT` - Telemetry port (default: `7444`)
- `MAX_CYCLES` - Maximum mining cycles (default: `10000`)
- `ENERGY_TOLERANCE` - Energy drift tolerance (default: `1e-5`)
- `ENTROPY_LIMIT` - Entropy decay limit (default: `1e-3`)

### Lexicon API
- `DB_URL` - PostgreSQL connection string (REQUIRED in production)
- `LEDGER_PATH` - Path to ledger storage
- `ENCRYPTION_KEY` - API encryption key (REQUIRED - generate with `openssl rand -hex 32`)
- `ENABLE_WEBSOCKETS` - Enable WebSocket telemetry (default: `true`)
- `KERNEL_HOST` - Resonance kernel hostname
- `KERNEL_PORT` - Resonance kernel port

**Security Note:** The API will not start without `DB_URL` and `ENCRYPTION_KEY` set. This prevents accidentally running with default/insecure credentials.

### Dashboard UI
- `REACT_APP_API_BASE_URL` - API base URL
- `REACT_APP_WS_TELEMETRY_URL` - WebSocket telemetry URL
- `DEFAULT_VIEW` - Default visualization mode (default: `MetatronCubeNavigator`)

## Volumes and Data Persistence

### Docker Compose
Data is persisted in the `./data/` directory:
- `./data/ledger/` - Proof-of-Resonance ledger entries
- `./data/operators/` - Operator manifests
- `./data/telemetry/` - Telemetry logs
- `./data/postgres/` - PostgreSQL database files

### Kubernetes
Persistent Volume Claims (PVCs):
- `ledger-pvc` - 10Gi (ReadWriteMany)
- `operators-pvc` - 10Gi (ReadWriteMany)
- `telemetry-pvc` - 5Gi (ReadWriteMany)
- `postgres-pvc` - 20Gi (ReadWriteOnce)

## Security

### Authentication
- JWT token-based authentication (implemented in API)
- User roles: `admin`, `researcher`, `guest`

### Ledger Signing
- Algorithm: Ed25519
- Key path: `./keys/ledger_sign.key`

### Data Encryption
- Algorithm: AES-256-GCM
- Key from `API_KEY` environment variable

**Production Security Checklist:**
- [ ] Change default PostgreSQL password
- [ ] Set strong `API_KEY` environment variable
- [ ] Generate and protect Ed25519 signing keys
- [ ] Enable TLS/SSL for external endpoints
- [ ] Configure network policies in Kubernetes
- [ ] Set up secrets management (e.g., Vault)

## Monitoring and Telemetry

### Metrics
Real-time telemetry includes:
- ΔH (energy drift)
- ΔS (entropy gradient)
- ψρω variance
- Operator birth rate
- Stability mean

### Logs
- Kernel logs: stdout → `/data/telemetry/runtime.log`
- API logs: stdout (JSON format)
- UI logs: Browser console

### Health Checks
- API: `GET /status`
- Database: `pg_isready`
- All services include liveness/readiness probes in K8s

## Troubleshooting

### Services won't start
```bash
# Check logs
docker-compose logs resonance_kernel
docker-compose logs lexicon_api
docker-compose logs dashboard_ui

# In Kubernetes
kubectl logs -n metatron-cosmos deployment/resonance-kernel
kubectl logs -n metatron-cosmos deployment/lexicon-api
```

### Genesis routine fails
- Ensure all services are healthy: `docker-compose ps`
- Check API is responding: `curl http://localhost:8080/status`
- Verify ledger directory permissions

### Database connection issues
- Check PostgreSQL is running: `docker-compose ps db`
- Verify connection string: `echo $DB_URL`
- Test connection: `docker-compose exec db psql -U metatron -d operators`

### WebSocket not connecting
- Check CORS settings in API
- Verify WebSocket URL in UI environment
- Check browser console for errors

## API Bindings

The following endpoints are available:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/status` | GET | API health and version |
| `/operator` | GET | List/search operators |
| `/operator` | POST | Create new operator |
| `/operator/{id}` | GET | Get operator details |
| `/operator/{id}` | DELETE | Delete operator (admin) |
| `/operator/{id}/visual` | GET | Get visualization assets |
| `/operator/{id}/relations` | GET | Get operator relations graph |
| `/ledger` | GET | List ledger entries |
| `/ledger/{hash}` | GET | Get ledger entry audit trail |
| `/analytics` | GET | System analytics |
| `/telemetry` | WebSocket | Real-time telemetry stream |

## Post-Deployment Checks

After deployment and genesis routine completion, verify:

- [ ] Ledger directory created and writable
- [ ] Kernel self-test passed (100 cycle simulation)
- [ ] API endpoints respond with HTTP 200
- [ ] UI connects to telemetry stream without packet loss
- [ ] At least 10 operators in lexicon
- [ ] Mean stability > 0.95
- [ ] Dashboard displays operator cards
- [ ] WebSocket telemetry updates in real-time

## Expected Results

Upon successful deployment:

**System Status:** Fully operational

**Endpoints:**
- Dashboard: http://localhost:3000 (or LoadBalancer IP in K8s)
- API: http://localhost:8080
- Telemetry: ws://localhost:8080/telemetry

**Capabilities:**
- Real-time operator mining visualization
- Searchable Operator Lexicon
- Proof-of-Resonance ledger replay
- Tensor/Gabriel/Mandorla dynamics simulation

## Version Information

- Stack Version: 1.0
- Resonance Kernel: Rust 1.75+
- Lexicon API: Python 3.11 + FastAPI 0.104+
- Dashboard UI: React 18 + TypeScript 5
- Database: PostgreSQL 15

## Support

For issues and questions:
- GitHub Issues: https://github.com/LashSesh/genesis-engine/issues
- Documentation: See `/docs` directory
- System Architecture: See `SYSTEM_ARCHITECTURE.md`

## License

CC-BY-4.0 - See LICENSE file for details
