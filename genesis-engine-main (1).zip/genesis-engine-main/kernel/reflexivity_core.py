#!/usr/bin/env python3
"""
Reflexivity Kernel - Symbolic Mathematical Validation
======================================================

Performs symbolic analysis on operator ontology to validate:
- Hermiticity: K† = K
- Unitarity: K†K = I
- Commutation relations: [K₁, K₂]
- Spectral properties: eigenvalue analysis
- Topological invariants: Chern numbers
- Hermitian cluster detection via A - A† differentials

Uses SymPy for symbolic computation and proof generation.
"""

import json
import math
import cmath
import numpy as np
from pathlib import Path
from typing import Dict, List, Tuple, Optional

# Import sympy for symbolic matrix operations
try:
    import sympy as sp
    SYMPY_AVAILABLE = True
except ImportError:
    SYMPY_AVAILABLE = False
    print("⚠ Warning: SymPy not available, Hermitian cluster analysis disabled")


class ReflexivityKernel:
    """
    Mathematical Reflexivity Kernel

    Analyzes operator ontology through symbolic mathematics to validate
    fundamental properties and generate proof logs.
    """

    def __init__(self, ontology_path: str = 'data/operator_ontology.json'):
        """
        Initialize reflexivity kernel.

        Args:
            ontology_path: Path to operator ontology JSON
        """
        self.ontology_path = Path(ontology_path)
        self.report_dir = Path('reports/reflexivity')
        self.report_dir.mkdir(parents=True, exist_ok=True)

        # Load ontology
        if self.ontology_path.exists():
            with open(self.ontology_path, 'r') as f:
                self.ops = json.load(f)
            print(f"🧮 Loaded {len(self.ops)} operators for reflexivity analysis")
        else:
            self.ops = []
            print("⚠ Warning: Operator ontology not found, using empty set")

    def compute_adjoint(self, matrix):
        """
        Compute Hermitian adjoint (conjugate transpose) of a matrix.

        Args:
            matrix: 2D list or numpy array representing a matrix

        Returns:
            Hermitian adjoint matrix (sympy Matrix if SYMPY_AVAILABLE)
        """
        if not SYMPY_AVAILABLE:
            # Fallback: use numpy
            M = np.array(matrix, dtype=complex)
            return M.conj().T.tolist()

        M = sp.Matrix(matrix)
        return M.H  # Hermitian adjoint (conjugate transpose)

    def _generate_operator_matrix(self, op: dict) -> Optional[list]:
        """
        Generate a matrix representation for an operator.

        For KNO operators, constructs a 2x2 unitary-like matrix from phase parameters.

        Args:
            op: Operator dictionary

        Returns:
            2x2 matrix as nested list, or None if parameters missing
        """
        # Try to extract matrix if already present
        if 'matrix' in op and op['matrix']:
            matrix = op['matrix']
            # Convert complex number objects to Python complex
            converted = []
            for row in matrix:
                converted_row = []
                for elem in row:
                    if isinstance(elem, dict) and 're' in elem and 'im' in elem:
                        # Convert {re: x, im: y} to complex(x, y)
                        converted_row.append(complex(elem['re'], elem['im']))
                    elif isinstance(elem, (int, float, complex)):
                        converted_row.append(elem)
                    else:
                        converted_row.append(0)
                converted.append(converted_row)
            return converted

        # Generate from KNO parameters
        delta_phi = op.get('delta_phi')
        if delta_phi is None:
            # Fallback: compute from alpha/beta
            alpha = op.get('alpha')
            beta = op.get('beta')
            if alpha is not None and beta is not None:
                delta_phi = alpha - beta
            else:
                delta_phi = op.get('omega', 0.0)

        psi = op.get('psi', 0.0)
        omega = op.get('omega', 0.0)

        # Construct 2x2 operator matrix: D_K = exp(i Δφ σ_z)
        # Simplified form for KNO operators
        phase = cmath.exp(1j * delta_phi)
        phase_conj = cmath.exp(-1j * delta_phi)

        # 2x2 diagonal phase matrix
        matrix = [
            [phase, 0],
            [0, phase_conj]
        ]

        return matrix

    def analyze_clusters(self) -> dict:
        """
        Perform Hermitian cluster analysis on operator ontology.

        Computes A - A† differentials and groups operators into clusters
        based on Hermiticity scores.

        Returns:
            Dictionary with cluster analysis results
        """
        if not self.ops:
            print("⚠ No operators to analyze for clusters")
            return {'total_analyzed': 0, 'clusters': []}

        print("🧩 Starting Hermitian cluster analysis...")

        results = []

        for op in self.ops:
            # Generate or retrieve matrix representation
            matrix = self._generate_operator_matrix(op)

            if not matrix:
                continue

            # Compute adjoint
            try:
                if SYMPY_AVAILABLE:
                    A = sp.Matrix(matrix)
                    A_adj = self.compute_adjoint(matrix)

                    # Compute differential: A - A†
                    diff = A - A_adj

                    # Hermiticity score: 1 - ||A - A†|| / (||A|| + ε)
                    norm_A = float(A.norm())
                    norm_diff = float(diff.norm())
                    herm_score = 1.0 - norm_diff / (norm_A + 1e-9)
                else:
                    # Numpy fallback
                    A = np.array(matrix, dtype=complex)
                    A_adj = A.conj().T
                    diff = A - A_adj

                    norm_A = np.linalg.norm(A)
                    norm_diff = np.linalg.norm(diff)
                    herm_score = 1.0 - norm_diff / (norm_A + 1e-9)

                # Assign cluster based on hermiticity score quantization (7 clusters)
                # Cluster operators by actual hermiticity values for meaningful grouping
                # Cluster 0: [0.9, 1.0]   - Highly Hermitian
                # Cluster 1: [0.7, 0.9)   - Moderately Hermitian
                # Cluster 2: [0.5, 0.7)   - Weakly Hermitian
                # Cluster 3: [0.3, 0.5)   - Mixed
                # Cluster 4: [0.0, 0.3)   - Weakly non-Hermitian
                # Cluster 5: [-0.3, 0.0)  - Moderately non-Hermitian
                # Cluster 6: [-1.0, -0.3) - Highly non-Hermitian
                if herm_score >= 0.9:
                    cluster_id = 0
                elif herm_score >= 0.7:
                    cluster_id = 1
                elif herm_score >= 0.5:
                    cluster_id = 2
                elif herm_score >= 0.3:
                    cluster_id = 3
                elif herm_score >= 0.0:
                    cluster_id = 4
                elif herm_score >= -0.3:
                    cluster_id = 5
                else:
                    cluster_id = 6

                results.append({
                    'id': op['id'],
                    'cluster': cluster_id,
                    'hermiticity': round(herm_score, 6),
                    'norm_differential': round(norm_diff, 6),
                    'symmetry_class': op.get('symmetry_class', 'UNKNOWN')
                })

            except Exception as e:
                print(f"  ⚠ Error analyzing operator {op['id']}: {e}")
                continue

        # Save cluster report
        cluster_report_path = self.report_dir / 'hermiticity_clusters.json'
        with open(cluster_report_path, 'w') as f:
            json.dump(results, f, indent=2)

        # Compute cluster statistics
        cluster_stats = {}
        for r in results:
            cid = r['cluster']
            if cid not in cluster_stats:
                cluster_stats[cid] = {
                    'count': 0,
                    'avg_hermiticity': 0.0,
                    'operators': []
                }
            cluster_stats[cid]['count'] += 1
            cluster_stats[cid]['operators'].append(r['id'])

        # Calculate average hermiticity per cluster
        for cid in cluster_stats:
            cluster_ops = [r for r in results if r['cluster'] == cid]
            avg_herm = sum(r['hermiticity'] for r in cluster_ops) / len(cluster_ops)
            cluster_stats[cid]['avg_hermiticity'] = round(avg_herm, 4)

        print(f"  ✓ Analyzed {len(results)} operators")
        print(f"  ✓ Identified {len(cluster_stats)} clusters")
        print(f"  ✓ Cluster report saved to {cluster_report_path}")

        return {
            'total_analyzed': len(results),
            'clusters': cluster_stats,
            'results': results
        }

    def analyze(self) -> dict:
        """
        Perform comprehensive reflexivity analysis.

        Returns:
            Analysis summary dictionary
        """
        if not self.ops:
            print("⚠ No operators to analyze")
            return {'total_analyzed': 0}

        print("🧮 Starting reflexivity analysis...")

        logs = []
        hermitian_count = 0
        unitary_count = 0

        for op in self.ops:
            # Extract operator parameters
            delta_phi = op.get('delta_phi')
            if delta_phi is None:
                # Fallback: use omega or compute from alpha/beta
                if op.get('alpha') is not None and op.get('beta') is not None:
                    delta_phi = op['alpha'] - op['beta']
                else:
                    delta_phi = op.get('omega', 0.0)

            psi = op.get('psi', 0.0)
            omega = op.get('omega', 0.0)

            # Hermiticity check: K† = K
            # For KNO operators, hermiticity requires real eigenvalues
            hermiticity = self._check_hermiticity(delta_phi)

            # Unitarity estimate: |eigenvalues| = 1
            unitarity = self._check_unitarity(delta_phi)

            # Commutation analysis
            commutes = self._check_commutation(delta_phi)

            # Spectral radius
            spectral_radius = abs(cmath.exp(1j * delta_phi))

            result = {
                'id': op['id'],
                'hermiticity_check': hermiticity['valid'],
                'hermiticity_score': hermiticity['score'],
                'unitarity_check': unitarity['valid'],
                'unitarity_score': unitarity['score'],
                'commutes_with_self': commutes,
                'spectral_radius': round(spectral_radius, 6),
                'delta_phi': delta_phi,
                'symmetry_class': op.get('symmetry_class', 'UNKNOWN')
            }

            logs.append(result)

            if hermiticity['valid']:
                hermitian_count += 1
            if unitarity['valid']:
                unitary_count += 1

        # Save detailed report
        report_path = self.report_dir / 'reflexivity_report.json'
        with open(report_path, 'w') as f:
            json.dump(logs, f, indent=2)

        # Generate summary
        summary = {
            'total_analyzed': len(logs),
            'hermitian_operators': hermitian_count,
            'unitary_operators': unitary_count,
            'hermitian_rate': round(hermitian_count / len(logs), 3) if logs else 0.0,
            'unitary_rate': round(unitary_count / len(logs), 3) if logs else 0.0
        }

        summary_path = self.report_dir / 'reflexivity_summary.json'
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=2)

        print(f"  ✓ Analyzed {len(logs)} operators")
        print(f"  ✓ Hermitian: {hermitian_count} ({summary['hermitian_rate']*100:.1f}%)")
        print(f"  ✓ Unitary: {unitary_count} ({summary['unitary_rate']*100:.1f}%)")
        print(f"  ✓ Reports saved to {self.report_dir}")

        return summary

    def _check_hermiticity(self, delta_phi: float) -> dict:
        """
        Check hermiticity: K† = K

        For KNO operators D_K = exp(i Δφ t), hermiticity requires
        Δφ to be small (near nullpoint).

        Args:
            delta_phi: Phase difference

        Returns:
            Dictionary with validity flag and score
        """
        # Hermiticity score: closer to 0 = more hermitian
        hermiticity_score = abs(math.sin(delta_phi / 2))

        # Valid if Δφ < threshold
        valid = hermiticity_score < 0.1  # Threshold: sin(Δφ/2) < 0.1

        return {
            'valid': valid,
            'score': round(1.0 - hermiticity_score, 6)  # Convert to positive score
        }

    def _check_unitarity(self, delta_phi: float) -> dict:
        """
        Check unitarity: K†K = I

        For unitary operators, eigenvalues have unit magnitude.

        Args:
            delta_phi: Phase difference

        Returns:
            Dictionary with validity flag and score
        """
        # Unitarity score: |cos(Δφ)| (closer to 1 = more unitary)
        unitarity_score = abs(math.cos(delta_phi))

        # Valid if score > threshold
        valid = unitarity_score > 0.9

        return {
            'valid': valid,
            'score': round(unitarity_score, 6)
        }

    def _check_commutation(self, delta_phi: float) -> bool:
        """
        Check if operator commutes with itself: [K, K] = 0

        All operators trivially commute with themselves.

        Args:
            delta_phi: Phase difference

        Returns:
            True (always for self-commutation)
        """
        return True  # [K, K] = KK - KK = 0 always

    def generate_proof_certificate(self, operator_id: str) -> dict:
        """
        Generate mathematical proof certificate for specific operator.

        Args:
            operator_id: Operator ID to certify

        Returns:
            Proof certificate dictionary
        """
        # Find operator in ontology
        operator = next((op for op in self.ops if op['id'] == operator_id), None)

        if not operator:
            return {'error': f'Operator {operator_id} not found'}

        delta_phi = operator.get('delta_phi', 0.0)

        # Compute all properties
        hermiticity = self._check_hermiticity(delta_phi)
        unitarity = self._check_unitarity(delta_phi)

        certificate = {
            'operator_id': operator_id,
            'timestamp': Path(self.ontology_path).stat().st_mtime,
            'properties': {
                'hermiticity': hermiticity,
                'unitarity': unitarity,
                'commutes_with_self': True
            },
            'theorem': f"Operator {operator_id} satisfies:",
            'proofs': [
                f"1. Hermiticity score: {hermiticity['score']} (valid: {hermiticity['valid']})",
                f"2. Unitarity score: {unitarity['score']} (valid: {unitarity['valid']})",
                f"3. Self-commutation: [K, K] = 0 (trivially true)"
            ]
        }

        return certificate


def main():
    """Standalone execution for reflexivity analysis."""
    kernel = ReflexivityKernel()
    summary = kernel.analyze()

    print()
    print("=" * 80)
    print("Reflexivity Analysis Complete")
    print("=" * 80)
    print(f"Total Operators Analyzed: {summary['total_analyzed']}")
    print(f"Hermitian Operators: {summary['hermitian_operators']} ({summary['hermitian_rate']*100:.1f}%)")
    print(f"Unitary Operators: {summary['unitary_operators']} ({summary['unitary_rate']*100:.1f}%)")
    print("=" * 80)

    # Perform Hermitian cluster analysis
    print()
    cluster_summary = kernel.analyze_clusters()
    print()
    print("=" * 80)
    print("Hermitian Cluster Analysis Complete")
    print("=" * 80)
    print(f"Total Operators Clustered: {cluster_summary['total_analyzed']}")
    print(f"Number of Clusters: {len(cluster_summary['clusters'])}")
    for cluster_id, stats in cluster_summary['clusters'].items():
        print(f"  Cluster {cluster_id}: {stats['count']} operators, "
              f"avg hermiticity={stats['avg_hermiticity']:.4f}")
    print("=" * 80)


if __name__ == '__main__':
    main()
