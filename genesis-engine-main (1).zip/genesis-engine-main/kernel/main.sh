#!/bin/bash
# Resonance Kernel entry point

set -e

echo "Starting Metatron Resonance Kernel..."
echo "LEDGER_PATH: ${LEDGER_PATH}"
echo "MAX_CYCLES: ${MAX_CYCLES}"
echo "ENERGY_TOLERANCE: ${ENERGY_TOLERANCE}"
echo "ENTROPY_LIMIT: ${ENTROPY_LIMIT}"

# Initialize ledger directory if it doesn't exist
if [ ! -d "${LEDGER_PATH}" ]; then
    echo "Creating ledger directory at ${LEDGER_PATH}"
    mkdir -p "${LEDGER_PATH}"
fi

# Start the MOGE CLI in server mode
# This is a placeholder for the actual kernel service
# In production, this would run the resonance kernel server
exec moge --mode server \
    --ledger-path "${LEDGER_PATH}" \
    --max-cycles "${MAX_CYCLES:-10000}" \
    --port 7000 \
    --telemetry-port "${TELEMETRY_PORT:-7444}"
