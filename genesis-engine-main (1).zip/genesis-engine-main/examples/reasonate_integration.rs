//! MOGE Reasonate Integration Example
//!
//! Demonstrates the full Reasonate Kernel integration with MOGE

use genesis_engine::{
    signature::Signature5D,
    evolution_cycle::{EvolutionCycle, EvolutionConfig, EvolutionStats},
    recursive_optimizer::{RecursiveOptimizer, AdaptiveConstants},
    resonance_dynamics::HamiltonianConfig,
};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("=== MOGE Reasonate Kernel Integration Demo ===\n");

    // Step 1: Initialize operator signatures
    println!("Step 1: Initializing operator signatures...");
    let signatures = vec![
        Signature5D::new(0.8, 0.7, 0.6, 0.5, 0.4),
        Signature5D::new(0.6, 0.6, 0.7, 0.5, 0.5),
        Signature5D::new(0.7, 0.5, 0.8, 0.6, 0.4),
        Signature5D::new(0.5, 0.6, 0.6, 0.5, 0.5),
        Signature5D::new(0.6, 0.7, 0.5, 0.6, 0.4),
    ];
    println!("✓ Initialized {} operator signatures\n", signatures.len());

    // Step 2: Configure evolution cycle
    println!("Step 2: Configuring evolution cycle...");
    let config = EvolutionConfig {
        ticks_per_cycle: 15,
        hamiltonian: HamiltonianConfig {
            dt: 0.01,
            energy_threshold: 1e-5,
            damping: 0.95,
        },
        topology_threshold: 0.2,
        path_depth: 5,
    };
    let mut cycle = EvolutionCycle::new(config, signatures);
    println!("✓ Evolution cycle configured\n");

    // Step 3: Initialize recursive optimizer
    println!("Step 3: Initializing recursive optimizer...");
    let constants = AdaptiveConstants {
        alpha: 0.01,
        beta: 0.05,
        resonance_threshold: 0.85,
        energy_threshold: 1e-5,
        topology_threshold: 1e-3,
        invariance_tolerance: 1e-4,
    };
    let mut optimizer = RecursiveOptimizer::with_constants(constants);
    let mut stats = EvolutionStats::new();
    println!("✓ Optimizer initialized\n");

    // Step 4: Run evolution cycles
    println!("Step 4: Running evolution cycles...\n");
    let total_cycles = 100;
    let mut equilibrium_count = 0;

    for i in 0..total_cycles {
        // Execute one complete cycle (15 ticks)
        let state = cycle.run_cycle()?;
        
        // Check if system reached equilibrium
        let at_equilibrium = cycle.is_at_equilibrium();
        if at_equilibrium {
            equilibrium_count += 1;
        }

        // Update statistics
        stats.update(&state, at_equilibrium);

        // Optimize kernel constants based on feedback
        optimizer.optimize_step(state.energy_drift, state.topological_variance);

        // Log progress every 10 cycles
        if (i + 1) % 10 == 0 {
            println!("Cycle {:3}: Energy drift: {:.6}, Topo variance: {:.6}, Equilibrium: {}",
                i + 1, state.energy_drift, state.topological_variance, at_equilibrium);
            
            if let Some(betti) = &state.betti_numbers {
                println!("         Betti: β₀={}, β₁={}, β₂={}, weight={:.4}",
                    betti.beta_0, betti.beta_1, betti.beta_2, betti.topological_weight());
            }
        }
    }

    // Step 5: Final report
    println!("\n=== Final Statistics ===");
    println!("Total cycles executed: {}", stats.total_cycles);
    println!("Total ticks executed: {}", stats.total_ticks);
    println!("Equilibrium cycles: {} ({:.1}%)", 
        equilibrium_count, 
        (equilibrium_count as f64 / total_cycles as f64) * 100.0);
    println!("Equilibrium rate: {:.2}%", stats.equilibrium_rate() * 100.0);
    println!("Average energy drift: {:.6}", stats.avg_energy_drift);
    println!("Average topology variance: {:.6}", stats.avg_topological_variance);

    // Step 6: Optimization results
    println!("\n=== Optimization Results ===");
    let opt_stats = optimizer.get_stats();
    println!("Total iterations: {}", opt_stats.total_iterations);
    println!("Error reduction: {:.2}%", opt_stats.error_reduction_percent);
    println!("Avg energy drift: {:.6}", opt_stats.avg_energy_drift);
    println!("Avg topology variance: {:.6}", opt_stats.avg_topology_variance);
    println!("Converged: {}", if opt_stats.converged { "Yes" } else { "No" });

    // Step 7: Display final constants
    println!("\n=== Final Adaptive Constants ===");
    let final_constants = optimizer.get_constants();
    println!("Learning rate (α): {:.6}", final_constants.alpha);
    println!("Damping factor (β): {:.6}", final_constants.beta);
    println!("Resonance threshold: {:.6}", final_constants.resonance_threshold);
    println!("Energy threshold: {:.6}", final_constants.energy_threshold);
    println!("Topology threshold: {:.6}", final_constants.topology_threshold);
    println!("Invariance tolerance: {:.6}", final_constants.invariance_tolerance);

    // Step 8: Validation checks
    println!("\n=== Validation Checks ===");
    let energy_valid = stats.avg_energy_drift < 1e-4;
    let topology_valid = stats.avg_topological_variance < 1e-2;
    let equilibrium_valid = stats.equilibrium_rate() >= 0.5;
    
    println!("Energy conservation (< 10⁻⁴): {} {}", 
        if energy_valid { "✓" } else { "✗" },
        if energy_valid { "PASS" } else { "FAIL" });
    println!("Topological variance (< 10⁻²): {} {}", 
        if topology_valid { "✓" } else { "✗" },
        if topology_valid { "PASS" } else { "FAIL" });
    println!("Operator stability (≥ 50%): {} {}", 
        if equilibrium_valid { "✓" } else { "✗" },
        if equilibrium_valid { "PASS" } else { "FAIL" });

    let all_valid = energy_valid && topology_valid && equilibrium_valid;
    
    if all_valid {
        println!("\n🎉 All validation checks PASSED!");
        println!("Reasonate Kernel is operating within specification.");
        
        // Save optimized constants
        optimizer.save_constants("adaptive_constants.toml")?;
        println!("\n✓ Adaptive constants saved to adaptive_constants.toml");
    } else {
        println!("\n⚠ Some validation checks FAILED.");
        println!("Further optimization may be required.");
    }

    // Step 9: Final operator states
    println!("\n=== Final Operator States ===");
    let final_signatures = cycle.get_signatures();
    for (i, sig) in final_signatures.iter().enumerate() {
        println!("Operator {}: ψ={:.3}, ρ={:.3}, ω={:.3}, χ={:.3}, η={:.3}",
            i, sig.psi, sig.rho, sig.omega, sig.chi, sig.eta);
    }

    println!("\n=== Integration Demo Complete ===");
    Ok(())
}
