//! KNO/DK Cyclic Conversion Operator Demo
//!
//! Demonstrates the complete 5-stage simulation pipeline for the
//! Klemm Nullpunktoperator (KNO) and Double-Kick (DK) operator system.
//!
//! Run with: cargo run --example kno_demo

use genesis_engine::kno_simulation::{KNOSimulation, SimulationConfig};

fn main() -> genesis_engine::Result<()> {
    println!("╔══════════════════════════════════════════════════════════════╗");
    println!("║  Cyclic Conversion Operator Model (KNO/DK Framework)        ║");
    println!("║  Mathematically Rigorous Hermitian System Simulation        ║");
    println!("╚══════════════════════════════════════════════════════════════╝\n");

    // Configuration for the simulation
    let config = SimulationConfig {
        time_start: 0.0,
        time_end: 2.0 * std::f64::consts::PI,
        time_steps: 500,
        alpha: 1.0,      // Forward phase parameter
        beta: 0.9,       // Backward phase parameter (Δφ = 0.1)
        max_eigenstate: 10,
        max_stabilization_iterations: 1000,
        output_dir: "./kno_demo_output".to_string(),
    };

    // Create and run simulation
    let simulation = KNOSimulation::new(config);
    let results = simulation.run()?;

    // Display results summary
    println!("\n╔══════════════════════════════════════════════════════════════╗");
    println!("║  Simulation Results Summary                                  ║");
    println!("╚══════════════════════════════════════════════════════════════╝");

    println!("\n📊 Field Generation:");
    println!("  • Samples generated: {}", results.field.time_lattice.len());
    println!("  • Phase difference Δφ: {:.6}", results.field.delta_phi);
    println!("  • Domain: [{:.2}, {:.2}]",
        results.field.time_lattice.first().unwrap_or(&0.0),
        results.field.time_lattice.last().unwrap_or(&0.0));

    println!("\n🔄 Cyclic Conversion (Involution D_K²):");
    println!("  • All checks passed: {}", results.conversion.all_passed);
    println!("  • Maximum error: {:.2e}", results.conversion.max_error);
    println!("  • Passing rate: {:.1}%",
        (results.conversion.involution_checks.iter().filter(|c| c.passed).count() as f64
         / results.conversion.involution_checks.len() as f64) * 100.0);

    println!("\n⚡ KNO Stabilization:");
    println!("  • Converged: {}", results.stabilization.converged);
    println!("  • Iterations: {}", results.stabilization.iterations);
    println!("  • Final Δφ: {:.2e}", results.stabilization.final_delta_phi);
    println!("  • Final state magnitude: {:.6}", results.stabilization.final_state.magnitude());

    println!("\n🌈 Spectral Decomposition:");
    println!("  • Eigenfrequencies computed: {}", results.spectrum.eigenfrequencies.len());
    println!("  • Spectrum symmetric: {}", results.spectrum.spectrum_symmetric);
    println!("  • Dominant eigenstates: {}",
        results.spectrum.eigenstates.iter()
            .filter(|(_, amp)| *amp > 0.1)
            .count());

    println!("\n✅ Hermitian Validation:");
    println!("  • Hermitian property: {}",
        if results.audit.hermitian_valid { "✓ PASS" } else { "✗ FAIL" });
    println!("  • Hermitian error: {:.2e}", results.audit.hermitian_error);
    println!("  • Norm conservation: {}",
        if results.audit.norm_conservation { "✓ PASS" } else { "✗ FAIL" });
    println!("  • Phase coherence: {}",
        if results.audit.phase_coherence { "✓ PASS" } else { "✗ FAIL" });
    println!("  • Coherence ratio: {:.4} (target: ≥0.9999)", results.audit.coherence_ratio);
    println!("  • Energy error: {:.2e} (target: <1e-10)", results.audit.energy_error);

    println!("\n┌────────────────────────────────────────────────────────────┐");
    if results.audit.all_passed {
        println!("│ 🎉 ALL TESTS PASSED - System is Hermitian and Stable    │");
    } else {
        println!("│ ⚠️  SOME TESTS FAILED - Review output for details        │");
    }
    println!("└────────────────────────────────────────────────────────────┘");

    println!("\n📁 Output files saved to: ./kno_demo_output/");
    println!("  • dk_field.json");
    println!("  • cyclic_conversion_metrics.json");
    println!("  • kno_stabilization.json");
    println!("  • operator_spectrum.csv");
    println!("  • hermitian_validation.json");

    println!("\n✨ Simulation complete!\n");

    Ok(())
}
