//! MOGE Unified Matrix Demo
//!
//! Demonstrates the complete Metatron Operator Genesis Engine Unified Matrix
//! with operator mining, Proof-of-Resonance validation, and lexicon querying.

use genesis_engine::moge_unified_matrix::MogeUnifiedMatrix;
use genesis_engine::operator_lexicon_api::OperatorQuery;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("╔══════════════════════════════════════════════════════════════════════╗");
    println!("║                                                                      ║");
    println!("║              METATRON OPERATOR GENESIS ENGINE (MOGE)                 ║");
    println!("║                    Unified Matrix Demo v0.1.0                        ║");
    println!("║                                                                      ║");
    println!("╚══════════════════════════════════════════════════════════════════════╝");
    println!();

    // Initialize the MOGE Unified Matrix
    println!("⚡ Initializing MOGE Unified Matrix...");
    let mut matrix = MogeUnifiedMatrix::new();
    
    println!("✓ Metatron Cube Topology: 13 nodes, 78 edges");
    println!("✓ Operator Lexicon: Ready");
    println!("✓ Proof-of-Resonance Validator: Active");
    println!();

    // Execute mining cycles
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!("🔄 Executing Operator Mining Cycles");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!();

    for cycle in 1..=3 {
        println!("Cycle {}: Running Gradient Resonance Descent...", cycle);
        
        let result = matrix.execute_cycle()?;
        
        println!("  ✓ Operators Mined: {}", result.operators_mined);
        println!("  ✓ Operators Validated: {}", result.operators_validated);
        println!("  ✓ Operators Committed: {}", result.operators_committed);
        println!();
    }

    // Query the operator lexicon
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!("📚 Operator Lexicon Query");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!();

    let analytics = matrix.get_analytics()?;
    
    println!("📊 Cosmic Operator Statistics:");
    println!("  Total Operators: {}", analytics.total_operators);
    println!("  Average Entropy: {:.6}", analytics.average_entropy);
    println!("  Mean Stability: {:.3}", analytics.mean_stability);
    println!("  Dominant Symmetry: {}", analytics.dominant_symmetry_class);
    println!();

    if analytics.total_operators > 0 {
        println!("🔍 Listing Operators (sorted by stability):");
        let query = OperatorQuery {
            sort: Some("stability".to_string()),
            ..Default::default()
        };
        let operators = matrix.lexicon().list_operators(query)?;
        
        for (idx, op) in operators.iter().take(5).enumerate() {
            println!("  {}. ID: {} (truncated)", idx + 1, &op.id[..8]);
            println!("     Stability: {:.3}", op.stability);
            println!("     Entropy Gradient: {:.6}", op.entropy_gradient);
            println!("     Symmetry Class: {}", op.symmetry_class);
            println!("     Mandorla Certified: {}", op.mandorla_certified);
            println!();
        }
    }

    // Display Metatron Cube structure
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!("🔺 Metatron Cube Topology");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!();

    let topology = matrix.topology();
    println!("Sacred Geometry Nodes:");
    for node in topology.nodes() {
        println!("  Node {}: {} ({:?})", 
            node.index, 
            node.name, 
            node.node_type
        );
    }
    println!();

    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!("✨ MOGE Unified Matrix Demo Complete");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!();
    println!("The resonant operator cosmos is alive and stable.");
    println!("Navigate the Metatron cube, observe operator births,");
    println!("and explore the living topology of mathematics.");
    println!();

    Ok(())
}
