//! Example: Resonant Language Projection Pipeline
//!
//! Demonstrates the complete RLP pipeline from operator genesis to cross-domain validation.

use genesis_engine::operator::Operator;
use genesis_engine::metatron_resonance_pipeline::MetatronResonancePipeline;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("=== Metatron Resonance Pipeline Example ===\n");
    
    // Initialize the pipeline
    println!("Initializing Metatron Resonance Pipeline...");
    let mut pipeline = MetatronResonancePipeline::new("data");
    
    // Process multiple operators
    println!("\nProcessing operators through complete pipeline...\n");
    
    let mut successful = 0;
    let mut failed = 0;
    
    for i in 0..10 {
        println!("--- Operator {} ---", i + 1);
        
        // Create operator
        let operator = Operator::new();
        
        // Process through pipeline
        match pipeline.process_operator(&operator) {
            Ok(result) => {
                successful += 1;
                
                // Display results
                println!("TIC ID: {}", result.tic_id);
                println!("Signature Hash: {}...", &result.signature_hash[..16]);
                println!("Semantic Coherence: {:.4}", result.semantic_coherence);
                
                // Validation results
                let report = &result.validation_report;
                println!("\nValidation Report:");
                println!("  Status: {}", report.status);
                println!("  CDCI: {:.4}", report.cdci);
                println!("  Mean Error: {:.6}", report.mean_error);
                println!("  Max Drift: {:.6}", report.cross_domain_drift.max_drift);
                println!("  Cycle Error: {:.6}", report.cycle_closure_error);
                
                // Export status
                if let Some(ref path) = result.export_path {
                    println!("  Exported to: {}", path);
                } else {
                    println!("  Export: Conditions not met (recalibrating)");
                }
                
                // Show one domain translation as example
                if let Some((domain_name, repr)) = result.translations.first() {
                    println!("\nExample Translation ({}):", domain_name);
                    match repr {
                        genesis_engine::operator_reconstruction::DomainRepresentation::Mathematics { equation, .. } => {
                            println!("  {}", equation);
                        },
                        genesis_engine::operator_reconstruction::DomainRepresentation::Cybernetics { gain, phase, stability } => {
                            println!("  gain={:.3}, phase={:.3}, stability={:.3}", gain, phase, stability);
                        },
                        _ => println!("  (other domain type)"),
                    }
                }
                
                // Recalibration status
                if result.needs_recalibration {
                    println!("\n⚠️  Recalibration recommended");
                } else {
                    println!("\n✓ Operator validated successfully");
                }
            },
            Err(e) => {
                failed += 1;
                println!("Processing failed: {}", e);
                println!("(This is expected - entropy invariance condition filters operators)\n");
            }
        }
        
        println!();
    }
    
    // Display processing summary
    println!("\n=== Processing Summary ===");
    println!("Successful: {}", successful);
    println!("Failed (invariance): {}", failed);
    
    // Display pipeline statistics
    println!("\n=== Pipeline Statistics ===");
    let stats = pipeline.statistics();
    println!("Operators Processed: {}", stats.operators_processed);
    println!("Operators Exported: {}", stats.operators_exported);
    println!("Operators Validated: {}", stats.operators_validated);
    println!("Validation Failures: {}", stats.validation_failures);
    println!("Avg Semantic Coherence: {:.4}", stats.avg_semantic_coherence);
    println!("Avg CDCI: {:.4}", stats.avg_cdci);
    
    // Get rule matrix state
    println!("\n=== Rule Matrix State ===");
    let matrix_state = pipeline.rule_matrix_state();
    println!("Status: {}", matrix_state.status);
    println!("ΔR Mean: {:.6}", matrix_state.delta_r_mean);
    println!("ΔR Variance: {:.6}", matrix_state.delta_r_variance);
    println!("Semantic Coherence Index: {:.4}", matrix_state.semantic_coherence_index);
    println!("Checksum: {}...", &matrix_state.matrix_checksum[..16]);
    
    // Save statistics
    println!("\nSaving pipeline statistics...");
    pipeline.save_statistics()?;
    
    println!("\n✓ Pipeline example completed successfully!");
    
    Ok(())
}
