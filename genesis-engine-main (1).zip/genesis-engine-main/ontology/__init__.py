"""
Operator Ontology System
========================

A structured knowledge base for storing evolved operators with semantic metadata.
Enables queries by symmetry class, stability, entropy, origin cycle, and geometry.
"""

__version__ = "1.0.0"
__author__ = "ORIPHIEL-QLOGIC Development Team"
