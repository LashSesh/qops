#!/usr/bin/env python3
"""
Operator Query Engine - Advanced Ontology Analysis
===================================================

Provides sophisticated query and analytical capabilities for the
operator ontology, enabling selective feedback and visualization.

Query capabilities:
- Multi-criteria filtering (symmetry, stability, entropy, cluster)
- Statistical summaries and distributions
- Geometric analysis (phase space, stability landscape)
- Correlation discovery
- Stability and entropy profiling

Supports the ORIPHIEL-QLOGIC feedback loop with targeted analysis.
"""

import json
import math
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple


class OperatorQueries:
    """
    Advanced Query Engine for Operator Ontology

    Provides analytical and search capabilities for exploring
    the evolved operator corpus.
    """

    def __init__(self, ontology_path: str = 'data/operator_ontology.json'):
        """
        Initialize query engine.

        Args:
            ontology_path: Path to operator ontology JSON
        """
        self.path = Path(ontology_path)

        # Load ontology
        if self.path.exists():
            with open(self.path, 'r') as f:
                self.ops = json.load(f)
            print(f"🔍 Loaded {len(self.ops)} operators for query analysis")
        else:
            self.ops = []
            print("⚠ Warning: Operator ontology not found, using empty set")

    def find(
        self,
        symmetry: Optional[str] = None,
        stability: Optional[float] = None,
        entropy: Optional[float] = None,
        cluster: Optional[int] = None,
        semantic_state: Optional[str] = None,
        min_stability: Optional[float] = None,
        max_entropy: Optional[float] = None
    ) -> List[Dict]:
        """
        Query operators by multiple criteria.

        Args:
            symmetry: Symmetry class (exact match)
            stability: Minimum stability value (≥)
            entropy: Maximum entropy value (≤)
            cluster: Cluster ID (exact match)
            semantic_state: Semantic state (exact match)
            min_stability: Alternative minimum stability filter
            max_entropy: Alternative maximum entropy filter

        Returns:
            List of matching operators
        """
        results = self.ops.copy()

        # Apply filters
        if symmetry is not None:
            results = [r for r in results if str(r.get('symmetry_class')) == str(symmetry)]

        if stability is not None or min_stability is not None:
            min_stab = stability if stability is not None else min_stability
            results = [r for r in results if r.get('stability', 0) >= min_stab]

        if entropy is not None or max_entropy is not None:
            max_ent = entropy if entropy is not None else max_entropy
            results = [r for r in results if abs(r.get('entropy', 0)) <= max_ent]

        if cluster is not None:
            results = [r for r in results if r.get('cluster') == cluster]

        if semantic_state is not None:
            results = [r for r in results if str(r.get('semantic_state')) == str(semantic_state)]

        print(f"🔍 Query matched {len(results)} operators (from {len(self.ops)} total)")

        return results

    def summary(self) -> dict:
        """
        Generate comprehensive ontology summary.

        Returns:
            Dictionary with summary statistics
        """
        if not self.ops:
            print("⚠ No operators in ontology")
            return {
                'total_operators': 0,
                'avg_entropy': 0.0,
                'avg_stability': 0.0
            }

        # Compute statistics
        entropies = [abs(op.get('entropy', 0)) for op in self.ops]
        stabilities = [op.get('stability', 0) for op in self.ops]

        avg_entropy = sum(entropies) / len(entropies)
        avg_stability = sum(stabilities) / len(stabilities)
        std_entropy = np.std(entropies)
        std_stability = np.std(stabilities)

        # Symmetry distribution
        symmetry_dist = {}
        for op in self.ops:
            sym = op.get('symmetry_class', 'UNKNOWN')
            symmetry_dist[sym] = symmetry_dist.get(sym, 0) + 1

        # Cluster distribution
        cluster_dist = {}
        for op in self.ops:
            cluster = op.get('cluster')
            if cluster is not None:
                cluster_dist[cluster] = cluster_dist.get(cluster, 0) + 1

        summary = {
            'total_operators': len(self.ops),
            'avg_entropy': round(avg_entropy, 6),
            'avg_stability': round(avg_stability, 6),
            'std_entropy': round(std_entropy, 6),
            'std_stability': round(std_stability, 6),
            'entropy_range': [round(min(entropies), 6), round(max(entropies), 6)],
            'stability_range': [round(min(stabilities), 6), round(max(stabilities), 6)],
            'symmetry_distribution': symmetry_dist,
            'cluster_distribution': cluster_dist
        }

        # Print summary
        print()
        print("=" * 80)
        print("Operator Ontology Summary")
        print("=" * 80)
        print(f"Total Operators: {summary['total_operators']}")
        print(f"⟨Entropy⟩ = {summary['avg_entropy']:.6f} ± {summary['std_entropy']:.6f}")
        print(f"⟨Stability⟩ = {summary['avg_stability']:.6f} ± {summary['std_stability']:.6f}")
        print(f"Entropy Range: [{summary['entropy_range'][0]:.6f}, {summary['entropy_range'][1]:.6f}]")
        print(f"Stability Range: [{summary['stability_range'][0]:.6f}, {summary['stability_range'][1]:.6f}]")
        print()
        print("Symmetry Distribution:")
        for sym, count in summary['symmetry_distribution'].items():
            pct = 100 * count / summary['total_operators']
            print(f"  {sym}: {count} ({pct:.1f}%)")
        if summary['cluster_distribution']:
            print()
            print("Cluster Distribution:")
            for cluster, count in sorted(summary['cluster_distribution'].items()):
                pct = 100 * count / summary['total_operators']
                print(f"  Cluster {cluster}: {count} ({pct:.1f}%)")
        print("=" * 80)

        return summary

    def analyze_stability_landscape(self) -> dict:
        """
        Analyze stability landscape in phase space.

        Returns:
            Dictionary with landscape analysis
        """
        if not self.ops:
            return {'error': 'No operators available'}

        # Extract stability and phase parameters
        stability_data = []
        for op in self.ops:
            delta_phi = op.get('delta_phi')
            if delta_phi is None:
                alpha = op.get('alpha')
                beta = op.get('beta')
                if alpha is not None and beta is not None:
                    delta_phi = alpha - beta
                else:
                    delta_phi = op.get('omega', 0.0)

            stability_data.append({
                'id': op['id'],
                'stability': op.get('stability', 0.0),
                'delta_phi': delta_phi,
                'entropy': abs(op.get('entropy', 0.0))
            })

        # Identify stable regions (high stability)
        stable_operators = [d for d in stability_data if d['stability'] > 0.7]
        unstable_operators = [d for d in stability_data if d['stability'] < 0.3]

        analysis = {
            'total_operators': len(stability_data),
            'stable_count': len(stable_operators),
            'unstable_count': len(unstable_operators),
            'stable_fraction': round(len(stable_operators) / len(stability_data), 4),
            'avg_stability_stable': round(np.mean([d['stability'] for d in stable_operators]), 6) if stable_operators else 0.0,
            'avg_stability_unstable': round(np.mean([d['stability'] for d in unstable_operators]), 6) if unstable_operators else 0.0
        }

        print()
        print("=" * 80)
        print("Stability Landscape Analysis")
        print("=" * 80)
        print(f"Stable Operators (>0.7): {analysis['stable_count']} ({analysis['stable_fraction']*100:.1f}%)")
        print(f"Unstable Operators (<0.3): {analysis['unstable_count']}")
        print("=" * 80)

        return analysis

    def find_correlations(self) -> dict:
        """
        Discover correlations between operator properties.

        Returns:
            Dictionary with correlation coefficients
        """
        if len(self.ops) < 2:
            return {'error': 'Insufficient data for correlation analysis'}

        # Extract numerical features
        stabilities = []
        entropies = []
        delta_phis = []

        for op in self.ops:
            stabilities.append(op.get('stability', 0.0))
            entropies.append(abs(op.get('entropy', 0.0)))

            delta_phi = op.get('delta_phi')
            if delta_phi is None:
                alpha = op.get('alpha')
                beta = op.get('beta')
                if alpha is not None and beta is not None:
                    delta_phi = alpha - beta
                else:
                    delta_phi = op.get('omega', 0.0)
            delta_phis.append(delta_phi)

        # Compute correlation coefficients
        correlations = {}

        # Stability vs Entropy
        if len(stabilities) > 1 and len(entropies) > 1:
            corr_stab_ent = np.corrcoef(stabilities, entropies)[0, 1]
            correlations['stability_entropy'] = round(corr_stab_ent, 4)

        # Stability vs Delta_phi
        if len(stabilities) > 1 and len(delta_phis) > 1:
            corr_stab_phi = np.corrcoef(stabilities, delta_phis)[0, 1]
            correlations['stability_delta_phi'] = round(corr_stab_phi, 4)

        # Entropy vs Delta_phi
        if len(entropies) > 1 and len(delta_phis) > 1:
            corr_ent_phi = np.corrcoef(entropies, delta_phis)[0, 1]
            correlations['entropy_delta_phi'] = round(corr_ent_phi, 4)

        print()
        print("=" * 80)
        print("Property Correlations")
        print("=" * 80)
        for key, value in correlations.items():
            print(f"{key}: {value:.4f}")
        print("=" * 80)

        return correlations

    def export_query_results(
        self,
        results: List[Dict],
        output_path: Optional[str] = None
    ):
        """
        Export query results to JSON file.

        Args:
            results: Query results to export
            output_path: Output file path (default: reports/reflexivity/query_results.json)
        """
        if output_path is None:
            output_dir = Path('reports/reflexivity')
            output_dir.mkdir(parents=True, exist_ok=True)
            output_path = output_dir / 'query_results.json'
        else:
            output_path = Path(output_path)
            # Ensure parent directories exist for custom paths
            output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w') as f:
            json.dump(results, f, indent=2)

        print(f"💾 Query results exported to {output_path}")

    def get_top_operators(
        self,
        criterion: str = 'stability',
        n: int = 10,
        reverse: bool = True
    ) -> List[Dict]:
        """
        Get top N operators by specified criterion.

        Args:
            criterion: Sorting criterion ('stability', 'entropy', 'delta_phi')
            n: Number of operators to return
            reverse: If True, sort in descending order

        Returns:
            List of top operators
        """
        if not self.ops:
            return []

        # Sort by criterion
        if criterion == 'entropy':
            sorted_ops = sorted(
                self.ops,
                key=lambda op: abs(op.get('entropy', 0)),
                reverse=reverse
            )
        elif criterion == 'stability':
            sorted_ops = sorted(
                self.ops,
                key=lambda op: op.get('stability', 0),
                reverse=reverse
            )
        elif criterion == 'delta_phi':
            def get_delta_phi(op):
                delta_phi = op.get('delta_phi')
                if delta_phi is None:
                    alpha = op.get('alpha')
                    beta = op.get('beta')
                    if alpha is not None and beta is not None:
                        return alpha - beta
                    return op.get('omega', 0.0)
                return delta_phi

            sorted_ops = sorted(
                self.ops,
                key=get_delta_phi,
                reverse=reverse
            )
        else:
            print(f"⚠ Unknown criterion: {criterion}")
            return []

        return sorted_ops[:n]


def main():
    """Standalone execution for operator queries."""
    queries = OperatorQueries()

    # Generate summary
    queries.summary()

    # Analyze stability landscape
    queries.analyze_stability_landscape()

    # Find correlations
    queries.find_correlations()

    # Example queries
    print()
    print("=" * 80)
    print("Example Queries")
    print("=" * 80)

    # Find highly stable operators
    stable_ops = queries.find(min_stability=0.8)
    print(f"Highly stable operators (≥0.8): {len(stable_ops)}")

    # Find low entropy operators
    coherent_ops = queries.find(max_entropy=0.1)
    print(f"Coherent operators (entropy ≤0.1): {len(coherent_ops)}")

    # Find by symmetry class
    u1_ops = queries.find(symmetry='U(1)_COHERENT')
    print(f"U(1)_COHERENT operators: {len(u1_ops)}")

    print("=" * 80)


if __name__ == '__main__':
    main()
