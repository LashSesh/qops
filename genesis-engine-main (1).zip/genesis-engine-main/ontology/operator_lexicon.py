#!/usr/bin/env python3
"""
Operator Lexicon - Structured Ontology for Mathematical Operators
==================================================================

Stores evolved operators as structured mathematical objects with:
- Unique identifiers
- Symmetry class classification
- Stability and entropy metrics
- Origin cycle tracking
- Resonance profiles
- Geometric node assignments

Supports semantic queries for operator corpus exploration.
"""

import json
import os
import math
import uuid
from pathlib import Path
from typing import Dict, List, Optional


class OperatorLexicon:
    """
    Operator Ontology Database

    A persistent knowledge base for mathematical operators evolved
    through the ORIPHIEL-QLOGIC framework.
    """

    def __init__(self, path: str = 'data/operator_ontology.json'):
        """
        Initialize operator lexicon.

        Args:
            path: Path to ontology JSON file
        """
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data: List[Dict] = []

        # Load existing ontology if available
        if self.path.exists():
            with open(self.path, 'r') as f:
                self.data = json.load(f)
            print(f"📚 Loaded operator ontology: {len(self.data)} operators")
        else:
            print("📚 Initialized empty operator ontology")

    def register_operator(self, op_dict: dict) -> dict:
        """
        Register a new operator in the ontology.

        Args:
            op_dict: Operator dictionary with metadata

        Returns:
            Registered operator entry with assigned ID
        """
        # Generate unique operator identifier
        op_id = op_dict.get('id')
        if not op_id:
            op_id = f"KNO_Ω_{uuid.uuid4().hex[:8]}"

        # Classify symmetry based on stability and entropy
        symmetry_class = self._classify_symmetry(
            op_dict.get('stable', False),
            op_dict.get('entropy', 0.0)
        )

        # Create structured entry
        op_entry = {
            'id': op_id,
            'symmetry_class': symmetry_class,
            'stability': float(op_dict.get('stability', 0.0)),
            'entropy': float(op_dict.get('entropy', 0.0)),
            'origin_cycle': int(op_dict.get('origin_cycle', 0)),
            'resonance_profile': op_dict.get('resonance_profile', {}),
            'semantic_state': op_dict.get('semantic_state', 'UNKNOWN'),
            'geometry_node': op_dict.get('geometry_node', None),
            'alpha': op_dict.get('alpha'),
            'beta': op_dict.get('beta'),
            'delta_phi': op_dict.get('delta_phi'),
            'psi': op_dict.get('psi'),
            'omega': op_dict.get('omega')
        }

        self.data.append(op_entry)
        return op_entry

    def _classify_symmetry(self, stable: bool, entropy: float) -> str:
        """
        Classify operator symmetry based on stability and entropy.

        Args:
            stable: Stability flag
            entropy: Entropy value

        Returns:
            Symmetry class string
        """
        if stable and entropy < 0.3:
            return "U(1)_COHERENT"  # High coherence, unitary
        elif stable and entropy < 0.6:
            return "SU(2)_STABLE"   # Moderate coherence
        elif not stable and entropy > 0.7:
            return "CHAOTIC"        # High entropy, no symmetry
        else:
            return "MIXED"          # Intermediate

    def save(self):
        """Persist ontology to disk."""
        with open(self.path, 'w') as f:
            json.dump(self.data, f, indent=2)
        print(f"💾 Saved operator ontology: {len(self.data)} operators")

    def query(self, **criteria) -> List[Dict]:
        """
        Query ontology by semantic criteria.

        Supported criteria:
        - symmetry_class: Exact match
        - stability: Maximum value (≤)
        - entropy: Maximum value (≤)
        - origin_cycle: Exact match
        - semantic_state: Exact match

        Args:
            **criteria: Query parameters

        Returns:
            List of matching operator entries
        """
        results = self.data

        for key, value in criteria.items():
            if key in ['stability', 'entropy']:
                # Numeric range query (less than or equal)
                results = [r for r in results if r.get(key, float('inf')) <= value]
            else:
                # Exact match query
                results = [r for r in results if str(r.get(key)) == str(value)]

        return results

    def get_statistics(self) -> dict:
        """
        Compute ontology statistics.

        Returns:
            Dictionary with counts and averages
        """
        if not self.data:
            return {
                'total_operators': 0,
                'symmetry_distribution': {},
                'avg_stability': 0.0,
                'avg_entropy': 0.0
            }

        # Symmetry distribution
        symmetry_counts = {}
        for op in self.data:
            sym = op.get('symmetry_class', 'UNKNOWN')
            symmetry_counts[sym] = symmetry_counts.get(sym, 0) + 1

        # Averages
        avg_stability = sum(op.get('stability', 0) for op in self.data) / len(self.data)
        avg_entropy = sum(op.get('entropy', 0) for op in self.data) / len(self.data)

        return {
            'total_operators': len(self.data),
            'symmetry_distribution': symmetry_counts,
            'avg_stability': round(avg_stability, 3),
            'avg_entropy': round(avg_entropy, 3)
        }

    def export_corpus(self, output_path: Path):
        """
        Export complete operator corpus with statistics.

        Args:
            output_path: Path for export file
        """
        corpus = {
            'metadata': {
                'total_operators': len(self.data),
                'statistics': self.get_statistics()
            },
            'operators': self.data
        }

        with open(output_path, 'w') as f:
            json.dump(corpus, f, indent=2)

        print(f"📦 Exported operator corpus to {output_path}")


def main():
    """Standalone execution for ontology management."""
    lexicon = OperatorLexicon()
    stats = lexicon.get_statistics()

    print("=" * 80)
    print("Operator Ontology Statistics")
    print("=" * 80)
    print(f"Total Operators: {stats['total_operators']}")
    print(f"Average Stability: {stats['avg_stability']}")
    print(f"Average Entropy: {stats['avg_entropy']}")
    print("\nSymmetry Distribution:")
    for sym, count in stats['symmetry_distribution'].items():
        print(f"  {sym}: {count}")
    print("=" * 80)


if __name__ == '__main__':
    main()
