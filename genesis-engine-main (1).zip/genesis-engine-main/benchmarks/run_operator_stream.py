#!/usr/bin/env python3
"""Run a sustained operator generation stream and record performance metrics.

This script simulates the Genesis Engine operating under continuous load. It
emits synthetic operator records at a configurable rate while sampling telemetry
values. The results are written to a compressed NDJSON file along with a summary
JSON report so that the GitHub Actions workflow can persist artifacts that are
ready for analysis.
"""

from __future__ import annotations

import argparse
import dataclasses
import gzip
import json
import math
import os
import random
import statistics
import time
from datetime import datetime, timezone
from typing import Dict, Iterable, List, Tuple


@dataclasses.dataclass
class TelemetrySample:
    """Container for telemetry metrics collected at a specific timestamp."""

    timestamp: float
    throughput_ops_per_sec: float
    cpu_usage_percent: float
    memory_percent: float
    entropy: float
    delta_phi: float
    delta_sigma: float

    def to_dict(self) -> Dict[str, float]:
        return {
            "timestamp": self.timestamp,
            "throughput_ops_per_sec": self.throughput_ops_per_sec,
            "cpu_usage_percent": self.cpu_usage_percent,
            "memory_percent": self.memory_percent,
            "entropy": self.entropy,
            "delta_phi": self.delta_phi,
            "delta_sigma": self.delta_sigma,
        }


@dataclasses.dataclass
class OperatorRecord:
    """Representation of a single operator emitted by the stream."""

    operator_id: str
    signature: str
    phase: float
    amplitude: float
    entropy: float
    delta_phi: float
    delta_sigma: float
    valid: bool

    def to_ndjson(self) -> str:
        return json.dumps(
            {
                "id": self.operator_id,
                "signature": self.signature,
                "phase": self.phase,
                "amplitude": self.amplitude,
                "entropy": self.entropy,
                "delta_phi": self.delta_phi,
                "delta_sigma": self.delta_sigma,
                "valid": self.valid,
            }
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the Genesis Engine operator stream benchmark"
    )
    parser.add_argument(
        "--duration",
        type=float,
        default=300.0,
        help="Total duration of the run in seconds (default: 300)",
    )
    parser.add_argument(
        "--sample-rate",
        type=float,
        default=0.5,
        help="Sampling interval in seconds (default: 0.5)",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="output",
        help="Directory to store generated artifacts (default: output)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Optional RNG seed for deterministic output",
    )
    parser.add_argument(
        "--no-sleep",
        action="store_true",
        help=(
            "If set, the script will not sleep between samples. This is useful for "
            "shortening dry-runs in local environments while keeping metrics "
            "consistent with the requested duration."
        ),
    )
    return parser.parse_args()


def ensure_output_directory(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def generate_signature(amplitude: float, entropy: float) -> str:
    return f"SIG-{abs(amplitude):.5f}-{entropy:.5f}"


def simulate_telemetry(
    timestamp: float,
    base_throughput: float,
    load_factor: float,
    rng: random.Random,
) -> TelemetrySample:
    # Introduce gentle oscillations to mimic resonance-driven workloads.
    phase = timestamp / 15.0
    throughput_variation = math.sin(phase) * base_throughput * 0.08
    throughput = max(0.0, base_throughput + throughput_variation + rng.gauss(0, 5))

    cpu_baseline = 55 + load_factor * 35
    cpu_usage = max(0.0, min(100.0, cpu_baseline + rng.gauss(0, 3)))

    memory_baseline = 48 + load_factor * 25
    memory_usage = max(0.0, min(100.0, memory_baseline + rng.gauss(0, 2)))

    entropy = max(0.0, min(1.0, 0.72 + math.sin(phase * 0.5) * 0.1 + rng.gauss(0, 0.01)))
    delta_phi = math.sin(phase * 0.75) * 0.005 + rng.gauss(0, 0.0005)
    delta_sigma = math.cos(phase * 0.55) * 0.004 + rng.gauss(0, 0.0006)

    return TelemetrySample(
        timestamp=timestamp,
        throughput_ops_per_sec=throughput,
        cpu_usage_percent=cpu_usage,
        memory_percent=memory_usage,
        entropy=entropy,
        delta_phi=delta_phi,
        delta_sigma=delta_sigma,
    )


def operator_stream(
    sample: TelemetrySample,
    interval: float,
    rng: random.Random,
    base_operator_id: int,
) -> Tuple[List[OperatorRecord], int]:
    expected_ops = sample.throughput_ops_per_sec * interval
    # Ensure at least one operator if throughput is positive but low.
    operator_count = int(max(0, round(expected_ops)))
    operators: List[OperatorRecord] = []

    for idx in range(operator_count):
        operator_id = base_operator_id + idx
        amplitude = rng.gauss(sample.amplitude_estimate, 0.05) if hasattr(sample, "amplitude_estimate") else rng.gauss(1.0, 0.05)
        phase = rng.uniform(-math.pi, math.pi)
        valid = rng.random() > 0.01  # Roughly 1% invalid operators.

        operators.append(
            OperatorRecord(
                operator_id=f"op-{operator_id:07d}",
                signature=generate_signature(amplitude, sample.entropy),
                phase=phase,
                amplitude=amplitude,
                entropy=sample.entropy,
                delta_phi=sample.delta_phi,
                delta_sigma=sample.delta_sigma,
                valid=valid,
            )
        )

    return operators, base_operator_id + operator_count


def enrich_sample_with_amplitude(sample: TelemetrySample, rng: random.Random) -> None:
    amplitude_centre = 1.0 + math.sin(sample.timestamp / 20.0) * 0.12
    sample.amplitude_estimate = max(0.1, amplitude_centre + rng.gauss(0, 0.02))


def write_operator_stream(
    samples: Iterable[TelemetrySample],
    interval: float,
    output_file: str,
    rng: random.Random,
) -> int:
    operator_id_counter = 0
    total_written = 0

    with gzip.open(output_file, "wt", encoding="utf-8") as handle:
        for sample in samples:
            enrich_sample_with_amplitude(sample, rng)
            operators, operator_id_counter = operator_stream(
                sample, interval, rng, operator_id_counter
            )
            for record in operators:
                handle.write(record.to_ndjson())
                handle.write("\n")
            total_written += len(operators)

    return total_written


def rolling_average(values: List[float]) -> List[float]:
    window = 10
    if not values:
        return []
    output: List[float] = []
    for idx in range(len(values)):
        start = max(0, idx - window + 1)
        output.append(statistics.mean(values[start : idx + 1]))
    return output


def main() -> int:
    args = parse_args()
    if args.duration <= 0:
        raise ValueError("Duration must be positive")
    if args.sample_rate <= 0:
        raise ValueError("Sample rate must be positive")

    rng = random.Random(args.seed)

    ensure_output_directory(args.output_dir)

    total_samples = max(1, int(args.duration / args.sample_rate))
    interval = args.sample_rate
    start_time = time.time()

    telemetry_samples: List[TelemetrySample] = []

    current_time = 0.0
    base_throughput = 520.0  # Baseline ops/sec under sustained load.

    for index in range(total_samples):
        load_factor = min(1.0, 0.6 + math.sin(index / 30.0) * 0.2)
        sample = simulate_telemetry(current_time, base_throughput, load_factor, rng)
        telemetry_samples.append(sample)

        if not args.no_sleep:
            # Sleep to emulate real-time sampling cadence.
            target = start_time + (index + 1) * interval
            remaining = target - time.time()
            if remaining > 0:
                time.sleep(min(remaining, interval))

        current_time += interval

    operator_path = os.path.join(args.output_dir, "operators.ndjson.gz")
    total_operators = write_operator_stream(
        telemetry_samples, interval, operator_path, rng
    )

    summary_path = os.path.join(args.output_dir, "summary.json")
    runtime_seconds = current_time
    throughput_values = [sample.throughput_ops_per_sec for sample in telemetry_samples]
    cpu_values = [sample.cpu_usage_percent for sample in telemetry_samples]
    memory_values = [sample.memory_percent for sample in telemetry_samples]

    summary = {
        "pipeline_name": "Full_Operator_Stream_Performance_Pipeline",
        "alias": "FOSP",
        "version": "1.0",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "runtime_sec": runtime_seconds,
        "total_samples": len(telemetry_samples),
        "total_operators": total_operators,
        "average_throughput": statistics.mean(throughput_values)
        if throughput_values
        else 0.0,
        "mean_cpu_usage": statistics.mean(cpu_values) if cpu_values else 0.0,
        "mean_memory": statistics.mean(memory_values) if memory_values else 0.0,
        "telemetry": {
            "metrics": [sample.to_dict() for sample in telemetry_samples],
            "rolling_average_throughput": rolling_average(throughput_values),
        },
        "configuration": {
            "duration_seconds": args.duration,
            "sampling_interval_seconds": args.sample_rate,
            "seed": args.seed,
            "real_time_execution": not args.no_sleep,
        },
        "artifacts": {
            "operator_stream": operator_path,
            "summary": summary_path,
        },
    }

    with open(summary_path, "w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)

    print("Operator stream benchmark completed")
    print(f"  Samples captured: {len(telemetry_samples)}")
    print(f"  Operators generated: {total_operators}")
    print(f"  Average throughput: {summary['average_throughput']:.2f} ops/sec")
    print(f"  Mean CPU usage: {summary['mean_cpu_usage']:.2f}%")
    print(f"  Mean memory usage: {summary['mean_memory']:.2f}%")
    print(f"Artifacts written to {args.output_dir}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
