#!/usr/bin/env python3
"""
Genesis Engine Performance Benchmarks
Measures core operation performance: TIC conversion, domain projection,
rule normalization, validation, and throughput.
"""

import time
import json
import argparse
import statistics
from typing import Dict, List, Any
import sys


class BenchmarkRunner:
    """Runs and records performance benchmarks for Genesis Engine operations."""
    
    def __init__(self):
        self.results = {}
        
    def benchmark_tic_conversion(self, iterations: int = 1000) -> Dict[str, Any]:
        """Benchmark Time-Independent Coordinate conversion (O(1) operation)."""
        times = []
        
        for _ in range(iterations):
            start = time.perf_counter()
            # Simulate TIC conversion - simple coordinate transformation
            x, y, z = 1.5, 2.3, 3.7
            # TIC: Convert to normalized spherical coordinates
            r = (x**2 + y**2 + z**2) ** 0.5
            theta = (y / (x**2 + y**2) ** 0.5) if (x**2 + y**2) > 0 else 0
            phi = z / r if r > 0 else 0
            result = (r, theta, phi)
            end = time.perf_counter()
            times.append((end - start) * 1000)  # Convert to ms
        
        avg_time = statistics.mean(times)
        std_dev = statistics.stdev(times) if len(times) > 1 else 0
        
        return {
            "name": "TIC_conversion",
            "complexity": "O(1)",
            "iterations": iterations,
            "avg_time_ms": avg_time,
            "std_dev_ms": std_dev,
            "min_time_ms": min(times),
            "max_time_ms": max(times),
            "median_time_ms": statistics.median(times)
        }
    
    def benchmark_domain_projection(self, n: int = 5, iterations: int = 100) -> Dict[str, Any]:
        """Benchmark domain projection operation (O(n) operation)."""
        times = []
        
        for _ in range(iterations):
            start = time.perf_counter()
            # Simulate domain projection - linear operation over n elements
            domain = list(range(n))
            projected = []
            for elem in domain:
                # Apply projection transformation
                projected_val = elem * 1.618 + 0.5  # Golden ratio projection
                projected.append(projected_val)
            end = time.perf_counter()
            times.append((end - start) * 1000)  # Convert to ms
        
        avg_time = statistics.mean(times)
        std_dev = statistics.stdev(times) if len(times) > 1 else 0
        
        return {
            "name": "Domain_projection",
            "complexity": "O(n)",
            "n": n,
            "iterations": iterations,
            "avg_time_ms": avg_time,
            "std_dev_ms": std_dev,
            "min_time_ms": min(times),
            "max_time_ms": max(times),
            "median_time_ms": statistics.median(times)
        }
    
    def benchmark_rule_normalization(self, k: int = 100, iterations: int = 50) -> Dict[str, Any]:
        """Benchmark rule matrix normalization (O(k) operation)."""
        times = []
        
        for _ in range(iterations):
            start = time.perf_counter()
            # Simulate rule matrix normalization - linear operation over k rules
            rules = [0.5 + i * 0.01 for i in range(k)]
            total = sum(rules)
            normalized = [r / total for r in rules] if total > 0 else rules
            end = time.perf_counter()
            times.append((end - start) * 1000)  # Convert to ms
        
        avg_time = statistics.mean(times)
        std_dev = statistics.stdev(times) if len(times) > 1 else 0
        
        return {
            "name": "Rule_matrix_normalization",
            "complexity": "O(k)",
            "k": k,
            "iterations": iterations,
            "avg_time_ms": avg_time,
            "std_dev_ms": std_dev,
            "min_time_ms": min(times),
            "max_time_ms": max(times),
            "median_time_ms": statistics.median(times)
        }
    
    def benchmark_validation(self, n: int = 5, iterations: int = 50) -> Dict[str, Any]:
        """Benchmark validation operation (O(n^2) operation)."""
        times = []
        
        for _ in range(iterations):
            start = time.perf_counter()
            # Simulate validation - quadratic operation (pairwise comparison)
            elements = list(range(n))
            # Perform pairwise validation checks (O(n²) complexity)
            for i in range(len(elements)):
                for j in range(len(elements)):
                    # Simulate pairwise validation check
                    if i != j:
                        # Calculate delta between elements for validation
                        delta = abs(elements[i] - elements[j])
                        # In real validation, would check if delta exceeds threshold
                        # For benchmark purposes, just perform the computation
            end = time.perf_counter()
            times.append((end - start) * 1000)  # Convert to ms
        
        avg_time = statistics.mean(times)
        std_dev = statistics.stdev(times) if len(times) > 1 else 0
        
        return {
            "name": "Validation",
            "complexity": "O(n^2)",
            "n": n,
            "iterations": iterations,
            "avg_time_ms": avg_time,
            "std_dev_ms": std_dev,
            "min_time_ms": min(times),
            "max_time_ms": max(times),
            "median_time_ms": statistics.median(times)
        }
    
    def benchmark_throughput(self, duration_seconds: float = 1.0) -> Dict[str, Any]:
        """Benchmark operator throughput (ops/sec).

        Simulates a realistic operator processing pipeline including:
        - TIC coordinate conversion with trigonometry
        - Domain projection over larger dataset
        - Complex validation checks
        - JSON serialization/deserialization
        - Result aggregation
        """
        import json
        import math

        start = time.perf_counter()
        end_time = start + duration_seconds
        operations = 0

        # Pre-allocate data structures to simulate operator state
        operator_cache = []
        domain_buffer = list(range(100))  # Increased from 10 to 100

        while time.perf_counter() < end_time:
            # Simulate realistic operator processing pipeline

            # Step 1: TIC coordinate conversion with trigonometry
            x, y, z = 1.5 + operations * 0.001, 2.3, 3.7
            r = (x**2 + y**2 + z**2) ** 0.5
            theta = math.atan2(y, x)  # Proper angle calculation
            phi = math.acos(z / r) if r > 0 else 0

            # Additional spectral calculations
            entropy = -math.log(abs(math.sin(theta) * math.cos(phi)) + 0.1)
            phase = math.sin(operations * 0.1) * math.pi

            # Step 2: Domain projection (simulate O(n) operation over 100 elements)
            projected = []
            for elem in domain_buffer:
                # More complex projection with transcendental functions
                projected_val = math.exp(-elem * 0.01) * math.sin(elem + phi) + entropy
                projected.append(projected_val)

            # Step 3: Validation (more extensive pairwise checks)
            valid = True
            validation_score = 0.0
            for i in range(min(10, len(projected))):  # Increased from 3 to 10
                for j in range(i + 1, min(10, len(projected))):
                    delta = abs(projected[i] - projected[j])
                    validation_score += delta
                    if delta < 0.001:
                        valid = False

            # Step 4: JSON serialization (simulate I/O overhead)
            result = {
                'coords': (r, theta, phi),
                'entropy': entropy,
                'phase': phase,
                'projection': projected[:10],
                'validation_score': validation_score,
                'valid': valid
            }

            # Serialize and deserialize to simulate real data handling
            serialized = json.dumps(result)
            deserialized = json.loads(serialized)

            operator_cache.append(deserialized)

            # Limit cache size to prevent unbounded growth
            if len(operator_cache) > 100:
                # Perform cache cleanup with scoring
                scores = [item.get('validation_score', 0) for item in operator_cache]
                avg_score = sum(scores) / len(scores) if scores else 0
                operator_cache = operator_cache[-50:]

            operations += 1

        elapsed = time.perf_counter() - start
        ops_per_sec = operations / elapsed

        return {
            "name": "Throughput",
            "duration_seconds": elapsed,
            "total_operations": operations,
            "ops_per_sec": ops_per_sec,
            "avg_time_per_op_ms": (elapsed / operations) * 1000 if operations > 0 else 0
        }
    
    def run_all_benchmarks(self) -> Dict[str, Any]:
        """Run all benchmarks and return combined results."""
        print("Running Genesis Engine Performance Benchmarks...")
        print("=" * 60)
        
        # Run TIC conversion benchmark
        print("\n[1/5] TIC Conversion Benchmark...")
        self.results['TIC_conversion'] = self.benchmark_tic_conversion()
        print(f"  Average time: {self.results['TIC_conversion']['avg_time_ms']:.6f} ms")
        
        # Run domain projection benchmark
        print("\n[2/5] Domain Projection Benchmark...")
        self.results['Domain_projection'] = self.benchmark_domain_projection()
        print(f"  Average time: {self.results['Domain_projection']['avg_time_ms']:.6f} ms")
        
        # Run rule normalization benchmark
        print("\n[3/5] Rule Matrix Normalization Benchmark...")
        self.results['Rule_matrix_normalization'] = self.benchmark_rule_normalization()
        print(f"  Average time: {self.results['Rule_matrix_normalization']['avg_time_ms']:.6f} ms")
        
        # Run validation benchmark
        print("\n[4/5] Validation Benchmark...")
        self.results['Validation'] = self.benchmark_validation()
        print(f"  Average time: {self.results['Validation']['avg_time_ms']:.6f} ms")
        
        # Run throughput benchmark
        print("\n[5/5] Throughput Benchmark...")
        self.results['Throughput'] = self.benchmark_throughput()
        print(f"  Throughput: {self.results['Throughput']['ops_per_sec']:.2f} ops/sec")
        
        print("\n" + "=" * 60)
        print("Benchmark suite completed successfully!")
        
        return {
            "timestamp": time.time(),
            "benchmarks": self.results,
            "summary": {
                "total_benchmarks": len(self.results),
                "throughput_ops_per_sec": self.results['Throughput']['ops_per_sec']
            }
        }


def main():
    parser = argparse.ArgumentParser(
        description='Run Genesis Engine performance benchmarks'
    )
    parser.add_argument(
        '--output',
        type=str,
        default='perf_results.json',
        help='Output JSON file for results (default: perf_results.json)'
    )
    
    args = parser.parse_args()
    
    # Run benchmarks
    runner = BenchmarkRunner()
    results = runner.run_all_benchmarks()
    
    # Save results to JSON file
    with open(args.output, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\nResults saved to: {args.output}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
