import React, { useEffect, useState } from 'react';

interface CoherencePattern {
  pattern_id: string;
  name: string;
  description: string;
  confidence: number;
  operator_families: string[];
  temporal_signature: number[];
  stability_correlation: number;
}

interface PatternSpectrum {
  patterns: CoherencePattern[];
  mean_confidence: number;
  dominant_pattern: string | null;
  generated_at: string;
}

interface EmergentTopic {
  topic_id: string;
  label: string;
  keywords: string[];
  correlation_strength: number;
  operator_count: number;
}

interface SemanticMap {
  topics: EmergentTopic[];
  latent_dimensions: [string, number][];
  generated_at: string;
}

interface ReasoningRule {
  rule_id: string;
  axiom: string;
  inference_logic: string;
  bayesian_prior_strength: number;
  applications: number;
  success_rate: number;
  created_at: string;
}

interface SelfReflectionReport {
  timestamp: string;
  cycle: number;
  dominant_pattern: string;
  reasoning_trace: string;
  confidence: number;
  adaptation_suggestion: string;
  meta_insights: string[];
}

interface MetaTelemetry {
  meta_coherence_score: number;
  causal_inference_depth: number;
  semantic_entropy: number;
  self_reflection_density: number;
  timestamp: string;
}

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8080';
const WS_META_URL = process.env.REACT_APP_WS_META_URL || 'ws://localhost:8080/meta';

// Polling intervals (milliseconds)
const PATTERNS_POLL_INTERVAL = 30000;      // 30 seconds
const SEMANTIC_POLL_INTERVAL = 30000;      // 30 seconds
const RULES_POLL_INTERVAL = 30000;         // 30 seconds
const REFLECTIONS_POLL_INTERVAL = 60000;   // 60 seconds

// View types
type MetaView = 'overview' | 'patterns' | 'semantic' | 'reasoning' | 'reflections';

const MetaCognitionDashboard: React.FC = () => {
  const [patterns, setPatterns] = useState<PatternSpectrum | null>(null);
  const [semanticMap, setSemanticMap] = useState<SemanticMap | null>(null);
  const [reasoningRules, setReasoningRules] = useState<ReasoningRule[]>([]);
  const [reflections, setReflections] = useState<SelfReflectionReport[]>([]);
  const [metaTelemetry, setMetaTelemetry] = useState<MetaTelemetry | null>(null);
  const [connected, setConnected] = useState(false);
  const [enabled, setEnabled] = useState(false);
  const [view, setView] = useState<MetaView>('overview');

  // Check if meta-cognition is enabled
  useEffect(() => {
    const checkStatus = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/meta/status`);
        const data = await response.json();
        setEnabled(data.enabled || false);
      } catch (error) {
        console.error('Error checking meta-cognition status:', error);
      }
    };

    checkStatus();
  }, []);

  // Enable meta-cognition
  const enableMetaCognition = async () => {
    try {
      await fetch(`${API_BASE_URL}/meta/enable`, { method: 'POST' });
      setEnabled(true);
    } catch (error) {
      console.error('Error enabling meta-cognition:', error);
    }
  };

  // Fetch pattern spectrum
  useEffect(() => {
    if (!enabled) return;

    const fetchPatterns = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/meta/patterns`);
        const data = await response.json();
        setPatterns(data);
      } catch (error) {
        console.error('Error fetching patterns:', error);
      }
    };

    fetchPatterns();
    const interval = setInterval(fetchPatterns, PATTERNS_POLL_INTERVAL);
    return () => clearInterval(interval);
  }, [enabled]);

  // Fetch semantic map
  useEffect(() => {
    if (!enabled) return;

    const fetchSemanticMap = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/meta/semantic`);
        const data = await response.json();
        setSemanticMap(data);
      } catch (error) {
        console.error('Error fetching semantic map:', error);
      }
    };

    fetchSemanticMap();
    const interval = setInterval(fetchSemanticMap, SEMANTIC_POLL_INTERVAL);
    return () => clearInterval(interval);
  }, [enabled]);

  // Fetch reasoning rules
  useEffect(() => {
    if (!enabled) return;

    const fetchRules = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/meta/reasoning`);
        const data = await response.json();
        setReasoningRules(data);
      } catch (error) {
        console.error('Error fetching reasoning rules:', error);
      }
    };

    fetchRules();
    const interval = setInterval(fetchRules, RULES_POLL_INTERVAL);
    return () => clearInterval(interval);
  }, [enabled]);

  // Fetch self-reflections
  useEffect(() => {
    if (!enabled) return;

    const fetchReflections = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/meta/reflections?limit=10`);
        const data = await response.json();
        setReflections(data);
      } catch (error) {
        console.error('Error fetching reflections:', error);
      }
    };

    fetchReflections();
    const interval = setInterval(fetchReflections, REFLECTIONS_POLL_INTERVAL);
    return () => clearInterval(interval);
  }, [enabled]);

  // WebSocket for meta-cognition telemetry
  useEffect(() => {
    if (!enabled) return;

    const ws = new WebSocket(WS_META_URL);

    ws.onopen = () => {
      console.log('Meta-cognition WebSocket connected');
      setConnected(true);
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'meta_telemetry') {
          setMetaTelemetry({
            meta_coherence_score: data.meta_coherence_score,
            causal_inference_depth: data.causal_inference_depth,
            semantic_entropy: data.semantic_entropy,
            self_reflection_density: data.self_reflection_density,
            timestamp: data.timestamp
          });
        }
      } catch (error) {
        console.error('Error parsing meta telemetry:', error);
      }
    };

    ws.onclose = () => {
      console.log('Meta-cognition WebSocket disconnected');
      setConnected(false);
    };

    ws.onerror = (error) => {
      console.error('Meta WebSocket error:', error);
    };

    return () => {
      ws.close();
    };
  }, [enabled]);

  if (!enabled) {
    return (
      <div className="meta-cognition-disabled">
        <h2>⚡ Metatron Meta-Cognition Layer (Ω.∞)</h2>
        <p>The meta-cognition layer is currently disabled.</p>
        <button onClick={enableMetaCognition} className="enable-button">
          Enable Meta-Cognition
        </button>
      </div>
    );
  }

  return (
    <div className="meta-cognition-dashboard">
      <div className="meta-header">
        <h2>⚡ Metatron Meta-Cognition Layer (Ω.∞)</h2>
        <div className="connection-status">
          <span className={connected ? 'status-indicator connected' : 'status-indicator disconnected'}></span>
          {connected ? 'Stream Active' : 'Stream Inactive'}
        </div>
      </div>

      <nav className="meta-navigation">
        <button
          className={view === 'overview' ? 'active' : ''}
          onClick={() => setView('overview')}
        >
          Overview
        </button>
        <button
          className={view === 'patterns' ? 'active' : ''}
          onClick={() => setView('patterns')}
        >
          Coherence Patterns
        </button>
        <button
          className={view === 'semantic' ? 'active' : ''}
          onClick={() => setView('semantic')}
        >
          Semantic Map
        </button>
        <button
          className={view === 'reasoning' ? 'active' : ''}
          onClick={() => setView('reasoning')}
        >
          Reasoning Rules
        </button>
        <button
          className={view === 'reflections' ? 'active' : ''}
          onClick={() => setView('reflections')}
        >
          Self-Reflections
        </button>
      </nav>

      <div className="meta-content">
        {view === 'overview' && (
          <div className="meta-overview">
            <h3>Meta-Cognition Telemetry</h3>
            {metaTelemetry ? (
              <div className="meta-telemetry-grid">
                <div className="meta-metric">
                  <h4>Meta-Coherence Score</h4>
                  <div className="metric-value">{metaTelemetry.meta_coherence_score.toFixed(3)}</div>
                  <div className="metric-bar">
                    <div
                      className="metric-fill"
                      style={{ width: `${metaTelemetry.meta_coherence_score * 100}%` }}
                    ></div>
                  </div>
                </div>
                <div className="meta-metric">
                  <h4>Causal Inference Depth</h4>
                  <div className="metric-value">{metaTelemetry.causal_inference_depth}</div>
                </div>
                <div className="meta-metric">
                  <h4>Semantic Entropy</h4>
                  <div className="metric-value">{metaTelemetry.semantic_entropy.toFixed(3)}</div>
                </div>
                <div className="meta-metric">
                  <h4>Reflection Density</h4>
                  <div className="metric-value">{metaTelemetry.self_reflection_density.toFixed(5)}</div>
                </div>
              </div>
            ) : (
              <p>Waiting for telemetry data...</p>
            )}

            <h3>Recent Self-Reflection</h3>
            {reflections.length > 0 ? (
              <div className="latest-reflection">
                <div className="reflection-header">
                  <strong>Cycle {reflections[0].cycle}</strong>
                  <span className="reflection-confidence">
                    Confidence: {(reflections[0].confidence * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="reflection-pattern">
                  <strong>Dominant Pattern:</strong> {reflections[0].dominant_pattern}
                </div>
                <div className="reflection-trace">{reflections[0].reasoning_trace}</div>
                <div className="reflection-suggestion">
                  <strong>Adaptation:</strong> {reflections[0].adaptation_suggestion}
                </div>
              </div>
            ) : (
              <p>No reflections generated yet.</p>
            )}
          </div>
        )}

        {view === 'patterns' && (
          <div className="patterns-view">
            <h3>Coherence Pattern Spectrum</h3>
            {patterns ? (
              <>
                <div className="pattern-summary">
                  <div className="summary-item">
                    <strong>Detected Patterns:</strong> {patterns.patterns.length}
                  </div>
                  <div className="summary-item">
                    <strong>Mean Confidence:</strong> {(patterns.mean_confidence * 100).toFixed(1)}%
                  </div>
                  {patterns.dominant_pattern && (
                    <div className="summary-item">
                      <strong>Dominant:</strong> {patterns.dominant_pattern}
                    </div>
                  )}
                </div>
                <div className="patterns-grid">
                  {patterns.patterns.map((pattern) => (
                    <div key={pattern.pattern_id} className="pattern-card">
                      <h4>{pattern.name}</h4>
                      <p className="pattern-description">{pattern.description}</p>
                      <div className="pattern-stats">
                        <div className="stat">
                          <label>Confidence:</label>
                          <span>{(pattern.confidence * 100).toFixed(1)}%</span>
                        </div>
                        <div className="stat">
                          <label>Stability Correlation:</label>
                          <span>{pattern.stability_correlation.toFixed(2)}</span>
                        </div>
                      </div>
                      <div className="pattern-families">
                        {pattern.operator_families.map((family) => (
                          <span key={family} className="family-tag">{family}</span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <p>Loading pattern spectrum...</p>
            )}
          </div>
        )}

        {view === 'semantic' && (
          <div className="semantic-view">
            <h3>Semantic Map</h3>
            {semanticMap ? (
              <>
                <div className="semantic-topics">
                  <h4>Emergent Topics</h4>
                  <div className="topics-grid">
                    {semanticMap.topics.map((topic) => (
                      <div key={topic.topic_id} className="topic-card">
                        <h5>{topic.label}</h5>
                        <div className="topic-stats">
                          <div className="stat">
                            <label>Operators:</label>
                            <span>{topic.operator_count}</span>
                          </div>
                          <div className="stat">
                            <label>Correlation:</label>
                            <span>{(topic.correlation_strength * 100).toFixed(1)}%</span>
                          </div>
                        </div>
                        <div className="topic-keywords">
                          {topic.keywords.map((keyword) => (
                            <span key={keyword} className="keyword">{keyword}</span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="latent-dimensions">
                  <h4>Latent Dimensions</h4>
                  <div className="dimensions-list">
                    {semanticMap.latent_dimensions.map(([name, correlation]) => (
                      <div key={name} className="dimension-item">
                        <span className="dimension-name">{name}</span>
                        <div className="dimension-bar">
                          <div
                            className="dimension-fill"
                            style={{ width: `${correlation * 100}%` }}
                          ></div>
                        </div>
                        <span className="dimension-value">{correlation.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <p>Loading semantic map...</p>
            )}
          </div>
        )}

        {view === 'reasoning' && (
          <div className="reasoning-view">
            <h3>Adaptive Reasoning Rules</h3>
            {reasoningRules.length > 0 ? (
              <div className="rules-list">
                {reasoningRules.map((rule) => (
                  <div key={rule.rule_id} className="rule-card">
                    <h4>{rule.axiom}</h4>
                    <p className="rule-logic">{rule.inference_logic}</p>
                    <div className="rule-stats">
                      <div className="stat">
                        <label>Success Rate:</label>
                        <span>{(rule.success_rate * 100).toFixed(1)}%</span>
                      </div>
                      <div className="stat">
                        <label>Applications:</label>
                        <span>{rule.applications}</span>
                      </div>
                      <div className="stat">
                        <label>Prior Strength:</label>
                        <span>{rule.bayesian_prior_strength.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p>No reasoning rules generated yet.</p>
            )}
          </div>
        )}

        {view === 'reflections' && (
          <div className="reflections-view">
            <h3>Self-Reflection Reports</h3>
            {reflections.length > 0 ? (
              <div className="reflections-list">
                {reflections.map((report, idx) => (
                  <div key={idx} className="reflection-card">
                    <div className="reflection-header">
                      <strong>Cycle {report.cycle}</strong>
                      <span className="reflection-time">
                        {new Date(report.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <div className="reflection-body">
                      <div className="reflection-section">
                        <label>Dominant Pattern:</label>
                        <span>{report.dominant_pattern}</span>
                      </div>
                      <div className="reflection-section">
                        <label>Reasoning Trace:</label>
                        <p>{report.reasoning_trace}</p>
                      </div>
                      <div className="reflection-section">
                        <label>Confidence:</label>
                        <span>{(report.confidence * 100).toFixed(1)}%</span>
                      </div>
                      <div className="reflection-section">
                        <label>Adaptation Suggestion:</label>
                        <p className="adaptation">{report.adaptation_suggestion}</p>
                      </div>
                      {report.meta_insights.length > 0 && (
                        <div className="reflection-section">
                          <label>Meta-Insights:</label>
                          <ul>
                            {report.meta_insights.map((insight, i) => (
                              <li key={i}>{insight}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p>No self-reflections available yet.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default MetaCognitionDashboard;
