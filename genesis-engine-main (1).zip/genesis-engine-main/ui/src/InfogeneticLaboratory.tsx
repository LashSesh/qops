import React, { useEffect, useState } from 'react';
import './InfogeneticLaboratory.css';

// ============================================================================
// Type Definitions
// ============================================================================

interface SpectralSignature {
  psi: number;
  rho: number;
  omega: number;
  chi: number;
  tau: number;
}

interface TargetSignature {
  signature: SpectralSignature;
  entropy_minimum: number;
  domain: string;
}

interface IRGStatus {
  current_phase: string;
  iteration: number;
  delta_sigma: number;
  coherence_ratio: number;
  is_valid: boolean;
  has_converged: boolean;
}

interface IRGTelemetry {
  timestamp: number;
  spectral_entropy: number;
  operator_throughput: number;
  coherence_ratio: number;
  semantic_integrity: number;
  delta_phi_drift: number;
  entropy_growth: number;
}

interface IRGCoreManifest {
  id: string;
  signature: SpectralSignature;
  target: TargetSignature;
  status: IRGStatus;
  system_time: number;
  created_at: string;
  last_updated: string;
}

interface MutationEvent {
  event_id: string;
  core_id: string;
  mutation_type: string;
  before_signature: SpectralSignature;
  after_signature: SpectralSignature;
  stability_check: boolean;
  timestamp: string;
}

interface LearningHistoryEntry {
  core_id: string;
  iteration: number;
  phase: string;
  delta_sigma: number;
  current_signature: SpectralSignature;
  timestamp: string;
}

// ============================================================================
// Configuration
// ============================================================================

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8080';
const WS_IRG_URL = process.env.REACT_APP_WS_IRG_URL || 'ws://localhost:8080/ws/irg';

// Polling intervals (milliseconds)
const CORES_POLL_INTERVAL = 5000;      // 5 seconds
const MUTATIONS_POLL_INTERVAL = 5000;  // 5 seconds
const TELEMETRY_POLL_INTERVAL = 1000;  // 1 second

// View types
type LaboratoryView = 'overview' | 'resonance_field' | 'mutations' | 'signatures' | 'lineage';

// ============================================================================
// Main Component
// ============================================================================

const InfogeneticLaboratory: React.FC = () => {
  const [cores, setCores] = useState<IRGCoreManifest[]>([]);
  const [selectedCore, setSelectedCore] = useState<IRGCoreManifest | null>(null);
  const [mutations, setMutations] = useState<MutationEvent[]>([]);
  const [learningHistory, setLearningHistory] = useState<LearningHistoryEntry[]>([]);
  const [telemetry, setTelemetry] = useState<IRGTelemetry | null>(null);
  const [connected, setConnected] = useState(false);
  const [enabled, setEnabled] = useState(false);
  const [view, setView] = useState<LaboratoryView>('overview');
  const [ws, setWs] = useState<WebSocket | null>(null);

  // ============================================================================
  // WebSocket Connection
  // ============================================================================

  useEffect(() => {
    if (!enabled) return;

    const websocket = new WebSocket(WS_IRG_URL);

    websocket.onopen = () => {
      console.log('IRG WebSocket connected');
      setConnected(true);
    };

    websocket.onmessage = (event) => {
      const data = JSON.parse(event.data);

      if (data.type === 'irg_telemetry') {
        setTelemetry(data);
      } else if (data.type === 'irg_status') {
        // Update core status in real-time
        setCores(prevCores =>
          prevCores.map(core =>
            core.id === data.core_id ? { ...core, status: data.status } : core
          )
        );
      } else if (data.type === 'irg_mutation') {
        // Refresh mutations list
        fetchMutations();
      }
    };

    websocket.onerror = (error) => {
      console.error('IRG WebSocket error:', error);
    };

    websocket.onclose = () => {
      console.log('IRG WebSocket disconnected');
      setConnected(false);
    };

    setWs(websocket);

    return () => {
      websocket.close();
    };
  }, [enabled]);

  // ============================================================================
  // API Calls
  // ============================================================================

  // Check if IRG Core is enabled
  useEffect(() => {
    const checkStatus = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/irg/status`);
        const data = await response.json();
        setEnabled(data.enabled || false);
      } catch (error) {
        console.error('Error checking IRG status:', error);
      }
    };

    checkStatus();
  }, []);

  // Enable IRG Core
  const enableIRGCore = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/irg/enable`, {
        method: 'POST',
      });
      const data = await response.json();
      if (data.status === 'enabled') {
        setEnabled(true);
      }
    } catch (error) {
      console.error('Error enabling IRG Core:', error);
    }
  };

  // Fetch cores
  const fetchCores = async () => {
    if (!enabled) return;

    try {
      const response = await fetch(`${API_BASE_URL}/irg/core`);
      const data = await response.json();
      setCores(data);
    } catch (error) {
      console.error('Error fetching cores:', error);
    }
  };

  // Fetch mutations
  const fetchMutations = async () => {
    if (!enabled) return;

    try {
      const response = await fetch(`${API_BASE_URL}/irg/mutations?limit=50`);
      const data = await response.json();
      setMutations(data);
    } catch (error) {
      console.error('Error fetching mutations:', error);
    }
  };

  // Fetch learning history
  const fetchLearningHistory = async (coreId: string) => {
    if (!enabled) return;

    try {
      const response = await fetch(`${API_BASE_URL}/irg/core/${coreId}/history?limit=100`);
      const data = await response.json();
      setLearningHistory(data);
    } catch (error) {
      console.error('Error fetching learning history:', error);
    }
  };

  // Evolve core
  const evolveCore = async (coreId: string) => {
    try {
      const response = await fetch(`${API_BASE_URL}/irg/core/${coreId}/evolve`, {
        method: 'POST',
      });
      const data = await response.json();
      console.log('Evolution step:', data);
      fetchCores();
      if (selectedCore?.id === coreId) {
        fetchLearningHistory(coreId);
      }
    } catch (error) {
      console.error('Error evolving core:', error);
    }
  };

  // ============================================================================
  // Polling
  // ============================================================================

  useEffect(() => {
    if (!enabled) return;

    fetchCores();
    const interval = setInterval(fetchCores, CORES_POLL_INTERVAL);
    return () => clearInterval(interval);
  }, [enabled]);

  useEffect(() => {
    if (!enabled) return;

    fetchMutations();
    const interval = setInterval(fetchMutations, MUTATIONS_POLL_INTERVAL);
    return () => clearInterval(interval);
  }, [enabled]);

  // ============================================================================
  // Utility Functions
  // ============================================================================

  const getPhaseColor = (phase: string): string => {
    switch (phase) {
      case 'Initialization': return '#3b82f6';
      case 'Observation': return '#10b981';
      case 'Mutation': return '#f59e0b';
      case 'Calibration': return '#8b5cf6';
      case 'Integration': return '#ec4899';
      default: return '#6b7280';
    }
  };

  const formatSignature = (sig: SpectralSignature): string => {
    return `ψ:${sig.psi.toFixed(3)} ρ:${sig.rho.toFixed(3)} ω:${sig.omega.toFixed(3)} χ:${sig.chi.toFixed(3)} τ:${sig.tau.toFixed(3)}`;
  };

  // ============================================================================
  // Render Functions
  // ============================================================================

  const renderOverview = () => (
    <div className="overview-panel">
      <h2>Infogenetic Resonance Overview</h2>

      {/* System Status */}
      <div className="status-section">
        <h3>System Status</h3>
        <div className="status-grid">
          <div className="status-card">
            <span className="label">Active Cores</span>
            <span className="value">{cores.length}</span>
          </div>
          <div className="status-card">
            <span className="label">Mutations</span>
            <span className="value">{mutations.length}</span>
          </div>
          <div className="status-card">
            <span className="label">WebSocket</span>
            <span className={`status-indicator ${connected ? 'connected' : 'disconnected'}`}>
              {connected ? 'Connected' : 'Disconnected'}
            </span>
          </div>
        </div>
      </div>

      {/* Latest Telemetry */}
      {telemetry && (
        <div className="telemetry-section">
          <h3>Latest Telemetry</h3>
          <div className="telemetry-grid">
            <div className="telemetry-item">
              <span className="label">Spectral Entropy:</span>
              <span className="value">{telemetry.spectral_entropy.toExponential(3)}</span>
            </div>
            <div className="telemetry-item">
              <span className="label">Coherence Ratio:</span>
              <span className="value">{(telemetry.coherence_ratio * 100).toFixed(1)}%</span>
            </div>
            <div className="telemetry-item">
              <span className="label">Semantic Integrity:</span>
              <span className="value">{(telemetry.semantic_integrity * 100).toFixed(1)}%</span>
            </div>
            <div className="telemetry-item">
              <span className="label">ΔΦ Drift:</span>
              <span className="value">{telemetry.delta_phi_drift.toFixed(4)}</span>
            </div>
            <div className="telemetry-item">
              <span className="label">Entropy Growth:</span>
              <span className="value">{telemetry.entropy_growth.toExponential(3)}</span>
            </div>
            <div className="telemetry-item">
              <span className="label">Throughput:</span>
              <span className="value">{telemetry.operator_throughput} ops/sec</span>
            </div>
          </div>
        </div>
      )}

      {/* Core List */}
      <div className="cores-section">
        <h3>IRG Core Instances</h3>
        {cores.length === 0 ? (
          <p className="empty-state">No IRG cores active</p>
        ) : (
          <div className="cores-list">
            {cores.map(core => (
              <div
                key={core.id}
                className={`core-card ${selectedCore?.id === core.id ? 'selected' : ''}`}
                onClick={() => {
                  setSelectedCore(core);
                  fetchLearningHistory(core.id);
                }}
              >
                <div className="core-header">
                  <span className="core-id">{core.id}</span>
                  <span
                    className="phase-badge"
                    style={{ backgroundColor: getPhaseColor(core.status.current_phase) }}
                  >
                    {core.status.current_phase}
                  </span>
                </div>
                <div className="core-details">
                  <div className="detail-row">
                    <span>Domain:</span>
                    <span>{core.target.domain}</span>
                  </div>
                  <div className="detail-row">
                    <span>Iteration:</span>
                    <span>{core.status.iteration}</span>
                  </div>
                  <div className="detail-row">
                    <span>ΔΣ:</span>
                    <span>{core.status.delta_sigma.toFixed(6)}</span>
                  </div>
                  <div className="detail-row">
                    <span>Coherence:</span>
                    <span className={core.status.coherence_ratio >= 0.51 ? 'valid' : 'invalid'}>
                      {(core.status.coherence_ratio * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="detail-row">
                    <span>Status:</span>
                    <span className={core.status.is_valid ? 'valid' : 'invalid'}>
                      {core.status.is_valid ? 'Valid' : 'Invalid'}
                    </span>
                  </div>
                  <div className="detail-row">
                    <span>Converged:</span>
                    <span>{core.status.has_converged ? 'Yes' : 'No'}</span>
                  </div>
                </div>
                <button
                  className="evolve-button"
                  onClick={(e) => {
                    e.stopPropagation();
                    evolveCore(core.id);
                  }}
                  disabled={core.status.has_converged}
                >
                  Evolve Step
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  const renderResonanceField = () => (
    <div className="resonance-panel">
      <h2>Resonance Field Map</h2>
      {selectedCore ? (
        <div className="field-visualization">
          <h3>Core: {selectedCore.id}</h3>
          <div className="signature-comparison">
            <div className="signature-box">
              <h4>Current Signature</h4>
              <div className="signature-components">
                <div className="component">
                  <span className="label">ψ (Psi):</span>
                  <div className="bar-container">
                    <div className="bar" style={{ width: `${selectedCore.signature.psi * 100}%` }}></div>
                  </div>
                  <span className="value">{selectedCore.signature.psi.toFixed(3)}</span>
                </div>
                <div className="component">
                  <span className="label">ρ (Rho):</span>
                  <div className="bar-container">
                    <div className="bar" style={{ width: `${selectedCore.signature.rho * 100}%` }}></div>
                  </div>
                  <span className="value">{selectedCore.signature.rho.toFixed(3)}</span>
                </div>
                <div className="component">
                  <span className="label">ω (Omega):</span>
                  <div className="bar-container">
                    <div className="bar" style={{ width: `${selectedCore.signature.omega * 100}%` }}></div>
                  </div>
                  <span className="value">{selectedCore.signature.omega.toFixed(3)}</span>
                </div>
                <div className="component">
                  <span className="label">χ (Chi):</span>
                  <div className="bar-container">
                    <div className="bar" style={{ width: `${selectedCore.signature.chi * 100}%` }}></div>
                  </div>
                  <span className="value">{selectedCore.signature.chi.toFixed(3)}</span>
                </div>
                <div className="component">
                  <span className="label">τ (Tau):</span>
                  <div className="bar-container">
                    <div className="bar" style={{ width: `${selectedCore.signature.tau * 100}%` }}></div>
                  </div>
                  <span className="value">{selectedCore.signature.tau.toFixed(3)}</span>
                </div>
              </div>
            </div>
            <div className="signature-box">
              <h4>Target Signature</h4>
              <div className="signature-components">
                <div className="component">
                  <span className="label">ψ (Psi):</span>
                  <div className="bar-container">
                    <div className="bar target" style={{ width: `${selectedCore.target.signature.psi * 100}%` }}></div>
                  </div>
                  <span className="value">{selectedCore.target.signature.psi.toFixed(3)}</span>
                </div>
                <div className="component">
                  <span className="label">ρ (Rho):</span>
                  <div className="bar-container">
                    <div className="bar target" style={{ width: `${selectedCore.target.signature.rho * 100}%` }}></div>
                  </div>
                  <span className="value">{selectedCore.target.signature.rho.toFixed(3)}</span>
                </div>
                <div className="component">
                  <span className="label">ω (Omega):</span>
                  <div className="bar-container">
                    <div className="bar target" style={{ width: `${selectedCore.target.signature.omega * 100}%` }}></div>
                  </div>
                  <span className="value">{selectedCore.target.signature.omega.toFixed(3)}</span>
                </div>
                <div className="component">
                  <span className="label">χ (Chi):</span>
                  <div className="bar-container">
                    <div className="bar target" style={{ width: `${selectedCore.target.signature.chi * 100}%` }}></div>
                  </div>
                  <span className="value">{selectedCore.target.signature.chi.toFixed(3)}</span>
                </div>
                <div className="component">
                  <span className="label">τ (Tau):</span>
                  <div className="bar-container">
                    <div className="bar target" style={{ width: `${selectedCore.target.signature.tau * 100}%` }}></div>
                  </div>
                  <span className="value">{selectedCore.target.signature.tau.toFixed(3)}</span>
                </div>
              </div>
            </div>
          </div>

          {learningHistory.length > 0 && (
            <div className="convergence-chart">
              <h4>Convergence History (ΔΣ over iterations)</h4>
              <div className="chart">
                {learningHistory.map((entry, idx) => (
                  <div
                    key={idx}
                    className="chart-bar"
                    style={{
                      height: `${Math.min(entry.delta_sigma * 100, 100)}%`,
                      backgroundColor: getPhaseColor(entry.phase)
                    }}
                    title={`Iteration ${entry.iteration}: ΔΣ = ${entry.delta_sigma.toFixed(6)}`}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <p className="empty-state">Select a core to view resonance field</p>
      )}
    </div>
  );

  const renderMutations = () => (
    <div className="mutations-panel">
      <h2>Mutation Events</h2>
      {mutations.length === 0 ? (
        <p className="empty-state">No mutations recorded</p>
      ) : (
        <div className="mutations-list">
          {mutations.slice().reverse().map(mutation => (
            <div key={mutation.event_id} className="mutation-card">
              <div className="mutation-header">
                <span className="mutation-type">{mutation.mutation_type}</span>
                <span className={`stability-badge ${mutation.stability_check ? 'stable' : 'unstable'}`}>
                  {mutation.stability_check ? 'Stable' : 'Unstable'}
                </span>
              </div>
              <div className="mutation-details">
                <div className="detail-row">
                  <span>Core ID:</span>
                  <span>{mutation.core_id}</span>
                </div>
                <div className="detail-row">
                  <span>Event ID:</span>
                  <span>{mutation.event_id}</span>
                </div>
                <div className="detail-row">
                  <span>Before:</span>
                  <span className="signature-text">{formatSignature(mutation.before_signature)}</span>
                </div>
                <div className="detail-row">
                  <span>After:</span>
                  <span className="signature-text">{formatSignature(mutation.after_signature)}</span>
                </div>
                <div className="detail-row">
                  <span>Timestamp:</span>
                  <span>{new Date(mutation.timestamp).toLocaleString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const renderSignatures = () => (
    <div className="signatures-panel">
      <h2>Spectral Signatures</h2>
      {cores.length === 0 ? (
        <p className="empty-state">No signatures available</p>
      ) : (
        <div className="signatures-grid">
          {cores.map(core => (
            <div key={core.id} className="signature-card">
              <h4>{core.id}</h4>
              <div className="signature-radar">
                {/* Simplified radar chart representation */}
                <div className="radar-labels">
                  <span>ψ: {core.signature.psi.toFixed(2)}</span>
                  <span>ρ: {core.signature.rho.toFixed(2)}</span>
                  <span>ω: {core.signature.omega.toFixed(2)}</span>
                  <span>χ: {core.signature.chi.toFixed(2)}</span>
                  <span>τ: {core.signature.tau.toFixed(2)}</span>
                </div>
              </div>
              <div className="signature-info">
                <span>Domain: {core.target.domain}</span>
                <span>Entropy Min: {core.target.entropy_minimum.toExponential(2)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const renderLineage = () => (
    <div className="lineage-panel">
      <h2>Operator Lineage Tree</h2>
      {selectedCore && learningHistory.length > 0 ? (
        <div className="lineage-tree">
          <h3>Evolution Timeline for {selectedCore.id}</h3>
          <div className="timeline">
            {learningHistory.map((entry, idx) => (
              <div key={idx} className="timeline-entry">
                <div className="timeline-marker" style={{ backgroundColor: getPhaseColor(entry.phase) }}></div>
                <div className="timeline-content">
                  <div className="timeline-header">
                    <span className="iteration">Iteration {entry.iteration}</span>
                    <span className="phase">{entry.phase}</span>
                  </div>
                  <div className="timeline-details">
                    <span>ΔΣ: {entry.delta_sigma.toFixed(6)}</span>
                    <span className="timestamp">{new Date(entry.timestamp).toLocaleTimeString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <p className="empty-state">Select a core to view lineage</p>
      )}
    </div>
  );

  // ============================================================================
  // Main Render
  // ============================================================================

  if (!enabled) {
    return (
      <div className="infogenetic-laboratory disabled">
        <div className="enable-prompt">
          <h1>Infogenetic Resonant Genesis Laboratory</h1>
          <p>The IRG Core system is currently disabled.</p>
          <button className="enable-button" onClick={enableIRGCore}>
            Enable IRG Core
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="infogenetic-laboratory">
      <header className="laboratory-header">
        <h1>🧬 Infogenetic Resonant Genesis Laboratory</h1>
        <div className="connection-status">
          <span className={`status-dot ${connected ? 'connected' : 'disconnected'}`}></span>
          <span>{connected ? 'WebSocket Connected' : 'WebSocket Disconnected'}</span>
        </div>
      </header>

      <nav className="laboratory-nav">
        <button
          className={view === 'overview' ? 'active' : ''}
          onClick={() => setView('overview')}
        >
          Overview
        </button>
        <button
          className={view === 'resonance_field' ? 'active' : ''}
          onClick={() => setView('resonance_field')}
        >
          Resonance Field Map
        </button>
        <button
          className={view === 'mutations' ? 'active' : ''}
          onClick={() => setView('mutations')}
        >
          Mutation Console
        </button>
        <button
          className={view === 'signatures' ? 'active' : ''}
          onClick={() => setView('signatures')}
        >
          Spectral Signatures
        </button>
        <button
          className={view === 'lineage' ? 'active' : ''}
          onClick={() => setView('lineage')}
        >
          Lineage Tree
        </button>
      </nav>

      <main className="laboratory-content">
        {view === 'overview' && renderOverview()}
        {view === 'resonance_field' && renderResonanceField()}
        {view === 'mutations' && renderMutations()}
        {view === 'signatures' && renderSignatures()}
        {view === 'lineage' && renderLineage()}
      </main>
    </div>
  );
};

export default InfogeneticLaboratory;
