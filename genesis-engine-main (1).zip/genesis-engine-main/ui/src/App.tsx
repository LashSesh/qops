import React, { useEffect, useState } from 'react';
import './App.css';
import CubechainNavigator from './CubechainNavigator';
import MetaCognitionDashboard from './MetaCognitionDashboard';

interface TelemetryData {
  type: string;
  cycle?: number;
  delta_h?: number;
  delta_s?: number;
  psi_variance?: number;
  timestamp?: string;
}

interface OperatorSummary {
  id: string;
  name?: string;
  stability: number;
  entropy_gradient: number;
  symmetry_class: string;
  mandorla_certified: boolean;
  created_at: string;
}

interface Analytics {
  total_operators: number;
  average_entropy: number;
  mean_stability: number;
  dominant_symmetry_class: string;
}

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8080';
const WS_TELEMETRY_URL = process.env.REACT_APP_WS_TELEMETRY_URL || 'ws://localhost:8080/telemetry';

function App() {
  const [operators, setOperators] = useState<OperatorSummary[]>([]);
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [telemetry, setTelemetry] = useState<TelemetryData | null>(null);
  const [connected, setConnected] = useState(false);
  const [view, setView] = useState('operators');

  // Fetch operators
  useEffect(() => {
    const fetchOperators = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/operator?sort=stability`);
        const data = await response.json();
        setOperators(data);
      } catch (error) {
        console.error('Error fetching operators:', error);
      }
    };

    fetchOperators();
    const interval = setInterval(fetchOperators, 5000);
    return () => clearInterval(interval);
  }, []);

  // Fetch analytics
  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/analytics`);
        const data = await response.json();
        setAnalytics(data);
      } catch (error) {
        console.error('Error fetching analytics:', error);
      }
    };

    fetchAnalytics();
    const interval = setInterval(fetchAnalytics, 10000);
    return () => clearInterval(interval);
  }, []);

  // WebSocket telemetry
  useEffect(() => {
    const ws = new WebSocket(WS_TELEMETRY_URL);

    ws.onopen = () => {
      console.log('Telemetry WebSocket connected');
      setConnected(true);
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        setTelemetry(data);
      } catch (error) {
        console.error('Error parsing telemetry:', error);
      }
    };

    ws.onclose = () => {
      console.log('Telemetry WebSocket disconnected');
      setConnected(false);
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    return () => {
      ws.close();
    };
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <h1>⬡ Metatron Operator Cosmos Dashboard</h1>
        <div className="connection-status">
          <span className={connected ? 'status-indicator connected' : 'status-indicator disconnected'}></span>
          {connected ? 'Connected' : 'Disconnected'}
        </div>
      </header>

      <nav className="navigation">
        <button 
          className={view === 'operators' ? 'active' : ''} 
          onClick={() => setView('operators')}
        >
          Operator Lexicon
        </button>
        <button 
          className={view === 'analytics' ? 'active' : ''} 
          onClick={() => setView('analytics')}
        >
          Analytics
        </button>
        <button 
          className={view === 'cubechain' ? 'active' : ''} 
          onClick={() => setView('cubechain')}
        >
          Cubechain Navigator
        </button>
        <button 
          className={view === 'meta' ? 'active' : ''} 
          onClick={() => setView('meta')}
        >
          Meta-Cognition
        </button>
        <button 
          className={view === 'telemetry' ? 'active' : ''} 
          onClick={() => setView('telemetry')}
        >
          Telemetry
        </button>
      </nav>

      <main className="main-content">
        {view === 'operators' && (
          <div className="operators-view">
            <h2>Operator Lexicon ({operators.length})</h2>
            <div className="operators-grid">
              {operators.map((op) => (
                <div key={op.id} className="operator-card">
                  <h3>{op.name || op.id.substring(0, 8)}</h3>
                  <div className="operator-stats">
                    <div className="stat">
                      <label>Stability:</label>
                      <span className="stability-value">{op.stability.toFixed(3)}</span>
                    </div>
                    <div className="stat">
                      <label>Entropy:</label>
                      <span>{op.entropy_gradient.toFixed(5)}</span>
                    </div>
                    <div className="stat">
                      <label>Symmetry:</label>
                      <span>{op.symmetry_class}</span>
                    </div>
                    <div className="stat">
                      <label>Mandorla:</label>
                      <span className={op.mandorla_certified ? 'certified' : 'uncertified'}>
                        {op.mandorla_certified ? '✓ Certified' : '✗ Uncertified'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
              {operators.length === 0 && (
                <div className="empty-state">
                  <p>No operators in lexicon yet.</p>
                  <p>Run the genesis routine to seed the system.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {view === 'analytics' && analytics && (
          <div className="analytics-view">
            <h2>System Analytics</h2>
            <div className="analytics-grid">
              <div className="analytics-card">
                <h3>Total Operators</h3>
                <div className="big-number">{analytics.total_operators}</div>
              </div>
              <div className="analytics-card">
                <h3>Mean Stability</h3>
                <div className="big-number">{analytics.mean_stability.toFixed(3)}</div>
              </div>
              <div className="analytics-card">
                <h3>Average Entropy</h3>
                <div className="big-number">{analytics.average_entropy.toFixed(5)}</div>
              </div>
              <div className="analytics-card">
                <h3>Dominant Symmetry</h3>
                <div className="big-number">{analytics.dominant_symmetry_class}</div>
              </div>
            </div>
          </div>
        )}

        {view === 'cubechain' && (
          <CubechainNavigator />
        )}

        {view === 'meta' && (
          <MetaCognitionDashboard />
        )}

        {view === 'telemetry' && (
          <div className="telemetry-view">
            <h2>Real-Time Telemetry</h2>
            {telemetry ? (
              <div className="telemetry-data">
                <div className="telemetry-card">
                  <h3>Energy Drift (ΔH)</h3>
                  <div className="telemetry-value">
                    {telemetry.delta_h?.toExponential(2) || 'N/A'}
                  </div>
                </div>
                <div className="telemetry-card">
                  <h3>Entropy Gradient (ΔS)</h3>
                  <div className="telemetry-value">
                    {telemetry.delta_s?.toExponential(2) || 'N/A'}
                  </div>
                </div>
                <div className="telemetry-card">
                  <h3>ψρω Variance</h3>
                  <div className="telemetry-value">
                    {telemetry.psi_variance?.toFixed(4) || 'N/A'}
                  </div>
                </div>
                <div className="telemetry-card">
                  <h3>Cycle</h3>
                  <div className="telemetry-value">
                    {telemetry.cycle || 0}
                  </div>
                </div>
              </div>
            ) : (
              <div className="empty-state">
                <p>Waiting for telemetry data...</p>
              </div>
            )}
          </div>
        )}
      </main>

      <footer className="App-footer">
        <p>Metatron Operator Genesis Engine - Cosmos Stack v1.0</p>
      </footer>
    </div>
  );
}

export default App;
