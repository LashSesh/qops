import React, { useEffect, useState } from 'react';
import './CubechainNavigator.css';

interface Cube {
  id: string;
  signature: {
    psi: number;
    rho: number;
    omega: number;
    chi: number;
    eta: number;
  };
  operator_basis: {
    DK?: number;
    WT?: number;
    PI?: number;
    SW?: number;
  };
  beta_symmetry: number;
  s_field: number;
  proof_score: number;
  antipode_id?: string;
  generation: number;
  parents: string[];
  created_at: string;
}

interface Transition {
  id: string;
  from_cube: string;
  to_cube: string;
  operator: 'DK' | 'WT' | 'PI' | 'SW';
  resonance_amplitude: number;
  phase_delta: number;
  energy_delta: number;
  entropy_delta: number;
  validated: boolean;
}

interface CubechainStats {
  total_cubes: number;
  validated_transitions: number;
  mean_entropy: number;
  stability_index: number;
  metatron_nodes: number;
}

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:8080';

const OPERATOR_COLORS = {
  DK: '#ff4444',  // Red - Double-Kick
  WT: '#44ff44',  // Green - Wave-Transform
  PI: '#4444ff',  // Blue - Phase-Integrator
  SW: '#ffff44',  // Yellow - Swap-Operator
};

const CubechainNavigator: React.FC = () => {
  const [enabled, setEnabled] = useState(false);
  const [stats, setStats] = useState<CubechainStats | null>(null);
  const [cubes, setCubes] = useState<Cube[]>([]);
  const [selectedCube, setSelectedCube] = useState<Cube | null>(null);
  const [transitions, setTransitions] = useState<Transition[]>([]);
  const [showAntipodes, setShowAntipodes] = useState(true);
  const [colorMode, setColorMode] = useState<'operator' | 'resonance' | 'generation'>('operator');

  // Check if cubechain is enabled
  useEffect(() => {
    const checkStatus = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/cubechain/status`);
        const data = await response.json();
        setEnabled(data.enabled || false);
      } catch (error) {
        console.error('Error checking cubechain status:', error);
        setEnabled(false);
      }
    };

    checkStatus();
    const interval = setInterval(checkStatus, 5000);
    return () => clearInterval(interval);
  }, []);

  // Fetch cubechain stats
  useEffect(() => {
    if (!enabled) return;

    const fetchStats = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/cubechain/stats`);
        const data = await response.json();
        setStats(data);
      } catch (error) {
        console.error('Error fetching cubechain stats:', error);
      }
    };

    fetchStats();
    const interval = setInterval(fetchStats, 3000);
    return () => clearInterval(interval);
  }, [enabled]);

  // Fetch cubechain export for visualization
  useEffect(() => {
    if (!enabled) return;

    const fetchCubechain = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/cubechain/export`);
        const data = await response.json();
        
        // Convert cubes object to array
        const cubesArray = Object.values(data.cubes || {}) as Cube[];
        setCubes(cubesArray);

        // Convert transitions object to array
        const transitionsArray = Object.values(data.transitions || {}) as Transition[];
        setTransitions(transitionsArray);
      } catch (error) {
        console.error('Error fetching cubechain:', error);
      }
    };

    fetchCubechain();
    const interval = setInterval(fetchCubechain, 5000);
    return () => clearInterval(interval);
  }, [enabled]);

  const enableCubechain = async () => {
    try {
      await fetch(`${API_BASE_URL}/cubechain/enable`, { method: 'POST' });
      setEnabled(true);
    } catch (error) {
      console.error('Error enabling cubechain:', error);
    }
  };

  const getCubeColor = (cube: Cube): string => {
    switch (colorMode) {
      case 'operator':
        // Dominant operator determines color
        const basis = cube.operator_basis;
        const dominant = Object.entries(basis).reduce((max, [op, weight]) => 
          weight > max.weight ? { op: op as keyof typeof OPERATOR_COLORS, weight } : max,
          { op: 'DK' as keyof typeof OPERATOR_COLORS, weight: 0 }
        );
        return OPERATOR_COLORS[dominant.op];
      
      case 'resonance':
        // Color based on proof score (0-1 range)
        const hue = cube.proof_score * 120; // 0 = red, 120 = green
        return `hsl(${hue}, 70%, 50%)`;
      
      case 'generation':
        // Color based on generation
        const genHue = (cube.generation * 30) % 360;
        return `hsl(${genHue}, 60%, 50%)`;
      
      default:
        return '#888';
    }
  };

  const getBrightness = (cube: Cube): number => {
    // Brightness based on resonance amplitude
    return 0.3 + cube.proof_score * 0.7;
  };

  if (!enabled) {
    return (
      <div className="cubechain-navigator">
        <div className="cubechain-disabled">
          <h2>Cubechain Navigator</h2>
          <p>Cubechain mode is not enabled.</p>
          <button onClick={enableCubechain} className="enable-button">
            Enable Cubechain
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="cubechain-navigator">
      <div className="cubechain-header">
        <h2>⬢ Cubechain Navigator - 5D Hypergraph Viewer</h2>
        <div className="cubechain-controls">
          <label>
            <input
              type="checkbox"
              checked={showAntipodes}
              onChange={(e) => setShowAntipodes(e.target.checked)}
            />
            Show Antipodes
          </label>
          <select value={colorMode} onChange={(e) => setColorMode(e.target.value as any)}>
            <option value="operator">Color by Operator</option>
            <option value="resonance">Color by Resonance</option>
            <option value="generation">Color by Generation</option>
          </select>
        </div>
      </div>

      {stats && (
        <div className="cubechain-stats">
          <div className="stat-box">
            <label>Total Cubes</label>
            <div className="stat-value">{stats.total_cubes}</div>
          </div>
          <div className="stat-box">
            <label>Validated Transitions</label>
            <div className="stat-value">{stats.validated_transitions}</div>
          </div>
          <div className="stat-box">
            <label>Mean Entropy</label>
            <div className="stat-value">{stats.mean_entropy.toExponential(2)}</div>
          </div>
          <div className="stat-box">
            <label>Stability Index</label>
            <div className="stat-value">{stats.stability_index.toFixed(3)}</div>
          </div>
          <div className="stat-box">
            <label>Metatron Nodes</label>
            <div className="stat-value">{stats.metatron_nodes}</div>
          </div>
        </div>
      )}

      <div className="cubechain-content">
        <div className="hypergraph-view">
          <h3>Hypergraph (3D Projection)</h3>
          <div className="hypergraph-canvas">
            {cubes.map((cube, index) => {
              // Simple 2D projection for visualization
              const x = 50 + (cube.signature.psi - 0.5) * 400;
              const y = 50 + (cube.signature.rho - 0.5) * 400;
              const size = 10 + cube.signature.omega * 20;
              const color = getCubeColor(cube);
              const opacity = getBrightness(cube);

              // Skip antipodes if toggle is off
              if (!showAntipodes && cube.antipode_id) {
                // Only show if this is the primary (lower ID)
                const antipode = cubes.find(c => c.id === cube.antipode_id);
                if (antipode && cube.id > antipode.id) {
                  return null;
                }
              }

              return (
                <div
                  key={cube.id}
                  className="hypergraph-node"
                  style={{
                    left: `${x}px`,
                    top: `${y}px`,
                    width: `${size}px`,
                    height: `${size}px`,
                    backgroundColor: color,
                    opacity: opacity,
                    border: selectedCube?.id === cube.id ? '3px solid white' : 'none',
                  }}
                  onClick={() => setSelectedCube(cube)}
                  title={`Cube ${cube.id.substring(0, 8)} - Gen ${cube.generation}`}
                />
              );
            })}

            {/* Draw transitions */}
            <svg className="transitions-overlay">
              {transitions.map((t) => {
                const fromCube = cubes.find(c => c.id === t.from_cube);
                const toCube = cubes.find(c => c.id === t.to_cube);
                
                if (!fromCube || !toCube) return null;

                const x1 = 50 + (fromCube.signature.psi - 0.5) * 400 + 10;
                const y1 = 50 + (fromCube.signature.rho - 0.5) * 400 + 10;
                const x2 = 50 + (toCube.signature.psi - 0.5) * 400 + 10;
                const y2 = 50 + (toCube.signature.rho - 0.5) * 400 + 10;

                return (
                  <line
                    key={t.id}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke={OPERATOR_COLORS[t.operator]}
                    strokeWidth={t.validated ? 2 : 1}
                    strokeOpacity={t.resonance_amplitude}
                    strokeDasharray={t.validated ? '0' : '5,5'}
                  />
                );
              })}
            </svg>
          </div>

          <div className="legend">
            <h4>Operator Legend</h4>
            {Object.entries(OPERATOR_COLORS).map(([op, color]) => (
              <div key={op} className="legend-item">
                <div className="legend-color" style={{ backgroundColor: color }}></div>
                <span>{op}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="cube-details">
          <h3>Cube Details</h3>
          {selectedCube ? (
            <div className="details-content">
              <div className="detail-row">
                <label>ID:</label>
                <span>{selectedCube.id}</span>
              </div>
              <div className="detail-row">
                <label>Generation:</label>
                <span>{selectedCube.generation}</span>
              </div>
              <div className="detail-section">
                <h4>Signature (5D)</h4>
                <div className="signature-values">
                  <div><label>ψ (psi):</label> {selectedCube.signature.psi.toFixed(4)}</div>
                  <div><label>ρ (rho):</label> {selectedCube.signature.rho.toFixed(4)}</div>
                  <div><label>ω (omega):</label> {selectedCube.signature.omega.toFixed(4)}</div>
                  <div><label>χ (chi):</label> {selectedCube.signature.chi.toFixed(4)}</div>
                  <div><label>η (eta):</label> {selectedCube.signature.eta.toFixed(4)}</div>
                </div>
              </div>
              <div className="detail-section">
                <h4>Operator Basis</h4>
                <div className="operator-weights">
                  {Object.entries(selectedCube.operator_basis).map(([op, weight]) => (
                    <div key={op} className="weight-bar">
                      <label>{op}:</label>
                      <div className="bar-container">
                        <div 
                          className="bar-fill" 
                          style={{ 
                            width: `${weight * 100}%`,
                            backgroundColor: OPERATOR_COLORS[op as keyof typeof OPERATOR_COLORS]
                          }}
                        />
                      </div>
                      <span>{weight.toFixed(3)}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="detail-row">
                <label>β-Symmetry:</label>
                <span>{selectedCube.beta_symmetry.toFixed(4)}</span>
              </div>
              <div className="detail-row">
                <label>S-Field (Entropy):</label>
                <span className={Math.abs(selectedCube.s_field) < 0.001 ? 'stable' : 'unstable'}>
                  {selectedCube.s_field.toExponential(2)}
                </span>
              </div>
              <div className="detail-row">
                <label>Proof Score:</label>
                <span>{selectedCube.proof_score.toFixed(4)}</span>
              </div>
              {selectedCube.antipode_id && (
                <div className="detail-row">
                  <label>Antipode:</label>
                  <span className="antipode-link">{selectedCube.antipode_id.substring(0, 8)}</span>
                </div>
              )}
            </div>
          ) : (
            <div className="empty-state">
              <p>Click on a cube to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CubechainNavigator;
