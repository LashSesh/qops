# Metatron Dashboard UI

Frontend interface for interactive operator exploration and visualization in the Metatron Operator Cosmos.

## Features

- **Operator Lexicon Browser** - Searchable catalog of mined operators
- **Real-time Telemetry** - Live WebSocket stream of system metrics
- **Analytics Dashboard** - System-wide statistics and trends
- **Responsive Design** - Works on desktop and mobile

## Technology Stack

- React 18
- TypeScript 5
- D3.js (for data visualization)
- Three.js & React Three Fiber (for 3D visualization)
- WebSockets (for real-time telemetry)

## Development

### Prerequisites
- Node.js 20+
- npm or yarn

### Setup

```bash
cd ui
npm install
```

### Run Development Server

```bash
npm start
```

The app will open at http://localhost:3000

### Build for Production

```bash
npm run build
```

## Environment Variables

Create a `.env` file in the `ui/` directory:

```
REACT_APP_API_BASE_URL=http://localhost:8080
REACT_APP_WS_TELEMETRY_URL=ws://localhost:8080/telemetry
```

## Docker

Build the Docker image:

```bash
docker build -f ui/Dockerfile -t metatron/dashboard-ui:latest .
```

Run the container:

```bash
docker run -p 3000:3000 metatron/dashboard-ui:latest
```

## Components

### Main Views

- **Operators View** - Grid of operator cards with key metrics
- **Analytics View** - Aggregate statistics and trends
- **Telemetry View** - Real-time system metrics

### Planned Features

- MetatronCubeNavigator - 3D navigation through the 13-node topology
- EntropyTimeline - Time-series visualization of entropy curves
- Operator Graph - Interactive relation graph between operators
