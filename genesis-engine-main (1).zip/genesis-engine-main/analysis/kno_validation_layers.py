#!/usr/bin/env python3
"""
KNO Validation Layers - 5-Layer Validation System

Implements comprehensive validation framework for KNO operators:
- Layer 1: Hermitianity Check (symbolic conjugate transpose)
- Layer 2: Potential Stability Validation (V'' > 0)
- Layer 3: Spectral Coherence Test (correlation metrics)
- Layer 4: Topological Integrity Check (Berry phase, Chern number)
- Layer 5: Divergence Detection (bounded amplitude)
"""

import numpy as np
import json
import sys
from pathlib import Path
from typing import List, Tuple, Dict, Optional, Any
from dataclasses import dataclass, asdict, field
from datetime import datetime


# Validation tolerances
HERMITIAN_TOLERANCE = 1e-10
STABILITY_TOLERANCE = 1e-6
COHERENCE_THRESHOLD = 0.995
BERRY_PHASE_TARGET = 2 * np.pi
BERRY_PHASE_TOLERANCE = 0.1
CHERN_NUMBER_TARGET = 1.0
CHERN_NUMBER_TOLERANCE = 0.05
AMPLITUDE_BOUND = 1e3


@dataclass
class LayerValidationResult:
    """Result from a single validation layer"""
    layer_number: int
    layer_name: str
    method: str
    passed: bool
    metric_value: float
    threshold: float
    error_message: Optional[str] = None
    details: Dict[str, float] = field(default_factory=dict)
    equations: Dict[str, str] = field(default_factory=dict)


@dataclass
class ValidationReport:
    """Complete validation report"""
    operator_id: str
    timestamp: str
    commit_ref: Optional[str]
    layer_results: List[LayerValidationResult]
    overall_passed: bool
    alerts_triggered: List[str]
    metadata: Dict[str, Any] = field(default_factory=dict)


class Layer1_HermitianityCheck:
    """
    Layer 1: Hermitianity Check

    Method: Symbolic conjugate transpose validation
    Procedure: Verify that LΦ(K)† = LΦ(K) within numerical tolerance (1e-10)
    Condition: Re(⟨Ψ | LΦ(K)Ψ⟩) = Re(⟨LΦ(K)Ψ | Ψ⟩)
    """

    def __init__(self, tolerance: float = HERMITIAN_TOLERANCE):
        self.tolerance = tolerance

    def validate(self, psi: complex, psi_dot: complex, omega: float,
                v_prime: float) -> LayerValidationResult:
        """
        Validate Hermitian property of LΦ(K)

        Args:
            psi: Wave function Ψ
            psi_dot: Time derivative dΨ/dt
            omega: Frequency ω
            v_prime: Potential derivative V'(ω)
        """
        # Apply operator: LΦ(K)Ψ = -i dΨ/dt + V'(ω) Ψ
        minus_i = -1j
        l_psi = minus_i * psi_dot + v_prime * psi

        # Compute ⟨Ψ | LΦ(K)Ψ⟩
        psi_star = np.conj(psi)
        inner1 = psi_star * l_psi

        # Compute ⟨LΦ(K)Ψ | Ψ⟩
        l_psi_star = np.conj(l_psi)
        inner2 = l_psi_star * psi

        # Check Hermitian condition: Re(inner1) ≈ Re(inner2)
        diff = np.abs(np.real(inner1) - np.real(inner2))

        passed = bool(diff < self.tolerance)

        result = LayerValidationResult(
            layer_number=1,
            layer_name="Hermitianity Check",
            method="Symbolic conjugate transpose validation",
            passed=passed,
            metric_value=float(diff),
            threshold=self.tolerance,
            error_message=None if passed else f"LΦ(K)† ≠ LΦ(K): diff = {diff:.2e}",
            details={
                "inner_product_1": float(np.real(inner1)),
                "inner_product_2": float(np.real(inner2)),
                "difference": float(diff),
                "psi_magnitude": float(np.abs(psi)),
                "lpsi_magnitude": float(np.abs(l_psi))
            },
            equations={
                "operator": "LΦ(K) = -i d/dt + f(Ψ, Φ)",
                "condition": "Re(⟨Ψ | LΦ(K)Ψ⟩) = Re(⟨LΦ(K)Ψ | Ψ⟩)"
            }
        )

        return result


class Layer2_PotentialStability:
    """
    Layer 2: Potential Stability Validation

    Method: Second derivative test on polynomial potential minima
    Procedure: Evaluate V''(γ_n) for each critical point γ_n
    Condition: V''(γ_n) > 0 for all Riemann zeros
    """

    def __init__(self, tolerance: float = STABILITY_TOLERANCE):
        self.tolerance = tolerance

    def compute_v_second_derivative(self, omega: float, zeros: List[float],
                                   kappa: float) -> float:
        """Compute V''(ω) for polynomial potential"""
        n = len(zeros)
        result = 0.0

        for i, gamma_i in enumerate(zeros):
            # First term: 2.0 * ∏(ω - γ_j)^2 for j ≠ i
            term1 = 2.0
            for j, gamma_j in enumerate(zeros):
                if i != j:
                    term1 *= (omega - gamma_j) ** 2
            result += term1

            # Second term: cross terms
            for k, gamma_k in enumerate(zeros):
                if k != i:
                    term2 = 4.0 * (omega - gamma_i) * 2.0 * (omega - gamma_k)
                    for j, gamma_j in enumerate(zeros):
                        if j != i and j != k:
                            term2 *= (omega - gamma_j) ** 2
                    result += term2

        return kappa * result

    def validate(self, zeros: List[float], kappa: float = 1.0) -> LayerValidationResult:
        """
        Validate stability at all Riemann zeros

        Args:
            zeros: Riemann zero imaginary parts
            kappa: Coupling constant
        """
        stability_checks = []

        for i, gamma in enumerate(zeros):
            v_pp = self.compute_v_second_derivative(gamma, zeros, kappa)
            is_stable = v_pp > self.tolerance
            stability_checks.append((gamma, v_pp, is_stable))

        total_zeros = len(zeros)
        stable_count = sum(1 for _, _, stable in stability_checks if stable)
        ratio = stable_count / total_zeros if total_zeros > 0 else 0.0

        passed = bool(stable_count == total_zeros)

        details = {
            "total_minima": float(total_zeros),
            "stable_minima": float(stable_count),
            "stability_ratio": float(ratio)
        }

        # Add individual zero details - convert numpy types to Python native types
        for i, (gamma, v_pp, is_stable) in enumerate(stability_checks):
            details[f"gamma_{i}_value"] = float(gamma)
            details[f"gamma_{i}_v_pp"] = float(v_pp)
            details[f"gamma_{i}_stable"] = 1.0 if is_stable else 0.0

        error_msg = None
        if not passed:
            unstable = [f"γ_{i}={gamma:.6f} (V''={v_pp:.2e})"
                       for i, (gamma, v_pp, is_stable) in enumerate(stability_checks)
                       if not is_stable]
            error_msg = f"V''(γ_n) ≤ 0 for {len(unstable)} zeros: {', '.join(unstable)}"

        result = LayerValidationResult(
            layer_number=2,
            layer_name="Potential Stability Validation",
            method="Second derivative test on polynomial potential minima",
            passed=passed,
            metric_value=float(ratio),
            threshold=1.0,
            error_message=error_msg,
            details=details,
            equations={
                "potential": "V_poly(ω) = κ ∏(ω - γ_n)^2",
                "condition": "∂²V/∂ω²|_{ω=γ_n} > 0"
            }
        )

        return result


class Layer3_SpectralCoherence:
    """
    Layer 3: Spectral Coherence Test

    Method: Eigenvalue alignment and phase-lock invariance
    Procedure: Track spectral trajectory and compute normalized correlation
    Metric: ρ = |⟨Ψ(t)|Ψ(t+Δt)⟩| / (||Ψ(t)|| · ||Ψ(t+Δt)||)
    Threshold: ρ > 0.995
    """

    def __init__(self, threshold: float = COHERENCE_THRESHOLD):
        self.threshold = threshold

    def evaluate_psi(self, t: float, primes: List[int]) -> complex:
        """Evaluate Ψ(t) = Σ_p p^{-1/2} e^{i t log p}"""
        psi = 0.0 + 0.0j
        for p in primes:
            amplitude = 1.0 / np.sqrt(p)
            phase = t * np.log(p)
            psi += amplitude * np.exp(1j * phase)
        return psi

    def validate(self, t: float, primes: List[int],
                delta_t: float = 0.1) -> LayerValidationResult:
        """
        Validate spectral coherence

        Args:
            t: Current time
            primes: Prime numbers for phase field
            delta_t: Time increment for correlation
        """
        psi_t = self.evaluate_psi(t, primes)
        psi_t_dt = self.evaluate_psi(t + delta_t, primes)

        # Compute inner product ⟨Ψ(t)|Ψ(t+Δt)⟩
        inner = psi_t * np.conj(psi_t_dt)

        # Compute norms
        norm_t = np.abs(psi_t)
        norm_t_dt = np.abs(psi_t_dt)

        # Proper correlation coefficient (normalized cross-correlation)
        # ρ = |⟨Ψ(t)|Ψ(t+Δt)⟩| / (||Ψ(t)|| · ||Ψ(t+Δt)||)
        denominator = norm_t * norm_t_dt
        if denominator > 1e-12:
            correlation = np.abs(inner) / denominator
        else:
            correlation = 0.0

        passed = bool(correlation > self.threshold)

        result = LayerValidationResult(
            layer_number=3,
            layer_name="Spectral Coherence Test",
            method="Eigenvalue alignment and phase-lock invariance",
            passed=passed,
            metric_value=float(correlation),
            threshold=self.threshold,
            error_message=None if passed else f"ρ = {correlation:.6f} < {self.threshold}",
            details={
                "correlation": float(correlation),
                "psi_t_magnitude": float(norm_t),
                "psi_t_dt_magnitude": float(norm_t_dt),
                "inner_product_magnitude": float(np.abs(inner)),
                "delta_t": float(delta_t),
                "time": float(t)
            },
            equations={
                "field": "Ψ(t)=Σ_p p^{-1/2} e^{i t log p}",
                "correlation_metric": "ρ = |⟨Ψ(t)|Ψ(t+Δt)⟩| / (||Ψ(t)|| · ||Ψ(t+Δt)||)"
            }
        )

        return result


class Layer4_TopologicalIntegrity:
    """
    Layer 4: Topological Integrity Check

    Method: Numerical evaluation of Berry phase and Chern number
    Procedure: Compute ∮ A·dl and ∬ (∂iAj - ∂jAi)dσ^i∧dσ^j
    Expected: Berry phase ≈ 2π ± 0.01, Chern number = 1 ± 0.05
    """

    def __init__(self, berry_tolerance: float = BERRY_PHASE_TOLERANCE,
                chern_tolerance: float = CHERN_NUMBER_TOLERANCE):
        self.berry_tolerance = berry_tolerance
        self.chern_tolerance = chern_tolerance

    def validate(self, berry_phase: Optional[float] = None,
                chern_number: Optional[float] = None) -> LayerValidationResult:
        """
        Validate topological invariants

        Args:
            berry_phase: Computed Berry phase
            chern_number: Computed Chern number
        """
        # Check Berry phase
        berry_ok = False
        berry_error = float('inf')

        if berry_phase is not None:
            berry_error = np.abs(berry_phase - BERRY_PHASE_TARGET)
            berry_ok = berry_error < self.berry_tolerance

        # Check Chern number
        chern_ok = False
        chern_error = float('inf')

        if chern_number is not None:
            chern_error = np.abs(chern_number - CHERN_NUMBER_TARGET)
            chern_ok = chern_error < self.chern_tolerance

        # Overall validation
        if berry_phase is None and chern_number is None:
            passed = False
            metric = 0.0
            error_msg = "Neither Berry phase nor Chern number computed"
        elif berry_ok and chern_ok:
            passed = True
            metric = 1.0
            error_msg = None
        elif berry_ok or chern_ok:
            passed = False
            metric = 0.5
            errors = []
            if not berry_ok:
                errors.append(f"|BerryPhase - 2π| = {berry_error:.6f} > {self.berry_tolerance}")
            if not chern_ok:
                errors.append(f"|Chern - 1| = {chern_error:.6f} > {self.chern_tolerance}")
            error_msg = "Topological violation: " + "; ".join(errors)
        else:
            passed = False
            metric = 0.0
            error_msg = "Both Berry phase and Chern number out of tolerance"

        details = {}
        if berry_phase is not None:
            details["berry_phase"] = float(berry_phase)
            details["berry_phase_target"] = float(BERRY_PHASE_TARGET)
            details["berry_phase_error"] = float(berry_error)
            details["berry_phase_ok"] = 1.0 if berry_ok else 0.0

        if chern_number is not None:
            details["chern_number"] = float(chern_number)
            details["chern_number_target"] = float(CHERN_NUMBER_TARGET)
            details["chern_number_error"] = float(chern_error)
            details["chern_number_ok"] = 1.0 if chern_ok else 0.0

        result = LayerValidationResult(
            layer_number=4,
            layer_name="Topological Integrity Check",
            method="Numerical evaluation of Berry phase and Chern number",
            passed=bool(passed),
            metric_value=float(metric),
            threshold=1.0,
            error_message=error_msg,
            details=details,
            equations={
                "berry_phase": "γ = ∮ A·dl",
                "chern_number": "C = (1/2π) ∬ (∂iAj - ∂jAi)dσ^i∧dσ^j"
            }
        )

        return result


class Layer5_DivergenceDetection:
    """
    Layer 5: Divergence Detection

    Method: Runge-Kutta propagation of KNO dynamic system
    Procedure: Integrate (Ψ, Φ, ω) and ensure bounded amplitude
    Condition: |Ψ(t)| < 10^3 for all t ∈ [0, T]
    """

    def __init__(self, amplitude_bound: float = AMPLITUDE_BOUND):
        self.amplitude_bound = amplitude_bound

    def validate(self, amplitude_history: List[float]) -> LayerValidationResult:
        """
        Validate bounded amplitude over evolution

        Args:
            amplitude_history: Time series of |Ψ(t)| values
        """
        if not amplitude_history:
            return LayerValidationResult(
                layer_number=5,
                layer_name="Divergence Detection",
                method="Runge-Kutta propagation monitoring",
                passed=False,
                metric_value=0.0,
                threshold=self.amplitude_bound,
                error_message="No amplitude history provided",
                details={},
                equations={
                    "condition": "|Ψ(t)| < 10^3 for all t ∈ [0, T]"
                }
            )

        max_amplitude = float(np.max(amplitude_history))
        mean_amplitude = float(np.mean(amplitude_history))
        std_amplitude = float(np.std(amplitude_history))

        passed = bool(max_amplitude < self.amplitude_bound)

        result = LayerValidationResult(
            layer_number=5,
            layer_name="Divergence Detection",
            method="Runge-Kutta propagation monitoring",
            passed=passed,
            metric_value=max_amplitude,
            threshold=self.amplitude_bound,
            error_message=None if passed else f"|Ψ(t)| = {max_amplitude:.2e} > {self.amplitude_bound:.2e}",
            details={
                "max_amplitude": max_amplitude,
                "mean_amplitude": mean_amplitude,
                "std_amplitude": std_amplitude,
                "samples": float(len(amplitude_history)),
                "growth_rate": (amplitude_history[-1] - amplitude_history[0]) / len(amplitude_history) if len(amplitude_history) > 1 else 0.0
            },
            equations={
                "condition": "|Ψ(t)| < 10^3 for all t ∈ [0, T]"
            }
        )

        return result


class KNOValidationFramework:
    """
    Complete 5-layer validation framework for KNO operators
    """

    def __init__(self, operator_id: str, commit_ref: Optional[str] = None):
        self.operator_id = operator_id
        self.commit_ref = commit_ref

        # Initialize all layers
        self.layer1 = Layer1_HermitianityCheck()
        self.layer2 = Layer2_PotentialStability()
        self.layer3 = Layer3_SpectralCoherence()
        self.layer4 = Layer4_TopologicalIntegrity()
        self.layer5 = Layer5_DivergenceDetection()

    def validate_all(self,
                    # Layer 1 params
                    psi: complex, psi_dot: complex, omega: float, v_prime: float,
                    # Layer 2 params
                    riemann_zeros: List[float], kappa: float,
                    # Layer 3 params
                    time: float, primes: List[int],
                    # Layer 4 params
                    berry_phase: Optional[float], chern_number: Optional[float],
                    # Layer 5 params
                    amplitude_history: List[float]) -> ValidationReport:
        """
        Run all 5 validation layers
        """
        results = []

        # Layer 1: Hermitianity
        print("Running Layer 1: Hermitianity Check...")
        result1 = self.layer1.validate(psi, psi_dot, omega, v_prime)
        results.append(result1)

        # Layer 2: Stability
        print("Running Layer 2: Potential Stability Validation...")
        result2 = self.layer2.validate(riemann_zeros, kappa)
        results.append(result2)

        # Layer 3: Spectral Coherence
        print("Running Layer 3: Spectral Coherence Test...")
        result3 = self.layer3.validate(time, primes)
        results.append(result3)

        # Layer 4: Topological Integrity
        print("Running Layer 4: Topological Integrity Check...")
        result4 = self.layer4.validate(berry_phase, chern_number)
        results.append(result4)

        # Layer 5: Divergence Detection
        print("Running Layer 5: Divergence Detection...")
        result5 = self.layer5.validate(amplitude_history)
        results.append(result5)

        # Generate alerts
        alerts = []
        for result in results:
            if not result.passed and result.error_message:
                alerts.append(f"{result.layer_name}: {result.error_message}")

        # Create final report
        overall_passed = all(r.passed for r in results)

        report = ValidationReport(
            operator_id=self.operator_id,
            timestamp=datetime.utcnow().isoformat() + "Z",
            commit_ref=self.commit_ref,
            layer_results=results,
            overall_passed=overall_passed,
            alerts_triggered=alerts,
            metadata={
                "framework_version": "KNO_Validation_v1.0",
                "layers_passed": sum(1 for r in results if r.passed),
                "layers_total": len(results)
            }
        )

        return report

    def save_report(self, report: ValidationReport, output_dir: Path):
        """Save validation report to JSON and log files"""
        output_dir.mkdir(parents=True, exist_ok=True)

        # Save summary JSON
        summary_file = output_dir / "validation_summary.json"
        with open(summary_file, 'w') as f:
            json.dump(asdict(report), f, indent=2)

        # Save individual log files
        for result in report.layer_results:
            log_filename = result.layer_name.lower().replace(" ", "_").replace(":", "") + ".log"
            log_file = output_dir / log_filename

            with open(log_file, 'w') as f:
                f.write(f"=== {result.layer_name} ===\n")
                f.write(f"Method: {result.method}\n")
                f.write(f"Status: {'PASSED' if result.passed else 'FAILED'}\n")
                f.write(f"Metric: {result.metric_value:.6e}\n")
                f.write(f"Threshold: {result.threshold:.6e}\n")

                if result.error_message:
                    f.write(f"Error: {result.error_message}\n")

                f.write("\nEquations:\n")
                for key, eq in result.equations.items():
                    f.write(f"  {key}: {eq}\n")

                f.write("\nDetails:\n")
                for key, value in result.details.items():
                    f.write(f"  {key}: {value:.6e}\n")

        print(f"\n✓ Validation report saved to: {summary_file}")
        return summary_file


def main():
    """Standalone validation execution"""
    print("=" * 80)
    print("KNO Validation Framework - 5-Layer System")
    print("=" * 80)
    print()

    # Example validation
    framework = KNOValidationFramework(
        operator_id="kno_test_001",
        commit_ref="test_commit"
    )

    # Dummy parameters for testing
    riemann_zeros = [14.134725, 21.022040, 25.010858]
    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]

    # Simple test wave function
    t = 1.0
    psi = sum(np.exp(1j * t * np.log(p)) / np.sqrt(p) for p in primes)
    psi_dot = sum(1j * np.log(p) * np.exp(1j * t * np.log(p)) / np.sqrt(p) for p in primes)
    omega = 15.0
    v_prime = 0.1

    amplitude_history = [1.0 + 0.1 * i for i in range(10)]

    report = framework.validate_all(
        psi=psi,
        psi_dot=psi_dot,
        omega=omega,
        v_prime=v_prime,
        riemann_zeros=riemann_zeros,
        kappa=1.0,
        time=t,
        primes=primes,
        berry_phase=6.28,
        chern_number=1.0,
        amplitude_history=amplitude_history
    )

    # Display results
    print()
    print("Validation Results:")
    print("-" * 80)
    for result in report.layer_results:
        status = "✓ PASSED" if result.passed else "✗ FAILED"
        print(f"Layer {result.layer_number}: {result.layer_name:40s} {status}")
        print(f"  Metric: {result.metric_value:.6e} (threshold: {result.threshold:.6e})")
        if result.error_message:
            print(f"  Error: {result.error_message}")

    print()
    print(f"Overall Status: {'✓ ALL LAYERS PASSED' if report.overall_passed else '✗ SOME LAYERS FAILED'}")
    print(f"Layers Passed: {report.metadata['layers_passed']}/{report.metadata['layers_total']}")

    if report.alerts_triggered:
        print()
        print("Alerts Triggered:")
        for alert in report.alerts_triggered:
            print(f"  ⚠ {alert}")

    # Save report
    output_dir = Path("reports/validation")
    framework.save_report(report, output_dir)

    sys.exit(0 if report.overall_passed else 1)


if __name__ == "__main__":
    main()
