#!/usr/bin/env python3
"""Compute topological metrics of the operator field.

This script constructs a 2D representation of operator space and computes
differential geometric properties like curvature and metric tensor components.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Dict, Tuple

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compute topology metrics for operator field"
    )
    parser.add_argument(
        "--grid-size",
        type=int,
        default=512,  # Reduced from 8192 to avoid OOM on GitHub runners
        help="Grid resolution (default: 512, max recommended: 2048)",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="topology_metrics.json",
        help="Output path for topology metrics",
    )
    return parser.parse_args()


class TopologyComputer:
    """Computes topological and geometric properties of operator space."""

    def __init__(self, grid_size: int = 512):
        """Initialize topology computer.

        Args:
            grid_size: Resolution of the computational grid. Default 512
                      is chosen to limit memory usage on CI runners.
                      Each grid consumes approximately:
                      - grid_size=512:  ~2 MB per array
                      - grid_size=1024: ~8 MB per array
                      - grid_size=2048: ~32 MB per array
                      - grid_size=8192: ~512 MB per array (OOM risk!)
        """
        if grid_size > 2048:
            print(
                f"[WARNING] Grid size {grid_size} may cause OOM on CI runners. "
                f"Recommended maximum: 2048"
            )

        self.grid_size = grid_size

    def construct_metric_field(self) -> Dict[str, np.ndarray]:
        """Construct the metric tensor field over operator space."""
        print(f"[METRIC] Constructing {self.grid_size}x{self.grid_size} metric field...")

        # Create 2D grid representing operator space (Re, Im planes)
        x = np.linspace(-10, 10, self.grid_size)
        y = np.linspace(-10, 10, self.grid_size)
        X, Y = np.meshgrid(x, y)

        # Potential function (synthetic for demonstration)
        # In a real implementation, this would be derived from operator data
        V = np.exp(-(X**2 + Y**2) / 10.0) * np.cos(X) * np.sin(Y)

        # Compute gradients
        dV_dx, dV_dy = np.gradient(V)

        # Metric tensor components g_ij
        # For a 2D Riemannian manifold embedded in potential field
        g_xx = 1.0 + dV_dx**2
        g_yy = 1.0 + dV_dy**2
        g_xy = dV_dx * dV_dy

        print("[METRIC] Metric field constructed")

        return {
            "X": X,
            "Y": Y,
            "V": V,
            "g_xx": g_xx,
            "g_yy": g_yy,
            "g_xy": g_xy,
        }

    def compute_curvature(self, metric: Dict[str, np.ndarray]) -> Dict[str, float]:
        """Compute scalar curvature and other geometric invariants."""
        print("[CURVATURE] Computing geometric invariants...")

        g_xx = metric["g_xx"]
        g_yy = metric["g_yy"]
        g_xy = metric["g_xy"]

        # Determinant of metric
        det_g = g_xx * g_yy - g_xy**2

        # Inverse metric components
        g_xx_inv = g_yy / det_g
        g_yy_inv = g_xx / det_g
        g_xy_inv = -g_xy / det_g

        # Compute Christoffel symbols (simplified)
        # In 2D, this is a subset of the full computation
        dg_xx_dx, dg_xx_dy = np.gradient(g_xx)
        dg_yy_dx, dg_yy_dy = np.gradient(g_yy)

        # Ricci scalar (simplified approximation)
        # Full computation would require all Christoffel symbols and their derivatives
        R_approx = -0.5 * (
            g_xx_inv * (dg_xx_dx**2 + dg_xx_dy**2) +
            g_yy_inv * (dg_yy_dx**2 + dg_yy_dy**2)
        )

        # Statistical summaries
        mean_curvature = float(np.mean(R_approx))
        std_curvature = float(np.std(R_approx))
        max_curvature = float(np.max(np.abs(R_approx)))

        print(f"[CURVATURE] Mean: {mean_curvature:.6f}")
        print(f"[CURVATURE] Std:  {std_curvature:.6f}")
        print(f"[CURVATURE] Max:  {max_curvature:.6f}")

        return {
            "mean_curvature": mean_curvature,
            "std_curvature": std_curvature,
            "max_curvature": max_curvature,
        }

    def compute_topology_metrics(self) -> Dict[str, any]:
        """Run full topology computation pipeline."""
        print("=" * 80)
        print("Operator Field Topology Computation")
        print("=" * 80)
        print(f"[CONFIG] Grid size: {self.grid_size}x{self.grid_size}")

        # Estimate memory usage
        bytes_per_float64 = 8
        elements_per_array = self.grid_size * self.grid_size
        mb_per_array = (bytes_per_float64 * elements_per_array) / (1024 * 1024)
        estimated_mb = mb_per_array * 6  # We create ~6 main arrays

        print(f"[CONFIG] Estimated memory usage: ~{estimated_mb:.1f} MB")

        # Construct metric field
        metric = self.construct_metric_field()

        # Compute curvature
        curvature = self.compute_curvature(metric)

        # Compile results
        results = {
            "configuration": {
                "grid_size": self.grid_size,
                "estimated_memory_mb": estimated_mb,
            },
            "geometric_invariants": curvature,
            "topology_status": {
                "computation_complete": True,
            },
        }

        print("\n" + "=" * 80)
        print("Topology Computation Complete")
        print("=" * 80)

        return results


def main() -> int:
    args = parse_args()

    # Validate grid size
    if args.grid_size < 64:
        print("[ERROR] Grid size must be at least 64", file=sys.stderr)
        return 1

    if args.grid_size > 4096:
        print(
            "[ERROR] Grid size exceeds maximum safe value (4096). "
            "Risk of OOM on CI runners.",
            file=sys.stderr
        )
        return 1

    # Run computation
    computer = TopologyComputer(grid_size=args.grid_size)
    results = computer.compute_topology_metrics()

    # Save results
    print(f"\n[SAVE] Writing results to {args.output}...")
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    print("[COMPLETE] Topology metrics saved successfully")

    return 0


if __name__ == "__main__":
    sys.exit(main())
