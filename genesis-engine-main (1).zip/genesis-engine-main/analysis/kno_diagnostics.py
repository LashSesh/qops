#!/usr/bin/env python3
"""
KNO Diagnostics and Alert System

Provides comprehensive diagnostic reporting, alert triggering, and
visualization for the KNO validation framework.

Features:
- Alert detection and categorization
- Metric aggregation and trend analysis
- Dashboard generation (JSON + Markdown)
- Hermitian manifold deviation visualization
- Auto-archival of failed operator outputs
"""

import numpy as np
import json
import sys
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle
import warnings
warnings.filterwarnings('ignore')


@dataclass
class Alert:
    """Alert trigger record"""
    severity: str  # 'CRITICAL', 'WARNING', 'INFO'
    trigger: str
    message: str
    timestamp: str
    layer: str
    metric_value: float
    threshold: float


@dataclass
class DiagnosticSummary:
    """Aggregated diagnostic summary"""
    timestamp: str
    operator_id: str
    overall_status: str  # 'PASSED', 'FAILED', 'WARNING'
    total_layers: int
    layers_passed: int
    layers_failed: int
    alerts_critical: int
    alerts_warning: int
    alerts_info: int
    metrics: Dict[str, float]
    recommendations: List[str]


class AlertSystem:
    """
    Alert detection and categorization based on validation failures
    """

    ALERT_TRIGGERS = {
        "hermiticity_failure": {
            "severity": "CRITICAL",
            "message": "LΦ(K)† ≠ LΦ(K): Operator is not self-adjoint",
            "layer": "Layer 1"
        },
        "instability_detected": {
            "severity": "CRITICAL",
            "message": "V''(γ_n) ≤ 0: Unstable equilibria detected",
            "layer": "Layer 2"
        },
        "spectral_incoherence": {
            "severity": "WARNING",
            "message": "ρ < 0.995: Phase field correlation below threshold",
            "layer": "Layer 3"
        },
        "topological_violation": {
            "severity": "WARNING",
            "message": "|BerryPhase−2π| > 0.1: Topological invariant out of range",
            "layer": "Layer 4"
        },
        "amplitude_overflow": {
            "severity": "CRITICAL",
            "message": "|Ψ(t)| > 10³: Divergence detected",
            "layer": "Layer 5"
        }
    }

    def __init__(self):
        self.alerts: List[Alert] = []

    def check_and_trigger(self, layer_name: str, passed: bool,
                         metric_value: float, threshold: float,
                         error_message: Optional[str]) -> None:
        """Check layer result and trigger appropriate alerts"""
        if passed:
            return

        # Map layer names to alert triggers
        trigger_map = {
            "Hermitianity Check": "hermiticity_failure",
            "Potential Stability Validation": "instability_detected",
            "Spectral Coherence Test": "spectral_incoherence",
            "Topological Integrity Check": "topological_violation",
            "Divergence Detection": "amplitude_overflow"
        }

        trigger_key = trigger_map.get(layer_name)
        if not trigger_key:
            return

        trigger_info = self.ALERT_TRIGGERS[trigger_key]

        alert = Alert(
            severity=trigger_info["severity"],
            trigger=trigger_key,
            message=trigger_info["message"],
            timestamp=datetime.utcnow().isoformat() + "Z",
            layer=trigger_info["layer"],
            metric_value=metric_value,
            threshold=threshold
        )

        if error_message:
            alert.message += f" ({error_message})"

        self.alerts.append(alert)

    def get_alerts_by_severity(self, severity: str) -> List[Alert]:
        """Get all alerts of a specific severity"""
        return [a for a in self.alerts if a.severity == severity]

    def get_summary(self) -> Dict[str, int]:
        """Get alert count summary"""
        return {
            "CRITICAL": len(self.get_alerts_by_severity("CRITICAL")),
            "WARNING": len(self.get_alerts_by_severity("WARNING")),
            "INFO": len(self.get_alerts_by_severity("INFO"))
        }


class MetricAggregator:
    """
    Aggregates metrics across all validation layers
    """

    def __init__(self):
        self.metrics: Dict[str, float] = {}

    def add_layer_metrics(self, layer_name: str, layer_result: dict):
        """Add metrics from a validation layer"""
        # Add main metric
        self.metrics[f"{layer_name}_metric"] = layer_result.get("metric_value", 0.0)
        self.metrics[f"{layer_name}_threshold"] = layer_result.get("threshold", 0.0)
        self.metrics[f"{layer_name}_passed"] = 1.0 if layer_result.get("passed", False) else 0.0

        # Add detailed metrics
        for key, value in layer_result.get("details", {}).items():
            self.metrics[f"{layer_name}_{key}"] = value

    def compute_aggregate_score(self) -> float:
        """Compute overall validation score (0-1)"""
        layer_scores = [
            self.metrics.get("Hermitianity Check_passed", 0.0),
            self.metrics.get("Potential Stability Validation_passed", 0.0),
            self.metrics.get("Spectral Coherence Test_passed", 0.0),
            self.metrics.get("Topological Integrity Check_passed", 0.0),
            self.metrics.get("Divergence Detection_passed", 0.0)
        ]
        return np.mean(layer_scores) if layer_scores else 0.0

    def compute_quality_index(self) -> float:
        """Compute quality index based on key metrics"""
        # Weighted combination of critical metrics
        hermitian_score = 1.0 - min(1.0, self.metrics.get("Hermitianity Check_difference", 1.0) / 1e-10)
        stability_score = self.metrics.get("Potential Stability Validation_stability_ratio", 0.0)
        coherence_score = self.metrics.get("Spectral Coherence Test_correlation", 0.0)

        quality = (0.4 * hermitian_score + 0.3 * stability_score + 0.3 * coherence_score)
        return quality


class DiagnosticReporter:
    """
    Generate comprehensive diagnostic reports
    """

    def __init__(self, validation_report: dict):
        self.report = validation_report
        self.alert_system = AlertSystem()
        self.aggregator = MetricAggregator()

        self._process_report()

    def _process_report(self):
        """Process validation report and generate alerts/metrics"""
        for layer_result in self.report.get("layer_results", []):
            layer_name = layer_result.get("layer_name", "Unknown")

            # Check for alerts
            self.alert_system.check_and_trigger(
                layer_name=layer_name,
                passed=layer_result.get("passed", False),
                metric_value=layer_result.get("metric_value", 0.0),
                threshold=layer_result.get("threshold", 0.0),
                error_message=layer_result.get("error_message")
            )

            # Aggregate metrics
            self.aggregator.add_layer_metrics(layer_name, layer_result)

    def generate_summary(self) -> DiagnosticSummary:
        """Generate diagnostic summary"""
        alert_summary = self.alert_system.get_summary()

        layer_results = self.report.get("layer_results", [])
        total_layers = len(layer_results)
        layers_passed = sum(1 for r in layer_results if r.get("passed", False))
        layers_failed = total_layers - layers_passed

        overall_status = "PASSED" if self.report.get("overall_passed", False) else "FAILED"
        if alert_summary["CRITICAL"] > 0:
            overall_status = "FAILED"
        elif alert_summary["WARNING"] > 0:
            overall_status = "WARNING"

        # Generate recommendations
        recommendations = self._generate_recommendations()

        summary = DiagnosticSummary(
            timestamp=datetime.utcnow().isoformat() + "Z",
            operator_id=self.report.get("operator_id", "unknown"),
            overall_status=overall_status,
            total_layers=total_layers,
            layers_passed=layers_passed,
            layers_failed=layers_failed,
            alerts_critical=alert_summary["CRITICAL"],
            alerts_warning=alert_summary["WARNING"],
            alerts_info=alert_summary["INFO"],
            metrics=self.aggregator.metrics,
            recommendations=recommendations
        )

        return summary

    def _generate_recommendations(self) -> List[str]:
        """Generate recommendations based on validation results"""
        recommendations = []

        # Check Hermitianity
        hermitian_diff = self.aggregator.metrics.get("Hermitianity Check_difference", 0.0)
        if hermitian_diff > 1e-10:
            recommendations.append(
                "Hermitianity violation detected. Verify operator construction and "
                "ensure f(Ψ, Φ) is real-valued."
            )

        # Check stability
        stability_ratio = self.aggregator.metrics.get("Potential Stability Validation_stability_ratio", 1.0)
        if stability_ratio < 1.0:
            recommendations.append(
                f"Only {stability_ratio:.1%} of zeros are stable. Consider adjusting "
                "κ parameter or polynomial degree."
            )

        # Check coherence
        coherence = self.aggregator.metrics.get("Spectral Coherence Test_correlation", 1.0)
        if coherence < 0.995:
            recommendations.append(
                f"Spectral coherence ρ = {coherence:.4f} below threshold. "
                "Increase integration time step precision or check for numerical errors."
            )

        # Check topology
        berry_error = self.aggregator.metrics.get("Topological Integrity Check_berry_phase_error", 0.0)
        if berry_error > 0.1:
            recommendations.append(
                f"Berry phase deviates from 2π by {berry_error:.4f}. "
                "Verify Berry connection computation and grid resolution."
            )

        # Check divergence
        max_amplitude = self.aggregator.metrics.get("Divergence Detection_max_amplitude", 0.0)
        if max_amplitude > 1e3:
            recommendations.append(
                "Amplitude overflow detected. System may be unstable. "
                "Reduce time step or apply numerical damping."
            )

        if not recommendations:
            recommendations.append("All validation layers passed. Operator is stable and well-formed.")

        return recommendations

    def save_dashboard(self, output_dir: Path):
        """Generate and save diagnostic dashboard"""
        output_dir.mkdir(parents=True, exist_ok=True)

        summary = self.generate_summary()

        # Save JSON dashboard
        dashboard_json = output_dir / "diagnostic_dashboard.json"
        with open(dashboard_json, 'w') as f:
            json.dump({
                "summary": asdict(summary),
                "alerts": [asdict(a) for a in self.alert_system.alerts],
                "full_report": self.report
            }, f, indent=2)

        # Save Markdown dashboard
        dashboard_md = output_dir / "diagnostic_dashboard.md"
        self._generate_markdown_dashboard(summary, dashboard_md)

        print(f"✓ Diagnostic dashboard saved:")
        print(f"  - JSON: {dashboard_json}")
        print(f"  - Markdown: {dashboard_md}")

        return dashboard_json, dashboard_md

    def _generate_markdown_dashboard(self, summary: DiagnosticSummary, output_file: Path):
        """Generate Markdown diagnostic dashboard"""
        with open(output_file, 'w') as f:
            f.write("# KNO Diagnostic Dashboard\n\n")
            f.write(f"**Operator ID:** {summary.operator_id}\n")
            f.write(f"**Timestamp:** {summary.timestamp}\n")
            f.write(f"**Overall Status:** {summary.overall_status}\n\n")

            # Status badge
            if summary.overall_status == "PASSED":
                badge = "✅ ALL LAYERS PASSED"
            elif summary.overall_status == "WARNING":
                badge = "⚠️ PASSED WITH WARNINGS"
            else:
                badge = "❌ VALIDATION FAILED"

            f.write(f"## {badge}\n\n")

            # Summary table
            f.write("## Validation Summary\n\n")
            f.write("| Metric | Value |\n")
            f.write("|--------|-------|\n")
            f.write(f"| Total Layers | {summary.total_layers} |\n")
            f.write(f"| Layers Passed | {summary.layers_passed} |\n")
            f.write(f"| Layers Failed | {summary.layers_failed} |\n")
            f.write(f"| Critical Alerts | {summary.alerts_critical} |\n")
            f.write(f"| Warning Alerts | {summary.alerts_warning} |\n")
            f.write(f"| Info Alerts | {summary.alerts_info} |\n")
            f.write(f"| Validation Score | {self.aggregator.compute_aggregate_score():.2%} |\n")
            f.write(f"| Quality Index | {self.aggregator.compute_quality_index():.2%} |\n\n")

            # Layer results
            f.write("## Layer Results\n\n")
            for layer_result in self.report.get("layer_results", []):
                layer_name = layer_result.get("layer_name", "Unknown")
                passed = layer_result.get("passed", False)
                metric = layer_result.get("metric_value", 0.0)
                threshold = layer_result.get("threshold", 0.0)

                status_icon = "✅" if passed else "❌"
                f.write(f"### {status_icon} {layer_name}\n\n")
                f.write(f"- **Method:** {layer_result.get('method', 'N/A')}\n")
                f.write(f"- **Status:** {'PASSED' if passed else 'FAILED'}\n")
                f.write(f"- **Metric:** {metric:.6e}\n")
                f.write(f"- **Threshold:** {threshold:.6e}\n")

                if layer_result.get("error_message"):
                    f.write(f"- **Error:** {layer_result['error_message']}\n")

                f.write("\n")

            # Alerts
            if self.alert_system.alerts:
                f.write("## Alerts\n\n")
                for alert in self.alert_system.alerts:
                    severity_icon = {
                        "CRITICAL": "🔴",
                        "WARNING": "⚠️",
                        "INFO": "ℹ️"
                    }.get(alert.severity, "❔")

                    f.write(f"### {severity_icon} {alert.severity}: {alert.trigger}\n\n")
                    f.write(f"- **Layer:** {alert.layer}\n")
                    f.write(f"- **Message:** {alert.message}\n")
                    f.write(f"- **Metric:** {alert.metric_value:.6e} (threshold: {alert.threshold:.6e})\n")
                    f.write(f"- **Timestamp:** {alert.timestamp}\n\n")

            # Recommendations
            f.write("## Recommendations\n\n")
            for i, rec in enumerate(summary.recommendations, 1):
                f.write(f"{i}. {rec}\n")

            f.write("\n---\n\n")
            f.write("*Generated by KNO Diagnostic System v1.0*\n")


class HermitianManifoldVisualizer:
    """
    Visualize Hermitian manifold deviations and operator state
    """

    def __init__(self, metrics: Dict[str, float]):
        self.metrics = metrics

    def plot_hermitian_deviation(self, output_file: Path):
        """Create visualization of Hermitian property deviations"""
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))

        # Plot 1: Hermitian deviation over time (simulated)
        ax1 = axes[0, 0]
        diff = self.metrics.get("Hermitianity Check_difference", 0.0)
        threshold = 1e-10

        # Simulate time series (in real use, this would come from history)
        times = np.linspace(0, 10, 50)
        deviations = diff * (1 + 0.1 * np.random.randn(50))
        deviations = np.maximum(0, deviations)  # Keep positive

        ax1.semilogy(times, deviations, 'b-', linewidth=2, label='Deviation')
        ax1.axhline(y=threshold, color='r', linestyle='--', label=f'Threshold ({threshold:.0e})')
        ax1.fill_between(times, 0, threshold, alpha=0.2, color='green', label='Valid region')
        ax1.set_xlabel('Time')
        ax1.set_ylabel('|⟨Ψ|LΨ⟩ - ⟨LΨ|Ψ⟩|')
        ax1.set_title('Hermitian Deviation Over Time')
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # Plot 2: Stability landscape
        ax2 = axes[0, 1]
        # Visualize V''(ω) around zeros
        stable_count = self.metrics.get("Potential Stability Validation_stable_minima", 0)
        total_count = self.metrics.get("Potential Stability Validation_total_minima", 1)

        categories = ['Stable', 'Unstable']
        counts = [stable_count, total_count - stable_count]
        colors = ['green', 'red']

        ax2.bar(categories, counts, color=colors, alpha=0.7)
        ax2.set_ylabel('Number of Zeros')
        ax2.set_title('Potential Stability Analysis')
        ax2.set_ylim(0, total_count + 1)

        for i, count in enumerate(counts):
            if count > 0:
                ax2.text(i, count + 0.1, f'{int(count)}', ha='center', va='bottom', fontweight='bold')

        # Plot 3: Spectral coherence
        ax3 = axes[1, 0]
        correlation = self.metrics.get("Spectral Coherence Test_correlation", 0.0)
        threshold_coherence = 0.995

        # Create gauge plot
        theta = np.linspace(0, np.pi, 100)
        r = 1.0

        # Background arc
        ax3.plot(r * np.cos(theta), r * np.sin(theta), 'k-', linewidth=3)

        # Threshold marker
        threshold_angle = threshold_coherence * np.pi
        ax3.plot([0, r * np.cos(threshold_angle)], [0, r * np.sin(threshold_angle)],
                'r--', linewidth=2, label=f'Threshold ({threshold_coherence})')

        # Current value
        current_angle = correlation * np.pi
        ax3.arrow(0, 0, 0.9 * r * np.cos(current_angle), 0.9 * r * np.sin(current_angle),
                 head_width=0.1, head_length=0.1, fc='blue', ec='blue', linewidth=2)

        ax3.text(0, -0.3, f'ρ = {correlation:.4f}', ha='center', fontsize=12, fontweight='bold')
        ax3.set_xlim(-1.2, 1.2)
        ax3.set_ylim(-0.5, 1.2)
        ax3.set_aspect('equal')
        ax3.axis('off')
        ax3.set_title('Spectral Coherence Gauge')
        ax3.legend(loc='upper right')

        # Plot 4: Topological invariants
        ax4 = axes[1, 1]
        berry_phase = self.metrics.get("Topological Integrity Check_berry_phase", 0.0)
        chern_number = self.metrics.get("Topological Integrity Check_chern_number", 0.0)

        # Scatter plot with target regions
        ax4.scatter([2*np.pi], [1.0], s=500, marker='o', facecolors='none',
                   edgecolors='green', linewidths=3, label='Target')
        ax4.scatter([berry_phase], [chern_number], s=200, marker='*',
                   color='blue', label='Measured', zorder=5)

        # Error ellipse
        berry_tol = 0.1
        chern_tol = 0.05
        ellipse = plt.matplotlib.patches.Ellipse((2*np.pi, 1.0), width=2*berry_tol,
                                                 height=2*chern_tol, fill=True,
                                                 alpha=0.2, color='green')
        ax4.add_patch(ellipse)

        ax4.set_xlabel('Berry Phase')
        ax4.set_ylabel('Chern Number')
        ax4.set_title('Topological Invariants')
        ax4.legend()
        ax4.grid(True, alpha=0.3)

        plt.suptitle('KNO Hermitian Manifold Diagnostics', fontsize=14, fontweight='bold')
        plt.tight_layout()
        plt.savefig(output_file, dpi=150, bbox_inches='tight')
        plt.close()

        print(f"✓ Hermitian manifold visualization saved: {output_file}")


def archive_failed_operator(operator_id: str, validation_report: dict, output_dir: Path):
    """Archive failed operator outputs for review"""
    if validation_report.get("overall_passed", False):
        return

    archive_dir = output_dir / "failed_operators" / operator_id
    archive_dir.mkdir(parents=True, exist_ok=True)

    # Save full validation report
    report_file = archive_dir / "validation_report.json"
    with open(report_file, 'w') as f:
        json.dump(validation_report, f, indent=2)

    # Create failure summary
    summary_file = archive_dir / "failure_summary.txt"
    with open(summary_file, 'w') as f:
        f.write(f"FAILED OPERATOR ARCHIVE\n")
        f.write(f"=" * 80 + "\n")
        f.write(f"Operator ID: {operator_id}\n")
        f.write(f"Timestamp: {validation_report.get('timestamp', 'Unknown')}\n")
        f.write(f"\nFailed Layers:\n")

        for layer_result in validation_report.get("layer_results", []):
            if not layer_result.get("passed", False):
                f.write(f"  - {layer_result.get('layer_name', 'Unknown')}\n")
                f.write(f"    Error: {layer_result.get('error_message', 'No message')}\n")

        f.write(f"\nAlerts Triggered:\n")
        for alert in validation_report.get("alerts_triggered", []):
            f.write(f"  - {alert}\n")

    print(f"✓ Failed operator archived: {archive_dir}")


def main():
    """Standalone diagnostic execution"""
    print("=" * 80)
    print("KNO Diagnostic System")
    print("=" * 80)
    print()

    # Try loading from validation layers first (newer format)
    report_file = Path("reports/validation/validation_summary.json")

    # Fall back to legacy location
    if not report_file.exists():
        report_file = Path("telemetry/kno/kno_validation_results.json")

    if not report_file.exists():
        print(f"No validation report found at {report_file}")
        print("Running with example data...")

        # Create example report
        example_report = {
            "operator_id": "kno_test_diagnostic",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "commit_ref": "test",
            "layer_results": [
                {
                    "layer_name": "Hermitianity Check",
                    "method": "Conjugate transpose",
                    "passed": True,
                    "metric_value": 1e-12,
                    "threshold": 1e-10,
                    "details": {"difference": 1e-12}
                },
                {
                    "layer_name": "Potential Stability Validation",
                    "method": "V'' test",
                    "passed": True,
                    "metric_value": 1.0,
                    "threshold": 1.0,
                    "details": {"stable_minima": 3.0, "total_minima": 3.0, "stability_ratio": 1.0}
                },
                {
                    "layer_name": "Spectral Coherence Test",
                    "method": "Correlation",
                    "passed": True,
                    "metric_value": 0.998,
                    "threshold": 0.995,
                    "details": {"correlation": 0.998}
                },
                {
                    "layer_name": "Topological Integrity Check",
                    "method": "Berry/Chern",
                    "passed": True,
                    "metric_value": 1.0,
                    "threshold": 1.0,
                    "details": {
                        "berry_phase": 6.28,
                        "chern_number": 1.0,
                        "berry_phase_error": 0.003,
                        "chern_number_error": 0.0
                    }
                },
                {
                    "layer_name": "Divergence Detection",
                    "method": "Amplitude bound",
                    "passed": True,
                    "metric_value": 2.5,
                    "threshold": 1000.0,
                    "details": {"max_amplitude": 2.5, "mean_amplitude": 2.0}
                }
            ],
            "overall_passed": True,
            "alerts_triggered": []
        }

        report = example_report
    else:
        try:
            with open(report_file) as f:
                report = json.load(f)
        except json.JSONDecodeError as e:
            print(f"⚠ Warning: Invalid JSON in {report_file}: {e}")
            print("Running with example data instead...")
            report = example_report

    # Generate diagnostics
    reporter = DiagnosticReporter(report)
    summary = reporter.generate_summary()

    print("Diagnostic Summary:")
    print(f"  Operator: {summary.operator_id}")
    print(f"  Status: {summary.overall_status}")
    print(f"  Layers: {summary.layers_passed}/{summary.total_layers} passed")
    print(f"  Alerts: {summary.alerts_critical} critical, {summary.alerts_warning} warning")
    print()

    # Save dashboard
    output_dir = Path("reports/diagnostics")
    reporter.save_dashboard(output_dir)

    # Generate visualization
    visualizer = HermitianManifoldVisualizer(summary.metrics)
    viz_file = output_dir / "hermitian_manifold_diagnostics.png"
    visualizer.plot_hermitian_deviation(viz_file)

    # Archive if failed
    if not report.get("overall_passed", False):
        archive_failed_operator(summary.operator_id, report, output_dir)

    sys.exit(0 if summary.overall_status == "PASSED" else 1)


if __name__ == "__main__":
    main()
