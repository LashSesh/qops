#!/usr/bin/env python3
"""
Integrated Result Fusion

Fuses HPM, polynomial, and metric data to build complete resonance map.
Creates unified validation report across all analysis domains.
"""

import json
import argparse
import sys
from pathlib import Path
from typing import Dict, List, Any
from datetime import datetime

class ResultFusion:
    """Fuses multiple analysis results into integrated validation"""

    def __init__(self):
        self.hpm_data = {}
        self.polynomial_data = {}
        self.hypercube_data = {}

    def load_results(self, hpm_path: str, polynomial_path: str, hypercube_path: str) -> bool:
        """Load all result files"""
        print("[LOAD] Loading analysis results...")

        # Load HPM results
        hpm_file = Path(hpm_path)
        if not hpm_file.exists():
            print(f"[ERROR] HPM results not found: {hpm_path}")
            return False
        with open(hpm_file, 'r') as f:
            self.hpm_data = json.load(f)

        # Load polynomial results
        poly_file = Path(polynomial_path)
        if not poly_file.exists():
            print(f"[ERROR] Polynomial results not found: {polynomial_path}")
            return False
        with open(poly_file, 'r') as f:
            self.polynomial_data = json.load(f)

        # Load hypercube results
        hyper_file = Path(hypercube_path)
        if not hyper_file.exists():
            print(f"[ERROR] Hypercube results not found: {hypercube_path}")
            return False
        with open(hyper_file, 'r') as f:
            self.hypercube_data = json.load(f)

        print("[LOAD] All results loaded successfully")
        return True

    def _compute_cross_domain_coherence(self) -> Dict[str, Any]:
        """
        Compute coherence metrics across different analysis domains.
        Measures consistency between HPM, polynomial, and topological results.
        """
        print("[COHERENCE] Computing cross-domain coherence...")

        # HPM alignment score
        hpm_alignment = self.hpm_data.get('alignment', {}).get('alignment_score', 0.0)

        # Polynomial alignment error (inverted to score)
        poly_error = self.polynomial_data.get('riemann_alignment', {}).get('error', 1.0)
        poly_alignment = max(0.0, 1.0 - poly_error)

        # Topological integrality (Chern number)
        chern_error = self.hypercube_data.get('chern_number', {}).get('integrality_error', 1.0)
        topo_alignment = max(0.0, 1.0 - chern_error * 100)  # Scale error

        # Overall coherence score (weighted average)
        weights = [0.4, 0.3, 0.3]  # HPM, Polynomial, Topology
        overall_coherence = (
            weights[0] * hpm_alignment +
            weights[1] * poly_alignment +
            weights[2] * topo_alignment
        )

        # Variance across domains
        scores = [hpm_alignment, poly_alignment, topo_alignment]
        coherence_variance = sum((s - overall_coherence)**2 for s in scores) / len(scores)
        coherence_std = coherence_variance**0.5

        print(f"[COHERENCE] HPM alignment:        {hpm_alignment:.6f}")
        print(f"[COHERENCE] Polynomial alignment: {poly_alignment:.6f}")
        print(f"[COHERENCE] Topology alignment:   {topo_alignment:.6f}")
        print(f"[COHERENCE] Overall coherence:    {overall_coherence:.6f}")
        print(f"[COHERENCE] Coherence std dev:    {coherence_std:.6f}")

        return {
            "hpm_alignment_score": hpm_alignment,
            "polynomial_alignment_score": poly_alignment,
            "topology_alignment_score": topo_alignment,
            "overall_coherence_score": overall_coherence,
            "coherence_std_dev": coherence_std,
            "coherence_variance_percent": (coherence_std / overall_coherence * 100) if overall_coherence > 0 else 100
        }

    def _build_resonance_map(self) -> Dict[str, Any]:
        """
        Build complete resonance map integrating all domains.
        """
        print("[MAP] Building resonance map...")

        # Extract key features from each domain
        resonance_map = {
            "spectral_domain": {
                "eigenvalue_count": self.hpm_data.get('eigenvalue_count', 0),
                "self_adjoint": self.hpm_data.get('self_adjoint', {}).get('is_hermitian', False),
                "spectrum_symmetric": self.hpm_data.get('spectral_symmetry', {}).get('is_symmetric', False),
                "eigenvalue_variance": self.hpm_data.get('eigenvalue_statistics', {}).get('real_variance', 0)
            },
            "potential_domain": {
                "polynomial_degree": self.polynomial_data.get('polynomial_degree', 0),
                "riemann_error": self.polynomial_data.get('riemann_alignment', {}).get('error', 1.0),
                "entropy_drift": self.polynomial_data.get('entropy', {}).get('drift', 0),
                "potential_stability": self.polynomial_data.get('stability', {})
            },
            "topological_domain": {
                "chern_number": self.hypercube_data.get('chern_number', {}).get('value', 0),
                "berry_phase": self.hypercube_data.get('berry_phase', {}).get('value', 0),
                "euler_characteristic": self.hypercube_data.get('topological_invariants', {}).get('euler_characteristic', 0)
            }
        }

        return resonance_map

    def _perform_integrated_validation(self, coherence: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform integrated validation across all domains.
        """
        print("[VALIDATE] Performing integrated validation...")

        # Individual domain validations
        hpm_valid = self.hpm_data.get('validation', {}).get('passed', False)
        poly_valid = self.polynomial_data.get('validation', {}).get('passed', False)
        hyper_valid = self.hypercube_data.get('validation', {}).get('passed', False)

        # Cross-domain validation criteria
        variance_threshold = 5.0  # Max 5% variance across domains
        coherence_threshold = 0.98  # Min 98% coherence

        variance_ok = coherence['coherence_variance_percent'] < variance_threshold
        coherence_ok = coherence['overall_coherence_score'] >= coherence_threshold

        validation = {
            "domain_validations": {
                "hilbert_polya": hpm_valid,
                "polynomial_potential": poly_valid,
                "hypercube_metric": hyper_valid
            },
            "cross_domain_validation": {
                "variance_across_resolutions": coherence['coherence_variance_percent'],
                "variance_acceptable": variance_ok,
                "spectral_coherence_ratio": coherence['overall_coherence_score'],
                "coherence_acceptable": coherence_ok
            },
            "overall_passed": all([
                hpm_valid,
                poly_valid,
                hyper_valid,
                variance_ok,
                coherence_ok
            ])
        }

        print(f"[VALIDATE] HPM validation:        {'✓' if hpm_valid else '✗'}")
        print(f"[VALIDATE] Polynomial validation: {'✓' if poly_valid else '✗'}")
        print(f"[VALIDATE] Hypercube validation:  {'✓' if hyper_valid else '✗'}")
        print(f"[VALIDATE] Variance check:        {'✓' if variance_ok else '✗'}")
        print(f"[VALIDATE] Coherence check:       {'✓' if coherence_ok else '✗'}")
        print(f"[VALIDATE] Overall:               {'✓ PASSED' if validation['overall_passed'] else '✗ FAILED'}")

        return validation

    def run_fusion(self, hpm_path: str, polynomial_path: str, hypercube_path: str,
                   output_path: str) -> int:
        """Run complete result fusion"""
        print("=" * 80)
        print("Integrated Result Fusion")
        print("=" * 80)

        # Load all results
        if not self.load_results(hpm_path, polynomial_path, hypercube_path):
            print("[ERROR] Failed to load all required results")
            return 1

        # Compute cross-domain coherence
        coherence = self._compute_cross_domain_coherence()

        # Build resonance map
        resonance_map = self._build_resonance_map()

        # Perform integrated validation
        validation = self._perform_integrated_validation(coherence)

        # Build integrated results
        results = {
            "integration": "Unified_HPM_Pipeline",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "source_files": {
                "hpm_results": hpm_path,
                "polynomial_results": polynomial_path,
                "hypercube_results": hypercube_path
            },
            "cross_domain_coherence": coherence,
            "resonance_map": resonance_map,
            "integrated_validation": validation,
            "summary": {
                "data_ready_for_visualization": validation['overall_passed'],
                "spectral_coherence_ratio": coherence['overall_coherence_score'],
                "variance_across_resolutions": coherence['coherence_variance_percent'],
                "scientific_value": [
                    "cross-verified numerical and topological evidence for Riemann alignment",
                    "empirical Hilbert-Pólya spectral mapping",
                    "topological invariant confirmation"
                ]
            }
        }

        # Save results
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        with open(output_file, 'w') as f:
            json.dump(results, f, indent=2)

        print(f"\n[OUTPUT] Integrated results saved to: {output_file}")

        # Print summary
        print("\n" + "=" * 80)
        print("INTEGRATION SUMMARY")
        print("=" * 80)
        print(f"Overall Coherence:     {coherence['overall_coherence_score']:.6f}")
        print(f"Cross-Domain Variance: {coherence['coherence_variance_percent']:.2f}%")
        print(f"Data Ready:            {'Yes' if validation['overall_passed'] else 'No'}")
        print(f"\nValidation: {'✓ PASSED' if validation['overall_passed'] else '✗ FAILED'}")
        print("=" * 80)

        return 0 if validation['overall_passed'] else 1

def main():
    parser = argparse.ArgumentParser(
        description='Integrated Result Fusion'
    )
    parser.add_argument('--inputs', nargs=3, required=True,
                        metavar=('HPM', 'POLY', 'HYPER'),
                        help='Input files: hpm_results.json polynomial_results.json hypercube_results.json')
    parser.add_argument('--output', type=str, required=True,
                        help='Output integrated validation file (JSON)')

    args = parser.parse_args()

    fusion = ResultFusion()
    return fusion.run_fusion(args.inputs[0], args.inputs[1], args.inputs[2], args.output)

if __name__ == '__main__':
    sys.exit(main())
