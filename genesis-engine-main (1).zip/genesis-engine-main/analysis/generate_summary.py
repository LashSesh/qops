#!/usr/bin/env python3
"""
UHP Audit and Summary Generation

Generates global summary and coherence audit for complete CI run.
Combines integrated validation with performance benchmarks.
"""

import json
import argparse
import sys
from pathlib import Path
from typing import Dict, List, Any
from datetime import datetime

class UHPAuditGenerator:
    """Generates comprehensive audit for Unified HPM Pipeline"""

    def __init__(self):
        self.integrated_data = {}
        self.performance_data = {}

    def load_data(self, integrated_path: str, performance_path: str) -> bool:
        """Load integrated validation and performance data"""
        print("[LOAD] Loading pipeline results...")

        # Load integrated validation
        integrated_file = Path(integrated_path)
        if not integrated_file.exists():
            print(f"[ERROR] Integrated validation not found: {integrated_path}")
            return False
        with open(integrated_file, 'r') as f:
            self.integrated_data = json.load(f)

        # Load performance summary
        perf_file = Path(performance_path)
        if not perf_file.exists():
            print(f"[ERROR] Performance summary not found: {performance_path}")
            return False
        with open(perf_file, 'r') as f:
            self.performance_data = json.load(f)

        print("[LOAD] All data loaded successfully")
        return True

    def _generate_executive_summary(self) -> Dict[str, Any]:
        """Generate executive summary of entire pipeline"""
        print("[SUMMARY] Generating executive summary...")

        # Validation status
        validation_passed = self.integrated_data.get('integrated_validation', {}).get('overall_passed', False)

        # Performance metrics
        sustained_throughput = self.performance_data.get('summary', {}).get('sustained_throughput_ops_per_sec', 0)
        variance = self.performance_data.get('summary', {}).get('variance_percent', 0)

        # Spectral metrics
        coherence = self.integrated_data.get('cross_domain_coherence', {}).get('overall_coherence_score', 0)

        # HPM metrics
        resonance_map = self.integrated_data.get('resonance_map', {})
        hpm_eigenvalues = resonance_map.get('spectral_domain', {}).get('eigenvalue_count', 0)
        chern_number = resonance_map.get('topological_domain', {}).get('chern_number', 0)

        summary = {
            "pipeline": "Unified_Genesis_Hilbert_Polya_Metatron_Pipeline",
            "version": "1.0",
            "execution_timestamp": datetime.utcnow().isoformat() + "Z",
            "overall_status": "PASSED" if validation_passed else "FAILED",
            "key_achievements": {
                "operators_generated": self.integrated_data.get('resonance_map', {}).get('spectral_domain', {}).get('eigenvalue_count', 0),
                "eigenvalues_computed": hpm_eigenvalues,
                "chern_number": chern_number,
                "sustained_throughput": sustained_throughput,
                "spectral_coherence": coherence
            },
            "performance_profile": {
                "sustained_throughput_ops_per_sec": sustained_throughput,
                "peak_throughput_ops_per_sec": self.performance_data.get('summary', {}).get('peak_throughput_ops_per_sec', 0),
                "variance_percent": variance,
                "target_range_met": 800 <= sustained_throughput <= 1500
            },
            "scientific_validation": {
                "hilbert_polya_verified": self.integrated_data.get('integrated_validation', {}).get('domain_validations', {}).get('hilbert_polya', False),
                "polynomial_potential_validated": self.integrated_data.get('integrated_validation', {}).get('domain_validations', {}).get('polynomial_potential', False),
                "topological_invariants_confirmed": self.integrated_data.get('integrated_validation', {}).get('domain_validations', {}).get('hypercube_metric', False),
                "cross_domain_coherence": coherence
            }
        }

        return summary

    def _perform_coherence_audit(self) -> Dict[str, Any]:
        """Perform detailed coherence audit"""
        print("[AUDIT] Performing coherence audit...")

        # Extract validation details
        domain_validations = self.integrated_data.get('integrated_validation', {}).get('domain_validations', {})
        cross_domain = self.integrated_data.get('integrated_validation', {}).get('cross_domain_validation', {})
        coherence = self.integrated_data.get('cross_domain_coherence', {})

        # Performance validation
        perf_validation = self.performance_data.get('validation', {})

        # Build audit trail
        audit = {
            "validation_chain": {
                "stage_01_operator_generation": {
                    "status": "COMPLETED",
                    "operators_generated": self.integrated_data.get('resonance_map', {}).get('spectral_domain', {}).get('eigenvalue_count', 0)
                },
                "stage_02_hpm_verification": {
                    "status": "PASSED" if domain_validations.get('hilbert_polya', False) else "FAILED",
                    "self_adjoint": self.integrated_data.get('resonance_map', {}).get('spectral_domain', {}).get('self_adjoint', False),
                    "spectrum_symmetric": self.integrated_data.get('resonance_map', {}).get('spectral_domain', {}).get('spectrum_symmetric', False)
                },
                "stage_03_polynomial_validation": {
                    "status": "PASSED" if domain_validations.get('polynomial_potential', False) else "FAILED",
                    "riemann_error": self.integrated_data.get('resonance_map', {}).get('potential_domain', {}).get('riemann_error', 1.0),
                    "entropy_drift": self.integrated_data.get('resonance_map', {}).get('potential_domain', {}).get('entropy_drift', 0)
                },
                "stage_04_topology_analysis": {
                    "status": "PASSED" if domain_validations.get('hypercube_metric', False) else "FAILED",
                    "chern_number": self.integrated_data.get('resonance_map', {}).get('topological_domain', {}).get('chern_number', 0),
                    "berry_phase": self.integrated_data.get('resonance_map', {}).get('topological_domain', {}).get('berry_phase', 0)
                },
                "stage_05_integration": {
                    "status": "PASSED" if cross_domain.get('variance_acceptable', False) and cross_domain.get('coherence_acceptable', False) else "FAILED",
                    "coherence_score": coherence.get('overall_coherence_score', 0),
                    "variance_percent": coherence.get('coherence_variance_percent', 0)
                },
                "stage_06_performance": {
                    "status": "PASSED" if perf_validation.get('passed', False) else "FAILED",
                    "sustained_throughput": self.performance_data.get('summary', {}).get('sustained_throughput_ops_per_sec', 0),
                    "variance": self.performance_data.get('summary', {}).get('variance_percent', 0)
                }
            },
            "coherence_metrics": {
                "cross_domain_coherence": coherence.get('overall_coherence_score', 0),
                "spectral_stability": self.performance_data.get('summary', {}).get('spectral_stability', {}),
                "variance_across_resolutions": coherence.get('coherence_variance_percent', 0),
                "overall_coherence_ratio": cross_domain.get('spectral_coherence_ratio', 0)
            },
            "quality_scores": {
                "data_integrity": 1.0 if all(domain_validations.values()) else 0.5,
                "numerical_precision": coherence.get('overall_coherence_score', 0),
                "performance_consistency": 1.0 - (self.performance_data.get('summary', {}).get('variance_percent', 0) / 100.0),
                "scientific_rigor": coherence.get('overall_coherence_score', 0)
            }
        }

        # Calculate overall quality score
        quality_values = list(audit['quality_scores'].values())
        audit['overall_quality_score'] = sum(quality_values) / len(quality_values) if quality_values else 0.0

        return audit

    def _generate_recommendations(self, audit: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on audit results"""
        recommendations = []

        # Check sustained throughput
        sustained_tp = self.performance_data.get('summary', {}).get('sustained_throughput_ops_per_sec', 0)
        if sustained_tp < 800:
            recommendations.append(
                f"⚠ Sustained throughput ({sustained_tp:.0f} ops/sec) below target (800-1500). "
                "Consider optimizing operator generation pipeline."
            )
        elif sustained_tp > 1500:
            recommendations.append(
                f"✓ Sustained throughput ({sustained_tp:.0f} ops/sec) exceeds target. "
                "Pipeline is performing excellently."
            )

        # Check variance
        variance = self.performance_data.get('summary', {}).get('variance_percent', 0)
        if variance > 5.0:
            recommendations.append(
                f"⚠ Performance variance ({variance:.2f}%) exceeds 5% threshold. "
                "Consider longer warmup period or load stabilization."
            )

        # Check coherence
        coherence = audit['coherence_metrics']['cross_domain_coherence']
        if coherence < 0.98:
            recommendations.append(
                f"⚠ Cross-domain coherence ({coherence:.4f}) below 0.98 threshold. "
                "Review HPM-polynomial-topology alignment."
            )

        # Check quality score
        quality = audit['overall_quality_score']
        if quality < 0.95:
            recommendations.append(
                f"⚠ Overall quality score ({quality:.4f}) below 0.95. "
                "Review failed validation stages and numerical precision."
            )

        # Add positive recommendations
        if not recommendations:
            recommendations.append(
                "✓ All metrics within target ranges. Pipeline is operating optimally."
            )

        return recommendations

    def _collect_artifacts(self) -> Dict[str, str]:
        """List all generated artifacts"""
        return {
            "operators": "operators.ndjson.gz",
            "hpm_results": "hpm_results.json",
            "hpm_eigenvalues": "hpm_results_eigenvalues.json",
            "polynomial_results": "polynomial_results.json",
            "hypercube_results": "hypercube_results.json",
            "integrated_validation": "integrated_validation.json",
            "performance_summary": "perf_summary.json",
            "performance_telemetry": "perf_summary_telemetry.ndjson.gz",
            "audit_report": "uhp_audit.json"
        }

    def run_audit(self, integrated_path: str, performance_path: str, output_path: str) -> int:
        """Run complete audit generation"""
        print("=" * 80)
        print("UHP Audit and Summary Generation")
        print("=" * 80)

        # Load data
        if not self.load_data(integrated_path, performance_path):
            print("[ERROR] Failed to load required data")
            return 1

        # Generate executive summary
        executive_summary = self._generate_executive_summary()

        # Perform coherence audit
        coherence_audit = self._perform_coherence_audit()

        # Generate recommendations
        recommendations = self._generate_recommendations(coherence_audit)

        # Collect artifacts
        artifacts = self._collect_artifacts()

        # Build complete audit report
        audit_report = {
            "audit": "Unified_Hilbert_Polya_Metatron_Pipeline_Audit",
            "version": "1.0",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "executive_summary": executive_summary,
            "coherence_audit": coherence_audit,
            "recommendations": recommendations,
            "artifacts": artifacts,
            "metadata": {
                "pipeline_stages": 9,
                "validation_criteria_count": 15,
                "total_processing_time_estimate": "10-20 minutes",
                "data_ready_for_visualization": self.integrated_data.get('summary', {}).get('data_ready_for_visualization', False)
            }
        }

        # Save audit report
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        with open(output_file, 'w') as f:
            json.dump(audit_report, f, indent=2)

        print(f"\n[OUTPUT] Audit report saved to: {output_file}")

        # Print summary
        print("\n" + "=" * 80)
        print("AUDIT SUMMARY")
        print("=" * 80)
        print(f"Pipeline Status:       {executive_summary['overall_status']}")
        print(f"Overall Quality Score: {coherence_audit['overall_quality_score']:.4f}")
        print(f"Sustained Throughput:  {executive_summary['performance_profile']['sustained_throughput_ops_per_sec']:.1f} ops/sec")
        print(f"Spectral Coherence:    {executive_summary['key_achievements']['spectral_coherence']:.4f}")
        print(f"Chern Number:          {executive_summary['key_achievements']['chern_number']:.4f}")
        print(f"\nRecommendations ({len(recommendations)}):")
        for i, rec in enumerate(recommendations, 1):
            print(f"  {i}. {rec}")
        print("=" * 80)

        # Return success if overall status is PASSED
        return 0 if executive_summary['overall_status'] == "PASSED" else 1

def main():
    parser = argparse.ArgumentParser(
        description='UHP Audit and Summary Generation'
    )
    parser.add_argument('--inputs', nargs=2, required=True,
                        metavar=('INTEGRATED', 'PERFORMANCE'),
                        help='Input files: integrated_validation.json perf_summary.json')
    parser.add_argument('--output', type=str, required=True,
                        help='Output audit report file (JSON)')

    args = parser.parse_args()

    generator = UHPAuditGenerator()
    return generator.run_audit(args.inputs[0], args.inputs[1], args.output)

if __name__ == '__main__':
    sys.exit(main())
