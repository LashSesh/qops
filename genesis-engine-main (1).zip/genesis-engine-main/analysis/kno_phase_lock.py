#!/usr/bin/env python3
"""
KNO Phase-Lock Integration Module

Simulates Ψ(t), Φ(t) trajectories and locates stationary points where ω̇=0.
Implements the phase dynamics:
    Ψ̇ = -i LΦ(K) Ψ
    Φ̇ = -∂_ω V_poly(ω)

Finds phase-locked states where the system reaches equilibrium.
"""

import numpy as np
import json
import sys
from pathlib import Path
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass, asdict
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt


@dataclass
class PhaseLockState:
    """State of a phase-locked operator"""
    time: float
    psi_magnitude: float
    psi_phase: float
    phi: float
    omega: float
    omega_dot: float
    is_locked: bool
    stability_index: float


@dataclass
class PhaseLockResult:
    """Results from phase-lock integration"""
    operator_id: str
    total_time: float
    timesteps: int
    locked_states: List[PhaseLockState]
    convergence_rate: float
    final_omega: float
    final_omega_dot: float
    equilibrium_reached: bool
    energy_drift: float
    phase_coherence: float


class PhaseLockIntegrator:
    """
    Integrates phase dynamics to find stationary points
    """

    def __init__(self, riemann_zeros: List[float], kappa: float = 1.0,
                 primes: List[int] = None, dt: float = 0.01):
        """
        Initialize phase-lock integrator

        Args:
            riemann_zeros: Riemann zero imaginary parts
            kappa: Coupling constant
            primes: Prime numbers for phase field
            dt: Time step for integration
        """
        self.riemann_zeros = np.array(riemann_zeros)
        self.kappa = kappa
        self.dt = dt

        if primes is None:
            primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]
        self.primes = np.array(primes)

    def evaluate_psi(self, t: float) -> complex:
        """
        Evaluate Ψ(t) = Σ_p p^{-1/2} e^{i t log p}
        """
        psi = 0.0 + 0.0j
        for p in self.primes:
            amplitude = 1.0 / np.sqrt(p)
            phase = t * np.log(p)
            psi += amplitude * np.exp(1j * phase)
        return psi

    def compute_dpsi_dt(self, t: float) -> complex:
        """
        Compute dΨ/dt = i Σ_p p^{-1/2} log(p) e^{i t log p}
        """
        dpsi_dt = 0.0 + 0.0j
        for p in self.primes:
            amplitude = 1.0 / np.sqrt(p)
            log_p = np.log(p)
            phase = t * log_p
            dpsi_dt += 1j * amplitude * log_p * np.exp(1j * phase)
        return dpsi_dt

    def evaluate_potential(self, omega: float) -> float:
        """
        Evaluate V_poly(ω) = κ ∏(ω - γ_n)^2
        """
        product = np.prod((omega - self.riemann_zeros) ** 2)
        return self.kappa * product

    def evaluate_potential_derivative(self, omega: float) -> float:
        """
        Evaluate V'(ω)
        """
        result = 0.0
        for i, gamma_i in enumerate(self.riemann_zeros):
            term = 2.0 * (omega - gamma_i)
            for j, gamma_j in enumerate(self.riemann_zeros):
                if i != j:
                    term *= (omega - gamma_j) ** 2
            result += term
        return self.kappa * result

    def evaluate_potential_second_derivative(self, omega: float) -> float:
        """
        Evaluate V''(ω)
        """
        n = len(self.riemann_zeros)
        result = 0.0

        for i, gamma_i in enumerate(self.riemann_zeros):
            term1 = 2.0
            for j, gamma_j in enumerate(self.riemann_zeros):
                if i != j:
                    term1 *= (omega - gamma_j) ** 2
            result += term1

            for k, gamma_k in enumerate(self.riemann_zeros):
                if k != i:
                    term2 = 4.0 * (omega - gamma_i) * 2.0 * (omega - gamma_k)
                    for j, gamma_j in enumerate(self.riemann_zeros):
                        if j != i and j != k:
                            term2 *= (omega - gamma_j) ** 2
                    result += term2

        return self.kappa * result

    def compute_omega(self, phi_history: List[float], time_history: List[float]) -> float:
        """
        Compute frequency ω = dΦ/dt from phase history
        """
        if len(phi_history) < 2:
            return 0.0

        # Use last few points for better estimate
        n_points = min(5, len(phi_history))
        dphi = np.diff(phi_history[-n_points:])
        dt = np.diff(time_history[-n_points:])

        # Handle phase wrapping
        dphi = np.where(dphi > np.pi, dphi - 2*np.pi, dphi)
        dphi = np.where(dphi < -np.pi, dphi + 2*np.pi, dphi)

        omega = np.mean(dphi / dt) if len(dt) > 0 else 0.0
        return omega

    def integrate_trajectory(self, t_max: float, lock_tolerance: float = 1e-6,
                           check_interval: int = 10) -> PhaseLockResult:
        """
        Integrate phase dynamics until phase-lock or t_max

        Args:
            t_max: Maximum integration time
            lock_tolerance: Tolerance for phase-lock detection (|ω̇| < tolerance)
            check_interval: Check for phase-lock every N steps

        Returns:
            PhaseLockResult with trajectory and locked states
        """
        operator_id = f"kno_phase_lock_{np.random.randint(10000):04d}"

        # Storage
        time_history = [0.0]
        psi_history = [self.evaluate_psi(0.0)]
        phi_history = [np.angle(psi_history[0])]
        omega_history = [0.0]
        locked_states = []

        t = 0.0
        step = 0
        equilibrium_reached = False

        # Integration loop
        while t < t_max:
            t += self.dt
            step += 1

            # Evaluate wave function
            psi = self.evaluate_psi(t)
            phi = np.angle(psi)

            # Store history
            psi_history.append(psi)
            phi_history.append(phi)
            time_history.append(t)

            # Compute frequency
            omega = self.compute_omega(phi_history, time_history)
            omega_history.append(omega)

            # Check for phase-lock periodically
            if step % check_interval == 0:
                v_pp = self.evaluate_potential_second_derivative(omega)
                omega_dot = -v_pp  # From equation: ω̇ = -∂_ω V_poly(ω)

                is_locked = np.abs(omega_dot) < lock_tolerance
                stability_index = v_pp  # Positive = stable

                # Create phase-lock state
                state = PhaseLockState(
                    time=t,
                    psi_magnitude=np.abs(psi),
                    psi_phase=phi,
                    phi=phi,
                    omega=omega,
                    omega_dot=omega_dot,
                    is_locked=is_locked,
                    stability_index=stability_index
                )

                if is_locked:
                    locked_states.append(state)

                    # Check if we've reached stable equilibrium
                    if len(locked_states) >= 5:
                        recent_omegas = [s.omega for s in locked_states[-5:]]
                        omega_variance = np.var(recent_omegas)

                        if omega_variance < lock_tolerance:
                            equilibrium_reached = True
                            print(f"  Equilibrium reached at t={t:.3f}, ω={omega:.6f}")
                            break

        # Compute metrics
        convergence_rate = self._compute_convergence_rate(omega_history, time_history)
        energy_drift = self._compute_energy_drift(psi_history)
        phase_coherence = self._compute_phase_coherence(phi_history)

        final_omega = omega_history[-1] if omega_history else 0.0
        v_pp_final = self.evaluate_potential_second_derivative(final_omega)
        final_omega_dot = -v_pp_final

        return PhaseLockResult(
            operator_id=operator_id,
            total_time=t,
            timesteps=step,
            locked_states=locked_states,
            convergence_rate=convergence_rate,
            final_omega=final_omega,
            final_omega_dot=final_omega_dot,
            equilibrium_reached=equilibrium_reached,
            energy_drift=energy_drift,
            phase_coherence=phase_coherence
        )

    def _compute_convergence_rate(self, omega_history: List[float],
                                  time_history: List[float]) -> float:
        """
        Compute convergence rate of ω to equilibrium
        """
        if len(omega_history) < 10:
            return 0.0

        # Fit exponential decay to |ω - ω_equilibrium|
        omega_arr = np.array(omega_history)
        omega_eq = omega_arr[-1]  # Assume last value is near equilibrium

        deviation = np.abs(omega_arr - omega_eq)
        log_deviation = np.log(deviation + 1e-12)

        # Linear fit in log space: log(dev) = log(A) - λt
        if len(log_deviation) >= 2:
            time_arr = np.array(time_history)
            coeffs = np.polyfit(time_arr, log_deviation, 1)
            convergence_rate = -coeffs[0]  # λ
            return max(0.0, convergence_rate)

        return 0.0

    def _compute_energy_drift(self, psi_history: List[complex]) -> float:
        """
        Compute energy drift: change in |Ψ|^2 over time
        """
        if len(psi_history) < 2:
            return 0.0

        magnitudes = np.array([np.abs(psi)**2 for psi in psi_history])
        drift = np.std(magnitudes) / np.mean(magnitudes) if np.mean(magnitudes) > 0 else 0.0
        return drift

    def _compute_phase_coherence(self, phi_history: List[float]) -> float:
        """
        Compute phase coherence: measure of phase stability
        """
        if len(phi_history) < 10:
            return 0.0

        # Use last 100 points
        phi_arr = np.array(phi_history[-100:])

        # Unwrap phase
        phi_unwrapped = np.unwrap(phi_arr)

        # Measure linearity (coherent phase evolution)
        t = np.arange(len(phi_unwrapped))
        coeffs = np.polyfit(t, phi_unwrapped, 1)
        residuals = phi_unwrapped - (coeffs[0] * t + coeffs[1])

        coherence = np.exp(-np.std(residuals))
        return coherence

    def visualize_trajectory(self, result: PhaseLockResult, output_path: Path):
        """
        Create visualization of phase-lock trajectory
        """
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))

        # Extract data
        times = [s.time for s in result.locked_states]
        omegas = [s.omega for s in result.locked_states]
        omega_dots = [s.omega_dot for s in result.locked_states]
        psi_mags = [s.psi_magnitude for s in result.locked_states]
        phis = [s.phi for s in result.locked_states]

        if len(times) == 0:
            print("Warning: No locked states to visualize")
            return

        # Plot 1: Frequency evolution
        axes[0, 0].plot(times, omegas, 'b-', linewidth=2)
        axes[0, 0].set_xlabel('Time t')
        axes[0, 0].set_ylabel('Frequency ω(t)')
        axes[0, 0].set_title('Frequency Evolution')
        axes[0, 0].grid(True, alpha=0.3)

        # Plot 2: Frequency derivative (phase-lock indicator)
        axes[0, 1].plot(times, omega_dots, 'r-', linewidth=2)
        axes[0, 1].axhline(y=0, color='k', linestyle='--', alpha=0.5)
        axes[0, 1].set_xlabel('Time t')
        axes[0, 1].set_ylabel('ω̇ = -V\'\'(ω)')
        axes[0, 1].set_title('Phase-Lock Indicator (ω̇ → 0)')
        axes[0, 1].grid(True, alpha=0.3)
        axes[0, 1].set_yscale('symlog', linthresh=1e-6)

        # Plot 3: Wave function magnitude
        axes[1, 0].plot(times, psi_mags, 'g-', linewidth=2)
        axes[1, 0].set_xlabel('Time t')
        axes[1, 0].set_ylabel('|Ψ(t)|')
        axes[1, 0].set_title('Wave Function Magnitude')
        axes[1, 0].grid(True, alpha=0.3)

        # Plot 4: Phase evolution
        axes[1, 1].plot(times, phis, 'm-', linewidth=2)
        axes[1, 1].set_xlabel('Time t')
        axes[1, 1].set_ylabel('Φ(t)')
        axes[1, 1].set_title('Phase Evolution')
        axes[1, 1].grid(True, alpha=0.3)

        plt.suptitle(f'KNO Phase-Lock Trajectory: {result.operator_id}', fontsize=14, fontweight='bold')
        plt.tight_layout()
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()

        print(f"  Trajectory visualization saved to: {output_path}")


def main():
    """Main phase-lock integration entry point"""
    # First 10 non-trivial Riemann zeros
    riemann_zeros = [
        14.134725, 21.022040, 25.010858, 30.424876, 32.935062,
        37.586178, 40.918719, 43.327073, 48.005151, 49.773832
    ]

    print("=" * 80)
    print("KNO Phase-Lock Integration")
    print("=" * 80)
    print()

    # Initialize integrator
    integrator = PhaseLockIntegrator(riemann_zeros, kappa=1.0, dt=0.01)

    # Run integration
    print("Integrating phase dynamics...")
    print("  Looking for stationary points where ω̇ = 0...")
    print()

    result = integrator.integrate_trajectory(
        t_max=50.0,
        lock_tolerance=1e-6,
        check_interval=10
    )

    # Display results
    print()
    print("Phase-Lock Integration Results:")
    print("-" * 80)
    print(f"Operator ID:           {result.operator_id}")
    print(f"Total Time:            {result.total_time:.3f}")
    print(f"Timesteps:             {result.timesteps}")
    print(f"Locked States Found:   {len(result.locked_states)}")
    print(f"Convergence Rate:      {result.convergence_rate:.6f}")
    print(f"Final ω:               {result.final_omega:.6f}")
    print(f"Final ω̇:               {result.final_omega_dot:.2e}")
    print(f"Equilibrium Reached:   {result.equilibrium_reached}")
    print(f"Energy Drift:          {result.energy_drift:.2e}")
    print(f"Phase Coherence:       {result.phase_coherence:.6f}")
    print()

    if result.equilibrium_reached:
        print("✓ System reached phase-locked equilibrium!")
        print(f"  Equilibrium frequency: ω = {result.final_omega:.6f}")
        print()

        # Check if equilibrium is near a Riemann zero
        distances = np.abs(np.array(riemann_zeros) - result.final_omega)
        nearest_idx = np.argmin(distances)
        nearest_zero = riemann_zeros[nearest_idx]
        distance = distances[nearest_idx]

        if distance < 1.0:
            print(f"  Equilibrium is near Riemann zero γ_{nearest_idx+1} = {nearest_zero:.6f}")
            print(f"  Distance: {distance:.6f}")
    else:
        print("⚠ System did not reach equilibrium within t_max")
        print("  Consider increasing integration time or adjusting parameters")

    print("-" * 80)

    # Save results
    output_dir = Path("telemetry/kno")
    output_dir.mkdir(parents=True, exist_ok=True)

    # Save JSON results
    output_file = output_dir / "kno_phase_lock_results.json"
    with open(output_file, 'w') as f:
        # Convert dataclass to dict, handling nested dataclasses
        result_dict = asdict(result)
        json.dump(result_dict, f, indent=2)

    print()
    print(f"Results saved to: {output_file}")

    # Create visualization
    plot_file = output_dir / "kno_phase_lock_trajectory.png"
    integrator.visualize_trajectory(result, plot_file)

    # Exit with appropriate code
    sys.exit(0 if result.equilibrium_reached else 1)


if __name__ == "__main__":
    main()
