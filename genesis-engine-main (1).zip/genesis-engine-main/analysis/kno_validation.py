#!/usr/bin/env python3
"""
Klemm Zero-Point Operator (KNO) Validation Module

Validates the polynomial potential, Berry connection, and self-adjoint properties
of the KNO framework according to the mathematical specification:
    LΦ(K)Ψ = 0, with LΦ(K) = -i d/dt + f(Ψ, Φ)
    V_poly(ω) = κ ∏(ω - γ_n)^2, where V''(γ_n) > 0
"""

import numpy as np
import json
import sys
from pathlib import Path
from typing import List, Tuple, Dict, Any
from dataclasses import dataclass, asdict


@dataclass
class KNOValidationResult:
    """Results from KNO validation"""
    operator_id: str
    hermitian_property: bool
    hermitian_error: float
    stability_validated: bool
    stable_zeros: List[float]
    unstable_zeros: List[float]
    berry_phase: float
    chern_number: float
    precision: float
    phase_locked: bool
    spectral_alignment: float
    validation_passed: bool


class PolynomialPotential:
    """
    Polynomial potential targeting Riemann zeros: V_poly(ω) = κ ∏(ω - γ_n)^2
    """

    def __init__(self, zeros: List[float], kappa: float = 1.0):
        """
        Initialize polynomial potential

        Args:
            zeros: Riemann zero imaginary parts (γ_n)
            kappa: Coupling constant κ
        """
        self.zeros = np.array(zeros)
        self.kappa = kappa

    def evaluate(self, omega: float) -> float:
        """Evaluate V_poly(ω)"""
        product = np.prod((omega - self.zeros) ** 2)
        return self.kappa * product

    def derivative(self, omega: float) -> float:
        """Evaluate first derivative V'(ω)"""
        result = 0.0
        for i, gamma_i in enumerate(self.zeros):
            term = 2.0 * (omega - gamma_i)
            for j, gamma_j in enumerate(self.zeros):
                if i != j:
                    term *= (omega - gamma_j) ** 2
            result += term
        return self.kappa * result

    def second_derivative(self, omega: float) -> float:
        """Evaluate second derivative V''(ω)"""
        n = len(self.zeros)
        result = 0.0

        for i, gamma_i in enumerate(self.zeros):
            # First term: 2.0 * ∏(ω - γ_j)^2 for j ≠ i
            term1 = 2.0
            for j, gamma_j in enumerate(self.zeros):
                if i != j:
                    term1 *= (omega - gamma_j) ** 2
            result += term1

            # Second term: cross terms
            for k, gamma_k in enumerate(self.zeros):
                if k != i:
                    term2 = 4.0 * (omega - gamma_i) * 2.0 * (omega - gamma_k)
                    for j, gamma_j in enumerate(self.zeros):
                        if j != i and j != k:
                            term2 *= (omega - gamma_j) ** 2
                    result += term2

        return self.kappa * result

    def check_stability(self, tolerance: float = 1e-6) -> List[Tuple[float, float, bool]]:
        """
        Check stability at each zero: V''(γ_n) > 0

        Returns:
            List of (zero, V''(zero), is_stable) tuples
        """
        results = []
        for gamma in self.zeros:
            v_pp = self.second_derivative(gamma)
            is_stable = v_pp > tolerance
            results.append((gamma, v_pp, is_stable))
        return results


class BerryConnection:
    """
    Berry connection: A_i = Im(Ψ* ∂iΨ) / |Ψ|^2
    """

    @staticmethod
    def compute(psi: complex, grad_psi: List[complex]) -> np.ndarray:
        """
        Compute Berry connection from wave function and gradient

        Args:
            psi: Wave function value Ψ
            grad_psi: Gradient ∂iΨ for each dimension

        Returns:
            Berry connection components A_i
        """
        psi_star = np.conj(psi)
        norm_sq = np.abs(psi) ** 2

        if norm_sq < 1e-12:
            return np.zeros(len(grad_psi))

        components = []
        for dpsi in grad_psi:
            product = psi_star * dpsi
            a_i = np.imag(product) / norm_sq
            components.append(a_i)

        return np.array(components)

    @staticmethod
    def field_strength(berry_field: np.ndarray, i: int, j: int) -> float:
        """
        Compute field strength (curvature): F_ij = ∂_i A_j - ∂_j A_i

        Args:
            berry_field: 2D array of Berry connection values
            i, j: Dimension indices

        Returns:
            Field strength component F_ij
        """
        if berry_field.ndim < 2:
            return 0.0

        # Finite difference approximation
        if i < berry_field.shape[0] - 1 and j < berry_field.shape[1] - 1:
            da_j_di = (berry_field[i+1, j] - berry_field[i, j])
            da_i_dj = (berry_field[i, j+1] - berry_field[i, j])
            return da_j_di - da_i_dj

        return 0.0


class ChernNumberCalculator:
    """
    Chern number computation: C = (1/2π) ∫Σ (∂iAj - ∂jAi) dσ^i ∧ dσ^j
    """

    @staticmethod
    def compute(berry_connections: np.ndarray, grid_size: int) -> Tuple[float, float]:
        """
        Compute Chern number from Berry connection over a 2D surface

        Args:
            berry_connections: 2D grid of Berry connection vectors
            grid_size: Grid resolution

        Returns:
            (chern_number, precision)
        """
        total_curvature = 0.0
        dσ = 1.0 / grid_size

        # Discrete integration over the 2D surface
        for i in range(grid_size - 1):
            for j in range(grid_size - 1):
                if berry_connections.ndim >= 3 and berry_connections.shape[2] >= 2:
                    # Extract 2x2 plaquette
                    a00 = berry_connections[i, j, :]
                    a10 = berry_connections[i+1, j, :]
                    a01 = berry_connections[i, j+1, :]
                    a11 = berry_connections[i+1, j+1, :]

                    # Finite difference approximation of F_ij
                    da1_dx2 = (a10[1] - a00[1]) / dσ if len(a10) > 1 else 0.0
                    da2_dx1 = (a01[0] - a00[0]) / dσ if len(a01) > 0 else 0.0
                    f_ij = da1_dx2 - da2_dx1

                    total_curvature += f_ij * dσ * dσ

        chern = total_curvature / (2.0 * np.pi)
        return chern, dσ


class PhaseFieldSimulator:
    """
    Phase field dynamics: Ψ(t) = Σ_p p^{-1/2} e^{i t log p}
    """

    def __init__(self, primes: List[int]):
        """
        Initialize phase field simulator

        Args:
            primes: List of prime numbers
        """
        self.primes = np.array(primes)

    def evaluate(self, t: float) -> complex:
        """
        Evaluate Ψ(t) = Σ_p p^{-1/2} e^{i t log p}

        Args:
            t: Time parameter

        Returns:
            Wave function value Ψ(t)
        """
        psi = 0.0 + 0.0j
        for p in self.primes:
            amplitude = 1.0 / np.sqrt(p)
            phase = t * np.log(p)
            psi += amplitude * np.exp(1j * phase)
        return psi

    def gradient(self, t: float, epsilon: float = 1e-6) -> complex:
        """
        Compute numerical gradient ∂Ψ/∂t

        Args:
            t: Time parameter
            epsilon: Finite difference step

        Returns:
            Gradient dΨ/dt
        """
        psi_t = self.evaluate(t)
        psi_t_plus = self.evaluate(t + epsilon)
        return (psi_t_plus - psi_t) / epsilon

    def frequency(self, t: float, dt: float = 0.1) -> float:
        """
        Compute frequency ω(t) = dΦ/dt

        Args:
            t: Time parameter
            dt: Time step for finite difference

        Returns:
            Frequency ω
        """
        psi_t = self.evaluate(t)
        psi_t_dt = self.evaluate(t + dt)

        phi_t = np.angle(psi_t)
        phi_t_dt = np.angle(psi_t_dt)

        # Handle phase wrapping
        dphi = phi_t_dt - phi_t
        if dphi > np.pi:
            dphi -= 2 * np.pi
        elif dphi < -np.pi:
            dphi += 2 * np.pi

        return dphi / dt


class KNOValidator:
    """
    Main KNO validation system
    """

    def __init__(self, riemann_zeros: List[float], kappa: float = 1.0, primes: List[int] = None):
        """
        Initialize KNO validator

        Args:
            riemann_zeros: Riemann zero imaginary parts
            kappa: Coupling constant
            primes: Prime numbers for phase field (default: first 20 primes)
        """
        self.potential = PolynomialPotential(riemann_zeros, kappa)
        self.riemann_zeros = riemann_zeros

        if primes is None:
            primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]

        self.phase_simulator = PhaseFieldSimulator(primes)

    def validate_stability(self, tolerance: float = 1e-6) -> Tuple[bool, List[float], List[float]]:
        """
        Validate stability: V''(γ_n) > 0 for all zeros

        Returns:
            (all_stable, stable_zeros, unstable_zeros)
        """
        stability_results = self.potential.check_stability(tolerance)

        stable_zeros = [gamma for gamma, v_pp, is_stable in stability_results if is_stable]
        unstable_zeros = [gamma for gamma, v_pp, is_stable in stability_results if not is_stable]

        all_stable = len(unstable_zeros) == 0

        return all_stable, stable_zeros, unstable_zeros

    def validate_hermitian(self, t: float, precision: float = 1e-6) -> Tuple[bool, float]:
        """
        Validate self-adjoint (Hermitian) property of LΦ(K)

        For the operator to be Hermitian:
        - Potential V(ω) must be real-valued
        - Berry connection must satisfy symmetry conditions

        Returns:
            (is_hermitian, error)
        """
        psi = self.phase_simulator.evaluate(t)
        omega = self.phase_simulator.frequency(t)

        # Check that potential is real
        v = self.potential.evaluate(omega)
        v_prime = self.potential.derivative(omega)

        error = 0.0
        if not np.isfinite(v) or not np.isfinite(v_prime):
            return False, np.inf

        # Berry connection should produce real-valued gauge field
        dpsi_dt = self.phase_simulator.gradient(t)
        berry = BerryConnection.compute(psi, [dpsi_dt])

        if not np.all(np.isfinite(berry)):
            return False, np.inf

        error = np.max(np.abs(np.imag(berry)))
        is_hermitian = bool(error < precision)

        return is_hermitian, float(error)

    def compute_berry_phase(self, t_range: Tuple[float, float], n_steps: int = 100) -> float:
        """
        Compute Berry phase: γ = ∮ A · dl

        Args:
            t_range: Time range (t_start, t_end)
            n_steps: Number of integration steps

        Returns:
            Berry phase γ
        """
        t_start, t_end = t_range
        times = np.linspace(t_start, t_end, n_steps)
        dt = (t_end - t_start) / n_steps

        berry_phase = 0.0
        for t in times:
            psi = self.phase_simulator.evaluate(t)
            dpsi_dt = self.phase_simulator.gradient(t)
            berry = BerryConnection.compute(psi, [dpsi_dt])

            if len(berry) > 0:
                berry_phase += berry[0] * dt

        return berry_phase

    def compute_chern_number(self, grid_size: int = 32) -> Tuple[float, float]:
        """
        Compute Chern number over parameter space

        Args:
            grid_size: Grid resolution

        Returns:
            (chern_number, precision)
        """
        berry_grid = np.zeros((grid_size, grid_size, 2))

        t_range = np.linspace(0, 10, grid_size)
        phi_range = np.linspace(0, 2*np.pi, grid_size)

        for i, t in enumerate(t_range):
            for j, phi in enumerate(phi_range):
                psi = self.phase_simulator.evaluate(t)
                dpsi_dt = self.phase_simulator.gradient(t)

                # Two-dimensional parameter space: (t, φ)
                grad_psi = [dpsi_dt, dpsi_dt * 1j]  # Simplified
                berry = BerryConnection.compute(psi, grad_psi)

                if len(berry) >= 2:
                    berry_grid[i, j, :] = berry[:2]

        return ChernNumberCalculator.compute(berry_grid, grid_size)

    def check_phase_lock(self, t: float, tolerance: float = 1e-6) -> Tuple[bool, float]:
        """
        Check if system is phase-locked: ω̇ = 0

        Args:
            t: Time parameter
            tolerance: Convergence threshold

        Returns:
            (is_phase_locked, omega_dot)
        """
        omega = self.phase_simulator.frequency(t)
        v_pp = self.potential.second_derivative(omega)
        omega_dot = -v_pp  # From equation: ω̇ = -∂_ω V_poly(ω)

        is_phase_locked = bool(np.abs(omega_dot) < tolerance)
        return is_phase_locked, float(omega_dot)

    def validate_spectral_alignment(self) -> float:
        """
        Validate alignment with Riemann zeros

        Returns:
            Alignment score (0-1, where 1 is perfect)
        """
        # Check that potential has minima at each Riemann zero
        alignment_scores = []

        for gamma in self.riemann_zeros:
            v = self.potential.evaluate(gamma)
            v_prime = self.potential.derivative(gamma)

            # At minimum: V(γ) = 0, V'(γ) ≈ 0
            score = np.exp(-np.abs(v) - np.abs(v_prime))
            alignment_scores.append(score)

        return np.mean(alignment_scores)

    def validate_full(self, operator_id: str = "kno_default", t: float = 1.0,
                     precision: float = 1e-6) -> KNOValidationResult:
        """
        Perform full validation of KNO operator

        Args:
            operator_id: Operator identifier
            t: Time parameter for evaluation
            precision: Validation precision threshold

        Returns:
            KNOValidationResult with all validation metrics
        """
        # Stability validation
        stability_validated, stable_zeros, unstable_zeros = self.validate_stability(precision)

        # Hermitian property
        hermitian_property, hermitian_error = self.validate_hermitian(t, precision)

        # Berry phase (should be ≈ 2π for topological system)
        berry_phase = self.compute_berry_phase((0, 2*np.pi), n_steps=100)

        # Chern number (should be ≈ 1 for topological insulator)
        chern_number, chern_precision = self.compute_chern_number(grid_size=16)

        # Phase-lock check
        phase_locked, omega_dot = self.check_phase_lock(t, precision)

        # Spectral alignment
        spectral_alignment = self.validate_spectral_alignment()

        # Overall validation
        validation_passed = bool(
            stability_validated and
            hermitian_property and
            hermitian_error < precision and
            np.abs(berry_phase - 2*np.pi) < 1.0 and
            np.abs(chern_number - 1.0) < 0.5 and
            spectral_alignment > 0.9
        )

        return KNOValidationResult(
            operator_id=operator_id,
            hermitian_property=hermitian_property,
            hermitian_error=float(hermitian_error),
            stability_validated=stability_validated,
            stable_zeros=stable_zeros,
            unstable_zeros=unstable_zeros,
            berry_phase=float(berry_phase),
            chern_number=float(chern_number),
            precision=float(precision),
            phase_locked=phase_locked,
            spectral_alignment=float(spectral_alignment),
            validation_passed=validation_passed
        )


def main():
    """Main validation entry point"""
    # First 10 non-trivial Riemann zeros (imaginary parts)
    riemann_zeros = [
        14.134725, 21.022040, 25.010858, 30.424876, 32.935062,
        37.586178, 40.918719, 43.327073, 48.005151, 49.773832
    ]

    print("=" * 80)
    print("KNO (Klemm Zero-Point Operator) Validation")
    print("=" * 80)
    print()

    # Initialize validator
    validator = KNOValidator(riemann_zeros, kappa=1.0)

    # Run validation
    print("Running full validation...")
    result = validator.validate_full(precision=1e-6)

    # Display results
    print()
    print("Validation Results:")
    print("-" * 80)
    print(f"Operator ID:           {result.operator_id}")
    print(f"Hermitian Property:    {result.hermitian_property} (error: {result.hermitian_error:.2e})")
    print(f"Stability Validated:   {result.stability_validated}")
    print(f"  Stable zeros:        {len(result.stable_zeros)}/{len(riemann_zeros)}")
    print(f"  Unstable zeros:      {len(result.unstable_zeros)}")
    print(f"Berry Phase:           {result.berry_phase:.6f} (target: 2π = {2*np.pi:.6f})")
    print(f"Chern Number:          {result.chern_number:.6f} (target: 1.0)")
    print(f"Phase Locked:          {result.phase_locked}")
    print(f"Spectral Alignment:    {result.spectral_alignment:.6f}")
    print(f"Precision:             {result.precision:.2e}")
    print()
    print(f"OVERALL VALIDATION:    {'PASSED ✓' if result.validation_passed else 'FAILED ✗'}")
    print("-" * 80)

    # Save results to JSON
    output_dir = Path("telemetry/kno")
    output_dir.mkdir(parents=True, exist_ok=True)

    output_file = output_dir / "kno_validation_results.json"

    # Convert result to dict and ensure numpy types are converted to Python native types
    result_dict = asdict(result)

    # Convert numpy bools to Python bools
    def convert_numpy_types(obj):
        """Recursively convert numpy types to Python native types"""
        if isinstance(obj, dict):
            return {k: convert_numpy_types(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_numpy_types(v) for v in obj]
        elif isinstance(obj, np.bool_):
            return bool(obj)
        elif isinstance(obj, (np.integer, np.floating)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        else:
            return obj

    result_dict = convert_numpy_types(result_dict)

    with open(output_file, 'w') as f:
        json.dump(result_dict, f, indent=2)

    print()
    print(f"Results saved to: {output_file}")

    # Exit with appropriate code
    sys.exit(0 if result.validation_passed else 1)


if __name__ == "__main__":
    main()
