#!/usr/bin/env python3
"""Hilbert-Pólya-Metatron (HPM) operator verification.

This script verifies that the operator stream exhibits properties consistent
with the Hilbert-Pólya conjecture framework, checking for self-adjointness,
spectral symmetry, and alignment with known Riemann zeta zeros.
"""

from __future__ import annotations

import argparse
import gzip
import json
import sys
from pathlib import Path
from typing import Any, Dict, List

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run Hilbert-Pólya-Metatron operator verification"
    )
    parser.add_argument(
        "--input",
        type=str,
        required=True,
        help="Path to operators.ndjson.gz file",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="hpm_verification.json",
        help="Output path for verification results",
    )
    parser.add_argument(
        "--max-operators",
        type=int,
        default=5000,
        help="Maximum number of operators to use for verification",
    )
    parser.add_argument(
        "--precision",
        type=float,
        default=1e-10,
        help="Numerical precision threshold for verification tests (default: 1e-10)",
    )
    return parser.parse_args()


def load_operators(input_path: str) -> List[Dict[str, Any]]:
    """Load operators from compressed NDJSON file."""
    operators = []
    print(f"[LOAD] Reading operators from {input_path}...")

    with gzip.open(input_path, "rt", encoding="utf-8") as f:
        for idx, line in enumerate(f, 1):
            if line.strip():
                operators.append(json.loads(line))
                if idx % 10000 == 0:
                    print(f"[LOAD] Loaded {idx} operators...")

    print(f"[LOAD] Total operators loaded: {len(operators)}")
    return operators


def construct_hpm_matrix(operators: List[Dict[str, Any]]) -> np.ndarray:
    """Construct the HPM operator matrix from spectral signatures.

    The matrix is constructed as a Hermitian operator with:
    - Diagonal: Energy levels based on entropy and delta_phi
    - Off-diagonal: Sparse couplings based on resonance (delta_sigma)
    """
    n = len(operators)
    print(f"[HPM] Constructing {n}x{n} HPM operator matrix...")

    # Initialize complex Hermitian matrix
    H = np.zeros((n, n), dtype=np.complex128)

    # Build operator from spectral signatures
    for i, op_i in enumerate(operators):
        if (i + 1) % 1000 == 0:
            progress = (i + 1) / n * 100
            print(f"[HPM] Construction progress: {progress:.1f}%")

        # Extract spectral features
        entropy_i = op_i.get("entropy", 0.5)
        delta_phi_i = op_i.get("delta_phi", 0.0)
        delta_sigma_i = op_i.get("delta_sigma", 0.0)

        # Diagonal: Energy levels based on entropy (must be real for Hermitian matrix)
        # delta_phi modulates the energy level
        H[i, i] = entropy_i + delta_phi_i

        # Off-diagonal: Couplings based on resonance
        for j in range(i + 1, min(i + 10, n)):  # Sparse coupling
            op_j = operators[j]
            entropy_j = op_j.get("entropy", 0.5)
            delta_sigma_j = op_j.get("delta_sigma", 0.0)

            # Coupling strength
            coupling = np.exp(-abs(entropy_i - entropy_j)) * (delta_sigma_i + delta_sigma_j) / 2.0

            H[i, j] = coupling
            H[j, i] = np.conj(coupling)  # Hermitian symmetry

    return H


def verify_self_adjoint(H: np.ndarray, tolerance: float = 1e-10) -> tuple[bool, float]:
    """Verify that the operator is self-adjoint (Hermitian)."""
    print("[VERIFY] Checking self-adjointness...")

    # Check H = H†
    deviation = np.max(np.abs(H - np.conj(H.T)))
    is_hermitian = deviation < tolerance

    print(f"[VERIFY] Max Hermitian deviation: {deviation:.2e}")
    print(f"[VERIFY] Self-adjoint: {is_hermitian}")

    return is_hermitian, float(deviation)


def compute_eigenspectrum(H: np.ndarray, num_eigenvalues: int = 1000) -> np.ndarray:
    """Compute eigenspectrum of the operator."""
    n = H.shape[0]
    print(f"[EIGEN] Computing eigenspectrum (matrix size: {n})...")

    # For large matrices, compute only a subset of eigenvalues
    if n > num_eigenvalues:
        # Use sparse eigenvalue solver for efficiency
        from scipy.sparse.linalg import eigs
        H_sparse = H
        eigenvalues, _ = eigs(H_sparse, k=num_eigenvalues, which='LM')
    else:
        # Full eigenvalue decomposition
        eigenvalues = np.linalg.eigvalsh(H)

    print(f"[EIGEN] Computed {len(eigenvalues)} eigenvalues")
    return eigenvalues


def check_spectral_symmetry(eigenvalues: np.ndarray, tolerance: float = 0.01) -> tuple[bool, float]:
    """Check if the spectrum exhibits expected symmetry properties."""
    print("[SYMMETRY] Checking spectral symmetry...")

    # Analyze real and imaginary parts
    real_parts = np.real(eigenvalues)
    imag_parts = np.imag(eigenvalues)

    real_mean = float(np.mean(real_parts))
    real_std = float(np.std(real_parts))
    imag_mean = float(np.mean(imag_parts))

    print(f"[SYMMETRY] Real part: μ={real_mean:.6f}, σ={real_std:.6f}")
    print(f"[SYMMETRY] Imag part: μ={imag_mean:.6f}")

    # Symmetry score based on concentration around mean
    symmetry_score = 1.0 - min(real_std, 1.0)
    is_symmetric = real_std < tolerance

    print(f"[SYMMETRY] Symmetry score: {symmetry_score:.6f}")
    print(f"[SYMMETRY] Spectrum symmetric: {is_symmetric}")

    return is_symmetric, float(symmetry_score)


def compute_riemann_alignment(eigenvalues: np.ndarray) -> float:
    """Compute alignment score with known Riemann zeta zeros.

    This is a simplified alignment check. A full implementation would
    compare against tabulated Riemann zeros.
    """
    print("[ALIGN] Computing Riemann zero alignment...")

    # For now, return a placeholder alignment score
    # In a real implementation, this would compare eigenvalues
    # to known zeros of the Riemann zeta function
    imag_parts = np.imag(eigenvalues)

    # Simple heuristic: alignment based on imaginary part distribution
    # Real Riemann zeros have Re(s) = 0.5, so we check if imaginary parts
    # follow expected distribution
    alignment_score = 0.0

    if len(imag_parts) > 0 and np.std(imag_parts) > 0:
        # Placeholder computation
        alignment_score = float(np.mean(np.abs(imag_parts)))

    print(f"[ALIGN] Alignment score: {alignment_score:.6f}")

    return float(alignment_score)


def convert_numpy_types(obj: Any) -> Any:
    """Convert numpy types to Python native types for JSON serialization."""
    if isinstance(obj, np.bool_):
        return bool(obj)
    elif isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, dict):
        return {key: convert_numpy_types(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [convert_numpy_types(item) for item in obj]
    else:
        return obj


class HPMVerifier:
    """Main verification orchestrator."""

    def __init__(self):
        pass

    def run_verification(
        self, input_path: str, output_path: str, max_operators: int, precision: float = 1e-10
    ) -> int:
        """Run the full HPM verification pipeline."""
        print("=" * 80)
        print("Hilbert-Pólya-Metatron Operator Verification")
        print("=" * 80)
        print(f"[CONFIG] Precision threshold: {precision:.2e}")

        # Load operators
        operators = load_operators(input_path)

        # Limit to max_operators
        if len(operators) > max_operators:
            print(f"[LIMIT] Using first {max_operators} operators for verification")
            operators = operators[:max_operators]

        # Construct HPM matrix
        H = construct_hpm_matrix(operators)

        # Verify self-adjointness
        is_hermitian, hermitian_deviation = verify_self_adjoint(H, tolerance=precision)

        # Compute eigenspectrum
        eigenvalues = compute_eigenspectrum(H)

        # Check spectral symmetry
        # Use a slightly relaxed tolerance for symmetry (100x precision)
        symmetry_tolerance = min(precision * 100, 0.01)
        is_symmetric, symmetry_score = check_spectral_symmetry(eigenvalues, tolerance=symmetry_tolerance)

        # Compute Riemann alignment
        alignment_score = compute_riemann_alignment(eigenvalues)

        # Compile results
        results = {
            "verification_summary": {
                "total_operators_loaded": len(load_operators(input_path)),
                "operators_used": len(operators),
                "matrix_size": H.shape[0],
            },
            "self_adjointness": {
                "is_hermitian": is_hermitian,
                "max_deviation": hermitian_deviation,
            },
            "spectral_properties": {
                "num_eigenvalues": len(eigenvalues),
                "is_symmetric": is_symmetric,
                "symmetry_score": symmetry_score,
            },
            "riemann_alignment": {
                "alignment_score": alignment_score,
            },
            "verification_status": {
                "passed": is_hermitian and (is_symmetric or symmetry_score > 0.95),
            },
        }

        # Convert numpy types to Python native types
        results = convert_numpy_types(results)

        # Save results
        print(f"\n[SAVE] Writing results to {output_path}...")
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)

        # Save eigenvalues separately for downstream validation
        output_file = Path(output_path)
        eigenvalue_path = output_file.parent / f"{output_file.stem}_eigenvalues.json"

        print(f"[SAVE] Writing eigenvalues to {eigenvalue_path}...")
        eigenvalue_data = [
            {"real": float(np.real(ev)), "imag": float(np.imag(ev))}
            for ev in eigenvalues
        ]
        with open(eigenvalue_path, "w", encoding="utf-8") as f:
            json.dump(eigenvalue_data, f, indent=2)

        print("\n" + "=" * 80)
        print("Verification Complete")
        print(f"  Self-adjoint: {is_hermitian}")
        print(f"  Symmetric: {is_symmetric} (score: {symmetry_score:.4f})")
        print(f"  Overall: {'PASSED' if results['verification_status']['passed'] else 'FAILED'}")
        print("=" * 80)

        return 0 if results["verification_status"]["passed"] else 1


def main() -> int:
    args = parse_args()
    verifier = HPMVerifier()
    return verifier.run_verification(args.input, args.output, args.max_operators, args.precision)


if __name__ == "__main__":
    sys.exit(main())
