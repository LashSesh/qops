//! Ledger Module
//!
//! The Ledger is the archiving system for stable operators and artefacts.
//! It provides:
//! - Persistent storage of Mandorla-certified artefacts
//! - Replay capability for verification
//! - Query and retrieval by signature properties
//! - Blueprint compression and optimization

use crate::artefact::Artefact;
use crate::signature::{Signature, Signature5D};
use crate::error::{Result, MogeError};
use crate::cubechain::{Cubechain, OperatorCube, ResonantTransition};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use uuid::Uuid;
use std::path::{Path, PathBuf};
use std::fs;

/// Ledger entry metadata
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LedgerEntry {
    /// Artefact UUID
    pub artefact_id: Uuid,
    /// Final node ID
    pub final_node: usize,
    /// Final resonance score
    pub resonance: f64,
    /// Stability score
    pub stability: f64,
    /// Is Mandorla certified
    pub mandorla_certified: bool,
    /// Path length (number of transformations)
    pub path_length: usize,
    /// Total signature distance traveled
    pub signature_distance: f64,
}

impl LedgerEntry {
    /// Create from artefact
    pub fn from_artefact(artefact: &Artefact) -> Self {
        Self {
            artefact_id: artefact.id,
            final_node: artefact.node_id,
            resonance: artefact.resonance(),
            stability: artefact.stability,
            mandorla_certified: artefact.is_mandorla_certified,
            path_length: artefact.blueprint.len(),
            signature_distance: artefact.signature_distance(),
        }
    }
}

/// Query criteria for searching the ledger
#[derive(Debug, Clone)]
pub struct LedgerQuery {
    /// Minimum resonance score
    pub min_resonance: Option<f64>,
    /// Minimum stability
    pub min_stability: Option<f64>,
    /// Only Mandorla-certified artefacts
    pub mandorla_only: bool,
    /// Maximum path length
    pub max_path_length: Option<usize>,
    /// Target signature (for proximity search)
    pub target_signature: Option<Signature5D>,
    /// Maximum distance from target signature
    pub max_signature_distance: Option<f64>,
}

impl Default for LedgerQuery {
    fn default() -> Self {
        Self {
            min_resonance: None,
            min_stability: None,
            mandorla_only: false,
            max_path_length: None,
            target_signature: None,
            max_signature_distance: None,
        }
    }
}

/// The Ledger: persistent storage for artefacts and cubechain
pub struct Ledger {
    /// Artefacts indexed by UUID
    artefacts: HashMap<Uuid, Artefact>,
    /// Metadata index for fast querying
    entries: HashMap<Uuid, LedgerEntry>,
    /// Cubechain hypergraph (optional)
    cubechain: Option<Cubechain>,
    /// Storage path (optional for persistence)
    storage_path: Option<PathBuf>,
}

impl Ledger {
    /// Create a new in-memory ledger
    pub fn new() -> Self {
        Self {
            artefacts: HashMap::new(),
            entries: HashMap::new(),
            cubechain: None,
            storage_path: None,
        }
    }

    /// Create a ledger with persistent storage
    pub fn with_storage<P: AsRef<Path>>(path: P) -> Result<Self> {
        let path_buf = path.as_ref().to_path_buf();

        // Create directory if it doesn't exist
        if let Some(parent) = path_buf.parent() {
            fs::create_dir_all(parent)?;
        }

        let mut ledger = Self {
            artefacts: HashMap::new(),
            entries: HashMap::new(),
            cubechain: None,
            storage_path: Some(path_buf),
        };

        // Load existing data if present
        ledger.load()?;

        Ok(ledger)
    }

    /// Enable cubechain mode
    pub fn enable_cubechain(&mut self) -> &mut Cubechain {
        if self.cubechain.is_none() {
            self.cubechain = Some(Cubechain::new());
        }
        self.cubechain.as_mut().unwrap()
    }

    /// Get cubechain reference
    pub fn cubechain(&self) -> Option<&Cubechain> {
        self.cubechain.as_ref()
    }

    /// Get mutable cubechain reference
    pub fn cubechain_mut(&mut self) -> Option<&mut Cubechain> {
        self.cubechain.as_mut()
    }

    /// Check if cubechain mode is enabled
    pub fn is_cubechain_enabled(&self) -> bool {
        self.cubechain.is_some()
    }

    /// Commit a cube to the cubechain ledger
    pub fn commit_cube(&mut self, cube: OperatorCube, node_index: usize) -> Result<Uuid> {
        let chain = self.cubechain.as_mut()
            .ok_or_else(|| MogeError::LedgerError("Cubechain not enabled".to_string()))?;
        
        let cube_id = cube.id;
        chain.add_cube(cube, node_index)?;
        
        // Persist if storage path is configured
        if self.storage_path.is_some() {
            self.save()?;
        }
        
        Ok(cube_id)
    }

    /// Commit a transition to the cubechain ledger
    pub fn commit_transition(&mut self, transition: ResonantTransition) -> Result<Uuid> {
        let chain = self.cubechain.as_mut()
            .ok_or_else(|| MogeError::LedgerError("Cubechain not enabled".to_string()))?;
        
        let transition_id = transition.id;
        chain.transitions.insert(transition_id, transition);
        
        // Persist if storage path is configured
        if self.storage_path.is_some() {
            self.save()?;
        }
        
        Ok(transition_id)
    }

    /// Export cubechain to JSON for hypergraph storage
    pub fn export_cubechain(&self) -> Result<String> {
        let chain = self.cubechain.as_ref()
            .ok_or_else(|| MogeError::LedgerError("Cubechain not enabled".to_string()))?;
        
        serde_json::to_string_pretty(chain)
            .map_err(|e| e.into())
    }

    /// Import cubechain from JSON
    pub fn import_cubechain(&mut self, json: &str) -> Result<()> {
        let chain: Cubechain = serde_json::from_str(json)?;
        self.cubechain = Some(chain);
        Ok(())
    }

    /// Get cubechain statistics
    pub fn cubechain_stats(&self) -> Option<CubechainStats> {
        self.cubechain.as_ref().map(|chain| {
            CubechainStats {
                total_cubes: chain.cube_count(),
                validated_transitions: chain.validated_transition_count(),
                mean_entropy: chain.mean_entropy(),
                stability_index: chain.stability_index(),
                metatron_nodes: chain.metatron_nodes.len(),
            }
        })
    }

    /// Commit an artefact to the ledger
    pub fn commit(&mut self, artefact: Artefact) -> Result<Uuid> {
        let entry = LedgerEntry::from_artefact(&artefact);
        let id = artefact.id;

        self.artefacts.insert(id, artefact);
        self.entries.insert(id, entry);

        // Persist if storage path is configured
        if self.storage_path.is_some() {
            self.save()?;
        }

        Ok(id)
    }

    /// Retrieve an artefact by ID
    pub fn get(&self, id: &Uuid) -> Option<&Artefact> {
        self.artefacts.get(id)
    }

    /// Query artefacts by criteria
    pub fn query(&self, query: &LedgerQuery) -> Vec<&Artefact> {
        self.entries
            .iter()
            .filter(|(_, entry)| self.matches_query(entry, query))
            .filter_map(|(id, _)| self.artefacts.get(id))
            .collect()
    }

    /// Check if an entry matches query criteria
    fn matches_query(&self, entry: &LedgerEntry, query: &LedgerQuery) -> bool {
        if let Some(min_res) = query.min_resonance {
            if entry.resonance < min_res {
                return false;
            }
        }

        if let Some(min_stab) = query.min_stability {
            if entry.stability < min_stab {
                return false;
            }
        }

        if query.mandorla_only && !entry.mandorla_certified {
            return false;
        }

        if let Some(max_len) = query.max_path_length {
            if entry.path_length > max_len {
                return false;
            }
        }

        if let (Some(target), Some(max_dist)) = (&query.target_signature, query.max_signature_distance) {
            if let Some(artefact) = self.artefacts.get(&entry.artefact_id) {
                if artefact.signature.distance(target) > max_dist {
                    return false;
                }
            }
        }

        true
    }

    /// Get all Mandorla-certified artefacts
    pub fn get_mandorla_certified(&self) -> Vec<&Artefact> {
        self.artefacts
            .values()
            .filter(|a| a.is_mandorla_certified)
            .collect()
    }

    /// Get artefacts with highest resonance
    pub fn get_top_resonance(&self, n: usize) -> Vec<&Artefact> {
        let mut artefacts: Vec<_> = self.artefacts.values().collect();
        artefacts.sort_by(|a, b| b.resonance().partial_cmp(&a.resonance()).unwrap());
        artefacts.truncate(n);
        artefacts
    }

    /// Total number of artefacts in ledger
    pub fn len(&self) -> usize {
        self.artefacts.len()
    }

    /// Check if ledger is empty
    pub fn is_empty(&self) -> bool {
        self.artefacts.is_empty()
    }

    /// Clear all artefacts
    pub fn clear(&mut self) {
        self.artefacts.clear();
        self.entries.clear();
    }

    /// Replay an artefact's traversal path
    ///
    /// Returns the sequence of signatures along the path
    pub fn replay(&self, id: &Uuid) -> Result<Vec<Signature5D>> {
        let artefact = self.get(id)
            .ok_or_else(|| MogeError::LedgerError("Artefact not found".to_string()))?;

        let mut signatures = vec![];

        // Add initial signature
        if let Some(first) = artefact.blueprint.first() {
            signatures.push(first.signature_before);
        }

        // Add all subsequent signatures
        for entry in &artefact.blueprint {
            signatures.push(entry.signature_after);
        }

        Ok(signatures)
    }

    /// Export artefact to JSON
    pub fn export_artefact(&self, id: &Uuid) -> Result<String> {
        let artefact = self.get(id)
            .ok_or_else(|| MogeError::LedgerError("Artefact not found".to_string()))?;

        serde_json::to_string_pretty(artefact)
            .map_err(|e| e.into())
    }

    /// Import artefact from JSON
    pub fn import_artefact(&mut self, json: &str) -> Result<Uuid> {
        let artefact: Artefact = serde_json::from_str(json)?;
        self.commit(artefact)
    }

    /// Save ledger to disk
    fn save(&self) -> Result<()> {
        if let Some(ref path) = self.storage_path {
            let json = serde_json::to_string_pretty(&self.artefacts)?;
            fs::write(path, json)?;
        }
        Ok(())
    }

    /// Load ledger from disk
    fn load(&mut self) -> Result<()> {
        if let Some(ref path) = self.storage_path {
            if path.exists() {
                let json = fs::read_to_string(path)?;
                let artefacts: HashMap<Uuid, Artefact> = serde_json::from_str(&json)?;

                for (id, artefact) in artefacts {
                    let entry = LedgerEntry::from_artefact(&artefact);
                    self.artefacts.insert(id, artefact);
                    self.entries.insert(id, entry);
                }
            }
        }
        Ok(())
    }

    /// Get statistics about the ledger
    pub fn stats(&self) -> LedgerStats {
        let total = self.len();
        let mandorla_count = self.artefacts.values()
            .filter(|a| a.is_mandorla_certified)
            .count();

        let avg_resonance = if total > 0 {
            self.artefacts.values()
                .map(|a| a.resonance())
                .sum::<f64>() / total as f64
        } else {
            0.0
        };

        let avg_stability = if total > 0 {
            self.artefacts.values()
                .map(|a| a.stability)
                .sum::<f64>() / total as f64
        } else {
            0.0
        };

        LedgerStats {
            total_artefacts: total,
            mandorla_certified: mandorla_count,
            avg_resonance,
            avg_stability,
        }
    }
}

impl Default for Ledger {
    fn default() -> Self {
        Self::new()
    }
}

/// Ledger statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LedgerStats {
    pub total_artefacts: usize,
    pub mandorla_certified: usize,
    pub avg_resonance: f64,
    pub avg_stability: f64,
}

/// Cubechain statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CubechainStats {
    pub total_cubes: usize,
    pub validated_transitions: usize,
    pub mean_entropy: f64,
    pub stability_index: f64,
    pub metatron_nodes: usize,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::signature::Signature5D;

    #[test]
    fn test_ledger_creation() {
        let ledger = Ledger::new();
        assert_eq!(ledger.len(), 0);
        assert!(ledger.is_empty());
    }

    #[test]
    fn test_commit_and_retrieve() {
        use crate::signature::Signature;
        
        let mut ledger = Ledger::new();
        let artefact = Artefact::new(0, Signature::new());
        let id = artefact.id;

        ledger.commit(artefact).unwrap();

        assert_eq!(ledger.len(), 1);
        assert!(ledger.get(&id).is_some());
    }

    #[test]
    fn test_query_by_resonance() {
        let mut ledger = Ledger::new();

        // Add artefacts with different resonances
        let art1 = Artefact::new(0, Signature5D::with_values(0.9, 0.9, 0.9, 0.9, 0.9).unwrap());
        let art2 = Artefact::new(1, Signature5D::with_values(0.5, 0.5, 0.5, 0.5, 0.5).unwrap());

        ledger.commit(art1).unwrap();
        ledger.commit(art2).unwrap();

        let query = LedgerQuery {
            min_resonance: Some(0.8),
            ..Default::default()
        };

        let results = ledger.query(&query);
        assert_eq!(results.len(), 1);
    }

    #[test]
    fn test_mandorla_query() {
        use crate::signature::Signature;
        
        let mut ledger = Ledger::new();

        let mut art1 = Artefact::new(0, Signature::new());
        art1.is_mandorla_certified = true;

        let art2 = Artefact::new(1, Signature::new());

        ledger.commit(art1).unwrap();
        ledger.commit(art2).unwrap();

        let certified = ledger.get_mandorla_certified();
        assert_eq!(certified.len(), 1);
    }

    #[test]
    fn test_top_resonance() {
        let mut ledger = Ledger::new();

        for i in 0..5 {
            let val = 0.1 * i as f64;
            let art = Artefact::new(i, Signature5D::with_values(val, val, val, val, val).unwrap());
            ledger.commit(art).unwrap();
        }

        let top = ledger.get_top_resonance(3);
        assert_eq!(top.len(), 3);

        // Should be sorted by resonance (highest first)
        assert!(top[0].resonance() > top[1].resonance());
    }

    #[test]
    fn test_replay() {
        use crate::signature::Signature;
        
        let mut ledger = Ledger::new();
        let mut art = Artefact::new(0, Signature::new());

        // Add some transformations
        for i in 1..5 {
            let sig = Signature5D::with_values(
                0.5 + i as f64 * 0.1,
                0.5,
                0.5,
                0.5,
                0.5
            ).unwrap();
            art.record_transformation(i-1, i, format!("t{}", i), sig);
        }

        let id = art.id;
        ledger.commit(art).unwrap();

        let replay = ledger.replay(&id).unwrap();
        assert_eq!(replay.len(), 5); // 1 initial + 4 transformations
    }

    #[test]
    fn test_stats() {
        let mut ledger = Ledger::new();

        for _ in 0..10 {
            let art = Artefact::new(0, Signature5D::with_values(0.8, 0.7, 0.9, 0.6, 0.5).unwrap());
            ledger.commit(art).unwrap();
        }

        let stats = ledger.stats();
        assert_eq!(stats.total_artefacts, 10);
        assert!(stats.avg_resonance > 0.0);
    }

    #[test]
    fn test_cubechain_enable() {
        let mut ledger = Ledger::new();
        assert!(!ledger.is_cubechain_enabled());
        
        ledger.enable_cubechain();
        assert!(ledger.is_cubechain_enabled());
        assert!(ledger.cubechain().is_some());
    }

    #[test]
    fn test_cubechain_commit() {
        use crate::cubechain::OperatorCube;
        
        let mut ledger = Ledger::new();
        ledger.enable_cubechain();
        
        let sig = Signature5D::new(0.6, 0.7, 0.8, 0.5, 0.3);
        let cube = OperatorCube::new(sig);
        let cube_id = cube.id;
        
        let result = ledger.commit_cube(cube, 0);
        assert!(result.is_ok());
        assert_eq!(result.unwrap(), cube_id);
    }

    #[test]
    fn test_cubechain_stats() {
        use crate::cubechain::OperatorCube;
        
        let mut ledger = Ledger::new();
        ledger.enable_cubechain();
        
        // Add some cubes
        for i in 0..5 {
            let sig = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);
            let cube = OperatorCube::new(sig);
            ledger.commit_cube(cube, i % 13).unwrap();
        }
        
        let stats = ledger.cubechain_stats().unwrap();
        assert_eq!(stats.total_cubes, 5);
        assert_eq!(stats.metatron_nodes, 13);
    }

    #[test]
    fn test_cubechain_export_import() {
        let mut ledger = Ledger::new();
        ledger.enable_cubechain();
        
        let sig = Signature5D::new(0.6, 0.7, 0.8, 0.5, 0.3);
        {
            let chain = ledger.cubechain_mut().unwrap();
            chain.bootstrap_genesis(sig).unwrap();
        }
        
        let exported = ledger.export_cubechain().unwrap();
        assert!(!exported.is_empty());
        
        // Create new ledger and import
        let mut ledger2 = Ledger::new();
        ledger2.import_cubechain(&exported).unwrap();
        
        let stats = ledger2.cubechain_stats().unwrap();
        assert_eq!(stats.total_cubes, 2); // Genesis + antipode
    }
}
