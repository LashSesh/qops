//! MOGE-Reasonate Hybrid Kernel with Invariant Crystal Integration
//!
//! This module implements the unified hybrid kernel that combines:
//! - MOGE core operator mining
//! - Reasonate RFAS Kernel (resonance dynamics)
//! - Invariant Crystal Architecture (TIC/MEF/CLIV)
//!
//! ## Data Flow
//! operator_primitives → resonance_dynamics → topology_projection → 
//! evolution_cycle → recursive_optimizer → invariant_crystal_layer
//!
//! ## Feedback Loop
//! recursive_optimizer ↔ invariant_crystal_layer ↔ evolution_cycle

use crate::signature::Signature5D;
use crate::resonance_dynamics::HamiltonianConfig;
use crate::topology_projection::BettiNumbers;
use crate::evolution_cycle::{EvolutionCycle, EvolutionConfig, EvolutionStats};
use crate::recursive_optimizer::RecursiveOptimizer;
use crate::invariant_crystal::{
    InvariantCrystalSystem, InvariantCheck, CrystalizedLivingInformationVector,
};
use crate::error::Result;
use serde::{Deserialize, Serialize};
use std::path::Path;

/// Hybrid kernel configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HybridKernelConfig {
    /// Evolution cycle configuration
    pub evolution: EvolutionConfig,
    /// Hamiltonian dynamics configuration
    pub hamiltonian: HamiltonianConfig,
    /// Number of TIC layers
    pub tic_layers: usize,
    /// MEF fractal depth
    pub mef_depth: usize,
    /// Topology threshold
    pub topology_threshold: f64,
    /// Invariance tolerance
    pub invariance_tolerance: f64,
}

impl Default for HybridKernelConfig {
    fn default() -> Self {
        Self {
            evolution: EvolutionConfig::default(),
            hamiltonian: HamiltonianConfig::default(),
            tic_layers: 128,
            mef_depth: 12,
            topology_threshold: 0.2,
            invariance_tolerance: 1e-4,
        }
    }
}

/// Hybrid kernel state snapshot
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HybridKernelState {
    pub cycle_number: usize,
    pub tick_number: usize,
    pub energy: f64,
    pub energy_drift: f64,
    pub betti_numbers: Option<BettiNumbers>,
    pub invariance_check: Option<InvariantCheck>,
    pub equilibrium_rate: f64,
    pub current_cliv: Option<CrystalizedLivingInformationVector>,
}

impl HybridKernelState {
    pub fn new() -> Self {
        Self {
            cycle_number: 0,
            tick_number: 0,
            energy: 0.0,
            energy_drift: 0.0,
            betti_numbers: None,
            invariance_check: None,
            equilibrium_rate: 0.0,
            current_cliv: None,
        }
    }
}

impl Default for HybridKernelState {
    fn default() -> Self {
        Self::new()
    }
}

/// MOGE-Reasonate Hybrid Kernel
///
/// Unified system combining resonance dynamics, topology, evolution,
/// recursive optimization, and invariant crystal architecture.
pub struct HybridKernel {
    pub config: HybridKernelConfig,
    pub evolution_cycle: EvolutionCycle,
    pub recursive_optimizer: RecursiveOptimizer,
    pub invariant_crystal: InvariantCrystalSystem,
    pub evolution_stats: EvolutionStats,
    pub state: HybridKernelState,
}

impl HybridKernel {
    /// Create new hybrid kernel with initial operator signatures
    pub fn new(config: HybridKernelConfig, initial_operators: Vec<Signature5D>) -> Self {
        let evolution_cycle = EvolutionCycle::new(config.evolution.clone(), initial_operators);
        let recursive_optimizer = RecursiveOptimizer::new();
        let invariant_crystal = InvariantCrystalSystem::new(config.tic_layers, config.mef_depth);
        let evolution_stats = EvolutionStats::new();
        let state = HybridKernelState::new();

        Self {
            config,
            evolution_cycle,
            recursive_optimizer,
            invariant_crystal,
            evolution_stats,
            state,
        }
    }

    /// Run one complete evolution cycle with all integrations
    pub fn run_cycle(&mut self) -> Result<HybridKernelState> {
        // Step 1: Run evolution cycle (15 ticks)
        let cycle_state = self.evolution_cycle.run_cycle()?;

        // Step 2: Update invariant crystal with new signatures
        let signatures = self.evolution_cycle.get_signatures();
        let topology = self.evolution_cycle.get_topology().get_betti_numbers();

        // Add each signature to invariant crystal
        for sig in signatures {
            self.invariant_crystal.update(sig, topology)?;
        }

        // Step 3: Check invariance
        let invariance_check = self.invariant_crystal.check_invariance();

        // Step 4: Apply recursive optimization
        self.recursive_optimizer.optimize_step(
            cycle_state.energy_drift,
            cycle_state.topological_variance,
        );

        // Step 5: Update evolution statistics
        let at_equilibrium = self.evolution_cycle.is_at_equilibrium() && invariance_check.is_stable();
        self.evolution_stats.update(&cycle_state, at_equilibrium);

        // Step 6: Advance crystal cycle
        self.invariant_crystal.advance_cycle();

        // Step 7: Update kernel state
        self.state = HybridKernelState {
            cycle_number: cycle_state.cycle_number,
            tick_number: cycle_state.tick_number,
            energy: cycle_state.energy,
            energy_drift: cycle_state.energy_drift,
            betti_numbers: cycle_state.betti_numbers,
            invariance_check: Some(invariance_check),
            equilibrium_rate: self.evolution_stats.equilibrium_rate(),
            current_cliv: self.invariant_crystal.get_cliv().cloned(),
        };

        Ok(self.state.clone())
    }

    /// Run multiple cycles until convergence or max iterations
    pub fn run_until_convergence(
        &mut self,
        max_cycles: usize,
        target_equilibrium_rate: f64,
    ) -> Result<Vec<HybridKernelState>> {
        let mut states = Vec::new();

        for _ in 0..max_cycles {
            let state = self.run_cycle()?;
            states.push(state.clone());

            // Check if we've reached target equilibrium
            if self.evolution_stats.equilibrium_rate() >= target_equilibrium_rate {
                break;
            }
        }

        Ok(states)
    }

    /// Get current kernel state
    pub fn get_state(&self) -> &HybridKernelState {
        &self.state
    }

    /// Get evolution statistics
    pub fn get_stats(&self) -> &EvolutionStats {
        &self.evolution_stats
    }

    /// Get optimizer statistics
    pub fn get_optimizer_stats(&self) -> crate::recursive_optimizer::OptimizationStats {
        self.recursive_optimizer.get_stats()
    }

    /// Get current CLIV state
    pub fn get_cliv(&self) -> Option<&CrystalizedLivingInformationVector> {
        self.invariant_crystal.get_cliv()
    }

    /// Get invariance check
    pub fn check_invariance(&self) -> InvariantCheck {
        self.invariant_crystal.check_invariance()
    }

    /// Get current operator signatures
    pub fn get_signatures(&self) -> &[Signature5D] {
        self.evolution_cycle.get_signatures()
    }

    /// Get Betti numbers
    pub fn get_betti_numbers(&self) -> Option<BettiNumbers> {
        self.evolution_cycle.get_topology().get_betti_numbers()
    }

    /// Save adaptive constants to file
    pub fn save_constants<P: AsRef<Path>>(&self, path: P) -> Result<()> {
        self.recursive_optimizer.save_constants(path)
    }

    /// Load adaptive constants from file
    pub fn load_constants<P: AsRef<Path>>(&mut self, path: P) -> Result<()> {
        self.recursive_optimizer.load_constants(path)
    }

    /// Export kernel state as JSON
    pub fn export_state_json(&self) -> String {
        serde_json::to_string_pretty(&self.state).unwrap_or_else(|_| "{}".to_string())
    }

    /// Check if system has stabilized
    pub fn is_stabilized(&self, stability_threshold: f64) -> bool {
        if let Some(ref invariance_check) = self.state.invariance_check {
            self.state.equilibrium_rate >= stability_threshold && invariance_check.is_stable()
        } else {
            false
        }
    }

    /// Get stability metrics
    pub fn get_stability_metrics(&self) -> StabilityMetrics {
        let invariance_check = self.check_invariance();

        StabilityMetrics {
            equilibrium_rate: self.evolution_stats.equilibrium_rate(),
            energy_drift: self.state.energy_drift,
            temporal_coherence: invariance_check.temporal_coherence,
            self_similarity: invariance_check.self_similarity,
            stability_score: invariance_check.stability_score(),
            is_stable: invariance_check.is_stable(),
        }
    }
}

/// Stability metrics for the hybrid kernel
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StabilityMetrics {
    pub equilibrium_rate: f64,
    pub energy_drift: f64,
    pub temporal_coherence: f64,
    pub self_similarity: f64,
    pub stability_score: f64,
    pub is_stable: bool,
}

impl StabilityMetrics {
    /// Check if metrics meet target thresholds
    pub fn meets_targets(&self) -> bool {
        self.equilibrium_rate >= 0.95
            && self.energy_drift < 1e-5
            && self.temporal_coherence > 0.95
            && self.self_similarity > 0.97
            && self.is_stable
    }
}

/// Verification pipeline results
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VerificationResults {
    pub resonance_validation: ResonanceValidation,
    pub topology_coherence: TopologyCoherence,
    pub feedback_entropy: FeedbackEntropy,
    pub invariance_validation: InvarianceValidation,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResonanceValidation {
    pub energy_variance: f64,
    pub resonance_stability: f64,
    pub lyapunov_exponent: f64,
    pub passed: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TopologyCoherence {
    pub betti_stability: f64,
    pub lattice_density: f64,
    pub passed: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FeedbackEntropy {
    pub entropy_gradient: f64,
    pub adaptive_convergence: f64,
    pub passed: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InvarianceValidation {
    pub temporal_coherence: f64,
    pub fractal_self_similarity: f64,
    pub mandorla_condition: bool,
    pub passed: bool,
}

impl VerificationResults {
    /// Check if all validations passed
    pub fn all_passed(&self) -> bool {
        self.resonance_validation.passed
            && self.topology_coherence.passed
            && self.feedback_entropy.passed
            && self.invariance_validation.passed
    }
}

/// Run verification pipeline on hybrid kernel
pub fn run_verification_pipeline(kernel: &HybridKernel) -> VerificationResults {
    let state = kernel.get_state();
    let invariance = kernel.check_invariance();
    let betti = kernel.get_betti_numbers();

    // Resonance validation
    let resonance_validation = ResonanceValidation {
        energy_variance: state.energy_drift,
        resonance_stability: 1.0 - state.energy_drift,
        lyapunov_exponent: state.energy_drift * 10.0, // Simplified
        passed: state.energy_drift < 1e-5,
    };

    // Topology coherence
    let lattice_density = if let Some(ref betti_nums) = betti {
        if betti_nums.beta_0 > 0 {
            1.0 - (betti_nums.beta_1 as f64 / (betti_nums.beta_0 + betti_nums.beta_1) as f64)
        } else {
            0.0
        }
    } else {
        0.0
    };

    let topology_coherence = TopologyCoherence {
        betti_stability: invariance.temporal_coherence,
        lattice_density,
        passed: lattice_density >= 0.9,
    };

    // Feedback entropy
    let optimizer_stats = kernel.get_optimizer_stats();
    let feedback_entropy = FeedbackEntropy {
        entropy_gradient: optimizer_stats.avg_energy_drift,
        adaptive_convergence: if optimizer_stats.converged { 1.0 } else { 0.5 },
        passed: optimizer_stats.avg_energy_drift < 1e-3,
    };

    // Invariance validation
    let invariance_validation = InvarianceValidation {
        temporal_coherence: invariance.temporal_coherence,
        fractal_self_similarity: invariance.self_similarity,
        mandorla_condition: invariance.mandorla_condition,
        passed: invariance.temporal_coherence > 0.95
            && invariance.self_similarity >= 0.97
            && invariance.mandorla_condition,
    };

    VerificationResults {
        resonance_validation,
        topology_coherence,
        feedback_entropy,
        invariance_validation,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn create_test_operators() -> Vec<Signature5D> {
        vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
            Signature5D::new(0.6, 0.4, 0.5, 0.5, 0.5),
            Signature5D::new(0.4, 0.6, 0.5, 0.5, 0.5),
        ]
    }

    #[test]
    fn test_hybrid_kernel_creation() {
        let config = HybridKernelConfig::default();
        let operators = create_test_operators();
        let kernel = HybridKernel::new(config, operators);

        assert_eq!(kernel.state.cycle_number, 0);
    }

    #[test]
    fn test_run_single_cycle() {
        let config = HybridKernelConfig::default();
        let operators = create_test_operators();
        let mut kernel = HybridKernel::new(config, operators);

        let result = kernel.run_cycle();
        assert!(result.is_ok());

        let state = result.unwrap();
        assert_eq!(state.cycle_number, 1);
    }

    #[test]
    fn test_invariance_check() {
        let config = HybridKernelConfig::default();
        let operators = create_test_operators();
        let mut kernel = HybridKernel::new(config, operators);

        // Run a few cycles
        for _ in 0..3 {
            kernel.run_cycle().unwrap();
        }

        let invariance = kernel.check_invariance();
        assert!(invariance.temporal_coherence >= 0.0);
        assert!(invariance.self_similarity >= 0.0);
    }

    #[test]
    fn test_stability_metrics() {
        let config = HybridKernelConfig::default();
        let operators = create_test_operators();
        let mut kernel = HybridKernel::new(config, operators);

        kernel.run_cycle().unwrap();

        let metrics = kernel.get_stability_metrics();
        assert!(metrics.stability_score >= 0.0 && metrics.stability_score <= 1.0);
    }

    #[test]
    fn test_verification_pipeline() {
        let config = HybridKernelConfig::default();
        let operators = create_test_operators();
        let mut kernel = HybridKernel::new(config, operators);

        // Run cycles to generate data
        for _ in 0..5 {
            kernel.run_cycle().unwrap();
        }

        let results = run_verification_pipeline(&kernel);
        
        // Check that all fields are populated
        assert!(results.resonance_validation.energy_variance >= 0.0);
        assert!(results.topology_coherence.lattice_density >= 0.0);
    }

    #[test]
    fn test_cliv_export() {
        let config = HybridKernelConfig::default();
        let operators = create_test_operators();
        let mut kernel = HybridKernel::new(config, operators);

        kernel.run_cycle().unwrap();

        if let Some(cliv) = kernel.get_cliv() {
            let json = cliv.to_json();
            assert!(!json.is_empty());
        }
    }

    #[test]
    fn test_run_until_convergence() {
        let config = HybridKernelConfig {
            evolution: EvolutionConfig {
                ticks_per_cycle: 5, // Shorter cycles for testing
                ..Default::default()
            },
            ..Default::default()
        };
        let operators = create_test_operators();
        let mut kernel = HybridKernel::new(config, operators);

        let result = kernel.run_until_convergence(10, 0.5);
        assert!(result.is_ok());

        let states = result.unwrap();
        assert!(states.len() > 0);
        assert!(states.len() <= 10);
    }

    #[test]
    fn test_export_state_json() {
        let config = HybridKernelConfig::default();
        let operators = create_test_operators();
        let mut kernel = HybridKernel::new(config, operators);

        kernel.run_cycle().unwrap();

        let json = kernel.export_state_json();
        assert!(!json.is_empty());
        assert!(json.contains("cycle_number"));
    }
}
