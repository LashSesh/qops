//! Traversal Graph - Multi-hop Reasoning
//!
//! Implements multi-hop reasoning through operator manifolds to explore
//! emergent transitions.
//!
//! Functions:
//! - multi_hop_path: Recursively explores neighbors along weighted resonance edges
//! - select_best_path: Chooses highest-coherence traversal via minimal entropy gain
//!
//! Acts as exploration logic in mining cycles.

use crate::signature::Signature5D;
use crate::resonance_kernel::resonance;
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};

/// Edge in the traversal graph
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TraversalEdge {
    pub from: usize,
    pub to: usize,
    pub weight: f64,
    pub signature_delta: Signature5D,
}

/// Node in the traversal graph
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TraversalNode {
    pub id: usize,
    pub signature: Signature5D,
    pub resonance: f64,
}

impl TraversalNode {
    pub fn new(id: usize, signature: Signature5D) -> Self {
        let res = resonance(&signature);
        Self {
            id,
            signature,
            resonance: res,
        }
    }
}

/// Path through the traversal graph
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TraversalPath {
    pub nodes: Vec<usize>,
    pub total_weight: f64,
    pub coherence: f64,
    pub entropy: f64,
}

impl TraversalPath {
    pub fn new() -> Self {
        Self {
            nodes: Vec::new(),
            total_weight: 0.0,
            coherence: 1.0,
            entropy: 0.0,
        }
    }

    /// Add node to path
    pub fn add_node(&mut self, node_id: usize, edge_weight: f64, resonance: f64) {
        self.nodes.push(node_id);
        self.total_weight += edge_weight;
        self.coherence *= resonance;
        self.entropy -= resonance * resonance.ln().max(-10.0); // Shannon entropy contribution
    }

    /// Get path length
    pub fn length(&self) -> usize {
        self.nodes.len()
    }

    /// Compute path quality score
    pub fn quality_score(&self) -> f64 {
        if self.nodes.is_empty() {
            return 0.0;
        }

        // Quality = coherence / (1 + entropy)
        // Higher coherence and lower entropy is better
        self.coherence / (1.0 + self.entropy)
    }
}

impl Default for TraversalPath {
    fn default() -> Self {
        Self::new()
    }
}

/// Traversal graph for multi-hop exploration
pub struct TraversalGraph {
    pub nodes: HashMap<usize, TraversalNode>,
    pub edges: Vec<TraversalEdge>,
    adjacency: HashMap<usize, Vec<usize>>,
}

impl TraversalGraph {
    pub fn new() -> Self {
        Self {
            nodes: HashMap::new(),
            edges: Vec::new(),
            adjacency: HashMap::new(),
        }
    }

    /// Add node to graph
    pub fn add_node(&mut self, node: TraversalNode) {
        let node_id = node.id;
        self.nodes.insert(node_id, node);
        self.adjacency.entry(node_id).or_insert_with(Vec::new);
    }

    /// Add edge to graph
    pub fn add_edge(&mut self, edge: TraversalEdge) {
        self.adjacency
            .entry(edge.from)
            .or_insert_with(Vec::new)
            .push(edge.to);

        self.edges.push(edge);
    }

    /// Get neighbors of a node
    pub fn get_neighbors(&self, node_id: usize) -> Vec<usize> {
        self.adjacency
            .get(&node_id)
            .cloned()
            .unwrap_or_default()
    }

    /// Get edge between two nodes
    pub fn get_edge(&self, from: usize, to: usize) -> Option<&TraversalEdge> {
        self.edges
            .iter()
            .find(|e| e.from == from && e.to == to)
    }

    /// Multi-hop path exploration
    ///
    /// Recursively explores neighbors along weighted resonance edges
    /// up to specified depth
    pub fn multi_hop_path(&self, start: usize, depth: usize) -> Vec<TraversalPath> {
        let mut paths = Vec::new();
        let mut visited = HashSet::new();
        let mut current_path = TraversalPath::new();

        self.explore_recursive(start, depth, &mut visited, &mut current_path, &mut paths);

        paths
    }

    /// Recursive exploration helper
    fn explore_recursive(
        &self,
        current: usize,
        remaining_depth: usize,
        visited: &mut HashSet<usize>,
        current_path: &mut TraversalPath,
        all_paths: &mut Vec<TraversalPath>,
    ) {
        // Mark as visited
        visited.insert(current);

        // Get current node resonance
        let resonance = self.nodes.get(&current).map(|n| n.resonance).unwrap_or(0.5);

        // Add to path
        let edge_weight = if current_path.nodes.is_empty() {
            0.0
        } else {
            let prev = current_path.nodes[current_path.nodes.len() - 1];
            self.get_edge(prev, current).map(|e| e.weight).unwrap_or(1.0)
        };

        current_path.add_node(current, edge_weight, resonance);

        // If we've reached the desired depth or no more neighbors, store path
        if remaining_depth == 0 || self.get_neighbors(current).is_empty() {
            all_paths.push(current_path.clone());
        } else {
            // Continue exploration
            for neighbor in self.get_neighbors(current) {
                if !visited.contains(&neighbor) {
                    self.explore_recursive(
                        neighbor,
                        remaining_depth - 1,
                        visited,
                        current_path,
                        all_paths,
                    );
                }
            }
        }

        // Backtrack
        current_path.nodes.pop();
        visited.remove(&current);
    }

    /// Select best path from a collection
    ///
    /// Chooses highest-coherence traversal via minimal entropy gain
    pub fn select_best_path<'a>(&self, paths: &'a [TraversalPath]) -> Option<&'a TraversalPath> {
        if paths.is_empty() {
            return None;
        }

        // Find path with highest quality score
        paths.iter().max_by(|a, b| {
            a.quality_score()
                .partial_cmp(&b.quality_score())
                .unwrap_or(std::cmp::Ordering::Equal)
        })
    }

    /// Find all paths between two nodes
    pub fn find_paths_between(&self, start: usize, end: usize, max_depth: usize) -> Vec<TraversalPath> {
        let mut paths = Vec::new();
        let mut visited = HashSet::new();
        let mut current_path = TraversalPath::new();

        self.find_paths_recursive(
            start,
            end,
            max_depth,
            &mut visited,
            &mut current_path,
            &mut paths,
        );

        paths
    }

    /// Recursive path finding helper
    fn find_paths_recursive(
        &self,
        current: usize,
        target: usize,
        remaining_depth: usize,
        visited: &mut HashSet<usize>,
        current_path: &mut TraversalPath,
        all_paths: &mut Vec<TraversalPath>,
    ) {
        visited.insert(current);

        let resonance = self.nodes.get(&current).map(|n| n.resonance).unwrap_or(0.5);
        let edge_weight = if current_path.nodes.is_empty() {
            0.0
        } else {
            let prev = current_path.nodes[current_path.nodes.len() - 1];
            self.get_edge(prev, current).map(|e| e.weight).unwrap_or(1.0)
        };

        current_path.add_node(current, edge_weight, resonance);

        // Found target
        if current == target {
            all_paths.push(current_path.clone());
        } else if remaining_depth > 0 {
            // Continue searching
            for neighbor in self.get_neighbors(current) {
                if !visited.contains(&neighbor) {
                    self.find_paths_recursive(
                        neighbor,
                        target,
                        remaining_depth - 1,
                        visited,
                        current_path,
                        all_paths,
                    );
                }
            }
        }

        // Backtrack
        current_path.nodes.pop();
        visited.remove(&current);
    }

    /// Get statistics about the graph
    pub fn stats(&self) -> GraphStats {
        let node_count = self.nodes.len();
        let edge_count = self.edges.len();

        let avg_resonance = if node_count > 0 {
            self.nodes.values().map(|n| n.resonance).sum::<f64>() / node_count as f64
        } else {
            0.0
        };

        let avg_degree = if node_count > 0 {
            self.adjacency.values().map(|v| v.len()).sum::<usize>() as f64 / node_count as f64
        } else {
            0.0
        };

        GraphStats {
            node_count,
            edge_count,
            avg_resonance,
            avg_degree,
        }
    }
}

impl Default for TraversalGraph {
    fn default() -> Self {
        Self::new()
    }
}

/// Graph statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GraphStats {
    pub node_count: usize,
    pub edge_count: usize,
    pub avg_resonance: f64,
    pub avg_degree: f64,
}

#[cfg(test)]
mod tests {
    use super::*;

    fn create_test_graph() -> TraversalGraph {
        let mut graph = TraversalGraph::new();

        // Add nodes
        for i in 0..5 {
            let sig = Signature5D::new(
                0.5 + i as f64 * 0.1,
                0.5,
                0.5,
                0.5,
                0.5,
            );
            graph.add_node(TraversalNode::new(i, sig));
        }

        // Add edges (linear chain)
        for i in 0..4 {
            graph.add_edge(TraversalEdge {
                from: i,
                to: i + 1,
                weight: 0.1,
                signature_delta: Signature5D::new(0.1, 0.0, 0.0, 0.0, 0.0),
            });
        }

        graph
    }

    #[test]
    fn test_graph_creation() {
        let graph = create_test_graph();
        assert_eq!(graph.nodes.len(), 5);
        assert_eq!(graph.edges.len(), 4);
    }

    #[test]
    fn test_multi_hop_path() {
        let graph = create_test_graph();
        let paths = graph.multi_hop_path(0, 3);

        assert!(paths.len() > 0);
        assert!(paths[0].nodes.len() <= 4); // depth 3 means up to 4 nodes
    }

    #[test]
    fn test_select_best_path() {
        let mut path1 = TraversalPath::new();
        path1.add_node(0, 0.0, 0.9);
        path1.add_node(1, 0.1, 0.9);

        let mut path2 = TraversalPath::new();
        path2.add_node(0, 0.0, 0.5);
        path2.add_node(1, 0.5, 0.5);

        let graph = TraversalGraph::new();
        let paths = vec![path1.clone(), path2.clone()];
        let best = graph.select_best_path(&paths);

        assert!(best.is_some());
        // path1 should be better due to higher coherence
        assert!(best.unwrap().quality_score() > 0.0);
    }

    #[test]
    fn test_find_paths_between() {
        let graph = create_test_graph();
        let paths = graph.find_paths_between(0, 4, 10);

        assert!(paths.len() > 0);
        assert!(paths[0].nodes.first() == Some(&0));
        assert!(paths[0].nodes.last() == Some(&4));
    }

    #[test]
    fn test_path_quality_score() {
        let mut path = TraversalPath::new();
        path.add_node(0, 0.0, 0.9);
        path.add_node(1, 0.1, 0.9);
        path.add_node(2, 0.1, 0.9);

        let score = path.quality_score();
        assert!(score > 0.0);
    }

    #[test]
    fn test_graph_stats() {
        let graph = create_test_graph();
        let stats = graph.stats();

        assert_eq!(stats.node_count, 5);
        assert_eq!(stats.edge_count, 4);
        assert!(stats.avg_resonance > 0.0);
    }
}
