//! Metatron Resonance Pipeline
//!
//! Full deterministic pipeline from operator genesis to cross-domain validation
//! and introspective feedback, as specified in the Metatron Resonance Pipeline Specification.

use crate::operator::Operator;
use crate::resonant_language_projection::ResonantLanguageProjection;
use crate::rule_matrix::{ProjectionNormalizer, RuleMatrixState};
use crate::operator_export_grammar::{OperatorExportGrammar, OperatorExportPackage, ExportFormat};
use crate::operator_reconstruction::OperatorReconstructionInterface;
use crate::operator_validation::{CrossDomainValidation, ValidationReport};
use crate::error::Result;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

/// Metatron Resonance Pipeline - Complete system integration
pub struct MetatronResonancePipeline {
    /// RLP layer
    rlp: ResonantLanguageProjection,
    
    /// Projection normalizer
    normalizer: ProjectionNormalizer,
    
    /// Export grammar
    export_grammar: OperatorExportGrammar,
    
    /// Reconstruction interface
    orti: OperatorReconstructionInterface,
    
    /// Validation protocol
    validation: CrossDomainValidation,
    
    /// Base data directory
    data_dir: PathBuf,
    
    /// Pipeline statistics
    stats: PipelineStatistics,
}

/// Pipeline statistics
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct PipelineStatistics {
    pub operators_processed: usize,
    pub operators_exported: usize,
    pub operators_validated: usize,
    pub validation_failures: usize,
    pub avg_semantic_coherence: f64,
    pub avg_cdci: f64,
}

impl MetatronResonancePipeline {
    /// Create a new Metatron Resonance Pipeline
    pub fn new(data_dir: impl Into<PathBuf>) -> Self {
        let data_dir = data_dir.into();
        let export_dir = data_dir.join("operators/export");
        
        Self {
            rlp: ResonantLanguageProjection::new(),
            normalizer: ProjectionNormalizer::new(),
            export_grammar: OperatorExportGrammar::new(export_dir.to_string_lossy().to_string()),
            orti: OperatorReconstructionInterface::new(),
            validation: CrossDomainValidation::new(),
            data_dir,
            stats: PipelineStatistics::default(),
        }
    }
    
    /// Process operator through complete pipeline
    /// 
    /// Pipeline stages:
    /// 1. Genesis: Operator → TIC (cyclic conversion)
    /// 2. Projection: TIC → Domain projections
    /// 3. Export: Package operator with projections
    /// 4. Translation: Generate domain-specific representations
    /// 5. Validation: Cross-domain verification
    /// 6. Feedback: Adaptive recalibration (if needed)
    pub fn process_operator(&mut self, operator: &Operator) -> Result<ProcessingResult> {
        self.stats.operators_processed += 1;
        
        // Stage 1 & 2: Genesis and Projection
        let (tic_id, mut projections, signature) = self.rlp.process_operator(operator)?;
        
        // Get TIC
        let tic = self.rlp.catalogue().get(&tic_id)
            .ok_or_else(|| crate::error::MogeError::InvalidArtefact("TIC not found".to_string()))?
            .clone();
        
        // Stage 2.5: Normalize projections
        self.normalizer.normalize(tic_id, &mut projections)?;
        
        // Get rule matrix state
        let rule_matrix_state = self.normalizer.rule_matrix().export_state();
        
        // Stage 3: Export
        let package = self.export_grammar.create_package(
            &tic,
            projections,
            rule_matrix_state,
            &signature,
        )?;
        
        // Check export conditions
        let can_export = self.export_grammar.validate_export_conditions(&package);
        
        let export_path = if can_export {
            let path = self.export_grammar.export_package(&package, ExportFormat::Json)?;
            self.stats.operators_exported += 1;
            Some(path)
        } else {
            None
        };
        
        // Stage 4: Translation (generate all domain representations)
        let translations = self.orti.translate_all_domains(&package)?;
        
        // Stage 5: Validation
        let validation_report = self.validation.validate(&package)?;
        
        if validation_report.status == "validated" || validation_report.status == "acceptable" {
            self.stats.operators_validated += 1;
            
            // Update running averages
            let n = self.stats.operators_validated as f64;
            self.stats.avg_semantic_coherence = 
                (self.stats.avg_semantic_coherence * (n - 1.0) + package.metadata.semantic_alignment) / n;
            self.stats.avg_cdci = 
                (self.stats.avg_cdci * (n - 1.0) + validation_report.cdci) / n;
        } else {
            self.stats.validation_failures += 1;
        }
        
        // Stage 6: Feedback (check if recalibration needed)
        let needs_recalibration = self.validation.needs_recalibration(&validation_report);
        
        Ok(ProcessingResult {
            tic_id,
            signature_hash: signature.signature_hash,
            semantic_coherence: signature.semantic_coherence,
            export_path,
            validation_report,
            needs_recalibration,
            translations: translations.into_iter().map(|(d, r)| (d.as_str().to_string(), r)).collect(),
        })
    }
    
    /// Get pipeline statistics
    pub fn statistics(&self) -> &PipelineStatistics {
        &self.stats
    }
    
    /// Get rule matrix state
    pub fn rule_matrix_state(&self) -> RuleMatrixState {
        self.normalizer.rule_matrix().export_state()
    }
    
    /// Export manifest of all processed operators
    pub fn export_manifest(&self, packages: &[OperatorExportPackage]) -> Result<String> {
        self.export_grammar.export_manifest(packages)
    }
    
    /// Save pipeline statistics
    pub fn save_statistics(&self) -> Result<()> {
        let stats_path = self.data_dir.join("pipeline_statistics.json");
        let json = serde_json::to_string_pretty(&self.stats)
            .map_err(|e| crate::error::MogeError::InvalidArtefact(format!("Failed to serialize stats: {}", e)))?;
        
        std::fs::write(&stats_path, json)
            .map_err(|e| crate::error::MogeError::InvalidArtefact(format!("Failed to write stats: {}", e)))?;
        
        Ok(())
    }
}

/// Result of processing an operator through the pipeline
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProcessingResult {
    /// TIC ID
    pub tic_id: uuid::Uuid,
    
    /// Universal signature hash
    pub signature_hash: String,
    
    /// Semantic coherence index
    pub semantic_coherence: f64,
    
    /// Export file path (if exported)
    pub export_path: Option<String>,
    
    /// Validation report
    pub validation_report: ValidationReport,
    
    /// Whether recalibration is needed
    pub needs_recalibration: bool,
    
    /// Domain translations
    pub translations: Vec<(String, crate::operator_reconstruction::DomainRepresentation)>,
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_pipeline_creation() {
        let pipeline = MetatronResonancePipeline::new("/tmp/test_pipeline");
        assert_eq!(pipeline.stats.operators_processed, 0);
    }
    
    #[test]
    fn test_process_operator() {
        let mut pipeline = MetatronResonancePipeline::new("/tmp/test_pipeline");
        let op = Operator::new();
        
        let result = pipeline.process_operator(&op);
        assert!(result.is_ok());
        
        let result = result.unwrap();
        assert!(!result.signature_hash.is_empty());
        assert_eq!(result.translations.len(), 5); // All 5 domains
    }
    
    #[test]
    fn test_pipeline_statistics() {
        let mut pipeline = MetatronResonancePipeline::new("/tmp/test_pipeline");
        
        for _ in 0..5 {
            let op = Operator::new();
            let _ = pipeline.process_operator(&op);
        }
        
        let stats = pipeline.statistics();
        assert_eq!(stats.operators_processed, 5);
    }
    
    #[test]
    fn test_rule_matrix_state() {
        let mut pipeline = MetatronResonancePipeline::new("/tmp/test_pipeline");
        let op = Operator::new();
        
        let _ = pipeline.process_operator(&op);
        
        let state = pipeline.rule_matrix_state();
        assert!(!state.matrix_checksum.is_empty());
    }
}
