//! Resonance Invariant Kernel (RIK)
//!
//! The RIK is the deepest control layer of MOGE. It ensures that only
//! transformations that preserve system coherence are allowed.
//!
//! ## Invariance Condition
//! Every artefact modification must satisfy: Δv · R ≤ ε
//! where:
//! - Δv: Signature difference before/after transformation
//! - R: Resonance function (weighted mean)
//! - ε: Coherence threshold
//!
//! ## Mandorla Zones
//! Signature spaces with stable feedback cycles where operators
//! automatically qualify for ledger certification.

use crate::signature::{Signature, Signature5D};
use crate::artefact::Artefact;
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};

/// Resonance Kernel configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResonanceKernelConfig {
    /// Coherence threshold (ε)
    pub epsilon: f64,
    /// Mandorla stability threshold
    pub mandorla_threshold: f64,
    /// Weights for resonance function [psi, rho, omega, chi, eta]
    pub resonance_weights: [f64; 5],
    /// Enable strict invariance checking
    pub strict_mode: bool,
}

impl Default for ResonanceKernelConfig {
    fn default() -> Self {
        Self {
            epsilon: 0.15,
            mandorla_threshold: 0.85,
            resonance_weights: [0.3, 0.2, 0.2, 0.15, 0.15],
            strict_mode: false,
        }
    }
}

/// The Resonance Invariant Kernel
pub struct ResonanceKernel {
    config: ResonanceKernelConfig,
}

impl ResonanceKernel {
    /// Create a new kernel with default configuration
    pub fn new() -> Self {
        Self {
            config: ResonanceKernelConfig::default(),
        }
    }

    /// Create with custom configuration
    pub fn with_config(config: ResonanceKernelConfig) -> Self {
        Self { config }
    }

    /// Check if a transformation preserves invariance
    ///
    /// Validates: Δv · R ≤ ε
    pub fn check_invariance(
        &self,
        signature_before: &Signature5D,
        signature_after: &Signature5D,
    ) -> Result<bool> {
        let delta = *signature_after - *signature_before;

        // Calculate weighted resonance (R)
        let resonance = self.compute_resonance(&delta);

        // Check invariance condition
        if resonance <= self.config.epsilon {
            Ok(true)
        } else if self.config.strict_mode {
            Err(MogeError::ResonanceViolation(
                format!(
                    "Invariance violated: resonance={:.4} > epsilon={:.4}",
                    resonance, self.config.epsilon
                )
            ))
        } else {
            Ok(false)
        }
    }

    /// Compute weighted resonance function R
    fn compute_resonance(&self, delta: &Signature5D) -> f64 {
        let w = &self.config.resonance_weights;

        (w[0] * delta.psi().abs()
            + w[1] * delta.rho().abs()
            + w[2] * delta.omega().abs()
            + w[3] * delta.chi().abs()
            + w[4] * delta.eta().abs())
            .abs()
    }

    /// Check if an artefact is in a Mandorla zone (stable attractor)
    ///
    /// Mandorla zones are signature regions with stable feedback cycles.
    /// Artefacts within these zones are candidates for ledger certification.
    pub fn is_mandorla_zone(&self, artefact: &Artefact) -> bool {
        if artefact.blueprint.len() < 3 {
            return false;
        }

        // Check stability threshold
        if artefact.stability < self.config.mandorla_threshold {
            return false;
        }

        // Check recent signature fluctuations
        let recent = artefact.blueprint.len().saturating_sub(5);
        let recent_sigs: Vec<_> = artefact.blueprint[recent..]
            .iter()
            .map(|e| e.signature_after)
            .collect();

        if recent_sigs.len() < 2 {
            return false;
        }

        // Calculate variance in recent signatures
        let mut total_distance = 0.0;
        for window in recent_sigs.windows(2) {
            total_distance += window[0].distance(&window[1]);
        }

        let avg_distance = total_distance / (recent_sigs.len() - 1) as f64;

        // Mandorla condition: low fluctuation + high stability
        avg_distance < 0.1 && artefact.stability > self.config.mandorla_threshold
    }

    /// Validate a transformation before applying it
    ///
    /// Returns true if transformation is safe, false otherwise
    pub fn validate_transformation(
        &self,
        current_signature: &Signature5D,
        proposed_signature: &Signature5D,
    ) -> Result<()> {
        // Check validity of new signature
        if !proposed_signature.is_valid() {
            return Err(MogeError::ResonanceViolation(
                "Proposed signature has invalid components".to_string()
            ));
        }

        // Check invariance
        match self.check_invariance(current_signature, proposed_signature)? {
            true => Ok(()),
            false => Err(MogeError::ResonanceViolation(
                "Transformation violates resonance invariance".to_string()
            )),
        }
    }

    /// Adaptive resonance adjustment
    ///
    /// Dynamically adjusts transformation to minimize resonance violation
    pub fn adapt_transformation(
        &self,
        current: &Signature5D,
        proposed: &Signature5D,
        learning_rate: f64,
    ) -> Signature5D {
        let delta = *proposed - *current;
        let resonance = self.compute_resonance(&delta);

        if resonance <= self.config.epsilon {
            return *proposed; // Already valid
        }

        // Scale down the transformation
        let scale = (self.config.epsilon / resonance).min(1.0) * learning_rate;

        Signature5D::with_values(
            current.psi() + delta.psi() * scale,
            current.rho() + delta.rho() * scale,
            current.omega() + delta.omega() * scale,
            current.chi() + delta.chi() * scale,
            current.eta() + delta.eta() * scale,
        ).unwrap_or(*current)
    }

    /// Calculate the "resonance field" around a signature
    ///
    /// Returns how much "room" there is for variation while maintaining invariance
    pub fn resonance_field(&self, signature: &Signature5D) -> f64 {
        // Calculate distance to nearest invalid region
        let mut max_variation = self.config.epsilon;

        // Test perturbations in each dimension
        for &delta in &[-0.1, 0.1] {
            for i in 0..5 {
                let mut test_components = [
                    signature.psi(),
                    signature.rho(),
                    signature.omega(),
                    signature.chi(),
                    signature.eta(),
                ];
                test_components[i] = (test_components[i] + delta).clamp(0.0, 1.0);

                if let Ok(test_sig) = Signature5D::from_components(&test_components) {
                    if let Ok(true) = self.check_invariance(signature, &test_sig) {
                        let resonance = self.compute_resonance(&(test_sig - *signature));
                        max_variation = max_variation.max(resonance);
                    }
                }
            }
        }

        max_variation
    }

    /// Get current configuration
    pub fn config(&self) -> &ResonanceKernelConfig {
        &self.config
    }

    /// Update configuration
    pub fn set_config(&mut self, config: ResonanceKernelConfig) {
        self.config = config;
    }
}

impl Default for ResonanceKernel {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_kernel_creation() {
        let kernel = ResonanceKernel::new();
        assert_eq!(kernel.config().epsilon, 0.15);
    }

    #[test]
    fn test_invariance_check_valid() {
        let kernel = ResonanceKernel::new();
        let sig1 = Signature5D::with_values(0.8, 0.7, 0.9, 0.6, 0.5).unwrap();
        let sig2 = Signature5D::with_values(0.82, 0.71, 0.91, 0.61, 0.51).unwrap();

        let result = kernel.check_invariance(&sig1, &sig2);
        assert!(result.is_ok());
    }

    #[test]
    fn test_invariance_check_large_delta() {
        let mut kernel = ResonanceKernel::new();
        kernel.config.strict_mode = true;

        let sig1 = Signature5D::with_values(0.8, 0.7, 0.9, 0.6, 0.5).unwrap();
        let sig2 = Signature5D::with_values(0.3, 0.2, 0.4, 0.1, 0.1).unwrap();

        let result = kernel.check_invariance(&sig1, &sig2);
        assert!(result.is_err());
    }

    #[test]
    fn test_transformation_validation() {
        let kernel = ResonanceKernel::new();
        let sig1 = Signature5D::with_values(0.8, 0.7, 0.9, 0.6, 0.5).unwrap();
        let sig2 = Signature5D::with_values(0.81, 0.71, 0.90, 0.61, 0.51).unwrap();

        assert!(kernel.validate_transformation(&sig1, &sig2).is_ok());
    }

    #[test]
    fn test_adaptive_transformation() {
        let kernel = ResonanceKernel::new();
        let current = Signature5D::with_values(0.5, 0.5, 0.5, 0.5, 0.5).unwrap();
        let proposed = Signature5D::with_values(0.9, 0.9, 0.9, 0.9, 0.9).unwrap();

        let adapted = kernel.adapt_transformation(&current, &proposed, 0.5);

        // Adapted should be closer to current than proposed
        let dist_adapted = current.distance(&adapted);
        let dist_proposed = current.distance(&proposed);
        assert!(dist_adapted < dist_proposed);
    }

    #[test]
    fn test_resonance_field() {
        let kernel = ResonanceKernel::new();
        let sig = Signature5D::with_values(0.5, 0.5, 0.5, 0.5, 0.5).unwrap();

        let field = kernel.resonance_field(&sig);
        assert!(field > 0.0);
    }

    #[test]
    fn test_mandorla_detection() {
        use crate::artefact::Artefact;
        use crate::signature::Signature;

        let kernel = ResonanceKernel::new();
        let mut artefact = Artefact::new(0, Signature::new());

        // Not enough history
        assert!(!kernel.is_mandorla_zone(&artefact));

        // Add stable transformations
        for i in 1..6 {
            let sig = Signature5D::with_values(0.85, 0.85, 0.85, 0.85, 0.85).unwrap();
            artefact.record_transformation(i-1, i, format!("t{}", i), sig);
        }

        artefact.stability = 0.9; // High stability
        assert!(kernel.is_mandorla_zone(&artefact));
    }
}
