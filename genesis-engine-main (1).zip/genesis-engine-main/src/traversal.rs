//! Traversal API
//!
//! High-level traversal interface combining agents, kernel validation,
//! and ledger archiving.

use crate::agent::{Agent, AgentConfig};
use crate::graph::MetatronCube;
use crate::kernel::ResonanceKernel;
use crate::ledger::Ledger;
use crate::artefact::Artefact;
use crate::error::Result;

/// Traversal engine coordinating all components
pub struct TraversalEngine {
    /// The MetatronCube graph
    pub cube: MetatronCube,
    /// Resonance kernel for validation
    pub kernel: ResonanceKernel,
    /// Ledger for storing artefacts
    pub ledger: Ledger,
}

impl TraversalEngine {
    /// Create a new traversal engine
    pub fn new() -> Self {
        Self {
            cube: MetatronCube::new(),
            kernel: ResonanceKernel::new(),
            ledger: Ledger::new(),
        }
    }

    /// Execute a single agent traversal
    ///
    /// Returns the generated artefact and automatically commits to ledger
    /// if it meets quality criteria
    pub fn execute_traversal(&mut self, agent: &mut Agent) -> Result<Artefact> {
        let artefact = agent.traverse(&self.cube)?;

        // Auto-commit high-quality artefacts
        if self.should_commit(&artefact) {
            self.ledger.commit(artefact.clone())?;
        }

        Ok(artefact)
    }

    /// Run a single agent from the seed node
    pub fn run_single(&mut self, config: AgentConfig) -> Result<Artefact> {
        let seed = self.cube.seed_node();
        let mut agent = Agent::with_config(seed, config);
        self.execute_traversal(&mut agent)
    }

    /// Run multiple agents in parallel (simulated)
    ///
    /// In a real implementation, this could use actual parallelism
    pub fn run_swarm(&mut self, count: usize, config: AgentConfig) -> Result<Vec<Artefact>> {
        let seed = self.cube.seed_node();
        let mut artefacts = Vec::new();

        for _ in 0..count {
            let mut agent = Agent::with_config(seed, config.clone());
            let artefact = self.execute_traversal(&mut agent)?;
            artefacts.push(artefact);
        }

        Ok(artefacts)
    }

    /// Check if artefact should be committed to ledger
    fn should_commit(&self, artefact: &Artefact) -> bool {
        // Commit if Mandorla certified or high quality
        artefact.is_mandorla_certified
            || artefact.resonance() > 0.8
            || artefact.stability > 0.85
    }

    /// Get reference to the cube
    pub fn cube(&self) -> &MetatronCube {
        &self.cube
    }

    /// Get reference to the kernel
    pub fn kernel(&self) -> &ResonanceKernel {
        &self.kernel
    }

    /// Get mutable reference to the ledger
    pub fn ledger_mut(&mut self) -> &mut Ledger {
        &mut self.ledger
    }

    /// Get reference to the ledger
    pub fn ledger(&self) -> &Ledger {
        &self.ledger
    }
}

impl Default for TraversalEngine {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::agent::TraversalStrategy;

    #[test]
    fn test_engine_creation() {
        let engine = TraversalEngine::new();
        assert!(engine.cube().node_count() > 0);
        assert_eq!(engine.ledger().len(), 0);
    }

    #[test]
    fn test_single_traversal() {
        let mut engine = TraversalEngine::new();
        let config = AgentConfig {
            max_steps: 10,
            ..Default::default()
        };

        let result = engine.run_single(config);
        assert!(result.is_ok());
    }

    #[test]
    fn test_swarm_traversal() {
        let mut engine = TraversalEngine::new();
        let config = AgentConfig {
            max_steps: 5,
            strategy: TraversalStrategy::Balanced,
            ..Default::default()
        };

        let result = engine.run_swarm(3, config);
        assert!(result.is_ok());

        let artefacts = result.unwrap();
        assert_eq!(artefacts.len(), 3);
    }

    #[test]
    fn test_auto_commit() {
        let mut engine = TraversalEngine::new();
        let config = AgentConfig {
            max_steps: 20,
            ..Default::default()
        };

        engine.run_single(config).unwrap();

        // Check if ledger is accessible
        // (Depends on traversal outcome)
        let _ = engine.ledger().len();
    }
}
