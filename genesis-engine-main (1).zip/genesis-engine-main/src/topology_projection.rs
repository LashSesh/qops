//! Topology Projection - Geometric Invariant Extraction
//!
//! Triangulates operator state-space and extracts geometric invariants
//! using persistent homology and Betti numbers.
//!
//! Structures:
//! - Node: Operator signature vector (ψ,ρ,ω,χ,η)
//! - Edge: Weighted resonance connection
//! - SimplicialComplex: n-dimensional operator manifold
//!
//! Algorithm:
//! 1. Generate Delaunay triangulation in ψρω-space
//! 2. Compute Betti numbers (β₀,β₁,β₂) for resonance clusters
//! 3. Assign topological weight w=β₁/β₀ per operator colony
//! 4. Store TopologyMap for mining visualization

use crate::signature::Signature5D;
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};

/// Topological node representing an operator signature
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TopologyNode {
    pub id: usize,
    pub signature: Signature5D,
    pub position: [f64; 3], // (ψ, ρ, ω) projection
}

impl TopologyNode {
    pub fn new(id: usize, signature: Signature5D) -> Self {
        Self {
            id,
            signature,
            position: [signature.psi, signature.rho, signature.omega],
        }
    }

    /// Euclidean distance to another node
    pub fn distance_to(&self, other: &TopologyNode) -> f64 {
        let dx = self.position[0] - other.position[0];
        let dy = self.position[1] - other.position[1];
        let dz = self.position[2] - other.position[2];
        (dx * dx + dy * dy + dz * dz).sqrt()
    }
}

/// Weighted resonance edge
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResonanceEdge {
    pub from: usize,
    pub to: usize,
    pub weight: f64,
}

/// Simplicial complex for topological analysis
#[derive(Debug, Clone)]
pub struct SimplicialComplex {
    pub nodes: Vec<TopologyNode>,
    pub edges: Vec<ResonanceEdge>,
    pub triangles: Vec<[usize; 3]>,
}

impl SimplicialComplex {
    pub fn new() -> Self {
        Self {
            nodes: Vec::new(),
            edges: Vec::new(),
            triangles: Vec::new(),
        }
    }

    /// Add node to complex
    pub fn add_node(&mut self, node: TopologyNode) {
        self.nodes.push(node);
    }

    /// Add edge between nodes
    pub fn add_edge(&mut self, from: usize, to: usize, weight: f64) {
        self.edges.push(ResonanceEdge { from, to, weight });
    }

    /// Build Delaunay-like triangulation
    ///
    /// Simplified triangulation: connect nodes within threshold distance
    pub fn build_triangulation(&mut self, threshold: f64) {
        // Build edges based on distance threshold
        for i in 0..self.nodes.len() {
            for j in (i + 1)..self.nodes.len() {
                let dist = self.nodes[i].distance_to(&self.nodes[j]);
                if dist < threshold {
                    self.add_edge(i, j, dist);
                }
            }
        }

        // Find triangles (3-cliques in the graph)
        self.find_triangles();
    }

    /// Find all triangles in the edge graph
    fn find_triangles(&mut self) {
        // Build adjacency list
        let mut adj: HashMap<usize, HashSet<usize>> = HashMap::new();
        for edge in &self.edges {
            adj.entry(edge.from).or_insert_with(HashSet::new).insert(edge.to);
            adj.entry(edge.to).or_insert_with(HashSet::new).insert(edge.from);
        }

        // Find triangles
        let mut triangles = Vec::new();
        for i in 0..self.nodes.len() {
            if let Some(neighbors_i) = adj.get(&i) {
                for &j in neighbors_i {
                    if j > i {
                        if let Some(neighbors_j) = adj.get(&j) {
                            for &k in neighbors_j {
                                if k > j && neighbors_i.contains(&k) {
                                    triangles.push([i, j, k]);
                                }
                            }
                        }
                    }
                }
            }
        }

        self.triangles = triangles;
    }

    /// Compute connected components (β₀)
    pub fn compute_connected_components(&self) -> usize {
        let mut visited = vec![false; self.nodes.len()];
        let mut components = 0;

        // Build adjacency
        let mut adj: HashMap<usize, Vec<usize>> = HashMap::new();
        for edge in &self.edges {
            adj.entry(edge.from).or_insert_with(Vec::new).push(edge.to);
            adj.entry(edge.to).or_insert_with(Vec::new).push(edge.from);
        }

        // DFS to find components
        for start in 0..self.nodes.len() {
            if !visited[start] {
                components += 1;
                let mut stack = vec![start];
                visited[start] = true;

                while let Some(node) = stack.pop() {
                    if let Some(neighbors) = adj.get(&node) {
                        for &neighbor in neighbors {
                            if !visited[neighbor] {
                                visited[neighbor] = true;
                                stack.push(neighbor);
                            }
                        }
                    }
                }
            }
        }

        components
    }

    /// Compute Betti numbers (simplified approximation)
    pub fn compute_betti_numbers(&self) -> BettiNumbers {
        let beta_0 = self.compute_connected_components();

        // β₁ = number of independent cycles (edges - nodes + components)
        // Euler characteristic: V - E + F = χ
        let vertices = self.nodes.len();
        let edges = self.edges.len();
        let faces = self.triangles.len();

        // β₁ approximation: edges - vertices + β₀
        let beta_1 = if edges >= vertices {
            edges - vertices + beta_0
        } else {
            0
        };

        // β₂ approximation: independent voids (simplified)
        let beta_2 = if faces > edges {
            (faces - edges).min(beta_1)
        } else {
            0
        };

        BettiNumbers {
            beta_0,
            beta_1,
            beta_2,
        }
    }
}

impl Default for SimplicialComplex {
    fn default() -> Self {
        Self::new()
    }
}

/// Betti numbers for topological characterization
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct BettiNumbers {
    /// β₀: Number of connected components
    pub beta_0: usize,
    /// β₁: Number of independent cycles (holes)
    pub beta_1: usize,
    /// β₂: Number of voids (cavities)
    pub beta_2: usize,
}

impl BettiNumbers {
    /// Compute topological weight: w = β₁/β₀
    pub fn topological_weight(&self) -> f64 {
        if self.beta_0 == 0 {
            0.0
        } else {
            self.beta_1 as f64 / self.beta_0 as f64
        }
    }

    /// Compute complexity measure
    pub fn complexity(&self) -> f64 {
        (self.beta_0 + self.beta_1 + self.beta_2) as f64
    }
}

/// Topology map for visualization and analysis
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TopologyMap {
    pub betti_numbers: BettiNumbers,
    pub topological_weight: f64,
    pub clusters: Vec<OperatorCluster>,
}

impl TopologyMap {
    pub fn new(complex: &SimplicialComplex) -> Self {
        let betti_numbers = complex.compute_betti_numbers();
        let topological_weight = betti_numbers.topological_weight();

        Self {
            betti_numbers,
            topological_weight,
            clusters: Vec::new(),
        }
    }

    /// Add operator cluster
    pub fn add_cluster(&mut self, cluster: OperatorCluster) {
        self.clusters.push(cluster);
    }
}

/// Operator cluster with topological characteristics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorCluster {
    pub id: usize,
    pub node_ids: Vec<usize>,
    pub centroid: Signature5D,
    pub topological_weight: f64,
}

impl OperatorCluster {
    pub fn new(id: usize, nodes: &[TopologyNode]) -> Self {
        let node_ids: Vec<usize> = nodes.iter().map(|n| n.id).collect();

        // Compute centroid
        let n = nodes.len() as f64;
        let avg_psi = nodes.iter().map(|n| n.signature.psi).sum::<f64>() / n;
        let avg_rho = nodes.iter().map(|n| n.signature.rho).sum::<f64>() / n;
        let avg_omega = nodes.iter().map(|n| n.signature.omega).sum::<f64>() / n;
        let avg_chi = nodes.iter().map(|n| n.signature.chi).sum::<f64>() / n;
        let avg_eta = nodes.iter().map(|n| n.signature.eta).sum::<f64>() / n;

        let centroid = Signature5D::new(avg_psi, avg_rho, avg_omega, avg_chi, avg_eta);

        Self {
            id,
            node_ids,
            centroid,
            topological_weight: 0.0,
        }
    }

    /// Update topological weight
    pub fn set_weight(&mut self, weight: f64) {
        self.topological_weight = weight;
    }
}

/// Topology projection system
pub struct TopologyProjection {
    pub complex: SimplicialComplex,
    pub map: Option<TopologyMap>,
    pub threshold: f64,
}

impl TopologyProjection {
    pub fn new(threshold: f64) -> Self {
        Self {
            complex: SimplicialComplex::new(),
            map: None,
            threshold,
        }
    }

    /// Build topology from signatures
    pub fn build_from_signatures(&mut self, signatures: &[Signature5D]) {
        // Clear existing complex
        self.complex = SimplicialComplex::new();

        // Add nodes
        for (i, sig) in signatures.iter().enumerate() {
            let node = TopologyNode::new(i, *sig);
            self.complex.add_node(node);
        }

        // Build triangulation
        self.complex.build_triangulation(self.threshold);

        // Compute topology map
        self.map = Some(TopologyMap::new(&self.complex));
    }

    /// Get Betti numbers
    pub fn get_betti_numbers(&self) -> Option<BettiNumbers> {
        self.map.as_ref().map(|m| m.betti_numbers)
    }

    /// Get topological weight
    pub fn get_topological_weight(&self) -> f64 {
        self.map.as_ref().map(|m| m.topological_weight).unwrap_or(0.0)
    }

    /// Identify operator clusters
    pub fn identify_clusters(&mut self, min_size: usize) -> Vec<OperatorCluster> {
        // Use connected components as clusters
        let mut visited = vec![false; self.complex.nodes.len()];
        let mut clusters = Vec::new();

        // Build adjacency
        let mut adj: HashMap<usize, Vec<usize>> = HashMap::new();
        for edge in &self.complex.edges {
            adj.entry(edge.from).or_insert_with(Vec::new).push(edge.to);
            adj.entry(edge.to).or_insert_with(Vec::new).push(edge.from);
        }

        let mut cluster_id = 0;
        for start in 0..self.complex.nodes.len() {
            if !visited[start] {
                let mut component = Vec::new();
                let mut stack = vec![start];
                visited[start] = true;

                while let Some(node) = stack.pop() {
                    component.push(node);
                    if let Some(neighbors) = adj.get(&node) {
                        for &neighbor in neighbors {
                            if !visited[neighbor] {
                                visited[neighbor] = true;
                                stack.push(neighbor);
                            }
                        }
                    }
                }

                if component.len() >= min_size {
                    let cluster_nodes: Vec<TopologyNode> = component
                        .iter()
                        .map(|&i| self.complex.nodes[i].clone())
                        .collect();

                    let cluster = OperatorCluster::new(cluster_id, &cluster_nodes);
                    clusters.push(cluster);
                    cluster_id += 1;
                }
            }
        }

        clusters
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_topology_node_distance() {
        let node1 = TopologyNode::new(0, Signature5D::new(0.0, 0.0, 0.0, 0.0, 0.0));
        let node2 = TopologyNode::new(1, Signature5D::new(1.0, 0.0, 0.0, 0.0, 0.0));

        let dist = node1.distance_to(&node2);
        assert!((dist - 1.0).abs() < 1e-6);
    }

    #[test]
    fn test_simplicial_complex() {
        let mut complex = SimplicialComplex::new();

        complex.add_node(TopologyNode::new(0, Signature5D::new(0.0, 0.0, 0.0, 0.5, 0.5)));
        complex.add_node(TopologyNode::new(1, Signature5D::new(0.1, 0.1, 0.1, 0.5, 0.5)));
        complex.add_node(TopologyNode::new(2, Signature5D::new(0.0, 0.1, 0.0, 0.5, 0.5)));

        complex.build_triangulation(0.2);

        assert!(complex.edges.len() > 0);
    }

    #[test]
    fn test_betti_numbers() {
        let mut complex = SimplicialComplex::new();

        // Create a simple triangle
        complex.add_node(TopologyNode::new(0, Signature5D::new(0.0, 0.0, 0.0, 0.5, 0.5)));
        complex.add_node(TopologyNode::new(1, Signature5D::new(0.1, 0.0, 0.0, 0.5, 0.5)));
        complex.add_node(TopologyNode::new(2, Signature5D::new(0.05, 0.1, 0.0, 0.5, 0.5)));

        complex.build_triangulation(0.15);

        let betti = complex.compute_betti_numbers();
        assert_eq!(betti.beta_0, 1); // Should be connected
        assert!(betti.topological_weight() >= 0.0);
    }

    #[test]
    fn test_topology_projection() {
        let signatures = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
            Signature5D::new(0.51, 0.49, 0.5, 0.5, 0.5),
            Signature5D::new(0.49, 0.51, 0.5, 0.5, 0.5),
        ];

        let mut projection = TopologyProjection::new(0.1);
        projection.build_from_signatures(&signatures);

        let betti = projection.get_betti_numbers();
        assert!(betti.is_some());
    }

    #[test]
    fn test_operator_cluster() {
        let nodes = vec![
            TopologyNode::new(0, Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5)),
            TopologyNode::new(1, Signature5D::new(0.6, 0.6, 0.6, 0.6, 0.6)),
        ];

        let cluster = OperatorCluster::new(0, &nodes);
        assert_eq!(cluster.node_ids.len(), 2);
        assert!(cluster.centroid.psi > 0.5);
    }
}
