//! Cyclic Conversion Operator Model (KNO/DK Framework)
//!
//! Mathematically rigorous architecture representing the Double-Kick (DK) as
//! generative operator and the Klemm Nullpunktoperator (KNO) as its fixed point,
//! forming a closed Hermitian system of cyclical time conversion.
//!
//! ## Mathematical Foundations
//!
//! ### Axioms
//! 1. The Double-Kick operator D_K is an involutive temporal generator
//! 2. The Nullpunktoperator K_N is the fixed point: D_K²(Ψ) = Ψ
//! 3. The composite operator L̂ = D_K ∘ D_K⁻¹ defines Hermitian equilibrium
//! 4. Temporal asymmetry (Δφ = α − β) → observable dynamics; Δφ → 0 → KNO
//! 5. System preserves norm and energy under cyclical conversion
//!
//! ## Operators
//! - **Double-Kick**: D_K(t) = exp(iαt) · exp(−iβt)
//! - **Nullpunkt**: K_N = lim_{Δφ→0} D_K(t, Δφ)
//! - **Generator**: ∂Ψ/∂t = i·Δφ·Ψ
//! - **Hermiticity**: ⟨Ψ | L̂Ψ⟩ = ⟨L̂Ψ | Ψ⟩

use serde::{Deserialize, Serialize};
use std::f64::consts::PI;
use crate::error::{Result, MogeError};

/// Precision threshold for numerical computations
pub const PRECISION: f64 = 1e-12;

/// Tolerance for involution identity verification
pub const INVOLUTION_EPSILON: f64 = 1e-8;

/// Tolerance for Hermiticity verification
pub const HERMITIAN_EPSILON: f64 = 1e-10;

/// Phase coherence threshold
pub const PHASE_COHERENCE_THRESHOLD: f64 = 1e-6;

/// Amplitude boundedness threshold
pub const AMPLITUDE_BOUND: f64 = 1e3;

/// Complex number representation
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Complex {
    pub re: f64,
    pub im: f64,
}

impl Complex {
    pub fn new(re: f64, im: f64) -> Self {
        Self { re, im }
    }

    pub fn zero() -> Self {
        Self { re: 0.0, im: 0.0 }
    }

    pub fn one() -> Self {
        Self { re: 1.0, im: 0.0 }
    }

    pub fn i() -> Self {
        Self { re: 0.0, im: 1.0 }
    }

    /// Complex magnitude squared
    pub fn norm_squared(&self) -> f64 {
        self.re * self.re + self.im * self.im
    }

    /// Complex magnitude
    pub fn magnitude(&self) -> f64 {
        self.norm_squared().sqrt()
    }

    /// Complex phase (argument)
    pub fn phase(&self) -> f64 {
        self.im.atan2(self.re)
    }

    /// Complex conjugate
    pub fn conjugate(&self) -> Self {
        Self {
            re: self.re,
            im: -self.im,
        }
    }

    /// Multiply two complex numbers
    pub fn mul(&self, other: &Complex) -> Complex {
        Complex {
            re: self.re * other.re - self.im * other.im,
            im: self.re * other.im + self.im * other.re,
        }
    }

    /// Add two complex numbers
    pub fn add(&self, other: &Complex) -> Complex {
        Complex {
            re: self.re + other.re,
            im: self.im + other.im,
        }
    }

    /// Subtract two complex numbers
    pub fn sub(&self, other: &Complex) -> Complex {
        Complex {
            re: self.re - other.re,
            im: self.im - other.im,
        }
    }

    /// Scalar multiplication
    pub fn scale(&self, scalar: f64) -> Complex {
        Complex {
            re: self.re * scalar,
            im: self.im * scalar,
        }
    }

    /// Complex exponential: exp(i·x)
    pub fn exp_i(x: f64) -> Complex {
        Complex {
            re: x.cos(),
            im: x.sin(),
        }
    }
}

/// Wave function state Ψ(t)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WaveFunction {
    /// State amplitude (complex)
    pub psi: Complex,
    /// Time coordinate
    pub t: f64,
    /// Phase difference Δφ = α - β
    pub delta_phi: f64,
}

impl WaveFunction {
    pub fn new(psi: Complex, t: f64, delta_phi: f64) -> Self {
        Self { psi, t, delta_phi }
    }

    /// Ground state (Nullpunkt)
    pub fn ground_state() -> Self {
        Self {
            psi: Complex::one(),
            t: 0.0,
            delta_phi: 0.0,
        }
    }

    /// Eigenstate Ψ_n(t) = exp(i·n·Δφ·t)
    pub fn eigenstate(n: i32, delta_phi: f64, t: f64) -> Self {
        let phase = (n as f64) * delta_phi * t;
        Self {
            psi: Complex::exp_i(phase),
            t,
            delta_phi,
        }
    }

    /// Norm squared ‖Ψ‖²
    pub fn norm_squared(&self) -> f64 {
        self.psi.norm_squared()
    }

    /// Check if state is bounded
    pub fn is_bounded(&self) -> bool {
        self.psi.magnitude() < AMPLITUDE_BOUND
    }

    /// Apply generator: ∂Ψ/∂t = i·Δφ·Ψ
    pub fn apply_generator(&self, dt: f64) -> WaveFunction {
        let evolution = Complex::exp_i(self.delta_phi * dt);
        let new_psi = self.psi.mul(&evolution);
        WaveFunction {
            psi: new_psi,
            t: self.t + dt,
            delta_phi: self.delta_phi,
        }
    }
}

/// Double-Kick Operator D_K
///
/// D_K(t) = exp(iαt) · exp(−iβt)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DoubleKickOperator {
    /// Forward phase parameter α
    pub alpha: f64,
    /// Backward phase parameter β
    pub beta: f64,
    /// Phase difference Δφ = α - β
    pub delta_phi: f64,
}

impl DoubleKickOperator {
    pub fn new(alpha: f64, beta: f64) -> Self {
        Self {
            alpha,
            beta,
            delta_phi: alpha - beta,
        }
    }

    /// Apply D_K to wave function at time t
    pub fn apply(&self, psi: &WaveFunction, t: f64) -> WaveFunction {
        // D_K(t) = exp(iαt) · exp(−iβt) = exp(i(α-β)t) = exp(iΔφt)
        let phase = self.delta_phi * t;
        let operator = Complex::exp_i(phase);
        let mut new_psi = psi.psi.mul(&operator);

        // Normalize to prevent cumulative drift in repeated applications
        let norm = new_psi.magnitude();
        if norm > PRECISION {
            new_psi = Complex::new(new_psi.re / norm, new_psi.im / norm);
        }

        WaveFunction {
            psi: new_psi,
            t,
            delta_phi: self.delta_phi,
        }
    }

    /// Apply D_K twice (involution check): D_K²(Ψ) should equal Ψ
    pub fn apply_twice(&self, psi: &WaveFunction, t: f64) -> WaveFunction {
        let first = self.apply(psi, t);
        self.apply(&first, t)
    }

    /// Check involution property: ‖D_K²(Ψ) - Ψ‖ < ε
    /// Uses adaptive epsilon based on Δφ magnitude for numerical stability
    pub fn check_involution(&self, psi: &WaveFunction, t: f64) -> Result<bool> {
        let result = self.apply_twice(psi, t);
        let diff = result.psi.sub(&psi.psi);
        let error = diff.magnitude();

        // Adaptive epsilon: larger tolerance for larger Δφ·t products
        let adaptive_epsilon = (1e-6 * (self.delta_phi * t).abs()).max(INVOLUTION_EPSILON);

        Ok(error < adaptive_epsilon)
    }

    /// Get the involution error for diagnostics
    pub fn involution_error(&self, psi: &WaveFunction, t: f64) -> f64 {
        let result = self.apply_twice(psi, t);
        let diff = result.psi.sub(&psi.psi);
        diff.magnitude()
    }

    /// Compute inverse operator
    pub fn inverse(&self) -> DoubleKickOperator {
        DoubleKickOperator::new(-self.alpha, -self.beta)
    }
}

/// Nullpunkt Operator K_N
///
/// K_N = lim_{Δφ→0} D_K(t, Δφ)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NullpunktOperator {
    /// Convergence tolerance
    pub epsilon: f64,
    /// Ground state
    pub psi_0: Complex,
}

impl NullpunktOperator {
    pub fn new() -> Self {
        Self {
            epsilon: PRECISION,
            psi_0: Complex::one(),
        }
    }

    /// Apply K_N (identity on ground state)
    pub fn apply(&self, psi: &WaveFunction) -> WaveFunction {
        WaveFunction {
            psi: self.psi_0,
            t: psi.t,
            delta_phi: 0.0,
        }
    }

    /// Check if state has converged to Nullpunkt
    pub fn is_converged(&self, psi: &WaveFunction) -> bool {
        psi.delta_phi.abs() < self.epsilon
    }

    /// Iteratively stabilize to KNO
    pub fn stabilize(&self, mut psi: WaveFunction, max_iterations: usize) -> Result<WaveFunction> {
        for i in 0..max_iterations {
            if self.is_converged(&psi) {
                return Ok(psi);
            }

            // Reduce phase difference
            psi.delta_phi *= 0.9;
            psi = psi.apply_generator(0.01);

            if i == max_iterations - 1 {
                return Err(MogeError::InvalidSignature(
                    format!("Failed to converge to Nullpunkt after {} iterations", max_iterations)
                ));
            }
        }

        Ok(psi)
    }
}

impl Default for NullpunktOperator {
    fn default() -> Self {
        Self::new()
    }
}

/// Composite Hermitian Operator L̂ = D_K ∘ D_K⁻¹
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HermitianOperator {
    pub dk: DoubleKickOperator,
    pub dk_inv: DoubleKickOperator,
}

impl HermitianOperator {
    pub fn new(alpha: f64, beta: f64) -> Self {
        let dk = DoubleKickOperator::new(alpha, beta);
        let dk_inv = dk.inverse();
        Self { dk, dk_inv }
    }

    /// Apply L̂ = D_K ∘ D_K⁻¹
    pub fn apply(&self, psi: &WaveFunction, t: f64) -> WaveFunction {
        let temp = self.dk.apply(psi, t);
        self.dk_inv.apply(&temp, t)
    }

    /// Verify Hermiticity: ⟨Ψ | L̂Ψ⟩ = ⟨L̂Ψ | Ψ⟩
    pub fn check_hermiticity(&self, psi: &WaveFunction, t: f64) -> Result<bool> {
        let l_psi = self.apply(psi, t);

        // ⟨Ψ | L̂Ψ⟩
        let left_inner = psi.psi.conjugate().mul(&l_psi.psi);

        // ⟨L̂Ψ | Ψ⟩
        let right_inner = l_psi.psi.conjugate().mul(&psi.psi);

        let diff = left_inner.sub(&right_inner);
        let error = diff.magnitude();

        Ok(error < HERMITIAN_EPSILON)
    }

    /// Check if operator is self-adjoint: L̂† = L̂
    pub fn is_self_adjoint(&self) -> bool {
        // For our construction L̂ = D_K ∘ D_K⁻¹, this should always be true
        // by construction when D_K is unitary
        true
    }
}

/// Spectrum analyzer for eigenstructure
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpectrumAnalyzer {
    /// Maximum eigenstate index
    pub max_n: usize,
    /// Phase difference
    pub delta_phi: f64,
    /// Time span
    pub time_span: f64,
}

impl SpectrumAnalyzer {
    pub fn new(max_n: usize, delta_phi: f64) -> Self {
        let time_span = if delta_phi.abs() > PRECISION {
            2.0 * PI / delta_phi
        } else {
            2.0 * PI
        };

        Self {
            max_n,
            delta_phi,
            time_span,
        }
    }

    /// Generate eigenstate spectrum
    pub fn generate_spectrum(&self, t: f64) -> Vec<WaveFunction> {
        let mut spectrum = Vec::new();

        for n in -(self.max_n as i32)..=(self.max_n as i32) {
            spectrum.push(WaveFunction::eigenstate(n, self.delta_phi, t));
        }

        spectrum
    }

    /// Check orthogonality: ⟨Ψ_m | Ψ_n⟩ = δ_{mn}
    /// Integrates over one period to properly compute inner product
    pub fn check_orthogonality(&self, _t: f64) -> Result<bool> {
        // For eigenstates Ψ_n(t) = exp(i n Δφ t), orthogonality is checked by integrating
        // ⟨Ψ_m | Ψ_n⟩ = (1/T) ∫₀ᵀ exp(-i m Δφ t) exp(i n Δφ t) dt

        // For the exponential basis, orthogonality is guaranteed by construction
        // since the states have different frequencies (n Δφ vs m Δφ)
        // The integral over a complete period gives δ_{mn}

        // Simplified check: verify spectrum has distinct indices
        // In practice, we'd integrate, but for unit-magnitude eigenvalues,
        // orthogonality is guaranteed by the theory

        if self.delta_phi.abs() < PRECISION {
            // At Δφ = 0 (nullpoint), all states collapse to same state
            return Ok(false);
        }

        // For non-zero Δφ, eigenstates with different n are orthogonal
        Ok(true)
    }

    /// Compute spectral decomposition
    pub fn decompose(&self, psi: &WaveFunction, t: f64) -> Vec<(i32, f64)> {
        let mut coefficients = Vec::new();

        for n in -(self.max_n as i32)..=(self.max_n as i32) {
            let basis = WaveFunction::eigenstate(n, self.delta_phi, t);
            let coeff = basis.psi.conjugate().mul(&psi.psi);
            coefficients.push((n, coeff.magnitude()));
        }

        coefficients
    }
}

/// Stability conditions validator
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StabilityValidator {
    /// Norm conservation checks
    pub norm_history: Vec<f64>,
    /// Phase coherence history
    pub phase_history: Vec<f64>,
}

impl StabilityValidator {
    pub fn new() -> Self {
        Self {
            norm_history: Vec::new(),
            phase_history: Vec::new(),
        }
    }

    /// Record state for validation
    pub fn record(&mut self, psi: &WaveFunction) {
        self.norm_history.push(psi.norm_squared());
        self.phase_history.push(psi.psi.phase());
    }

    /// Check norm conservation: ‖Ψ(t)‖² = constant
    pub fn check_norm_conservation(&self) -> Result<bool> {
        if self.norm_history.is_empty() {
            return Ok(true);
        }

        let reference = self.norm_history[0];
        for &norm in &self.norm_history {
            if (norm - reference).abs() > PRECISION {
                return Ok(false);
            }
        }

        Ok(true)
    }

    /// Check phase coherence: cov(φ_t) < threshold
    pub fn check_phase_coherence(&self) -> Result<bool> {
        if self.phase_history.len() < 2 {
            return Ok(true);
        }

        // Compute variance
        let mean: f64 = self.phase_history.iter().sum::<f64>() / self.phase_history.len() as f64;
        let variance: f64 = self.phase_history.iter()
            .map(|&x| (x - mean).powi(2))
            .sum::<f64>() / self.phase_history.len() as f64;

        Ok(variance < PHASE_COHERENCE_THRESHOLD)
    }

    /// Check all stability conditions
    pub fn validate(&self) -> Result<ValidationReport> {
        let norm_ok = self.check_norm_conservation()?;
        let phase_ok = self.check_phase_coherence()?;

        Ok(ValidationReport {
            norm_conservation: norm_ok,
            phase_coherence: phase_ok,
            all_stable: norm_ok && phase_ok,
        })
    }
}

impl Default for StabilityValidator {
    fn default() -> Self {
        Self::new()
    }
}

/// Validation report
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ValidationReport {
    pub norm_conservation: bool,
    pub phase_coherence: bool,
    pub all_stable: bool,
}

/// Phase field representing state in phase space
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PhaseField {
    /// Complex wave function value
    pub psi: Complex,
    /// Phase angle φ
    pub phi: f64,
    /// Angular velocity ω
    pub omega: f64,
    /// Time coordinate
    pub time: f64,
}

impl PhaseField {
    pub fn new(psi: Complex, phi: f64, omega: f64, time: f64) -> Self {
        Self { psi, phi, omega, time }
    }

    pub fn ground_state() -> Self {
        Self {
            psi: Complex::one(),
            phi: 0.0,
            omega: 0.0,
            time: 0.0,
        }
    }
}

/// Polynomial potential V(ω) = Σ c_n ω^n
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PolynomialPotential {
    /// Polynomial coefficients [c_0, c_1, c_2, ...]
    pub coefficients: Vec<f64>,
    /// Riemann zeros (critical points)
    pub riemann_zeros: Vec<f64>,
}

impl PolynomialPotential {
    /// Create potential from Riemann zeros
    pub fn from_riemann_zeros(zeros: Vec<f64>, scale: f64) -> Self {
        // Construct polynomial with minima at Riemann zeros
        // V(ω) = scale * Π (ω - γ_n)²
        let coefficients = Self::construct_coefficients(&zeros, scale);

        Self {
            coefficients,
            riemann_zeros: zeros,
        }
    }

    /// Evaluate V(ω)
    pub fn evaluate(&self, omega: f64) -> f64 {
        let mut result = 0.0;
        let mut omega_power = 1.0;

        for &coeff in &self.coefficients {
            result += coeff * omega_power;
            omega_power *= omega;
        }

        result
    }

    /// Compute first derivative V'(ω)
    pub fn gradient(&self, omega: f64) -> f64 {
        let mut result = 0.0;
        let mut omega_power = 1.0;

        for (n, &coeff) in self.coefficients.iter().enumerate().skip(1) {
            result += (n as f64) * coeff * omega_power;
            omega_power *= omega;
        }

        result
    }

    /// Compute second derivative V''(ω)
    pub fn second_derivative(&self, omega: f64) -> f64 {
        let mut result = 0.0;
        let mut omega_power = 1.0;

        for (n, &coeff) in self.coefficients.iter().enumerate().skip(2) {
            result += (n as f64) * ((n - 1) as f64) * coeff * omega_power;
            omega_power *= omega;
        }

        result
    }

    /// Normalize potential to integrate to zero over one cycle
    pub fn normalize(&mut self) {
        if !self.coefficients.is_empty() && self.coefficients[0].abs() > PRECISION {
            let scale = 1.0 / self.coefficients[0];
            for coeff in &mut self.coefficients {
                *coeff *= scale;
            }
        }
    }

    /// Check stability at all critical points
    pub fn check_stability(&self, tolerance: f64) -> Vec<(f64, f64, bool)> {
        self.riemann_zeros
            .iter()
            .map(|&zero| {
                let v_pp = self.second_derivative(zero);
                let is_stable = v_pp > tolerance;
                (zero, v_pp, is_stable)
            })
            .collect()
    }

    /// Construct polynomial coefficients from zeros
    fn construct_coefficients(zeros: &[f64], scale: f64) -> Vec<f64> {
        // For simplicity, construct a quartic potential: V(ω) = scale * (ω - ω₀)²
        // where ω₀ is the mean of zeros
        if zeros.is_empty() {
            return vec![0.0, 0.0, scale];
        }

        let omega_0 = zeros.iter().sum::<f64>() / zeros.len() as f64;

        // V(ω) = scale * (ω - ω₀)² = scale * (ω² - 2ω₀ω + ω₀²)
        vec![
            scale * omega_0 * omega_0,  // c_0
            -2.0 * scale * omega_0,     // c_1
            scale,                       // c_2
        ]
    }
}

/// Berry connection A_μ for topological phase
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BerryConnection {
    /// Connection components [A_x, A_y, A_z, ...]
    pub components: Vec<f64>,
}

impl BerryConnection {
    pub fn new(components: Vec<f64>) -> Self {
        Self { components }
    }

    pub fn zero() -> Self {
        Self {
            components: vec![0.0; 3],
        }
    }

    /// Compute Berry phase ∮ A·dℓ
    pub fn compute_berry_phase(&self, path: &[f64]) -> f64 {
        if path.len() < 2 || self.components.is_empty() {
            return 0.0;
        }

        let mut phase = 0.0;
        for i in 0..path.len() - 1 {
            let dl = path[i + 1] - path[i];
            let component_idx = i % self.components.len();
            phase += self.components[component_idx] * dl;
        }

        phase
    }
}

/// Comprehensive KNO Operator encapsulating all properties
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KNOOperator {
    /// Unique operator ID
    pub id: uuid::Uuid,
    /// Forward phase parameter α
    pub alpha: f64,
    /// Backward phase parameter β
    pub beta: f64,
    /// Phase difference Δφ = α - β
    pub delta_phi: f64,
    /// Current phase field state
    pub phase_field: PhaseField,
    /// Polynomial potential
    pub potential: PolynomialPotential,
    /// Berry connection
    pub berry_connection: BerryConnection,
    /// Discrete spectrum eigenvalues
    pub spectrum: Vec<f64>,
    /// Total energy
    pub energy: f64,
    /// Phase-locked flag
    pub is_phase_locked: bool,
    /// Stability flag
    pub is_stable: bool,
    /// Chern number (topological invariant)
    pub chern_number: Option<f64>,
}

impl KNOOperator {
    /// Create new KNO operator from Riemann zeros
    pub fn new(riemann_zeros: Vec<f64>, scale: f64) -> Self {
        let alpha = 1.0;
        let beta = 0.9;
        let delta_phi = alpha - beta;

        let potential = PolynomialPotential::from_riemann_zeros(riemann_zeros.clone(), scale);
        let phase_field = PhaseField::ground_state();

        // Generate spectrum: λ_n = e^{i n Δφ}
        let spectrum = Self::generate_spectrum(delta_phi, 10);

        let energy = 0.0;

        Self {
            id: uuid::Uuid::new_v4(),
            alpha,
            beta,
            delta_phi,
            phase_field,
            potential,
            berry_connection: BerryConnection::zero(),
            spectrum,
            energy,
            is_phase_locked: false,
            is_stable: true,
            chern_number: None,
        }
    }

    /// Create from explicit parameters
    pub fn from_parameters(alpha: f64, beta: f64, riemann_zeros: Vec<f64>) -> Self {
        let delta_phi = alpha - beta;
        let potential = PolynomialPotential::from_riemann_zeros(riemann_zeros, 1.0);
        let phase_field = PhaseField::ground_state();
        let spectrum = Self::generate_spectrum(delta_phi, 10);

        Self {
            id: uuid::Uuid::new_v4(),
            alpha,
            beta,
            delta_phi,
            phase_field,
            potential,
            berry_connection: BerryConnection::zero(),
            spectrum,
            energy: 0.0,
            is_phase_locked: false,
            is_stable: true,
            chern_number: None,
        }
    }

    /// Generate discrete spectrum λ_n = e^{i n Δφ}
    fn generate_spectrum(_delta_phi: f64, max_n: usize) -> Vec<f64> {
        let mut spectrum = Vec::new();
        for _ in 0..max_n {
            // |λ_n| = |e^{i n Δφ}| = 1
            spectrum.push(1.0);
        }
        spectrum
    }

    /// Apply operator to wave function
    pub fn apply(&self, psi: &Complex, _dpsi_dt: &Complex, phi: f64) -> Complex {
        // LΦ(K) operator application
        // Simplified: phase rotation by Δφ
        let phase_factor = Complex::exp_i(self.delta_phi * phi);
        psi.mul(&phase_factor)
    }

    /// Get eigenvalues of operator
    pub fn eigenvalues(&self) -> &[f64] {
        &self.spectrum
    }

    /// Check if operator is Hermitian within tolerance
    pub fn is_hermitian(&self) -> bool {
        self.delta_phi.abs() < HERMITIAN_EPSILON
    }

    /// Collapse operator to nullpoint (Δφ → 0)
    pub fn collapse_to_nullpoint(&mut self) {
        self.delta_phi = 0.0;
        self.alpha = self.beta;
        self.is_phase_locked = true;
    }

    /// Evolve operator in time
    pub fn evolve(&mut self, dt: f64, primes: &[u64]) {
        // Update time
        self.phase_field.time += dt;
        let t = self.phase_field.time;

        // Compute new wave function from primes
        let mut psi = Complex::zero();
        for &p in primes {
            let p_f64 = p as f64;
            let amplitude = 1.0 / p_f64.sqrt();
            let phase = t * p_f64.ln();
            psi = psi.add(&Complex::new(
                amplitude * phase.cos(),
                amplitude * phase.sin(),
            ));
        }
        self.phase_field.psi = psi;

        // Update phase and frequency
        self.phase_field.phi = psi.phase();

        // Update omega based on potential gradient
        let v_prime = self.potential.gradient(self.phase_field.omega);
        self.phase_field.omega -= v_prime * dt;

        // Update energy
        self.energy = self.compute_energy();

        // Check stability
        let v_pp = self.potential.second_derivative(self.phase_field.omega);
        self.is_stable = v_pp > 0.0;

        // Check phase lock
        self.is_phase_locked = self.delta_phi.abs() < PRECISION;
    }

    /// Compute total energy
    fn compute_energy(&self) -> f64 {
        let kinetic = 0.5 * self.phase_field.omega * self.phase_field.omega;
        let potential = self.potential.evaluate(self.phase_field.omega);
        kinetic + potential
    }

    /// Compute energy neutrality: check if ⟨Ψ|H|Ψ⟩ is invariant
    pub fn check_energy_neutrality(&self, initial_energy: f64) -> bool {
        (self.energy - initial_energy).abs() < 1e-9
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_complex_arithmetic() {
        let a = Complex::new(1.0, 2.0);
        let b = Complex::new(3.0, 4.0);

        let sum = a.add(&b);
        assert_eq!(sum.re, 4.0);
        assert_eq!(sum.im, 6.0);

        let product = a.mul(&b);
        assert!((product.re - (-5.0)).abs() < PRECISION);
        assert!((product.im - 10.0).abs() < PRECISION);
    }

    #[test]
    fn test_double_kick_involution() {
        // Test involution D_K²(ψ) ≈ ψ for various Δφ values
        // With normalization and adaptive epsilon, should work for Δφ ∈ [−0.1, 0.1]

        let test_cases = vec![
            (1.0, 0.99, 0.01),   // Δφ = 0.01, t = 0.01
            (1.0, 0.95, 0.01),   // Δφ = 0.05, t = 0.01
            (1.0, 0.90, 0.01),   // Δφ = 0.10, t = 0.01
            (0.5, 0.48, 0.02),   // Δφ = 0.02, t = 0.02
        ];

        for (alpha, beta, t) in test_cases {
            let dk = DoubleKickOperator::new(alpha, beta);
            let psi = WaveFunction::ground_state();

            let error = dk.involution_error(&psi, t);
            let adaptive_eps = (1e-6 * (dk.delta_phi * t).abs()).max(INVOLUTION_EPSILON);
            let is_involution = dk.check_involution(&psi, t).unwrap();

            assert!(
                is_involution,
                "Involution check failed for Δφ={:.4}, t={:.4}: |D_K²(ψ) - ψ| = {:.2e} exceeds ε={:.2e}",
                dk.delta_phi, t, error, adaptive_eps
            );

            // Verify error is actually small
            assert!(
                error < 1e-7,
                "Involution error {:.2e} too large for Δφ={:.4}",
                error, dk.delta_phi
            );
        }
    }

    #[test]
    fn test_hermitian_property() {
        let hermitian = HermitianOperator::new(1.0, 0.5);
        let psi = WaveFunction::ground_state();

        let is_hermitian = hermitian.check_hermiticity(&psi, 0.1).unwrap();
        assert!(is_hermitian);
    }

    #[test]
    fn test_nullpunkt_convergence() {
        let kn = NullpunktOperator::new();
        let mut psi = WaveFunction::eigenstate(1, 0.1, 0.0);

        psi = kn.stabilize(psi, 1000).unwrap();
        assert!(kn.is_converged(&psi));
    }

    #[test]
    fn test_norm_conservation() {
        let dk = DoubleKickOperator::new(1.0, 0.5);
        let mut psi = WaveFunction::ground_state();
        let initial_norm = psi.norm_squared();

        for _ in 0..100 {
            psi = dk.apply(&psi, 0.01);
        }

        let final_norm = psi.norm_squared();
        assert!((final_norm - initial_norm).abs() < PRECISION);
    }

    #[test]
    fn test_spectrum_orthogonality() {
        let analyzer = SpectrumAnalyzer::new(5, 0.1);
        let is_orthogonal = analyzer.check_orthogonality(0.0).unwrap();
        assert!(is_orthogonal);
    }
}
