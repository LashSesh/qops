//! Export Module
//!
//! Provides export functionality for visualization and analysis:
//! - Graphviz DOT format for path visualization
//! - JSON export for web-based tools
//! - SVG generation for static visualizations

use crate::artefact::Artefact;
use crate::graph::MetatronCube;
use crate::error::Result;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Graphviz export options
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GraphvizOptions {
    /// Include edge weights
    pub show_weights: bool,
    /// Include signature deltas
    pub show_deltas: bool,
    /// Highlight mandorla-certified nodes
    pub highlight_mandorla: bool,
    /// Color scheme: "spectral", "plasma", "viridis"
    pub color_scheme: String,
    /// Maximum nodes to include (prevents huge graphs)
    pub max_nodes: Option<usize>,
}

impl Default for GraphvizOptions {
    fn default() -> Self {
        Self {
            show_weights: true,
            show_deltas: true,
            highlight_mandorla: true,
            color_scheme: "spectral".to_string(),
            max_nodes: Some(100),
        }
    }
}

/// Export an artefact's blueprint path as Graphviz DOT format
pub fn export_artefact_path_graphviz(
    artefact: &Artefact,
    graph: &MetatronCube,
    options: &GraphvizOptions,
) -> Result<String> {
    let mut dot = String::new();

    // Header
    dot.push_str("digraph ArtefactPath {\n");
    dot.push_str("  rankdir=LR;\n");
    dot.push_str("  node [shape=circle, style=filled];\n");
    dot.push_str("  edge [fontsize=10];\n\n");

    // Add title
    dot.push_str(&format!(
        "  label=\"Artefact {} | Resonance: {:.4}\";\n",
        artefact.id,
        artefact.resonance()
    ));
    dot.push_str("  labelloc=\"t\";\n\n");

    // Track visited nodes for deduplication
    let mut visited_nodes = HashMap::new();

    // Process blueprint path
    let blueprint = &artefact.blueprint;
    if blueprint.is_empty() {
        return Ok(dot + "}\n");
    }

    // Add nodes
    for (idx, entry) in blueprint.iter().enumerate() {
        if let Some(max) = options.max_nodes {
            if idx >= max {
                dot.push_str("  \"...\" [shape=plaintext];\n");
                break;
            }
        }

        let node_label = format!("N{}", idx);
        let node_id = if idx == 0 { entry.from_node } else { entry.to_node };
        visited_nodes.insert(node_id, node_label.clone());

        // Color based on position in path
        let color = get_color_for_position(idx, blueprint.len(), &options.color_scheme);

        let mut attrs = format!("fillcolor=\"{}\"", color);

        // Highlight mandorla certification
        if options.highlight_mandorla && artefact.is_mandorla_certified && idx == blueprint.len() - 1 {
            attrs.push_str(", penwidth=3, color=gold");
        }

        dot.push_str(&format!(
            "  \"{}\" [label=\"{}\\n{}\", {}];\n",
            node_label,
            node_label,
            format_node_id(node_id),
            attrs
        ));
    }

    dot.push_str("\n");

    // Add edges
    for i in 0..blueprint.len().saturating_sub(1) {
        if let Some(max) = options.max_nodes {
            if i >= max - 1 {
                break;
            }
        }

        let from = format!("N{}", i);
        let to = format!("N{}", i + 1);

        let mut edge_attrs = Vec::new();

        // Add edge weight if available and requested
        if options.show_weights {
            if let (Some(from_idx), Some(to_idx)) = (
                graph.get_node_by_id(blueprint[i].from_node),
                graph.get_node_by_id(blueprint[i].to_node)
            ) {
                if let Some(edge) = graph.get_edge(from_idx, to_idx) {
                    edge_attrs.push(format!("label=\"w:{:.2}\"", edge.weight));
                }
            }
        }

        dot.push_str(&format!(
            "  \"{}\" -> \"{}\"",
            from, to
        ));

        if !edge_attrs.is_empty() {
            dot.push_str(&format!(" [{}]", edge_attrs.join(", ")));
        }

        dot.push_str(";\n");
    }

    dot.push_str("}\n");

    Ok(dot)
}

/// Export multiple artefacts as a combined Graphviz graph
pub fn export_artefacts_combined_graphviz(
    artefacts: &[&Artefact],
    _graph: &MetatronCube,
    options: &GraphvizOptions,
) -> Result<String> {
    let mut dot = String::new();

    // Header
    dot.push_str("digraph CombinedPaths {\n");
    dot.push_str("  rankdir=LR;\n");
    dot.push_str("  node [shape=circle, style=filled];\n");
    dot.push_str("  edge [fontsize=8];\n\n");

    dot.push_str(&format!(
        "  label=\"Combined {} Artefact Paths\";\n",
        artefacts.len()
    ));
    dot.push_str("  labelloc=\"t\";\n\n");

    // Track all nodes and edges
    let mut all_nodes = HashMap::new();
    let mut edge_counts: HashMap<(usize, usize), usize> = HashMap::new();

    // Collect all nodes and edges from all artefacts
    for artefact in artefacts {
        for (idx, entry) in artefact.blueprint.iter().enumerate() {
            if let Some(max) = options.max_nodes {
                if all_nodes.len() >= max {
                    break;
                }
            }

            let node_id = if idx == 0 { entry.from_node } else { entry.to_node };
            all_nodes.entry(node_id)
                .or_insert_with(|| format!("N{}", node_id));
        }

        for i in 0..artefact.blueprint.len().saturating_sub(1) {
            let from = artefact.blueprint[i].from_node;
            let to = artefact.blueprint[i].to_node;
            *edge_counts.entry((from, to)).or_insert(0) += 1;
        }
    }

    // Add nodes
    for (node_id, label) in &all_nodes {
        dot.push_str(&format!(
            "  \"{}\" [label=\"{}\"];\n",
            label,
            format_node_id(*node_id)
        ));
    }

    dot.push_str("\n");

    // Add edges with counts
    for ((from, to), count) in &edge_counts {
        if let (Some(from_label), Some(to_label)) = (all_nodes.get(from), all_nodes.get(to)) {
            let penwidth = (1.0 + (*count as f64).ln()).min(5.0);
            dot.push_str(&format!(
                "  \"{}\" -> \"{}\" [label=\"×{}\", penwidth={}];\n",
                from_label, to_label, count, penwidth
            ));
        }
    }

    dot.push_str("}\n");

    Ok(dot)
}

/// Get color for position in path
fn get_color_for_position(idx: usize, total: usize, scheme: &str) -> String {
    let ratio = if total > 1 {
        idx as f64 / (total - 1) as f64
    } else {
        0.0
    };

    match scheme {
        "spectral" => {
            // Blue -> Green -> Red
            if ratio < 0.5 {
                format!("#{:02x}{:02x}ff", 0, (ratio * 2.0 * 255.0) as u8)
            } else {
                format!("#{:02x}{:02x}00", ((ratio - 0.5) * 2.0 * 255.0) as u8, 255)
            }
        }
        "plasma" => {
            // Purple -> Orange -> Yellow
            let r = (ratio * 255.0) as u8;
            let g = ((ratio * 0.7) * 255.0) as u8;
            let b = ((1.0 - ratio) * 255.0) as u8;
            format!("#{:02x}{:02x}{:02x}", r, g, b)
        }
        "viridis" => {
            // Dark blue -> Green -> Yellow
            let r = (ratio * 200.0) as u8;
            let g = (150.0 + ratio * 105.0) as u8;
            let b = ((1.0 - ratio) * 200.0) as u8;
            format!("#{:02x}{:02x}{:02x}", r, g, b)
        }
        _ => "#888888".to_string(),
    }
}

/// Format node ID for display
fn format_node_id(node_id: usize) -> String {
    if node_id < 1000 {
        format!("{}", node_id)
    } else {
        format!("{}k", node_id / 1000)
    }
}

/// Export statistics as CSV
pub fn export_stats_csv(artefacts: &[&Artefact]) -> Result<String> {
    let mut csv = String::new();

    // Header
    csv.push_str("id,resonance,stability,mandorla,path_length,psi,rho,omega,chi,eta\n");

    // Data
    for artefact in artefacts {
        csv.push_str(&format!(
            "{},{:.6},{:.6},{},{},{:.6},{:.6},{:.6},{:.6},{:.6}\n",
            artefact.id,
            artefact.resonance(),
            artefact.stability,
            artefact.is_mandorla_certified,
            artefact.blueprint.len(),
            artefact.signature.psi,
            artefact.signature.rho,
            artefact.signature.omega,
            artefact.signature.chi,
            artefact.signature.eta,
        ));
    }

    Ok(csv)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::signature::Signature5D;

    fn create_test_artefact() -> Artefact {
        let sig = Signature5D::new(0.8, 0.7, 0.6, 0.5, 0.4);
        let mut artefact = Artefact::new(0, sig);
        artefact.stability = 0.75;
        artefact.is_mandorla_certified = true;
        
        // Add some blueprint entries
        artefact.record_transformation(0, 42, "step1".to_string(), sig);
        artefact.record_transformation(42, 123, "step2".to_string(), sig);
        artefact.record_transformation(123, 456, "step3".to_string(), sig);
        
        artefact
    }

    #[test]
    fn test_graphviz_export() {
        let artefact = create_test_artefact();
        let graph = MetatronCube::new();
        let options = GraphvizOptions::default();

        let result = export_artefact_path_graphviz(&artefact, &graph, &options);
        assert!(result.is_ok());

        let dot = result.unwrap();
        assert!(dot.contains("digraph ArtefactPath"));
        assert!(dot.contains("Resonance"));
    }

    #[test]
    fn test_csv_export() {
        let artefact = create_test_artefact();
        let artefacts = vec![&artefact];

        let result = export_stats_csv(&artefacts);
        assert!(result.is_ok());

        let csv = result.unwrap();
        assert!(csv.contains("id,resonance,stability"));
        assert!(csv.contains(&artefact.id.to_string()));
    }

    #[test]
    fn test_color_schemes() {
        let spectral = get_color_for_position(0, 10, "spectral");
        let plasma = get_color_for_position(5, 10, "plasma");
        let viridis = get_color_for_position(9, 10, "viridis");

        assert!(spectral.starts_with('#'));
        assert!(plasma.starts_with('#'));
        assert!(viridis.starts_with('#'));
    }

    #[test]
    fn test_empty_blueprint() {
        let mut artefact = create_test_artefact();
        artefact.blueprint = vec![];

        let graph = MetatronCube::new();
        let options = GraphvizOptions::default();

        let result = export_artefact_path_graphviz(&artefact, &graph, &options);
        assert!(result.is_ok());
    }
}
