//! Dual-Merkaba Consensus Core (Phase 3)
//!
//! Mirror-stability validation and Proof-of-Resonance consensus mechanism.
//! Implements MCI (Mirror Coherence Index) and Lyapunov stability checking.

use crate::signature::Signature5D;
use crate::operator::Operator;
use crate::resonance_kernel::resonance;
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};

/// Merkaba Gate - dual consensus validator
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MerkabaGate {
    /// Mirror Coherence Index
    pub mci: f64,
    /// Lyapunov delta (stability measure)
    pub lyapunov_delta: f64,
    /// Consensus state
    pub consensus_state: ConsensusState,
    /// Configuration
    pub config: MerkabaConfig,
}

/// Consensus state enumeration
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ConsensusState {
    /// No consensus yet
    Pending,
    /// Consensus achieved
    Achieved,
    /// Consensus failed
    Failed,
    /// Under validation
    Validating,
}

/// Merkaba configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MerkabaConfig {
    /// MCI threshold for consensus
    pub mci_threshold: f64,
    /// Lyapunov stability bound
    pub lyapunov_bound: f64,
    /// History window for Lyapunov check
    pub history_window: usize,
}

impl Default for MerkabaConfig {
    fn default() -> Self {
        Self {
            mci_threshold: 0.97,
            lyapunov_bound: 0.001,
            history_window: 100,
        }
    }
}

impl MerkabaGate {
    /// Create new Merkaba Gate
    pub fn new(config: MerkabaConfig) -> Self {
        Self {
            mci: 0.0,
            lyapunov_delta: 0.0,
            consensus_state: ConsensusState::Pending,
            config,
        }
    }

    /// Evaluate dual consensus between two operators
    pub fn evaluate_dual_consensus(&mut self, a: &Operator, b: &Operator) -> bool {
        self.consensus_state = ConsensusState::Validating;

        // Compute MCI
        self.mci = Self::compute_mci(&a.signature, &b.signature);

        // Check MCI threshold
        if self.mci < self.config.mci_threshold {
            self.consensus_state = ConsensusState::Failed;
            return false;
        }

        // For full Lyapunov check, we'd need history
        // Simplified: check if operators are mirror-stable
        let mirror_stable = self.check_mirror_stability(a, b);

        if mirror_stable && self.mci >= self.config.mci_threshold {
            self.consensus_state = ConsensusState::Achieved;
            true
        } else {
            self.consensus_state = ConsensusState::Failed;
            false
        }
    }

    /// Compute Mirror Coherence Index
    ///
    /// MCI measures primal↔dual resonance symmetry
    pub fn compute_mci(a: &Signature5D, b: &Signature5D) -> f64 {
        let res_a = resonance(a);
        let res_b = resonance(b);

        // Mirror product: how well do they resonate together?
        let mirror_product = res_a * res_b;

        // Signature alignment (cosine similarity)
        let dot_product = a.psi * b.psi + a.rho * b.rho +
                         a.omega * b.omega + a.chi * b.chi +
                         a.eta * b.eta;

        let norm_a = (a.psi.powi(2) + a.rho.powi(2) +
                     a.omega.powi(2) + a.chi.powi(2) +
                     a.eta.powi(2)).sqrt();

        let norm_b = (b.psi.powi(2) + b.rho.powi(2) +
                     b.omega.powi(2) + b.chi.powi(2) +
                     b.eta.powi(2)).sqrt();

        let alignment = if norm_a > 0.0 && norm_b > 0.0 {
            dot_product / (norm_a * norm_b)
        } else {
            0.0
        };

        // MCI combines resonance product and alignment
        let mci = 0.6 * mirror_product + 0.4 * alignment;

        mci.clamp(0.0, 1.0)
    }

    /// Check mirror stability between operators
    fn check_mirror_stability(&self, a: &Operator, b: &Operator) -> bool {
        // Mirror stability: operators should be complementary
        // Check if their signatures form a stable dual pair

        // Complementarity check
        let complementarity = Self::compute_complementarity(&a.signature, &b.signature);

        // Resonance balance
        let res_diff = (a.resonance_score - b.resonance_score).abs();

        // Stable if highly complementary and balanced resonance
        complementarity > 0.8 && res_diff < 0.1
    }

    /// Compute complementarity between signatures
    fn compute_complementarity(a: &Signature5D, b: &Signature5D) -> f64 {
        // Complementarity: how well they fill signature space together
        let coverage = ((a.psi + b.psi) / 2.0).min(1.0) *
                      ((a.rho + b.rho) / 2.0).min(1.0) *
                      ((a.omega + b.omega) / 2.0).min(1.0) *
                      ((a.chi + b.chi) / 2.0).min(1.0) *
                      ((a.eta + b.eta) / 2.0).min(1.0);

        coverage.powf(0.2) // Fifth root for balanced contribution
    }

    /// Check Lyapunov stability from history
    pub fn lyapunov_check(&mut self, history: &[f64]) -> bool {
        if history.len() < self.config.history_window {
            return false;
        }

        // Compute Lyapunov exponent approximation
        let window = &history[history.len() - self.config.history_window..];

        let mut sum_log_divergence = 0.0;
        let mut count = 0;

        for i in 1..window.len() {
            let divergence = (window[i] - window[i-1]).abs();
            if divergence > 1e-10 {
                sum_log_divergence += divergence.ln();
                count += 1;
            }
        }

        if count == 0 {
            self.lyapunov_delta = 0.0;
            return true; // Stable (no divergence)
        }

        self.lyapunov_delta = sum_log_divergence / count as f64;

        self.lyapunov_delta.abs() < self.config.lyapunov_bound
    }

    /// Check if consensus is achieved
    pub fn has_consensus(&self) -> bool {
        self.consensus_state == ConsensusState::Achieved
    }
}

/// Consensus Engine - orchestrates proof-of-resonance
#[derive(Debug)]
pub struct ConsensusEngine {
    /// Merkaba gate for validation
    pub gate: MerkabaGate,
    /// Operator pairs under consensus
    pub pairs: Vec<(Operator, Operator)>,
    /// Consensus history
    pub history: Vec<ConsensusRecord>,
    /// Configuration
    pub config: ConsensusEngineConfig,
}

/// Consensus engine configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConsensusEngineConfig {
    /// Merkaba configuration
    pub merkaba_config: MerkabaConfig,
    /// Maximum pairs to track
    pub max_pairs: usize,
    /// Commit threshold (min successful consensuses)
    pub commit_threshold: usize,
}

impl Default for ConsensusEngineConfig {
    fn default() -> Self {
        Self {
            merkaba_config: MerkabaConfig::default(),
            max_pairs: 100,
            commit_threshold: 3,
        }
    }
}

/// Consensus record
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConsensusRecord {
    pub timestamp: chrono::DateTime<chrono::Utc>,
    pub mci: f64,
    pub lyapunov_delta: f64,
    pub success: bool,
    pub operator_ids: (uuid::Uuid, uuid::Uuid),
}

impl ConsensusEngine {
    /// Create new consensus engine
    pub fn new(config: ConsensusEngineConfig) -> Self {
        let gate = MerkabaGate::new(config.merkaba_config.clone());

        Self {
            gate,
            pairs: Vec::new(),
            history: Vec::new(),
            config,
        }
    }

    /// Submit operator pair for consensus
    pub fn submit_pair(&mut self, a: Operator, b: Operator) -> Result<()> {
        if self.pairs.len() >= self.config.max_pairs {
            return Err(MogeError::InvalidArtefact(
                "Consensus engine full".to_string()
            ));
        }

        self.pairs.push((a, b));
        Ok(())
    }

    /// Process all pending pairs
    pub fn process_consensus(&mut self) -> Vec<(Operator, Operator)> {
        let mut validated_pairs = Vec::new();

        for (a, b) in self.pairs.drain(..) {
            let success = self.gate.evaluate_dual_consensus(&a, &b);

            // Record consensus attempt
            let record = ConsensusRecord {
                timestamp: chrono::Utc::now(),
                mci: self.gate.mci,
                lyapunov_delta: self.gate.lyapunov_delta,
                success,
                operator_ids: (a.id, b.id),
            };

            self.history.push(record);

            if success {
                validated_pairs.push((a, b));
            }
        }

        validated_pairs
    }

    /// Check if ready to commit to ledger
    pub fn ready_to_commit(&self) -> bool {
        let recent_successes = self.history.iter()
            .rev()
            .take(self.config.commit_threshold * 2)
            .filter(|r| r.success)
            .count();

        recent_successes >= self.config.commit_threshold
    }

    /// Get consensus statistics
    pub fn stats(&self) -> ConsensusStats {
        let total_attempts = self.history.len();
        let successful = self.history.iter().filter(|r| r.success).count();

        let avg_mci = if !self.history.is_empty() {
            self.history.iter().map(|r| r.mci).sum::<f64>() / total_attempts as f64
        } else {
            0.0
        };

        let avg_lyapunov = if !self.history.is_empty() {
            self.history.iter().map(|r| r.lyapunov_delta).sum::<f64>() / total_attempts as f64
        } else {
            0.0
        };

        ConsensusStats {
            total_attempts,
            successful,
            success_rate: if total_attempts > 0 {
                successful as f64 / total_attempts as f64
            } else {
                0.0
            },
            avg_mci,
            avg_lyapunov,
            pending_pairs: self.pairs.len(),
        }
    }

    /// Clear history
    pub fn clear_history(&mut self) {
        self.history.clear();
    }
}

/// Consensus statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConsensusStats {
    pub total_attempts: usize,
    pub successful: usize,
    pub success_rate: f64,
    pub avg_mci: f64,
    pub avg_lyapunov: f64,
    pub pending_pairs: usize,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_merkaba_gate_creation() {
        let config = MerkabaConfig::default();
        let gate = MerkabaGate::new(config);

        assert_eq!(gate.consensus_state, ConsensusState::Pending);
        assert_eq!(gate.mci, 0.0);
    }

    #[test]
    fn test_mci_computation() {
        let sig_a = Signature5D::new(0.9, 0.8, 0.7, 0.6, 0.5);
        let sig_b = Signature5D::new(0.9, 0.8, 0.7, 0.6, 0.5);

        let mci = MerkabaGate::compute_mci(&sig_a, &sig_b);

        // Identical signatures should have high MCI
        assert!(mci > 0.9);
    }

    #[test]
    fn test_dual_consensus() {
        let config = MerkabaConfig::default();
        let mut gate = MerkabaGate::new(config);

        // Create similar high-resonance operators
        let mut op_a = Operator::from_signature(Signature5D::new(0.9, 0.85, 0.8, 0.7, 0.3));
        let mut op_b = Operator::from_signature(Signature5D::new(0.9, 0.85, 0.8, 0.7, 0.3));

        op_a.resonance_score = resonance(&op_a.signature);
        op_b.resonance_score = resonance(&op_b.signature);

        let _result = gate.evaluate_dual_consensus(&op_a, &op_b);

        // Similar high-quality operators should reach consensus
        assert!(gate.mci > 0.9);
    }

    #[test]
    fn test_lyapunov_check() {
        let config = MerkabaConfig::default();
        let mut gate = MerkabaGate::new(config);

        // Stable history (small fluctuations)
        let stable_history: Vec<f64> = (0..100)
            .map(|i| 0.8 + 0.001 * (i as f64 * 0.1).sin())
            .collect();

        let is_stable = gate.lyapunov_check(&stable_history);

        assert!(is_stable);
        assert!(gate.lyapunov_delta.abs() < 0.01);
    }

    #[test]
    fn test_consensus_engine() {
        let config = ConsensusEngineConfig::default();
        let mut engine = ConsensusEngine::new(config);

        let op_a = Operator::from_signature(Signature5D::new(0.9, 0.8, 0.8, 0.7, 0.3));
        let op_b = Operator::from_signature(Signature5D::new(0.9, 0.8, 0.8, 0.7, 0.3));

        engine.submit_pair(op_a, op_b).unwrap();

        let _validated = engine.process_consensus();

        assert_eq!(engine.history.len(), 1);
    }

    #[test]
    fn test_commit_readiness() {
        let config = ConsensusEngineConfig::default();
        let mut engine = ConsensusEngine::new(config);

        // Add successful consensus records
        for _i in 0..5 {
            let op_a = Operator::from_signature(Signature5D::new(0.9, 0.8, 0.8, 0.7, 0.3));
            let op_b = Operator::from_signature(Signature5D::new(0.9, 0.8, 0.8, 0.7, 0.3));

            engine.submit_pair(op_a, op_b).unwrap();
        }

        engine.process_consensus();

        // After several successful consensuses, should be ready to commit
        let stats = engine.stats();
        assert!(stats.total_attempts > 0);
    }
}
