//! Signature Space and Operator Structure
//!
//! Every operator in MOGE possesses a signature σ ∈ [0,1]³ or v ∈ [0,1]⁵
//!
//! ## 3D Signature (σ)
//! - ψ (psi): Spectral quality (distance to target spectrum, e.g. GUE/Riemann)
//! - ρ (rho): Dynamic consistency (preservation/decay in time evolution)
//! - ω (omega): Structural coherence (stability within paths/clusters)
//!
//! ## 5D Signature (v) - Extended
//! Includes the 3D components plus:
//! - χ (chi): Topological path coherence
//! - η (eta): Resonance fluctuation in historical progression

use serde::{Deserialize, Serialize};
use std::ops::Sub;

/// Trait for signature types
pub trait Signature: Clone + Copy + PartialEq {
    /// Create a new signature with default values
    fn new() -> Self;

    /// Create a signature with specific values
    fn from_components(components: &[f64]) -> Result<Self, crate::error::MogeError> where Self: Sized;

    /// Get the spectral quality (ψ)
    fn psi(&self) -> f64;

    /// Get the dynamic consistency (ρ)
    fn rho(&self) -> f64;

    /// Get the structural coherence (ω)
    fn omega(&self) -> f64;

    /// Calculate the Euclidean distance between two signatures
    fn distance(&self, other: &Self) -> f64;

    /// Check if the signature is valid (all components in [0,1])
    fn is_valid(&self) -> bool;

    /// Get the overall resonance score (weighted combination)
    fn resonance(&self) -> f64;
}

/// 3D Signature vector: σ = (ψ, ρ, ω)
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Signature3D {
    /// ψ: Spectral quality
    pub psi: f64,
    /// ρ: Dynamic consistency
    pub rho: f64,
    /// ω: Structural coherence
    pub omega: f64,
}

impl Signature3D {
    /// Create a new 3D signature
    pub fn with_values(psi: f64, rho: f64, omega: f64) -> Result<Self, crate::error::MogeError> {
        let sig = Self { psi, rho, omega };
        if sig.is_valid() {
            Ok(sig)
        } else {
            Err(crate::error::MogeError::InvalidSignature(
                format!("Components must be in [0,1]: psi={}, rho={}, omega={}", psi, rho, omega)
            ))
        }
    }

    /// Create a random signature (for testing/initialization)
    pub fn random() -> Self {
        Self {
            psi: rand::random(),
            rho: rand::random(),
            omega: rand::random(),
        }
    }
}

impl Signature for Signature3D {
    fn new() -> Self {
        Self {
            psi: 0.5,
            rho: 0.5,
            omega: 0.5,
        }
    }

    fn from_components(components: &[f64]) -> Result<Self, crate::error::MogeError> {
        if components.len() != 3 {
            return Err(crate::error::MogeError::InvalidSignature(
                format!("Expected 3 components, got {}", components.len())
            ));
        }
        Self::with_values(components[0], components[1], components[2])
    }

    fn psi(&self) -> f64 { self.psi }
    fn rho(&self) -> f64 { self.rho }
    fn omega(&self) -> f64 { self.omega }

    fn distance(&self, other: &Self) -> f64 {
        let dpsi = self.psi - other.psi;
        let drho = self.rho - other.rho;
        let domega = self.omega - other.omega;
        (dpsi * dpsi + drho * drho + domega * domega).sqrt()
    }

    fn is_valid(&self) -> bool {
        (0.0..=1.0).contains(&self.psi)
            && (0.0..=1.0).contains(&self.rho)
            && (0.0..=1.0).contains(&self.omega)
    }

    fn resonance(&self) -> f64 {
        // Weighted combination: prioritize spectral quality and coherence
        0.4 * self.psi + 0.3 * self.rho + 0.3 * self.omega
    }
}

impl Default for Signature3D {
    fn default() -> Self {
        Self::new()
    }
}

impl Sub for Signature3D {
    type Output = Self;

    fn sub(self, other: Self) -> Self {
        Self {
            psi: self.psi - other.psi,
            rho: self.rho - other.rho,
            omega: self.omega - other.omega,
        }
    }
}

/// 5D Signature vector: v = (ψ, ρ, ω, χ, η)
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize)]
pub struct Signature5D {
    /// ψ: Spectral quality
    pub psi: f64,
    /// ρ: Dynamic consistency
    pub rho: f64,
    /// ω: Structural coherence
    pub omega: f64,
    /// χ: Topological path coherence
    pub chi: f64,
    /// η: Resonance fluctuation
    pub eta: f64,
}

impl Signature5D {
    /// Create a new 5D signature (unchecked)
    pub fn new(
        psi: f64,
        rho: f64,
        omega: f64,
        chi: f64,
        eta: f64
    ) -> Self {
        Self { psi, rho, omega, chi, eta }
    }

    /// Create a new 5D signature with validation
    pub fn with_values(
        psi: f64,
        rho: f64,
        omega: f64,
        chi: f64,
        eta: f64
    ) -> Result<Self, crate::error::MogeError> {
        let sig = Self { psi, rho, omega, chi, eta };
        if sig.is_valid() {
            Ok(sig)
        } else {
            Err(crate::error::MogeError::InvalidSignature(
                "All components must be in [0,1]".to_string()
            ))
        }
    }

    /// Create from 3D signature with default extended values
    pub fn from_3d(sig3d: Signature3D) -> Self {
        Self {
            psi: sig3d.psi,
            rho: sig3d.rho,
            omega: sig3d.omega,
            chi: 0.5,
            eta: 0.5,
        }
    }

    /// Project to 3D signature (discard χ and η)
    pub fn to_3d(&self) -> Signature3D {
        Signature3D {
            psi: self.psi,
            rho: self.rho,
            omega: self.omega,
        }
    }

    /// Create a random 5D signature
    pub fn random() -> Self {
        Self {
            psi: rand::random(),
            rho: rand::random(),
            omega: rand::random(),
            chi: rand::random(),
            eta: rand::random(),
        }
    }

    /// Get topological path coherence
    pub fn chi(&self) -> f64 { self.chi }

    /// Get resonance fluctuation
    pub fn eta(&self) -> f64 { self.eta }
}

impl Signature for Signature5D {
    fn new() -> Self {
        Self {
            psi: 0.5,
            rho: 0.5,
            omega: 0.5,
            chi: 0.5,
            eta: 0.5,
        }
    }

    fn from_components(components: &[f64]) -> Result<Self, crate::error::MogeError> {
        if components.len() != 5 {
            return Err(crate::error::MogeError::InvalidSignature(
                format!("Expected 5 components, got {}", components.len())
            ));
        }
        Self::with_values(
            components[0],
            components[1],
            components[2],
            components[3],
            components[4]
        )
    }

    fn psi(&self) -> f64 { self.psi }
    fn rho(&self) -> f64 { self.rho }
    fn omega(&self) -> f64 { self.omega }

    fn distance(&self, other: &Self) -> f64 {
        let d = [
            self.psi - other.psi,
            self.rho - other.rho,
            self.omega - other.omega,
            self.chi - other.chi,
            self.eta - other.eta,
        ];
        d.iter().map(|x| x * x).sum::<f64>().sqrt()
    }

    fn is_valid(&self) -> bool {
        (0.0..=1.0).contains(&self.psi)
            && (0.0..=1.0).contains(&self.rho)
            && (0.0..=1.0).contains(&self.omega)
            && (0.0..=1.0).contains(&self.chi)
            && (0.0..=1.0).contains(&self.eta)
    }

    fn resonance(&self) -> f64 {
        // Weighted combination with 5D components
        0.3 * self.psi
            + 0.2 * self.rho
            + 0.2 * self.omega
            + 0.15 * self.chi
            + 0.15 * self.eta
    }
}

impl Default for Signature5D {
    fn default() -> Self {
        Signature::new()
    }
}

impl Sub for Signature5D {
    type Output = Self;

    fn sub(self, other: Self) -> Self {
        Self {
            psi: self.psi - other.psi,
            rho: self.rho - other.rho,
            omega: self.omega - other.omega,
            chi: self.chi - other.chi,
            eta: self.eta - other.eta,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_signature3d_creation() {
        let sig = Signature3D::with_values(0.8, 0.6, 0.9).unwrap();
        assert_eq!(sig.psi(), 0.8);
        assert_eq!(sig.rho(), 0.6);
        assert_eq!(sig.omega(), 0.9);
    }

    #[test]
    fn test_signature3d_invalid() {
        assert!(Signature3D::with_values(1.5, 0.5, 0.5).is_err());
        assert!(Signature3D::with_values(0.5, -0.1, 0.5).is_err());
    }

    #[test]
    fn test_signature3d_distance() {
        let sig1 = Signature3D::with_values(0.5, 0.5, 0.5).unwrap();
        let sig2 = Signature3D::with_values(0.8, 0.7, 0.6).unwrap();
        let dist = sig1.distance(&sig2);
        assert!(dist > 0.0);
    }

    #[test]
    fn test_signature5d_creation() {
        let sig = Signature5D::with_values(0.8, 0.6, 0.9, 0.7, 0.5).unwrap();
        assert_eq!(sig.psi(), 0.8);
        assert_eq!(sig.chi(), 0.7);
        assert_eq!(sig.eta(), 0.5);
    }

    #[test]
    fn test_5d_from_3d_conversion() {
        let sig3d = Signature3D::with_values(0.8, 0.6, 0.9).unwrap();
        let sig5d = Signature5D::from_3d(sig3d);
        assert_eq!(sig5d.psi(), 0.8);
        assert_eq!(sig5d.rho(), 0.6);
        assert_eq!(sig5d.omega(), 0.9);
    }

    #[test]
    fn test_resonance_calculation() {
        let sig = Signature3D::with_values(1.0, 1.0, 1.0).unwrap();
        assert_eq!(sig.resonance(), 1.0);

        let sig_low = Signature3D::with_values(0.0, 0.0, 0.0).unwrap();
        assert_eq!(sig_low.resonance(), 0.0);
    }
}
