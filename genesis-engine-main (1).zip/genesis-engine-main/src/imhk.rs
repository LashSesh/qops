//! IMHK Unified Kernel (Phase 4)
//!
//! Unification of IMHK Foundation, Gabriel Cells substrate, and DMK consensus.
//! Orchestrates the complete resonance-driven system.

use crate::operator::{Operator, OperatorPool};
use crate::semantic::{Infogenome, SemanticNetwork};
use crate::resonance_kernel::{ResonanceDynamics, ResonanceKernelConfig, resonance, feedback_cycle};
use crate::gabriel_cells::{GabrielCluster, ClusterConfig};
use crate::consensus::{ConsensusEngine, ConsensusEngineConfig, ConsensusStats};
use crate::signature::Signature5D;
use crate::error::Result;
use serde::{Deserialize, Serialize};

/// IMHK System configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImhkConfig {
    /// Resonance kernel configuration
    pub resonance: ResonanceKernelConfig,
    /// Gabriel cluster configuration
    pub cluster: ClusterConfig,
    /// Consensus engine configuration
    pub consensus: ConsensusEngineConfig,
    /// Maximum operators in pool
    pub max_operators: usize,
    /// Target equilibrium rate
    pub equilibrium_target: f64,
    /// Maximum iterations
    pub max_iterations: usize,
}

impl Default for ImhkConfig {
    fn default() -> Self {
        Self {
            resonance: ResonanceKernelConfig::default(),
            cluster: ClusterConfig::default(),
            consensus: ConsensusEngineConfig::default(),
            max_operators: 1000,
            equilibrium_target: 0.95,
            max_iterations: 1000,
        }
    }
}

/// IMHK Unified System
pub struct ImhkSystem {
    /// Operator pool
    pub operators: OperatorPool,
    /// Semantic network
    pub semantic_net: SemanticNetwork,
    /// Resonance dynamics
    pub dynamics: ResonanceDynamics,
    /// Gabriel cell cluster
    pub cluster: GabrielCluster,
    /// Consensus engine
    pub consensus: ConsensusEngine,
    /// System configuration
    pub config: ImhkConfig,
    /// Current iteration
    pub iteration: usize,
    /// System state
    pub state: SystemState,
}

/// System state enumeration
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SystemState {
    Initializing,
    Running,
    Equilibrium,
    Complete,
}

impl ImhkSystem {
    /// Create new IMHK system
    pub fn new(config: ImhkConfig) -> Self {
        let operators = OperatorPool::new(config.max_operators);
        let semantic_net = SemanticNetwork::new();
        let dynamics = ResonanceDynamics::new(config.resonance.clone());
        let cluster = GabrielCluster::new(config.cluster.clone());
        let consensus = ConsensusEngine::new(config.consensus.clone());

        Self {
            operators,
            semantic_net,
            dynamics,
            cluster,
            consensus,
            config,
            iteration: 0,
            state: SystemState::Initializing,
        }
    }

    /// Initialize system with seed operators
    pub fn initialize(&mut self, seed_count: usize) -> Result<()> {
        use rand::Rng;
        let mut rng = rand::thread_rng();

        for _ in 0..seed_count {
            // Create random operator
            let mut op = Operator::new();

            // Activate and add to pool
            op.activate();
            self.operators.add(op)?;

            // Add corresponding Gabriel cell
            let sig = Signature5D::new(
                rng.gen_range(0.0..1.0),
                rng.gen_range(0.0..1.0),
                rng.gen_range(0.0..1.0),
                rng.gen_range(0.0..1.0),
                rng.gen_range(0.0..1.0),
            );
            self.cluster.add_cell(sig);
        }

        self.state = SystemState::Running;
        Ok(())
    }

    /// Run single iteration of the unified system
    pub fn step(&mut self) -> Result<StepResult> {
        self.iteration += 1;

        let mut result = StepResult::default();

        // 1. Update Gabriel Cell substrate
        self.cluster.update();

        // 2. Find stable colonies
        let colonies = self.cluster.find_colonies(0.7);
        result.colonies_found = colonies.len();

        // 3. Extract candidate operators from colonies
        for colony in &colonies {
            if let Some(mut op) = self.cluster.colony_to_operator(colony) {
                // Apply resonance feedback
                feedback_cycle(&mut op, &self.config.resonance);

                // Validate resonance
                let res = resonance(&op.signature);
                if res > 0.7 {
                    op.validate(res);
                    result.operators_validated += 1;

                    // Add to operator pool
                    if self.operators.size() < self.config.max_operators {
                        self.operators.add(op.clone())?;

                        // Add to semantic network
                        let genome = Infogenome::from_signature(&op.signature);
                        self.semantic_net.add_node(genome);
                    }
                }
            }
        }

        // 4. Create operator pairs for consensus
        let stable_ops: Vec<&Operator> = self.operators.get_stable();

        for i in 0..stable_ops.len().saturating_sub(1) {
            for j in (i + 1)..stable_ops.len() {
                if result.consensus_pairs < 20 { // Limit pairs per iteration
                    self.consensus.submit_pair(
                        stable_ops[i].clone(),
                        stable_ops[j].clone(),
                    )?;
                    result.consensus_pairs += 1;
                }
            }
        }

        // 5. Process consensus
        let validated_pairs = self.consensus.process_consensus();
        result.consensus_achieved = validated_pairs.len();

        // 6. Check for equilibrium
        let equilibrium_rate = self.check_equilibrium_rate();
        result.equilibrium_rate = equilibrium_rate;

        if equilibrium_rate >= self.config.equilibrium_target {
            if self.state == SystemState::Running {
                self.state = SystemState::Equilibrium;
            }
        }

        // 7. Check termination
        if self.iteration >= self.config.max_iterations {
            self.state = SystemState::Complete;
        }

        Ok(result)
    }

    /// Run system until equilibrium or max iterations
    pub fn run_to_equilibrium(&mut self) -> Result<ImhkResult> {
        let start_time = std::time::Instant::now();

        let mut iterations_at_equilibrium = 0;
        let required_stable_iterations = 10;

        while self.state != SystemState::Complete {
            let step_result = self.step()?;

            if step_result.equilibrium_rate >= self.config.equilibrium_target {
                iterations_at_equilibrium += 1;
            } else {
                iterations_at_equilibrium = 0;
            }

            // Require sustained equilibrium
            if iterations_at_equilibrium >= required_stable_iterations {
                break;
            }

            if self.iteration >= self.config.max_iterations {
                break;
            }
        }

        let runtime_ms = start_time.elapsed().as_millis() as u64;

        Ok(ImhkResult {
            iterations: self.iteration,
            runtime_ms,
            final_operators: self.operators.size(),
            stable_operators: self.operators.get_stable().len(),
            consensus_stats: self.consensus.stats(),
            cluster_stats: self.cluster.stats(),
            equilibrium_achieved: self.state == SystemState::Equilibrium,
        })
    }

    /// Check equilibrium rate
    fn check_equilibrium_rate(&self) -> f64 {
        let cluster_stats = self.cluster.stats();
        let consensus_stats = self.consensus.stats();

        // Equilibrium metrics
        let cluster_stability = if cluster_stats.total_cells > 0 {
            cluster_stats.active_cells as f64 / cluster_stats.total_cells as f64
        } else {
            0.0
        };

        let consensus_stability = consensus_stats.success_rate;

        // Combined equilibrium rate
        0.5 * cluster_stability + 0.5 * consensus_stability
    }

    /// Get system statistics
    pub fn stats(&self) -> SystemStats {
        SystemStats {
            iteration: self.iteration,
            state: self.state,
            total_operators: self.operators.size(),
            stable_operators: self.operators.get_stable().len(),
            semantic_nodes: self.semantic_net.size(),
            cluster_stats: self.cluster.stats(),
            consensus_stats: self.consensus.stats(),
            equilibrium_rate: self.check_equilibrium_rate(),
        }
    }

    /// Export stable operators
    pub fn export_operators(&self) -> Vec<Operator> {
        self.operators.get_stable().into_iter().cloned().collect()
    }
}

/// Step result
#[derive(Debug, Default, Clone, Serialize, Deserialize)]
pub struct StepResult {
    pub colonies_found: usize,
    pub operators_validated: usize,
    pub consensus_pairs: usize,
    pub consensus_achieved: usize,
    pub equilibrium_rate: f64,
}

/// IMHK execution result
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImhkResult {
    pub iterations: usize,
    pub runtime_ms: u64,
    pub final_operators: usize,
    pub stable_operators: usize,
    pub consensus_stats: ConsensusStats,
    pub cluster_stats: crate::gabriel_cells::ClusterStats,
    pub equilibrium_achieved: bool,
}

/// System statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemStats {
    pub iteration: usize,
    pub state: SystemState,
    pub total_operators: usize,
    pub stable_operators: usize,
    pub semantic_nodes: usize,
    pub cluster_stats: crate::gabriel_cells::ClusterStats,
    pub consensus_stats: ConsensusStats,
    pub equilibrium_rate: f64,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_imhk_creation() {
        let config = ImhkConfig::default();
        let system = ImhkSystem::new(config);

        assert_eq!(system.state, SystemState::Initializing);
        assert_eq!(system.iteration, 0);
    }

    #[test]
    fn test_imhk_initialization() {
        let config = ImhkConfig::default();
        let mut system = ImhkSystem::new(config);

        system.initialize(10).unwrap();

        assert_eq!(system.state, SystemState::Running);
        assert!(system.operators.size() > 0);
        assert!(system.cluster.stats().total_cells > 0);
    }

    #[test]
    fn test_imhk_step() {
        let config = ImhkConfig::default();
        let mut system = ImhkSystem::new(config);

        system.initialize(20).unwrap();

        let _result = system.step().unwrap();

        assert!(system.iteration == 1);
    }

    #[test]
    fn test_imhk_run() {
        let mut config = ImhkConfig::default();
        config.max_iterations = 50; // Limit for test

        let mut system = ImhkSystem::new(config);
        system.initialize(10).unwrap();

        let result = system.run_to_equilibrium().unwrap();

        assert!(result.iterations > 0);
        assert!(result.runtime_ms > 0);
    }

    #[test]
    fn test_imhk_export() {
        let config = ImhkConfig::default();
        let mut system = ImhkSystem::new(config);

        system.initialize(5).unwrap();

        // Run a few steps
        for _ in 0..10 {
            system.step().unwrap();
        }

        let _exported = system.export_operators();
        // Some operators should be stable
        assert!(system.stats().total_operators > 0);
    }
}
