//! Resonant Language Projection Layer (RLP)
//!
//! Translates internal resonance structures (TICs) into normalized projective 
//! representations valid across multiple domains.
//!
//! Pipeline:
//! 1. Cyclic Conversion: Transform operator sequences into TICs
//! 2. Projective Interpolation: Generate domain-specific projections
//! 3. Rule Matrix Normalization: Normalize through resonance-invariant matrix
//! 4. Signature Generation: Assign universal deterministic signatures

use crate::signature::Signature5D;
use crate::operator::Operator;
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};
use sha2::{Sha512, Digest};
use std::collections::HashMap;
use uuid::Uuid;

/// Temporal Information Crystal (TIC) - Core resonance structure
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TIC {
    /// Unique TIC identifier
    pub id: Uuid,
    /// Original operator signature (ψ, ρ, ω, β=χ, S=η)
    pub signature: Signature5D,
    /// Phase resolution
    pub phase: [f64; 3],
    /// Entropy gradient ΔS
    pub entropy_gradient: f64,
    /// Stability index
    pub stability: f64,
    /// Timestamp of creation
    pub timestamp: chrono::DateTime<chrono::Utc>,
    /// Kick threshold compliance (m_c)
    pub kick_threshold: f64,
}

impl TIC {
    /// Create a new TIC from an operator
    pub fn from_operator(op: &Operator, kick_threshold: f64, _phase_resolution: f64) -> Result<Self> {
        // Extract signature components
        let sig = op.signature;
        
        // Calculate phase from signature
        let phase = [
            (sig.psi * std::f64::consts::TAU) % std::f64::consts::TAU,
            (sig.rho * std::f64::consts::TAU) % std::f64::consts::TAU,
            (sig.omega * std::f64::consts::TAU) % std::f64::consts::TAU,
        ];
        
        // Calculate entropy gradient (simplified model)
        let entropy_gradient = (1.0 - sig.eta).abs();
        
        // Stability from omega and eta
        let stability = (sig.omega + (1.0 - entropy_gradient)) / 2.0;
        
        Ok(Self {
            id: Uuid::new_v4(),
            signature: sig,
            phase,
            entropy_gradient,
            stability,
            timestamp: chrono::Utc::now(),
            kick_threshold,
        })
    }
    
    /// Check if TIC meets invariance condition: ΔS_n < ΔS_(n-1)
    pub fn check_invariance(&self, previous_gradient: Option<f64>) -> bool {
        match previous_gradient {
            Some(prev) => self.entropy_gradient < prev,
            None => true, // First TIC always passes
        }
    }
}

/// Domain types for projective interpolation
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Domain {
    Mathematics,
    Cybernetics,
    Geometry,
    Logic,
    Physics,
}

impl Domain {
    /// Get all available domains
    pub fn all() -> Vec<Domain> {
        vec![
            Domain::Mathematics,
            Domain::Cybernetics,
            Domain::Geometry,
            Domain::Logic,
            Domain::Physics,
        ]
    }
    
    /// Get domain as string
    pub fn as_str(&self) -> &'static str {
        match self {
            Domain::Mathematics => "mathematics",
            Domain::Cybernetics => "cybernetics",
            Domain::Geometry => "geometry",
            Domain::Logic => "logic",
            Domain::Physics => "physics",
        }
    }
}

/// Projection tensor for a specific domain
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectionTensor {
    /// Target domain
    pub domain: Domain,
    /// Tensor data (2D matrix representation)
    pub tensor: Vec<Vec<f64>>,
    /// Basis vectors for this domain
    pub basis: Vec<String>,
    /// Normalized value after mapping
    pub normalized_value: f64,
    /// Checksum for integrity
    pub checksum: String,
}

impl ProjectionTensor {
    /// Create a new projection tensor for a domain
    pub fn new(domain: Domain, tic: &TIC) -> Self {
        let (tensor, basis, normalized_value) = Self::compute_projection(domain, tic);
        let checksum = Self::compute_checksum(&tensor);
        
        Self {
            domain,
            tensor,
            basis,
            normalized_value,
            checksum,
        }
    }
    
    /// Compute domain-specific projection
    fn compute_projection(domain: Domain, tic: &TIC) -> (Vec<Vec<f64>>, Vec<String>, f64) {
        let sig = &tic.signature;
        
        match domain {
            Domain::Mathematics => {
                // f_math(TIC) = Σ ψρ − ωβ + S²
                let value = sig.psi * sig.rho - sig.omega * sig.chi + sig.eta * sig.eta;
                let tensor = vec![
                    vec![sig.psi, sig.rho, sig.omega],
                    vec![sig.chi, sig.eta, value],
                ];
                let basis = vec!["ψ".into(), "ρ".into(), "ω".into(), "β".into(), "S".into()];
                (tensor, basis, value)
            },
            Domain::Cybernetics => {
                // f_cyber(TIC) = (ψρ/β) * feedback_gain
                let feedback_gain = 0.5 + sig.eta * 0.5; // Normalized feedback
                let value = if sig.chi > 0.0 {
                    (sig.psi * sig.rho / sig.chi) * feedback_gain
                } else {
                    sig.psi * sig.rho * feedback_gain
                };
                let tensor = vec![
                    vec![feedback_gain, tic.phase[0], sig.omega],
                    vec![value, sig.rho, sig.chi],
                ];
                let basis = vec!["feedback_gain".into(), "phase".into(), "coherence".into()];
                (tensor, basis, value)
            },
            Domain::Geometry => {
                // f_geom(TIC) = ψ·ω + ρ∧β (geometric product)
                let value = sig.psi * sig.omega + sig.rho * sig.chi;
                let tensor = vec![
                    vec![sig.psi, sig.omega, sig.rho],
                    vec![sig.chi, value, tic.stability],
                ];
                let basis = vec!["vertex_index".into(), "edge_tensor".into(), "dual_projection".into()];
                (tensor, basis, value)
            },
            Domain::Logic => {
                // f_logic(TIC) = (ψ > ρ) → ω else β
                let value = if sig.psi > sig.rho { sig.omega } else { sig.chi };
                let tensor = vec![
                    vec![if sig.psi > sig.rho { 1.0 } else { 0.0 }, value, sig.eta],
                    vec![sig.psi, sig.rho, sig.omega],
                ];
                let basis = vec!["true".into(), "false".into(), "flux".into(), "null".into()];
                (tensor, basis, value)
            },
            Domain::Physics => {
                // f_phys(TIC) = ψ² + ρ² − ω²
                let value = sig.psi * sig.psi + sig.rho * sig.rho - sig.omega * sig.omega;
                let tensor = vec![
                    vec![sig.psi * sig.psi, sig.rho * sig.rho, sig.omega * sig.omega],
                    vec![value, tic.phase[1], tic.entropy_gradient],
                ];
                let basis = vec!["energy_density".into(), "phase_velocity".into(), "entropy_gradient".into()];
                (tensor, basis, value)
            },
        }
    }
    
    /// Compute SHA-256 checksum of tensor
    fn compute_checksum(tensor: &[Vec<f64>]) -> String {
        use sha2::Sha256;
        let mut hasher = Sha256::new();
        
        for row in tensor {
            for &val in row {
                hasher.update(val.to_le_bytes());
            }
        }
        
        format!("{:x}", hasher.finalize())
    }
}

/// Universal operator signature combining all projections
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UniversalOperatorSignature {
    /// Base operator ID
    pub operator_id: Uuid,
    /// TIC ID
    pub tic_id: Uuid,
    /// Hash of all projections and rule matrix state
    pub signature_hash: String,
    /// Timestamp
    pub timestamp: chrono::DateTime<chrono::Utc>,
    /// Semantic coherence index
    pub semantic_coherence: f64,
}

impl UniversalOperatorSignature {
    /// Generate universal signature from TIC and projections
    pub fn generate(
        tic: &TIC,
        projections: &[ProjectionTensor],
        rule_matrix_state: &str,
    ) -> Self {
        let mut hasher = Sha512::new();
        
        // Hash signature components
        hasher.update(tic.signature.psi.to_le_bytes());
        hasher.update(tic.signature.rho.to_le_bytes());
        hasher.update(tic.signature.omega.to_le_bytes());
        hasher.update(tic.signature.chi.to_le_bytes());
        hasher.update(tic.signature.eta.to_le_bytes());
        
        // Hash projections
        for proj in projections {
            hasher.update(proj.checksum.as_bytes());
        }
        
        // Hash rule matrix state
        hasher.update(rule_matrix_state.as_bytes());
        
        let signature_hash = format!("{:x}", hasher.finalize());
        
        // Calculate semantic coherence (simplified)
        let semantic_coherence = if projections.len() >= 5 {
            let variance: f64 = projections.iter()
                .map(|p| p.normalized_value)
                .map(|v| (v - 0.5).powi(2))
                .sum::<f64>() / projections.len() as f64;
            1.0 - variance.sqrt()
        } else {
            0.0
        };
        
        Self {
            operator_id: Uuid::new_v4(), // In real implementation, use actual operator ID
            tic_id: tic.id,
            signature_hash,
            timestamp: chrono::Utc::now(),
            semantic_coherence,
        }
    }
}

/// TIC Catalogue - collection of Temporal Information Crystals
#[derive(Debug, Default, Serialize, Deserialize)]
pub struct TICCatalogue {
    /// All TICs indexed by ID
    tics: HashMap<Uuid, TIC>,
    /// Entropy gradient history for invariance checking
    entropy_history: Vec<f64>,
}

impl TICCatalogue {
    /// Create a new TIC catalogue
    pub fn new() -> Self {
        Self {
            tics: HashMap::new(),
            entropy_history: Vec::new(),
        }
    }
    
    /// Add a TIC to the catalogue
    pub fn add_tic(&mut self, tic: TIC) -> Result<()> {
        // Check invariance condition
        let last_gradient = self.entropy_history.last().copied();
        if !tic.check_invariance(last_gradient) {
            return Err(MogeError::InvalidArtefact(
                "TIC violates entropy invariance condition".to_string()
            ));
        }
        
        self.entropy_history.push(tic.entropy_gradient);
        self.tics.insert(tic.id, tic);
        Ok(())
    }
    
    /// Get TIC by ID
    pub fn get(&self, id: &Uuid) -> Option<&TIC> {
        self.tics.get(id)
    }
    
    /// Get all TICs
    pub fn all(&self) -> Vec<&TIC> {
        self.tics.values().collect()
    }
    
    /// Get catalogue size
    pub fn size(&self) -> usize {
        self.tics.len()
    }
}

/// Resonant Language Projection Layer - Main pipeline
pub struct ResonantLanguageProjection {
    /// TIC catalogue
    catalogue: TICCatalogue,
    /// Kick threshold parameter
    kick_threshold: f64,
    /// Phase resolution
    phase_resolution: f64,
}

impl ResonantLanguageProjection {
    /// Create a new RLP instance
    pub fn new() -> Self {
        Self {
            catalogue: TICCatalogue::new(),
            kick_threshold: 0.92,
            phase_resolution: 0.001,
        }
    }
    
    /// Stage 1: Cyclic Conversion - Transform operator to TIC
    pub fn cyclic_conversion(&mut self, operator: &Operator) -> Result<Uuid> {
        let tic = TIC::from_operator(operator, self.kick_threshold, self.phase_resolution)?;
        let tic_id = tic.id;
        self.catalogue.add_tic(tic)?;
        Ok(tic_id)
    }
    
    /// Stage 2: Projective Interpolation - Generate domain projections
    pub fn projective_interpolation(&self, tic_id: &Uuid) -> Result<Vec<ProjectionTensor>> {
        let tic = self.catalogue.get(tic_id)
            .ok_or_else(|| MogeError::InvalidArtefact("TIC not found".to_string()))?;
        
        let projections = Domain::all()
            .iter()
            .map(|&domain| ProjectionTensor::new(domain, tic))
            .collect();
        
        Ok(projections)
    }
    
    /// Stage 3: Rule Matrix Normalization (placeholder - see rule_matrix module)
    pub fn normalize_projections(&self, _projections: &mut [ProjectionTensor]) -> Result<()> {
        // Normalization will be handled by RuleMatrix
        // This is a simplified version
        Ok(())
    }
    
    /// Stage 4: Signature Generation
    pub fn generate_signature(
        &self,
        tic_id: &Uuid,
        projections: &[ProjectionTensor],
    ) -> Result<UniversalOperatorSignature> {
        let tic = self.catalogue.get(tic_id)
            .ok_or_else(|| MogeError::InvalidArtefact("TIC not found".to_string()))?;
        
        let rule_matrix_state = "converged"; // Simplified
        let signature = UniversalOperatorSignature::generate(tic, projections, rule_matrix_state);
        
        Ok(signature)
    }
    
    /// Full pipeline: operator -> TIC -> projections -> signature
    pub fn process_operator(&mut self, operator: &Operator) -> Result<(Uuid, Vec<ProjectionTensor>, UniversalOperatorSignature)> {
        // Stage 1: Cyclic conversion
        let tic_id = self.cyclic_conversion(operator)?;
        
        // Stage 2: Projective interpolation
        let mut projections = self.projective_interpolation(&tic_id)?;
        
        // Stage 3: Normalization
        self.normalize_projections(&mut projections)?;
        
        // Stage 4: Signature generation
        let signature = self.generate_signature(&tic_id, &projections)?;
        
        Ok((tic_id, projections, signature))
    }
    
    /// Get TIC catalogue reference
    pub fn catalogue(&self) -> &TICCatalogue {
        &self.catalogue
    }
}

impl Default for ResonantLanguageProjection {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_tic_creation() {
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        
        assert!(tic.phase.iter().all(|&p| p >= 0.0 && p < std::f64::consts::TAU));
        assert!(tic.entropy_gradient >= 0.0 && tic.entropy_gradient <= 1.0);
    }
    
    #[test]
    fn test_projection_tensor() {
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        
        let proj = ProjectionTensor::new(Domain::Mathematics, &tic);
        assert_eq!(proj.domain, Domain::Mathematics);
        assert!(!proj.checksum.is_empty());
        assert_eq!(proj.tensor.len(), 2);
    }
    
    #[test]
    fn test_all_domains() {
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        
        for domain in Domain::all() {
            let proj = ProjectionTensor::new(domain, &tic);
            assert_eq!(proj.domain, domain);
            assert!(!proj.basis.is_empty());
        }
    }
    
    #[test]
    fn test_universal_signature() {
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        let projections: Vec<_> = Domain::all()
            .iter()
            .map(|&d| ProjectionTensor::new(d, &tic))
            .collect();
        
        let sig = UniversalOperatorSignature::generate(&tic, &projections, "test_state");
        assert!(!sig.signature_hash.is_empty());
        assert!(sig.semantic_coherence >= 0.0 && sig.semantic_coherence <= 1.0);
    }
    
    #[test]
    fn test_tic_catalogue() {
        let mut catalogue = TICCatalogue::new();
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        let tic_id = tic.id;
        
        catalogue.add_tic(tic).unwrap();
        assert_eq!(catalogue.size(), 1);
        assert!(catalogue.get(&tic_id).is_some());
    }
    
    #[test]
    fn test_rlp_pipeline() {
        let mut rlp = ResonantLanguageProjection::new();
        let op = Operator::new();
        
        let result = rlp.process_operator(&op);
        assert!(result.is_ok());
        
        let (_tic_id, projections, signature) = result.unwrap();
        assert_eq!(projections.len(), 5); // All 5 domains
        assert!(!signature.signature_hash.is_empty());
    }
}
