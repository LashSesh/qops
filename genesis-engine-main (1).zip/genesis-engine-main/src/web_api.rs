//! Web API Module for MOGE Hybrid Kernel Telemetry
//!
//! Provides HTTP API endpoints for real-time monitoring and control
//! of the hybrid kernel system.

use crate::hybrid_kernel::{HybridKernel, HybridKernelConfig, run_verification_pipeline};
use crate::signature::Signature5D;
use crate::error::Result;
use serde::{Deserialize, Serialize};

/// API Response wrapper
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApiResponse<T> {
    pub success: bool,
    pub data: Option<T>,
    pub error: Option<String>,
}

impl<T> ApiResponse<T> {
    pub fn success(data: T) -> Self {
        Self {
            success: true,
            data: Some(data),
            error: None,
        }
    }

    pub fn error(message: String) -> Self {
        Self {
            success: false,
            data: None,
            error: Some(message),
        }
    }
}

/// Status endpoint response
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StatusResponse {
    pub cycle_number: usize,
    pub tick_number: usize,
    pub energy: f64,
    pub energy_drift: f64,
    pub equilibrium_rate: f64,
    pub temporal_coherence: f64,
    pub self_similarity: f64,
    pub is_stable: bool,
}

/// TIC state endpoint response
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TicStateResponse {
    pub num_layers: usize,
    pub current_cycle: usize,
    pub temporal_coherence: f64,
    pub stable_clusters: Vec<Vec<usize>>,
}

/// Calibration request
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CalibrationRequest {
    pub alpha: Option<f64>,
    pub beta: Option<f64>,
    pub topology_threshold: Option<f64>,
}

/// Ledger summary response
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LedgerResponse {
    pub total_operators: usize,
    pub total_cycles: usize,
    pub cliv_state: Option<String>,
    pub invariant_hashes: Vec<String>,
}

/// API Handler - simulates HTTP endpoint handling
pub struct ApiHandler {
    kernel: HybridKernel,
}

impl ApiHandler {
    /// Create new API handler with kernel
    pub fn new(config: HybridKernelConfig, initial_operators: Vec<Signature5D>) -> Self {
        let kernel = HybridKernel::new(config, initial_operators);
        Self { kernel }
    }

    /// GET /status - Current resonance & invariance metrics
    pub fn handle_status(&mut self) -> Result<ApiResponse<StatusResponse>> {
        // Run one cycle to get fresh status
        let state = self.kernel.run_cycle()?;
        let metrics = self.kernel.get_stability_metrics();
        let invariance = self.kernel.check_invariance();

        let response = StatusResponse {
            cycle_number: state.cycle_number,
            tick_number: state.tick_number,
            energy: state.energy,
            energy_drift: state.energy_drift,
            equilibrium_rate: state.equilibrium_rate,
            temporal_coherence: invariance.temporal_coherence,
            self_similarity: invariance.self_similarity,
            is_stable: metrics.is_stable,
        };

        Ok(ApiResponse::success(response))
    }

    /// GET /tic_state - Active Temporal Crystal layer structure
    pub fn handle_tic_state(&self) -> ApiResponse<TicStateResponse> {
        let response = TicStateResponse {
            num_layers: self.kernel.invariant_crystal.tic.num_layers,
            current_cycle: self.kernel.invariant_crystal.tic.current_cycle,
            temporal_coherence: self.kernel.invariant_crystal.tic.temporal_coherence(),
            stable_clusters: self.kernel.invariant_crystal.tic.get_stable_clusters(0.01),
        };

        ApiResponse::success(response)
    }

    /// POST /calibrate - Update adaptive constants
    pub fn handle_calibrate(&mut self, request: CalibrationRequest) -> Result<ApiResponse<String>> {
        // Get current constants
        let mut constants = self.kernel.recursive_optimizer.get_constants().clone();

        // Update with request values
        if let Some(alpha) = request.alpha {
            constants.alpha = alpha;
        }
        if let Some(beta) = request.beta {
            constants.beta = beta;
        }
        if let Some(threshold) = request.topology_threshold {
            constants.topology_threshold = threshold;
        }

        // Apply calibration through optimizer
        self.kernel.recursive_optimizer = crate::recursive_optimizer::RecursiveOptimizer::with_constants(constants);

        Ok(ApiResponse::success("Calibration updated".to_string()))
    }

    /// GET /ledger - Artefact summaries with invariant hashes
    pub fn handle_ledger(&self) -> ApiResponse<LedgerResponse> {
        let signatures = self.kernel.get_signatures();
        let cliv = self.kernel.get_cliv();

        let cliv_json = cliv.map(|c| c.to_json());

        // Generate simple hashes from signatures
        let hashes: Vec<String> = signatures
            .iter()
            .map(|sig| format!("{:x}", hash_signature(sig)))
            .collect();

        let response = LedgerResponse {
            total_operators: signatures.len(),
            total_cycles: self.kernel.state.cycle_number,
            cliv_state: cliv_json,
            invariant_hashes: hashes,
        };

        ApiResponse::success(response)
    }

    /// GET /verify - Run verification pipeline
    pub fn handle_verify(&self) -> ApiResponse<crate::hybrid_kernel::VerificationResults> {
        let results = run_verification_pipeline(&self.kernel);
        ApiResponse::success(results)
    }

    /// GET /signatures - Get current operator signatures
    pub fn handle_signatures(&self) -> ApiResponse<Vec<Signature5D>> {
        let signatures = self.kernel.get_signatures().to_vec();
        ApiResponse::success(signatures)
    }

    /// GET /metrics - Get detailed stability metrics
    pub fn handle_metrics(&self) -> ApiResponse<crate::hybrid_kernel::StabilityMetrics> {
        let metrics = self.kernel.get_stability_metrics();
        ApiResponse::success(metrics)
    }

    /// POST /cycle - Run one or more cycles
    pub fn handle_run_cycles(&mut self, count: usize) -> Result<ApiResponse<Vec<crate::hybrid_kernel::HybridKernelState>>> {
        let mut states = Vec::new();
        for _ in 0..count {
            let state = self.kernel.run_cycle()?;
            states.push(state);
        }
        Ok(ApiResponse::success(states))
    }
}

/// Helper function to hash a signature
fn hash_signature(sig: &Signature5D) -> u64 {
    let psi_q = (sig.psi * 1000.0) as u64;
    let rho_q = (sig.rho * 1000.0) as u64;
    let omega_q = (sig.omega * 1000.0) as u64;
    let chi_q = (sig.chi * 1000.0) as u64;
    let eta_q = (sig.eta * 1000.0) as u64;
    
    psi_q.wrapping_mul(31)
        .wrapping_add(rho_q.wrapping_mul(37))
        .wrapping_add(omega_q.wrapping_mul(41))
        .wrapping_add(chi_q.wrapping_mul(43))
        .wrapping_add(eta_q.wrapping_mul(47))
}

/// WebSocket telemetry message
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetryMessage {
    pub timestamp: u64,
    pub message_type: String,
    pub data: serde_json::Value,
}

impl TelemetryMessage {
    pub fn status(data: StatusResponse) -> Self {
        Self {
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_secs(),
            message_type: "status".to_string(),
            data: serde_json::to_value(data).unwrap(),
        }
    }

    pub fn metrics(data: crate::hybrid_kernel::StabilityMetrics) -> Self {
        Self {
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_secs(),
            message_type: "metrics".to_string(),
            data: serde_json::to_value(data).unwrap(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn create_test_handler() -> ApiHandler {
        let config = HybridKernelConfig::default();
        let operators = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
            Signature5D::new(0.6, 0.4, 0.5, 0.5, 0.5),
        ];
        ApiHandler::new(config, operators)
    }

    #[test]
    fn test_handle_status() {
        let mut handler = create_test_handler();
        let response = handler.handle_status();
        assert!(response.is_ok());
        
        let resp = response.unwrap();
        assert!(resp.success);
        assert!(resp.data.is_some());
    }

    #[test]
    fn test_handle_tic_state() {
        let handler = create_test_handler();
        let response = handler.handle_tic_state();
        assert!(response.success);
        assert!(response.data.is_some());
    }

    #[test]
    fn test_handle_ledger() {
        let handler = create_test_handler();
        let response = handler.handle_ledger();
        assert!(response.success);
        assert!(response.data.is_some());
    }

    #[test]
    fn test_handle_calibrate() {
        let mut handler = create_test_handler();
        let request = CalibrationRequest {
            alpha: Some(0.02),
            beta: Some(0.06),
            topology_threshold: None,
        };
        let response = handler.handle_calibrate(request);
        assert!(response.is_ok());
    }

    #[test]
    fn test_handle_signatures() {
        let handler = create_test_handler();
        let response = handler.handle_signatures();
        assert!(response.success);
        
        if let Some(sigs) = response.data {
            assert_eq!(sigs.len(), 2);
        }
    }

    #[test]
    fn test_telemetry_message() {
        let status = StatusResponse {
            cycle_number: 1,
            tick_number: 15,
            energy: 0.5,
            energy_drift: 1e-6,
            equilibrium_rate: 0.95,
            temporal_coherence: 0.98,
            self_similarity: 0.97,
            is_stable: true,
        };

        let msg = TelemetryMessage::status(status);
        assert_eq!(msg.message_type, "status");
        assert!(msg.timestamp > 0);
    }
}
