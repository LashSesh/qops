//! KNO Core Module - Operator Mining and Generation
//!
//! Provides iterative generation, validation, and spectral filtering of KNO operators
//! using the Nullpunkt formalism with Hermitian operator theory.

use crate::kno_framework::KNOOperator;
use crate::error::Result;
use serde::{Deserialize, Serialize};

/// Mining configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MiningConfig {
    /// Number of iterations for mining
    pub iterations: usize,
    /// Spectral balance threshold
    pub spectral_threshold: f64,
    /// Energy neutrality tolerance
    pub energy_tolerance: f64,
    /// Alpha parameter range [min, max]
    pub alpha_range: (f64, f64),
    /// Beta parameter range [min, max]
    pub beta_range: (f64, f64),
    /// Number of alpha samples
    pub alpha_samples: usize,
    /// Number of beta samples
    pub beta_samples: usize,
    /// Riemann zeros for potential construction
    pub riemann_zeros: Vec<f64>,
}

impl Default for MiningConfig {
    fn default() -> Self {
        Self {
            iterations: 1000,
            spectral_threshold: 1e-6,
            energy_tolerance: 1e-9,
            alpha_range: (0.5, 1.5),
            beta_range: (0.4, 1.4),
            alpha_samples: 10,
            beta_samples: 10,
            riemann_zeros: vec![14.134725, 21.022040, 25.010858],
        }
    }
}

/// Mining statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MiningStatistics {
    pub total_generated: usize,
    pub hermitian_operators: usize,
    pub stable_operators: usize,
    pub phase_locked_operators: usize,
    pub mean_energy: f64,
    pub mean_spectral_balance: f64,
    pub convergence_rate: f64,
}

impl MiningStatistics {
    pub fn new() -> Self {
        Self {
            total_generated: 0,
            hermitian_operators: 0,
            stable_operators: 0,
            phase_locked_operators: 0,
            mean_energy: 0.0,
            mean_spectral_balance: 0.0,
            convergence_rate: 0.0,
        }
    }
}

/// KNO Mining Core - Iterative operator generation and validation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KNOMiningCore {
    /// Mined operators
    pub operators: Vec<KNOOperator>,
    /// Mining configuration
    pub config: MiningConfig,
    /// Current iteration count
    pub current_iteration: usize,
    /// Mining statistics
    pub statistics: MiningStatistics,
}

impl KNOMiningCore {
    /// Create new mining core with configuration
    pub fn new(config: MiningConfig) -> Self {
        Self {
            operators: Vec::new(),
            config,
            current_iteration: 0,
            statistics: MiningStatistics::new(),
        }
    }

    /// Create with default configuration
    pub fn with_defaults() -> Self {
        Self::new(MiningConfig::default())
    }

    /// Mine operators across Δφ-space
    pub fn mine(&mut self) -> Result<Vec<KNOOperator>> {
        println!("Starting KNO operator mining...");
        println!("  Iterations: {}", self.config.iterations);
        println!("  Alpha range: [{:.3}, {:.3}]", self.config.alpha_range.0, self.config.alpha_range.1);
        println!("  Beta range: [{:.3}, {:.3}]", self.config.beta_range.0, self.config.beta_range.1);

        let alpha_step = (self.config.alpha_range.1 - self.config.alpha_range.0) / (self.config.alpha_samples as f64);
        let beta_step = (self.config.beta_range.1 - self.config.beta_range.0) / (self.config.beta_samples as f64);

        let mut hermitian_count = 0;
        let mut stable_count = 0;

        for i in 0..self.config.alpha_samples {
            for j in 0..self.config.beta_samples {
                let alpha = self.config.alpha_range.0 + (i as f64) * alpha_step;
                let beta = self.config.beta_range.0 + (j as f64) * beta_step;

                let operator = KNOOperator::from_parameters(
                    alpha,
                    beta,
                    self.config.riemann_zeros.clone(),
                );

                // Test hermiticity
                if operator.is_hermitian() {
                    hermitian_count += 1;
                }

                // Test stability
                if operator.is_stable {
                    stable_count += 1;
                }

                self.operators.push(operator);
                self.current_iteration += 1;

                if self.current_iteration >= self.config.iterations {
                    break;
                }
            }

            if self.current_iteration >= self.config.iterations {
                break;
            }
        }

        // Update statistics
        self.statistics.total_generated = self.operators.len();
        self.statistics.hermitian_operators = hermitian_count;
        self.statistics.stable_operators = stable_count;
        self.statistics.convergence_rate = hermitian_count as f64 / self.operators.len() as f64;

        println!("Mining complete:");
        println!("  Generated: {} operators", self.statistics.total_generated);
        println!("  Hermitian: {} ({:.2}%)", hermitian_count,
                 100.0 * hermitian_count as f64 / self.operators.len() as f64);
        println!("  Stable: {} ({:.2}%)", stable_count,
                 100.0 * stable_count as f64 / self.operators.len() as f64);

        Ok(self.operators.clone())
    }

    /// Evaluate spectral balance and energy neutrality
    pub fn evaluate(&mut self) -> Result<Vec<EvaluationReport>> {
        let mut reports = Vec::new();

        for operator in &self.operators {
            let spectral_balance = self.compute_spectral_balance(operator);
            let energy_neutral = operator.energy.abs() < self.config.energy_tolerance;
            let hermitian = operator.is_hermitian();

            let report = EvaluationReport {
                operator_id: operator.id,
                spectral_balance,
                energy: operator.energy,
                energy_neutral,
                hermitian,
                stable: operator.is_stable,
                delta_phi: operator.delta_phi,
            };

            reports.push(report);
        }

        // Update statistics
        let energies: Vec<f64> = reports.iter().map(|r| r.energy).collect();
        let balances: Vec<f64> = reports.iter().map(|r| r.spectral_balance).collect();

        self.statistics.mean_energy = energies.iter().sum::<f64>() / energies.len() as f64;
        self.statistics.mean_spectral_balance = balances.iter().sum::<f64>() / balances.len() as f64;

        Ok(reports)
    }

    /// Stabilize operators to nullpoints when equilibrium is reached
    pub fn stabilize(&mut self) -> Result<usize> {
        let mut stabilized_count = 0;

        for operator in &mut self.operators {
            // Check if operator is near equilibrium
            if operator.delta_phi.abs() < self.config.spectral_threshold {
                operator.collapse_to_nullpoint();
                stabilized_count += 1;
            }
        }

        self.statistics.phase_locked_operators = stabilized_count;

        println!("Stabilization complete: {} operators collapsed to nullpoint", stabilized_count);

        Ok(stabilized_count)
    }

    /// Filter operators by spectral threshold
    pub fn filter_by_spectral_threshold(&mut self) -> Vec<KNOOperator> {
        let filtered: Vec<KNOOperator> = self.operators
            .iter()
            .filter(|op| {
                let balance = self.compute_spectral_balance(op);
                balance < self.config.spectral_threshold
            })
            .cloned()
            .collect();

        println!("Filtered {} operators meeting spectral threshold", filtered.len());
        filtered
    }

    /// Filter operators that are Hermitian
    pub fn filter_hermitian(&self) -> Vec<KNOOperator> {
        self.operators
            .iter()
            .filter(|op| op.is_hermitian())
            .cloned()
            .collect()
    }

    /// Filter stable operators
    pub fn filter_stable(&self) -> Vec<KNOOperator> {
        self.operators
            .iter()
            .filter(|op| op.is_stable)
            .cloned()
            .collect()
    }

    /// Compute spectral balance: measure of spectral symmetry
    pub fn compute_spectral_balance(&self, operator: &KNOOperator) -> f64 {
        if operator.spectrum.is_empty() {
            return 0.0;
        }

        // Check that all eigenvalues satisfy |λ_n| ≈ 1
        let deviations: Vec<f64> = operator.spectrum
            .iter()
            .map(|&lambda| (lambda.abs() - 1.0).abs())
            .collect();

        deviations.iter().sum::<f64>() / deviations.len() as f64
    }

    /// Get mining statistics
    pub fn get_statistics(&self) -> &MiningStatistics {
        &self.statistics
    }

    /// Reset mining core
    pub fn reset(&mut self) {
        self.operators.clear();
        self.current_iteration = 0;
        self.statistics = MiningStatistics::new();
    }
}

/// Evaluation report for a single operator
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvaluationReport {
    pub operator_id: uuid::Uuid,
    pub spectral_balance: f64,
    pub energy: f64,
    pub energy_neutral: bool,
    pub hermitian: bool,
    pub stable: bool,
    pub delta_phi: f64,
}

impl EvaluationReport {
    /// Check if operator passes all validation criteria
    pub fn is_valid(&self) -> bool {
        self.energy_neutral && self.hermitian && self.stable
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mining_core_creation() {
        let core = KNOMiningCore::with_defaults();
        assert_eq!(core.operators.len(), 0);
        assert_eq!(core.current_iteration, 0);
    }

    #[test]
    fn test_operator_mining() {
        let mut config = MiningConfig::default();
        config.iterations = 10;
        config.alpha_samples = 3;
        config.beta_samples = 3;

        let mut core = KNOMiningCore::new(config);
        let operators = core.mine().unwrap();

        assert_eq!(operators.len(), 9); // 3x3 grid
        assert!(core.statistics.total_generated > 0);
    }

    #[test]
    fn test_spectral_balance_computation() {
        let config = MiningConfig::default();
        let core = KNOMiningCore::new(config.clone());

        let operator = KNOOperator::from_parameters(
            1.0,
            0.9,
            config.riemann_zeros.clone(),
        );

        let balance = core.compute_spectral_balance(&operator);
        assert!(balance < 1.0); // Should be small for valid spectrum
    }

    #[test]
    fn test_evaluation() {
        let mut config = MiningConfig::default();
        config.iterations = 5;
        config.alpha_samples = 2;
        config.beta_samples = 2;

        let mut core = KNOMiningCore::new(config);
        core.mine().unwrap();

        let reports = core.evaluate().unwrap();
        assert_eq!(reports.len(), core.operators.len());

        for report in &reports {
            assert!(report.spectral_balance >= 0.0);
        }
    }

    #[test]
    fn test_stabilization() {
        let mut config = MiningConfig::default();
        config.iterations = 10;
        config.alpha_samples = 2;
        config.beta_samples = 2;

        let mut core = KNOMiningCore::new(config);
        core.mine().unwrap();

        // Manually set some operators to near-zero delta_phi
        for i in 0..core.operators.len() / 2 {
            core.operators[i].delta_phi = 1e-8;
        }

        let stabilized = core.stabilize().unwrap();
        assert!(stabilized > 0);
    }

    #[test]
    fn test_hermitian_filtering() {
        let mut config = MiningConfig::default();
        config.iterations = 10;
        config.alpha_samples = 5;
        config.beta_samples = 5;
        config.alpha_range = (1.0, 1.0); // Same alpha/beta will give Hermitian
        config.beta_range = (1.0, 1.0);

        let mut core = KNOMiningCore::new(config);
        core.mine().unwrap();

        let hermitian = core.filter_hermitian();
        assert!(hermitian.len() > 0);

        for op in hermitian {
            assert!(op.is_hermitian());
        }
    }

    #[test]
    fn test_stable_filtering() {
        let mut config = MiningConfig::default();
        config.iterations = 20;
        config.alpha_samples = 4;
        config.beta_samples = 4;

        let mut core = KNOMiningCore::new(config);
        core.mine().unwrap();

        let stable = core.filter_stable();
        for op in stable {
            assert!(op.is_stable);
        }
    }
}
