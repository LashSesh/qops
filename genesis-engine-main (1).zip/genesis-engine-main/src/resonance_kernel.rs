//! Resonance Kernel - IMHK Foundation
//!
//! Core resonance computation and validation logic.
//! Implements resonance equilibrium and invariance conditions.

use crate::signature::Signature5D;
use crate::operator::Operator;
use serde::{Deserialize, Serialize};

/// Resonance kernel configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResonanceKernelConfig {
    /// Epsilon for invariance checking
    pub epsilon: f64,
    /// Resonance equilibrium tolerance
    pub equilibrium_tolerance: f64,
    /// Feedback strength
    pub feedback_strength: f64,
    /// Time delta for equilibrium checking
    pub time_delta: f64,
}

impl Default for ResonanceKernelConfig {
    fn default() -> Self {
        Self {
            epsilon: 0.001,
            equilibrium_tolerance: 1e-4,
            feedback_strength: 0.1,
            time_delta: 0.01,
        }
    }
}

/// Compute resonance score for a signature
///
/// Resonance formula: R(v) = 0.4·ψ + 0.3·ρ + 0.3·ω
/// Extended with χ and η for IMHK
pub fn resonance(v: &Signature5D) -> f64 {
    // Base resonance from core components
    let base = 0.4 * v.psi + 0.3 * v.rho + 0.3 * v.omega;

    // Topological and fluctuation corrections
    let topo_correction = 0.05 * v.chi;
    let fluct_correction = -0.05 * v.eta; // Negative because high fluctuation reduces stability

    (base + topo_correction + fluct_correction).clamp(0.0, 1.0)
}

/// Validate resonance invariant condition
///
/// Rule: |Δ(ψ·ρ·ω) + χ·η| < ε
pub fn validate_invariant(v1: &Signature5D, v2: &Signature5D, epsilon: f64) -> bool {
    let product1 = v1.psi * v1.rho * v1.omega;
    let product2 = v2.psi * v2.rho * v2.omega;

    let delta_product = (product2 - product1).abs();
    let chi_eta_term = v2.chi * v2.eta;

    let invariant = delta_product + chi_eta_term;

    invariant < epsilon
}

/// Check resonance equilibrium condition
///
/// Rule: d/dt(ψ·ρ·ω) ≈ 0
pub fn check_equilibrium(history: &[Signature5D], config: &ResonanceKernelConfig) -> bool {
    if history.len() < 2 {
        return false;
    }

    let n = history.len();
    let recent = &history[n - 1];
    let previous = &history[n - 2];

    let product_recent = recent.psi * recent.rho * recent.omega;
    let product_previous = previous.psi * previous.rho * previous.omega;

    let derivative = (product_recent - product_previous) / config.time_delta;

    derivative.abs() < config.equilibrium_tolerance
}

/// Apply feedback cycle to operator
pub fn feedback_cycle(op: &mut Operator, config: &ResonanceKernelConfig) {
    let resonance_score = resonance(&op.signature);

    // Compute feedback direction
    let target_resonance = 0.85; // Target high resonance
    let error = target_resonance - resonance_score;

    // Apply feedback to signature components
    let delta = config.feedback_strength * error;

    op.signature.psi += delta * 0.4; // Proportional to weight in resonance formula
    op.signature.rho += delta * 0.3;
    op.signature.omega += delta * 0.3;

    // Reduce fluctuation if resonance is low
    if resonance_score < 0.7 {
        op.signature.eta *= 0.95;
    }

    // Clamp to valid range
    op.signature.psi = op.signature.psi.clamp(0.0, 1.0);
    op.signature.rho = op.signature.rho.clamp(0.0, 1.0);
    op.signature.omega = op.signature.omega.clamp(0.0, 1.0);
    op.signature.chi = op.signature.chi.clamp(0.0, 1.0);
    op.signature.eta = op.signature.eta.clamp(0.0, 1.0);

    // Update resonance score
    op.resonance_score = resonance(&op.signature);
}

/// Resonance field - captures resonance landscape
#[derive(Debug, Clone)]
pub struct ResonanceField {
    pub samples: Vec<(Signature5D, f64)>,
    pub peak_resonance: f64,
    pub mean_resonance: f64,
}

impl ResonanceField {
    pub fn new() -> Self {
        Self {
            samples: Vec::new(),
            peak_resonance: 0.0,
            mean_resonance: 0.0,
        }
    }

    /// Add sample to field
    pub fn add_sample(&mut self, sig: Signature5D) {
        let res = resonance(&sig);
        self.samples.push((sig, res));

        // Update statistics
        if res > self.peak_resonance {
            self.peak_resonance = res;
        }

        self.mean_resonance = self.samples.iter()
            .map(|(_, r)| r)
            .sum::<f64>() / self.samples.len() as f64;
    }

    /// Find local maxima
    pub fn find_peaks(&self, threshold: f64) -> Vec<Signature5D> {
        self.samples.iter()
            .filter(|(_, r)| *r > threshold)
            .map(|(s, _)| *s)
            .collect()
    }

    /// Get gradient at signature (numerical approximation)
    pub fn gradient(&self, sig: &Signature5D, delta: f64) -> [f64; 5] {
        let base_res = resonance(sig);

        let mut grad = [0.0; 5];

        // Gradient w.r.t. psi
        let mut perturbed = *sig;
        perturbed.psi += delta;
        grad[0] = (resonance(&perturbed) - base_res) / delta;

        // Gradient w.r.t. rho
        perturbed = *sig;
        perturbed.rho += delta;
        grad[1] = (resonance(&perturbed) - base_res) / delta;

        // Gradient w.r.t. omega
        perturbed = *sig;
        perturbed.omega += delta;
        grad[2] = (resonance(&perturbed) - base_res) / delta;

        // Gradient w.r.t. chi
        perturbed = *sig;
        perturbed.chi += delta;
        grad[3] = (resonance(&perturbed) - base_res) / delta;

        // Gradient w.r.t. eta
        perturbed = *sig;
        perturbed.eta += delta;
        grad[4] = (resonance(&perturbed) - base_res) / delta;

        grad
    }
}

impl Default for ResonanceField {
    fn default() -> Self {
        Self::new()
    }
}

/// Resonance attractor - represents stable resonance state
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResonanceAttractor {
    pub center: Signature5D,
    pub resonance: f64,
    pub basin_radius: f64,
    pub stability: f64,
}

impl ResonanceAttractor {
    pub fn new(sig: Signature5D, basin_radius: f64) -> Self {
        let res = resonance(&sig);
        Self {
            center: sig,
            resonance: res,
            basin_radius,
            stability: 1.0,
        }
    }

    /// Check if signature is in attractor basin
    pub fn contains(&self, sig: &Signature5D) -> bool {
        let dist = signature_distance(&self.center, sig);
        dist < self.basin_radius
    }

    /// Pull signature towards attractor
    pub fn attract(&self, sig: &mut Signature5D, strength: f64) {
        let s = strength.clamp(0.0, 1.0);

        sig.psi += s * (self.center.psi - sig.psi);
        sig.rho += s * (self.center.rho - sig.rho);
        sig.omega += s * (self.center.omega - sig.omega);
        sig.chi += s * (self.center.chi - sig.chi);
        sig.eta += s * (self.center.eta - sig.eta);
    }
}

/// Compute Euclidean distance between signatures
fn signature_distance(a: &Signature5D, b: &Signature5D) -> f64 {
    (
        (a.psi - b.psi).powi(2) +
        (a.rho - b.rho).powi(2) +
        (a.omega - b.omega).powi(2) +
        (a.chi - b.chi).powi(2) +
        (a.eta - b.eta).powi(2)
    ).sqrt()
}

/// Resonance dynamics system
#[derive(Debug)]
pub struct ResonanceDynamics {
    pub config: ResonanceKernelConfig,
    pub history: Vec<Signature5D>,
    pub attractors: Vec<ResonanceAttractor>,
    pub field: ResonanceField,
}

impl ResonanceDynamics {
    pub fn new(config: ResonanceKernelConfig) -> Self {
        Self {
            config,
            history: Vec::new(),
            attractors: Vec::new(),
            field: ResonanceField::new(),
        }
    }

    /// Evolve signature one timestep
    pub fn evolve(&mut self, sig: &mut Signature5D) {
        // Record current state
        self.history.push(*sig);
        self.field.add_sample(*sig);

        // Apply attractor forces
        for attractor in &self.attractors {
            if attractor.contains(sig) {
                attractor.attract(sig, self.config.feedback_strength);
            }
        }

        // Apply feedback based on resonance gradient
        let grad = self.field.gradient(sig, 0.01);

        sig.psi += self.config.feedback_strength * grad[0];
        sig.rho += self.config.feedback_strength * grad[1];
        sig.omega += self.config.feedback_strength * grad[2];
        sig.chi += self.config.feedback_strength * grad[3];
        sig.eta += self.config.feedback_strength * grad[4];

        // Clamp
        sig.psi = sig.psi.clamp(0.0, 1.0);
        sig.rho = sig.rho.clamp(0.0, 1.0);
        sig.omega = sig.omega.clamp(0.0, 1.0);
        sig.chi = sig.chi.clamp(0.0, 1.0);
        sig.eta = sig.eta.clamp(0.0, 1.0);
    }

    /// Add attractor
    pub fn add_attractor(&mut self, attractor: ResonanceAttractor) {
        self.attractors.push(attractor);
    }

    /// Check if system is at equilibrium
    pub fn is_at_equilibrium(&self) -> bool {
        check_equilibrium(&self.history, &self.config)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_resonance_computation() {
        let sig = Signature5D::new(0.9, 0.8, 0.7, 0.6, 0.5);
        let res = resonance(&sig);

        assert!(res > 0.7);
        assert!(res <= 1.0);
    }

    #[test]
    fn test_invariant_validation() {
        let v1 = Signature5D::new(0.5, 0.5, 0.5, 0.1, 0.1);
        let v2 = Signature5D::new(0.5, 0.5, 0.51, 0.1, 0.1);

        assert!(validate_invariant(&v1, &v2, 0.1));
    }

    #[test]
    fn test_feedback_cycle() {
        let config = ResonanceKernelConfig::default();
        let mut op = Operator::from_signature(Signature5D::new(0.3, 0.3, 0.3, 0.3, 0.3));

        let initial_res = resonance(&op.signature);

        feedback_cycle(&mut op, &config);

        let final_res = resonance(&op.signature);

        // Resonance should improve
        assert!(final_res > initial_res);
    }

    #[test]
    fn test_resonance_field() {
        let mut field = ResonanceField::new();

        field.add_sample(Signature5D::new(0.9, 0.8, 0.7, 0.6, 0.5));
        field.add_sample(Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5));

        assert_eq!(field.samples.len(), 2);
        assert!(field.peak_resonance > 0.0);
        assert!(field.mean_resonance > 0.0);
    }

    #[test]
    fn test_resonance_attractor() {
        let attractor = ResonanceAttractor::new(
            Signature5D::new(0.9, 0.8, 0.7, 0.6, 0.5),
            0.3
        );

        let near = Signature5D::new(0.85, 0.8, 0.7, 0.6, 0.5);
        let far = Signature5D::new(0.1, 0.1, 0.1, 0.1, 0.1);

        assert!(attractor.contains(&near));
        assert!(!attractor.contains(&far));
    }

    #[test]
    fn test_resonance_dynamics() {
        let config = ResonanceKernelConfig::default();
        let mut dynamics = ResonanceDynamics::new(config);

        let mut sig = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);

        // Add attractor at high resonance
        let attractor = ResonanceAttractor::new(
            Signature5D::new(0.9, 0.8, 0.8, 0.7, 0.3),
            0.5
        );
        dynamics.add_attractor(attractor);

        // Evolve system
        for _ in 0..10 {
            dynamics.evolve(&mut sig);
        }

        // Signature should have moved towards attractor
        assert!(sig.psi > 0.5);
    }
}
