//! Artefact Module
//!
//! An Artefact represents a single node/operator in the MOGE system with:
//! - A unique ID
//! - A signature (3D or 5D)
//! - Blueprint history (traversal path, transformations)
//! - Timestamp and metadata

use crate::signature::{Signature, Signature3D, Signature5D};
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use chrono::{DateTime, Utc};

/// Blueprint entry recording a transformation step
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BlueprintEntry {
    /// Timestamp of this transformation
    pub timestamp: DateTime<Utc>,
    /// Source node ID
    pub from_node: usize,
    /// Target node ID
    pub to_node: usize,
    /// Transformation type/description
    pub transformation: String,
    /// Signature before transformation
    pub signature_before: Signature5D,
    /// Signature after transformation
    pub signature_after: Signature5D,
}

impl PartialEq for BlueprintEntry {
    fn eq(&self, other: &Self) -> bool {
        self.from_node == other.from_node
            && self.to_node == other.to_node
            && self.transformation == other.transformation
            && self.timestamp == other.timestamp
    }
}

impl Eq for BlueprintEntry {}

impl std::hash::Hash for BlueprintEntry {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        self.from_node.hash(state);
        self.to_node.hash(state);
        self.transformation.hash(state);
        self.timestamp.hash(state);
    }
}

impl std::fmt::Display for BlueprintEntry {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "{} -> {} via {} at {}",
            self.from_node, self.to_node, self.transformation, self.timestamp
        )
    }
}

/// An Artefact is a node with signature and history
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Artefact {
    /// Unique identifier
    pub id: Uuid,
    /// Current node in the MetatronCube graph
    pub node_id: usize,
    /// Current signature (5D for full tracking)
    pub signature: Signature5D,
    /// Blueprint history: sequence of transformations
    pub blueprint: Vec<BlueprintEntry>,
    /// Creation timestamp
    pub created_at: DateTime<Utc>,
    /// Last modification timestamp
    pub updated_at: DateTime<Utc>,
    /// Stability score (computed from signature variance)
    pub stability: f64,
    /// Whether this artefact has achieved Mandorla stability
    pub is_mandorla_certified: bool,
}

impl Artefact {
    /// Create a new artefact at a given node
    pub fn new(node_id: usize, signature: Signature5D) -> Self {
        let now = Utc::now();
        Self {
            id: Uuid::new_v4(),
            node_id,
            signature,
            blueprint: Vec::new(),
            created_at: now,
            updated_at: now,
            stability: 1.0, // Initially stable
            is_mandorla_certified: false,
        }
    }

    /// Create from 3D signature
    pub fn from_3d(node_id: usize, signature: Signature3D) -> Self {
        Self::new(node_id, Signature5D::from_3d(signature))
    }

    /// Add a blueprint entry recording a transformation
    pub fn record_transformation(
        &mut self,
        from_node: usize,
        to_node: usize,
        transformation: String,
        new_signature: Signature5D,
    ) {
        let entry = BlueprintEntry {
            timestamp: Utc::now(),
            from_node,
            to_node,
            transformation,
            signature_before: self.signature,
            signature_after: new_signature,
        };

        self.blueprint.push(entry);
        self.signature = new_signature;
        self.node_id = to_node;
        self.updated_at = Utc::now();

        // Recalculate stability
        self.update_stability();
    }

    /// Update stability score based on signature variance over history
    fn update_stability(&mut self) {
        if self.blueprint.len() < 2 {
            self.stability = 1.0;
            return;
        }

        // Calculate variance in resonance over time
        let resonances: Vec<f64> = self.blueprint
            .iter()
            .map(|e| e.signature_after.resonance())
            .collect();

        let mean = resonances.iter().sum::<f64>() / resonances.len() as f64;
        let variance = resonances
            .iter()
            .map(|r| (r - mean).powi(2))
            .sum::<f64>() / resonances.len() as f64;

        // Lower variance = higher stability
        self.stability = 1.0 / (1.0 + variance);
    }

    /// Check if artefact should be Mandorla-certified
    /// Criteria: stability > threshold and signature change is minimal
    pub fn check_mandorla_certification(&mut self, threshold: f64) {
        if self.blueprint.len() < 3 {
            return;
        }

        // Check if recent changes are below threshold
        let recent = &self.blueprint[self.blueprint.len()-3..];
        let mut delta_sum = 0.0;

        for window in recent.windows(2) {
            delta_sum += window[0].signature_after.distance(&window[1].signature_after);
        }

        let avg_delta = delta_sum / (recent.len() - 1) as f64;

        if self.stability > threshold && avg_delta < 0.1 {
            self.is_mandorla_certified = true;
        }
    }

    /// Get the current resonance score
    pub fn resonance(&self) -> f64 {
        self.signature.resonance()
    }

    /// Get the 3D projection of the signature
    pub fn signature_3d(&self) -> Signature3D {
        self.signature.to_3d()
    }

    /// Compress the blueprint (keep only significant transformations)
    /// This implements the compression: B_{n+1} = Compress(B_n, Δv)
    pub fn compress_blueprint(&mut self, significance_threshold: f64) {
        let mut compressed = Vec::new();

        for entry in &self.blueprint {
            let delta = entry.signature_before.distance(&entry.signature_after);
            if delta > significance_threshold {
                compressed.push(entry.clone());
            }
        }

        // Always keep the first and last entries
        if !self.blueprint.is_empty() {
            if !compressed.contains(&self.blueprint[0]) {
                compressed.insert(0, self.blueprint[0].clone());
            }
            if let Some(last) = self.blueprint.last() {
                if !compressed.contains(last) {
                    compressed.push(last.clone());
                }
            }
        }

        self.blueprint = compressed;
    }

    /// Get the traversal path as a sequence of node IDs
    pub fn get_path(&self) -> Vec<usize> {
        let mut path = vec![self.blueprint.first().map(|e| e.from_node).unwrap_or(self.node_id)];
        path.extend(self.blueprint.iter().map(|e| e.to_node));
        path
    }

    /// Calculate the total "distance traveled" through signature space
    pub fn signature_distance(&self) -> f64 {
        self.blueprint
            .windows(2)
            .map(|w| w[0].signature_after.distance(&w[1].signature_after))
            .sum()
    }
}

impl std::fmt::Display for Artefact {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "Artefact {} @ node {} | resonance: {:.3} | stability: {:.3} | steps: {} | mandorla: {}",
            &self.id.to_string()[..8],
            self.node_id,
            self.resonance(),
            self.stability,
            self.blueprint.len(),
            if self.is_mandorla_certified { "✓" } else { "✗" }
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_artefact_creation() {
        let sig = Signature5D::with_values(0.8, 0.7, 0.9, 0.6, 0.5).unwrap();
        let artefact = Artefact::new(0, sig);

        assert_eq!(artefact.node_id, 0);
        assert_eq!(artefact.signature, sig);
        assert!(artefact.blueprint.is_empty());
        assert_eq!(artefact.stability, 1.0);
    }

    #[test]
    fn test_transformation_recording() {
        let sig1 = Signature5D::with_values(0.8, 0.7, 0.9, 0.6, 0.5).unwrap();
        let sig2 = Signature5D::with_values(0.85, 0.75, 0.92, 0.65, 0.55).unwrap();
        let mut artefact = Artefact::new(0, sig1);

        artefact.record_transformation(0, 1, "test_transform".to_string(), sig2);

        assert_eq!(artefact.node_id, 1);
        assert_eq!(artefact.signature, sig2);
        assert_eq!(artefact.blueprint.len(), 1);
    }

    #[test]
    fn test_path_extraction() {
        let mut artefact = Artefact::new(0, Signature::new());

        artefact.record_transformation(0, 1, "t1".to_string(), Signature::new());
        artefact.record_transformation(1, 2, "t2".to_string(), Signature::new());
        artefact.record_transformation(2, 3, "t3".to_string(), Signature::new());

        let path = artefact.get_path();
        assert_eq!(path, vec![0, 1, 2, 3]);
    }

    #[test]
    fn test_blueprint_compression() {
        let mut artefact = Artefact::new(0, Signature::new());

        // Add transformations with varying significance
        for i in 1..10 {
            let sig = Signature5D::with_values(
                0.5 + i as f64 * 0.01,
                0.5,
                0.5,
                0.5,
                0.5
            ).unwrap();
            artefact.record_transformation(i-1, i, format!("t{}", i), sig);
        }

        let original_len = artefact.blueprint.len();
        artefact.compress_blueprint(0.05);

        // Should have compressed some entries
        assert!(artefact.blueprint.len() < original_len);
    }
}
