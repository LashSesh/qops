//! WebAssembly Module
//!
//! Provides WebAssembly bindings for MOGE:
//! - JavaScript interop
//! - Browser-based execution
//! - Web visualization support

use crate::simulation::{Simulation, SimulationConfig};
use serde::{Deserialize, Serialize};

#[cfg(target_arch = "wasm32")]
use wasm_bindgen::prelude::*;

/// WebAssembly-compatible simulation runner
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WasmSimulation {
    config: SimulationConfig,
}

#[cfg(target_arch = "wasm32")]
#[wasm_bindgen]
impl WasmSimulation {
    /// Create a new WASM simulation
    #[wasm_bindgen(constructor)]
    pub fn new(agent_count: usize, max_steps: usize, generations: usize) -> Self {
        let config = SimulationConfig {
            agent_count,
            max_steps_per_agent: max_steps,
            generations,
            enable_evolution: true,
            mutation_rate: 0.1,
            target_signature: None,
        };

        Self { config }
    }

    /// Run the simulation and return JSON results
    #[wasm_bindgen]
    pub fn run(&self) -> Result<String, JsValue> {
        let mut sim = Simulation::new(self.config.clone());

        let result = sim.run()
            .map_err(|e| JsValue::from_str(&format!("Simulation error: {}", e)))?;

        serde_json::to_string_pretty(&result)
            .map_err(|e| JsValue::from_str(&format!("Serialization error: {}", e)))
    }

    /// Get ledger statistics as JSON
    #[wasm_bindgen]
    pub fn get_stats(&self) -> Result<String, JsValue> {
        let mut sim = Simulation::new(self.config.clone());
        let _ = sim.run();

        let stats = sim.ledger_stats();

        serde_json::to_string_pretty(&stats)
            .map_err(|e| JsValue::from_str(&format!("Serialization error: {}", e)))
    }
}

/// WebAssembly-compatible traversal
#[cfg(target_arch = "wasm32")]
#[wasm_bindgen]
pub struct WasmTraversal {
    engine: TraversalEngine,
}

#[cfg(target_arch = "wasm32")]
#[wasm_bindgen]
impl WasmTraversal {
    /// Create a new WASM traversal engine
    #[wasm_bindgen(constructor)]
    pub fn new() -> Self {
        Self {
            engine: TraversalEngine::new(),
        }
    }

    /// Run a single traversal
    #[wasm_bindgen]
    pub fn run_single(&mut self, max_steps: usize, strategy: String) -> Result<String, JsValue> {
        let strat = match strategy.as_str() {
            "gradient" => TraversalStrategy::GradientAscent,
            "stability" => TraversalStrategy::StabilityMaximization,
            "cycle" => TraversalStrategy::CycleRecognition,
            "balanced" => TraversalStrategy::Balanced,
            "random" => TraversalStrategy::RandomWalk,
            _ => TraversalStrategy::Balanced,
        };

        let config = AgentConfig {
            max_steps,
            strategy: strat,
            ..Default::default()
        };

        let artefact = self.engine.run_single(config)
            .map_err(|e| JsValue::from_str(&format!("Traversal error: {}", e)))?;

        serde_json::to_string_pretty(&artefact)
            .map_err(|e| JsValue::from_str(&format!("Serialization error: {}", e)))
    }

    /// Get ledger contents as JSON
    #[wasm_bindgen]
    pub fn get_ledger(&self) -> Result<String, JsValue> {
        let stats = self.engine.ledger().stats();

        serde_json::to_string_pretty(&stats)
            .map_err(|e| JsValue::from_str(&format!("Serialization error: {}", e)))
    }
}

/// Initialize WASM module
#[cfg(target_arch = "wasm32")]
#[wasm_bindgen(start)]
pub fn wasm_init() {
    // Set panic hook for better error messages
    #[cfg(feature = "console_error_panic_hook")]
    console_error_panic_hook::set_once();
}

/// Get MOGE version
#[cfg(target_arch = "wasm32")]
#[wasm_bindgen]
pub fn get_version() -> String {
    crate::VERSION.to_string()
}

/// Create a signature from components
#[cfg(target_arch = "wasm32")]
#[wasm_bindgen]
pub fn create_signature(psi: f64, rho: f64, omega: f64, chi: f64, eta: f64) -> String {
    let sig = Signature5D::new(psi, rho, omega, chi, eta);
    serde_json::to_string(&sig).unwrap_or_else(|_| "{}".to_string())
}

/// Calculate resonance from signature JSON
#[cfg(target_arch = "wasm32")]
#[wasm_bindgen]
pub fn calculate_resonance(signature_json: String) -> Result<f64, JsValue> {
    let sig: Signature5D = serde_json::from_str(&signature_json)
        .map_err(|e| JsValue::from_str(&format!("Parse error: {}", e)))?;

    Ok(sig.resonance())
}

// Non-WASM implementations for native builds
#[cfg(not(target_arch = "wasm32"))]
impl WasmSimulation {
    pub fn new(agent_count: usize, max_steps: usize, generations: usize) -> Self {
        let config = SimulationConfig {
            agent_count,
            max_steps_per_agent: max_steps,
            generations,
            enable_evolution: true,
            mutation_rate: 0.1,
            target_signature: None,
        };

        Self { config }
    }

    pub fn run(&self) -> Result<String, String> {
        let mut sim = Simulation::new(self.config.clone());

        let result = sim.run()
            .map_err(|e| format!("Simulation error: {}", e))?;

        serde_json::to_string_pretty(&result)
            .map_err(|e| format!("Serialization error: {}", e))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_wasm_simulation_creation() {
        let sim = WasmSimulation::new(5, 20, 3);
        assert_eq!(sim.config.agent_count, 5);
        assert_eq!(sim.config.max_steps_per_agent, 20);
        assert_eq!(sim.config.generations, 3);
    }

    #[test]
    fn test_wasm_simulation_run() {
        let sim = WasmSimulation::new(2, 10, 1);
        let result = sim.run();
        assert!(result.is_ok());
    }
}
