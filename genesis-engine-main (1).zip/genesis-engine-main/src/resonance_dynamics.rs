//! Resonance Dynamics - Symplectic Integration Module
//!
//! Implements the Hamiltonian evolution and Double-Kick symplectic integration scheme
//! for resonance-coupled systems in the Reasonate Kernel.
//!
//! Core equations:
//! - Hamiltonian: H(ψ,ρ,ω) = ½(ψ²+ρ²+ω²) + χ·η
//! - Flow: dψ/dt = ∂H/∂ρ; dρ/dt = -∂H/∂ψ; dω/dt = ∂H/∂χ
//! - DoubleKick: Two-step leapfrog integration for resonance-coupled systems

use crate::signature::Signature5D;
use serde::{Deserialize, Serialize};

/// Hamiltonian dynamics configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HamiltonianConfig {
    /// Time step for integration
    pub dt: f64,
    /// Energy conservation threshold
    pub energy_threshold: f64,
    /// Damping factor λ for equilibrium
    pub damping: f64,
}

impl Default for HamiltonianConfig {
    fn default() -> Self {
        Self {
            dt: 0.01,
            energy_threshold: 1e-5,
            damping: 0.95,
        }
    }
}

/// State vector for Hamiltonian evolution
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct HamiltonianState {
    /// Position variables (ψ, ρ, ω)
    pub psi: f64,
    pub rho: f64,
    pub omega: f64,
    /// Momentum variables (conjugate momenta)
    pub p_psi: f64,
    pub p_rho: f64,
    pub p_omega: f64,
    /// Coupling variables
    pub chi: f64,
    pub eta: f64,
}

impl HamiltonianState {
    /// Create from signature
    pub fn from_signature(sig: &Signature5D) -> Self {
        Self {
            psi: sig.psi,
            rho: sig.rho,
            omega: sig.omega,
            p_psi: 0.0,
            p_rho: 0.0,
            p_omega: 0.0,
            chi: sig.chi,
            eta: sig.eta,
        }
    }

    /// Convert to signature
    pub fn to_signature(&self) -> Signature5D {
        Signature5D::new(self.psi, self.rho, self.omega, self.chi, self.eta)
    }
}

/// Compute Hamiltonian energy
///
/// H(ψ,ρ,ω,p_ψ,p_ρ,p_ω,χ,η) = ½(p_ψ²+p_ρ²+p_ω²) + ½(ψ²+ρ²+ω²) + χ·η
pub fn hamiltonian(state: &HamiltonianState) -> f64 {
    let kinetic = 0.5 * (state.p_psi.powi(2) + state.p_rho.powi(2) + state.p_omega.powi(2));
    let potential = 0.5 * (state.psi.powi(2) + state.rho.powi(2) + state.omega.powi(2));
    let coupling = state.chi * state.eta;

    kinetic + potential + coupling
}

/// Symplectic integrator using double-kick scheme
///
/// Update rule:
/// 1. Momentum half-step: p → p + dt/2 * F(q)
/// 2. Position full-step: q → q + dt * p
/// 3. Momentum half-step: p → p + dt/2 * F(q)
pub struct SymplecticIntegrator {
    pub config: HamiltonianConfig,
    pub state: HamiltonianState,
    pub initial_energy: f64,
    pub current_energy: f64,
    pub energy_drift: f64,
}

impl SymplecticIntegrator {
    /// Create new integrator with initial state
    pub fn new(state: HamiltonianState, config: HamiltonianConfig) -> Self {
        let initial_energy = hamiltonian(&state);
        Self {
            config,
            state,
            initial_energy,
            current_energy: initial_energy,
            energy_drift: 0.0,
        }
    }

    /// Perform one integration step using double-kick leapfrog
    pub fn step(&mut self) {
        let dt = self.config.dt;
        let half_dt = dt / 2.0;

        // Forces (negative gradient of potential)
        let force_psi = -self.state.psi;
        let force_rho = -self.state.rho;
        let force_omega = -self.state.omega - self.state.eta; // ∂H/∂ω includes coupling

        // First momentum half-step
        self.state.p_psi += half_dt * force_psi;
        self.state.p_rho += half_dt * force_rho;
        self.state.p_omega += half_dt * force_omega;

        // Position full-step
        self.state.psi += dt * self.state.p_psi;
        self.state.rho += dt * self.state.p_rho;
        self.state.omega += dt * self.state.p_omega;

        // Recompute forces at new position
        let force_psi = -self.state.psi;
        let force_rho = -self.state.rho;
        let force_omega = -self.state.omega - self.state.eta;

        // Second momentum half-step
        self.state.p_psi += half_dt * force_psi;
        self.state.p_rho += half_dt * force_rho;
        self.state.p_omega += half_dt * force_omega;

        // Apply damping for stability
        let lambda = self.config.damping;
        self.state.p_psi *= lambda;
        self.state.p_rho *= lambda;
        self.state.p_omega *= lambda;

        // Update energy tracking
        self.current_energy = hamiltonian(&self.state);
        self.energy_drift = (self.current_energy - self.initial_energy).abs();
    }

    /// Run multiple steps
    pub fn evolve(&mut self, steps: usize) {
        for _ in 0..steps {
            self.step();
        }
    }

    /// Check if energy is conserved within threshold
    pub fn is_energy_conserved(&self) -> bool {
        self.energy_drift < self.config.energy_threshold
    }

    /// Get current signature state
    pub fn get_signature(&self) -> Signature5D {
        self.state.to_signature()
    }

    /// Reset to new state
    pub fn reset(&mut self, state: HamiltonianState) {
        self.state = state;
        self.initial_energy = hamiltonian(&state);
        self.current_energy = self.initial_energy;
        self.energy_drift = 0.0;
    }
}

/// Resonance flow dynamics
///
/// Implements the Hamiltonian flow equations:
/// - dψ/dt = ∂H/∂p_ψ = p_ψ
/// - dp_ψ/dt = -∂H/∂ψ = -ψ
/// (and similarly for ρ, ω)
pub struct ResonanceFlow {
    integrator: SymplecticIntegrator,
    tick_count: usize,
}

impl ResonanceFlow {
    /// Create new resonance flow system
    pub fn new(signature: &Signature5D, config: HamiltonianConfig) -> Self {
        let state = HamiltonianState::from_signature(signature);
        let integrator = SymplecticIntegrator::new(state, config);
        Self {
            integrator,
            tick_count: 0,
        }
    }

    /// Perform one tick of resonance evolution
    pub fn tick(&mut self) -> Signature5D {
        self.integrator.step();
        self.tick_count += 1;
        self.integrator.get_signature()
    }

    /// Get current energy
    pub fn energy(&self) -> f64 {
        self.integrator.current_energy
    }

    /// Get energy drift
    pub fn energy_drift(&self) -> f64 {
        self.integrator.energy_drift
    }

    /// Check symplectic invariance
    pub fn check_invariance(&self) -> bool {
        self.integrator.is_energy_conserved()
    }

    /// Get tick count
    pub fn ticks(&self) -> usize {
        self.tick_count
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_hamiltonian_computation() {
        let state = HamiltonianState {
            psi: 0.5,
            rho: 0.5,
            omega: 0.5,
            p_psi: 0.1,
            p_rho: 0.1,
            p_omega: 0.1,
            chi: 0.3,
            eta: 0.3,
        };

        let h = hamiltonian(&state);
        assert!(h > 0.0);
    }

    #[test]
    fn test_symplectic_integration() {
        let sig = Signature5D::new(0.5, 0.5, 0.5, 0.3, 0.3);
        let state = HamiltonianState::from_signature(&sig);
        let config = HamiltonianConfig::default();

        let mut integrator = SymplecticIntegrator::new(state, config);

        // Run for 100 steps
        integrator.evolve(100);

        // Energy should be conserved (within threshold)
        assert!(integrator.is_energy_conserved());
        assert!(integrator.energy_drift < 1e-3);
    }

    #[test]
    fn test_resonance_flow() {
        let sig = Signature5D::new(0.8, 0.7, 0.6, 0.5, 0.4);
        let config = HamiltonianConfig::default();

        let mut flow = ResonanceFlow::new(&sig, config);

        // Evolve for 10 ticks
        for _ in 0..10 {
            let new_sig = flow.tick();
            assert!(new_sig.psi >= 0.0 && new_sig.psi <= 1.0 || new_sig.psi > 1.0);
        }

        assert_eq!(flow.ticks(), 10);
        assert!(flow.check_invariance());
    }

    #[test]
    fn test_energy_conservation() {
        let sig = Signature5D::new(0.5, 0.5, 0.5, 0.3, 0.3);
        let config = HamiltonianConfig {
            dt: 0.001, // Very small timestep for better conservation
            energy_threshold: 1e-5,
            damping: 1.0, // No damping
        };

        let mut flow = ResonanceFlow::new(&sig, config);

        let initial_energy = flow.energy();

        // Evolve for 1000 steps
        for _ in 0..1000 {
            flow.tick();
        }

        let final_energy = flow.energy();
        let drift = (final_energy - initial_energy).abs();

        // With small timestep and no damping, energy should be well-conserved
        assert!(drift < 1e-4, "Energy drift too large: {}", drift);
    }
}
