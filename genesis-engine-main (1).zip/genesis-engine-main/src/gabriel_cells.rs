//! Gabriel Cells - Resonance Substrate (Phase 2)
//!
//! Protointelligent resonance nodes forming mycelial substrate for operator emergence.
//! Self-organizing clusters explore local operator configurations.

use crate::signature::Signature5D;
use crate::operator::Operator;
use crate::resonance_kernel::resonance;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Gabriel Cell - basic resonance node
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GabrielCell {
    /// Cell identifier
    pub id: usize,
    /// Activity level [0, 1]
    pub activity: f64,
    /// Internal weight/potential
    pub weight: f64,
    /// Feedback accumulator
    pub feedback: f64,
    /// Activation threshold
    pub threshold: f64,
    /// Cell position in signature space
    pub position: Signature5D,
}

impl GabrielCell {
    /// Create new Gabriel Cell
    pub fn new(id: usize, position: Signature5D) -> Self {
        Self {
            id,
            activity: 0.0,
            weight: 0.5,
            feedback: 0.0,
            threshold: 0.5,
            position,
        }
    }

    /// Activation function: a_i(t+1) = f(a_i(t), R(v), Σ g_ij*a_j(t))
    pub fn activate(&mut self, resonance_input: f64, neighbor_sum: f64) {
        let total_input = self.activity + resonance_input + neighbor_sum;

        // Sigmoid activation with threshold
        let activated = 1.0 / (1.0 + (-(total_input - self.threshold)).exp());

        self.activity = activated;
        self.feedback = resonance_input; // Store for Hebbian learning
    }

    /// Check if cell is active
    pub fn is_active(&self) -> bool {
        self.activity > self.threshold
    }

    /// Decay activity over time
    pub fn decay(&mut self, decay_rate: f64) {
        self.activity *= 1.0 - decay_rate;
        if self.activity < 0.01 {
            self.activity = 0.0;
        }
    }
}

/// Edge between Gabriel Cells
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GabrielEdge {
    /// Source cell ID
    pub from: usize,
    /// Target cell ID
    pub to: usize,
    /// Edge weight (connection strength)
    pub weight: f64,
    /// Age of edge (for decay)
    pub age: usize,
}

impl GabrielEdge {
    pub fn new(from: usize, to: usize) -> Self {
        Self {
            from,
            to,
            weight: 0.1, // Initial weak connection
            age: 0,
        }
    }

    /// Hebbian update rule: Δg_ij = α*a_i*a_j - β*g_ij
    pub fn hebbian_update(&mut self, a_i: f64, a_j: f64, alpha: f64, beta: f64) {
        let delta = alpha * a_i * a_j - beta * self.weight;
        self.weight += delta;
        self.weight = self.weight.clamp(0.0, 1.0);
        self.age += 1;
    }

    /// Decay edge weight
    pub fn decay(&mut self, decay_rate: f64) {
        self.weight *= 1.0 - decay_rate;
    }

    /// Check if edge should be pruned
    pub fn should_prune(&self, min_weight: f64) -> bool {
        self.weight < min_weight
    }
}

/// Gabriel Cell Cluster - dynamic graph of cells
#[derive(Debug, Clone)]
pub struct GabrielCluster {
    /// Cells in the cluster
    pub cells: HashMap<usize, GabrielCell>,
    /// Edges between cells
    pub edges: Vec<GabrielEdge>,
    /// Cluster configuration
    pub config: ClusterConfig,
    /// Generation counter
    pub generation: usize,
    /// Next cell ID
    next_id: usize,
}

/// Cluster configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClusterConfig {
    /// Hebbian learning rate (α)
    pub alpha: f64,
    /// Weight decay rate (β)
    pub beta: f64,
    /// Activity decay rate
    pub activity_decay: f64,
    /// Edge decay rate
    pub edge_decay: f64,
    /// Minimum edge weight before pruning
    pub min_edge_weight: f64,
    /// Maximum cluster size
    pub max_size: usize,
}

impl Default for ClusterConfig {
    fn default() -> Self {
        Self {
            alpha: 0.1,
            beta: 0.05,
            activity_decay: 0.02,
            edge_decay: 0.01,
            min_edge_weight: 0.05,
            max_size: 100,
        }
    }
}

impl GabrielCluster {
    /// Create new cluster
    pub fn new(config: ClusterConfig) -> Self {
        Self {
            cells: HashMap::new(),
            edges: Vec::new(),
            config,
            generation: 0,
            next_id: 0,
        }
    }

    /// Add cell to cluster
    pub fn add_cell(&mut self, position: Signature5D) -> usize {
        if self.cells.len() >= self.config.max_size {
            return 0; // Cluster full
        }

        let id = self.next_id;
        self.next_id += 1;

        let cell = GabrielCell::new(id, position);
        self.cells.insert(id, cell);

        // Connect to nearby cells
        self.connect_nearby(id);

        id
    }

    /// Connect cell to nearby cells in signature space
    fn connect_nearby(&mut self, cell_id: usize) {
        if let Some(cell) = self.cells.get(&cell_id) {
            let pos = cell.position;

            // Find nearest neighbors
            let neighbors: Vec<usize> = self.cells.iter()
                .filter(|(id, _)| **id != cell_id)
                .filter(|(_, c)| {
                    let dist = signature_distance(&pos, &c.position);
                    dist < 0.3 // Connection threshold
                })
                .map(|(id, _)| *id)
                .collect();

            // Create edges
            for neighbor_id in neighbors {
                self.edges.push(GabrielEdge::new(cell_id, neighbor_id));
            }
        }
    }

    /// Update cluster for one timestep
    pub fn update(&mut self) {
        self.generation += 1;

        // Calculate resonance inputs for all cells
        let resonance_inputs: HashMap<usize, f64> = self.cells.iter()
            .map(|(id, cell)| (*id, resonance(&cell.position)))
            .collect();

        // Calculate neighbor sums
        let neighbor_sums: HashMap<usize, f64> = self.cells.keys()
            .map(|id| {
                let sum = self.edges.iter()
                    .filter(|e| e.to == *id)
                    .map(|e| {
                        if let Some(source_cell) = self.cells.get(&e.from) {
                            e.weight * source_cell.activity
                        } else {
                            0.0
                        }
                    })
                    .sum();
                (*id, sum)
            })
            .collect();

        // Update all cell activations
        for (id, cell) in self.cells.iter_mut() {
            let res_input = resonance_inputs.get(id).copied().unwrap_or(0.0);
            let neighbor_sum = neighbor_sums.get(id).copied().unwrap_or(0.0);
            cell.activate(res_input, neighbor_sum);
        }

        // Update edge weights (Hebbian learning)
        for edge in self.edges.iter_mut() {
            if let (Some(from_cell), Some(to_cell)) =
                (self.cells.get(&edge.from), self.cells.get(&edge.to))
            {
                edge.hebbian_update(
                    from_cell.activity,
                    to_cell.activity,
                    self.config.alpha,
                    self.config.beta,
                );
            }
        }

        // Decay inactive elements
        for cell in self.cells.values_mut() {
            cell.decay(self.config.activity_decay);
        }

        for edge in self.edges.iter_mut() {
            edge.decay(self.config.edge_decay);
        }

        // Prune weak edges
        self.edges.retain(|e| !e.should_prune(self.config.min_edge_weight));
    }

    /// Find stable subclusters (colonies)
    pub fn find_colonies(&self, _stability_threshold: f64) -> Vec<Vec<usize>> {
        let mut colonies = Vec::new();
        let mut visited = std::collections::HashSet::new();

        for cell_id in self.cells.keys() {
            if visited.contains(cell_id) || !self.is_stable_cell(*cell_id) {
                continue;
            }

            // BFS to find connected stable cells
            let colony = self.bfs_stable_region(*cell_id, &mut visited);

            if !colony.is_empty() {
                colonies.push(colony);
            }
        }

        colonies
    }

    /// Check if cell is stable
    fn is_stable_cell(&self, cell_id: usize) -> bool {
        if let Some(cell) = self.cells.get(&cell_id) {
            // Cell is stable if activity is high and consistent
            cell.activity > 0.7
        } else {
            false
        }
    }

    /// BFS to find stable region
    fn bfs_stable_region(&self, start: usize, visited: &mut std::collections::HashSet<usize>) -> Vec<usize> {
        let mut colony = Vec::new();
        let mut queue = std::collections::VecDeque::new();

        queue.push_back(start);
        visited.insert(start);

        while let Some(cell_id) = queue.pop_front() {
            if !self.is_stable_cell(cell_id) {
                continue;
            }

            colony.push(cell_id);

            // Add connected neighbors
            for edge in &self.edges {
                if edge.from == cell_id {
                    if !visited.contains(&edge.to) && edge.weight > 0.5 {
                        visited.insert(edge.to);
                        queue.push_back(edge.to);
                    }
                }
            }
        }

        colony
    }

    /// Extract operator from stable colony
    pub fn colony_to_operator(&self, colony: &[usize]) -> Option<Operator> {
        if colony.is_empty() {
            return None;
        }

        // Average signature from colony cells
        let mut sig_sum = Signature5D::new(0.0, 0.0, 0.0, 0.0, 0.0);
        let mut count = 0;

        for cell_id in colony {
            if let Some(cell) = self.cells.get(cell_id) {
                sig_sum.psi += cell.position.psi * cell.activity;
                sig_sum.rho += cell.position.rho * cell.activity;
                sig_sum.omega += cell.position.omega * cell.activity;
                sig_sum.chi += cell.position.chi * cell.activity;
                sig_sum.eta += cell.position.eta * cell.activity;
                count += 1;
            }
        }

        if count == 0 {
            return None;
        }

        let n = count as f64;
        sig_sum.psi /= n;
        sig_sum.rho /= n;
        sig_sum.omega /= n;
        sig_sum.chi /= n;
        sig_sum.eta /= n;

        Some(Operator::from_signature(sig_sum))
    }

    /// Get cluster statistics
    pub fn stats(&self) -> ClusterStats {
        let active_cells = self.cells.values().filter(|c| c.is_active()).count();
        let total_activity: f64 = self.cells.values().map(|c| c.activity).sum();
        let avg_activity = if !self.cells.is_empty() {
            total_activity / self.cells.len() as f64
        } else {
            0.0
        };

        let strong_edges = self.edges.iter().filter(|e| e.weight > 0.5).count();

        ClusterStats {
            total_cells: self.cells.len(),
            active_cells,
            avg_activity,
            total_edges: self.edges.len(),
            strong_edges,
            generation: self.generation,
        }
    }
}

/// Cluster statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClusterStats {
    pub total_cells: usize,
    pub active_cells: usize,
    pub avg_activity: f64,
    pub total_edges: usize,
    pub strong_edges: usize,
    pub generation: usize,
}

/// Compute distance between signatures
fn signature_distance(a: &Signature5D, b: &Signature5D) -> f64 {
    (
        (a.psi - b.psi).powi(2) +
        (a.rho - b.rho).powi(2) +
        (a.omega - b.omega).powi(2) +
        (a.chi - b.chi).powi(2) +
        (a.eta - b.eta).powi(2)
    ).sqrt()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_gabriel_cell_creation() {
        let pos = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);
        let cell = GabrielCell::new(0, pos);

        assert_eq!(cell.id, 0);
        assert_eq!(cell.activity, 0.0);
        assert!(!cell.is_active());
    }

    #[test]
    fn test_cell_activation() {
        let pos = Signature5D::new(0.9, 0.8, 0.7, 0.6, 0.5);
        let mut cell = GabrielCell::new(0, pos);

        cell.activate(0.8, 0.3);

        assert!(cell.activity > 0.5);
    }

    #[test]
    fn test_hebbian_learning() {
        let mut edge = GabrielEdge::new(0, 1);
        let initial_weight = edge.weight;

        // Strong co-activation should strengthen edge
        edge.hebbian_update(1.0, 1.0, 0.1, 0.05);

        assert!(edge.weight > initial_weight);
    }

    #[test]
    fn test_cluster_creation() {
        let config = ClusterConfig::default();
        let mut cluster = GabrielCluster::new(config);

        let sig = Signature5D::new(0.8, 0.7, 0.6, 0.5, 0.4);
        let id = cluster.add_cell(sig);

        assert_eq!(cluster.cells.len(), 1);
        assert!(cluster.cells.contains_key(&id));
    }

    #[test]
    fn test_cluster_update() {
        let config = ClusterConfig::default();
        let mut cluster = GabrielCluster::new(config);

        // Add several cells
        for i in 0..5 {
            let sig = Signature5D::new(
                0.5 + i as f64 * 0.05,
                0.5,
                0.5,
                0.5,
                0.5,
            );
            cluster.add_cell(sig);
        }

        // Run updates
        for _ in 0..10 {
            cluster.update();
        }

        let stats = cluster.stats();
        assert_eq!(stats.total_cells, 5);
        assert!(stats.generation == 10);
    }

    #[test]
    fn test_colony_detection() {
        let config = ClusterConfig::default();
        let mut cluster = GabrielCluster::new(config);

        // Add cells in high-resonance region
        for i in 0..5 {
            let sig = Signature5D::new(
                0.9,
                0.8 + i as f64 * 0.01,
                0.7,
                0.6,
                0.3,
            );
            cluster.add_cell(sig);
        }

        // Evolve to form colonies
        for _ in 0..50 {
            cluster.update();
        }

        let _colonies = cluster.find_colonies(0.7);
        // At least some stable structure should form
        assert!(cluster.stats().active_cells > 0);
    }
}
