//! Invariant Crystal Architecture - TIC/MEF/CLIV Implementation
//!
//! This module implements the core Invariant Crystal architecture that provides
//! temporal coherence, recursive self-similarity, and path independence to the
//! MOGE-Reasonate hybrid kernel.
//!
//! ## Components
//!
//! - **TIC** (Temporal Information Crystal): Ensures temporal coherence and path independence
//! - **MEF** (Mandorla Eigenstate Fractal): Recursive self-similarity preservation
//! - **CLIV** (Crystalized Living Information Vector): Unified representation of TIC/MEF state
//!
//! ## Invariance Conditions
//!
//! - Temporal: ∂Ψ/∂t ≈ 0 → ΔΨ < 10⁻⁵
//! - Mandorla: |Ψₙ − Ψₙ₋₁| < 10⁻⁴
//! - Combined: |Δ(ψρω)+χη| < 1e-4

use crate::signature::Signature5D;
use crate::topology_projection::BettiNumbers;
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};
use std::collections::VecDeque;

/// Temporal Information Crystal (TIC)
///
/// Ensures temporal coherence and path independence across evolution cycles.
/// Structure: 64-256 layers with sequential invariant composition ⊗ₖ Bₖ
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TemporalInformationCrystal {
    /// Number of layers in the crystal
    pub num_layers: usize,
    /// Layer compositions (each layer stores operator snapshots)
    pub layers: Vec<TICLayer>,
    /// Current cycle position
    pub current_cycle: usize,
    /// Temporal coherence threshold
    pub coherence_threshold: f64,
}

/// A single layer in the TIC structure
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TICLayer {
    pub layer_id: usize,
    pub cycle: usize,
    pub operator_snapshot: Signature5D,
    pub resonance_field: [f64; 3], // (ψ, ρ, ω) snapshot
    pub invariant_hash: u64,
    pub temporal_delta: f64,
}

impl TemporalInformationCrystal {
    /// Create new TIC with specified number of layers
    pub fn new(num_layers: usize, coherence_threshold: f64) -> Self {
        Self {
            num_layers,
            layers: Vec::new(),
            current_cycle: 0,
            coherence_threshold,
        }
    }

    /// Add a new layer to the crystal
    pub fn add_layer(&mut self, operator: &Signature5D) -> Result<()> {
        if self.layers.len() >= self.num_layers {
            return Err(MogeError::ResonanceViolation(
                "TIC is at maximum capacity".to_string(),
            ));
        }

        let layer = TICLayer {
            layer_id: self.layers.len(),
            cycle: self.current_cycle,
            operator_snapshot: *operator,
            resonance_field: [operator.psi, operator.rho, operator.omega],
            invariant_hash: self.compute_invariant_hash(operator),
            temporal_delta: 0.0,
        };

        self.layers.push(layer);
        Ok(())
    }

    /// Compute invariant hash for operator
    fn compute_invariant_hash(&self, op: &Signature5D) -> u64 {
        // Simple hash based on quantized signature values
        let psi_q = (op.psi * 1000.0) as u64;
        let rho_q = (op.rho * 1000.0) as u64;
        let omega_q = (op.omega * 1000.0) as u64;
        
        psi_q.wrapping_mul(31)
            .wrapping_add(rho_q.wrapping_mul(37))
            .wrapping_add(omega_q.wrapping_mul(41))
    }

    /// Check temporal invariance: ∂Ψ/∂t ≈ 0
    pub fn check_temporal_invariance(&self) -> bool {
        if self.layers.len() < 2 {
            return true;
        }

        let n = self.layers.len();
        let latest = &self.layers[n - 1];
        let previous = &self.layers[n - 2];

        let delta_psi = (latest.operator_snapshot.psi - previous.operator_snapshot.psi).abs();
        let delta_rho = (latest.operator_snapshot.rho - previous.operator_snapshot.rho).abs();
        let delta_omega = (latest.operator_snapshot.omega - previous.operator_snapshot.omega).abs();

        let total_delta = delta_psi + delta_rho + delta_omega;

        total_delta < self.coherence_threshold
    }

    /// Get temporal coherence metric
    pub fn temporal_coherence(&self) -> f64 {
        if self.layers.len() < 2 {
            return 1.0;
        }

        let mut total_delta = 0.0;
        for i in 1..self.layers.len() {
            let curr = &self.layers[i];
            let prev = &self.layers[i - 1];

            let delta = ((curr.operator_snapshot.psi - prev.operator_snapshot.psi).powi(2)
                + (curr.operator_snapshot.rho - prev.operator_snapshot.rho).powi(2)
                + (curr.operator_snapshot.omega - prev.operator_snapshot.omega).powi(2))
                .sqrt();

            total_delta += delta;
        }

        let avg_delta = total_delta / (self.layers.len() - 1) as f64;
        
        // Return coherence as 1 - normalized delta
        (1.0 - avg_delta.min(1.0)).max(0.0)
    }

    /// Advance to next cycle
    pub fn advance_cycle(&mut self) {
        self.current_cycle += 1;
    }

    /// Get stable operator clusters (Proof-of-Resonance)
    pub fn get_stable_clusters(&self, min_stability: f64) -> Vec<Vec<usize>> {
        let mut clusters = Vec::new();
        let mut current_cluster = Vec::new();

        for i in 0..self.layers.len() {
            current_cluster.push(i);

            // Check if we should close this cluster
            if i + 1 < self.layers.len() {
                let delta = self.layer_delta(i, i + 1);
                if delta > min_stability {
                    if !current_cluster.is_empty() {
                        clusters.push(current_cluster.clone());
                        current_cluster.clear();
                    }
                }
            }
        }

        if !current_cluster.is_empty() {
            clusters.push(current_cluster);
        }

        clusters
    }

    /// Compute delta between two layers
    fn layer_delta(&self, idx1: usize, idx2: usize) -> f64 {
        if idx1 >= self.layers.len() || idx2 >= self.layers.len() {
            return f64::MAX;
        }

        let l1 = &self.layers[idx1];
        let l2 = &self.layers[idx2];

        ((l1.operator_snapshot.psi - l2.operator_snapshot.psi).powi(2)
            + (l1.operator_snapshot.rho - l2.operator_snapshot.rho).powi(2)
            + (l1.operator_snapshot.omega - l2.operator_snapshot.omega).powi(2))
            .sqrt()
    }
}

/// Mandorla Eigenstate Fractal (MEF)
///
/// Recursive self-similarity layer preserving local resonance geometry.
/// Depth: 12, Mapping: Ψₙ₊₁ = F(Ψₙ, Ωₙ, χₙ)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MandorlaEigenstateFractal {
    /// Fractal depth
    pub depth: usize,
    /// Fractal layers (nested operator states)
    pub layers: VecDeque<MEFLayer>,
    /// Mandorla condition threshold
    pub mandorla_threshold: f64,
    /// Self-similarity index
    pub self_similarity: f64,
}

/// A single layer in the MEF fractal
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MEFLayer {
    pub depth_level: usize,
    pub operator_state: Signature5D,
    pub resonance_field: f64,
    pub local_chi: f64,
    pub fractal_signature: Vec<f64>,
}

impl MandorlaEigenstateFractal {
    /// Create new MEF with specified depth
    pub fn new(depth: usize, mandorla_threshold: f64) -> Self {
        Self {
            depth,
            layers: VecDeque::new(),
            mandorla_threshold,
            self_similarity: 0.0,
        }
    }

    /// Apply fractal mapping: Ψₙ₊₁ = F(Ψₙ, Ωₙ, χₙ)
    pub fn apply_fractal_mapping(&mut self, current: &Signature5D) -> Signature5D {
        // Fractal transformation preserving self-similarity
        let omega_factor = current.omega;
        let chi_factor = current.chi;

        let new_psi = current.psi * (1.0 + 0.1 * (omega_factor - 0.5));
        let new_rho = current.rho * (1.0 + 0.1 * (chi_factor - 0.5));
        let new_omega = (current.omega + omega_factor * 0.05).min(1.0);

        Signature5D::new(
            new_psi.clamp(0.0, 1.0),
            new_rho.clamp(0.0, 1.0),
            new_omega,
            current.chi,
            current.eta,
        )
    }

    /// Add layer to fractal
    pub fn add_layer(&mut self, operator: &Signature5D) {
        let layer = MEFLayer {
            depth_level: self.layers.len(),
            operator_state: *operator,
            resonance_field: operator.psi * operator.rho * operator.omega,
            local_chi: operator.chi,
            fractal_signature: vec![operator.psi, operator.rho, operator.omega],
        };

        self.layers.push_back(layer);

        // Keep only 'depth' layers
        while self.layers.len() > self.depth {
            self.layers.pop_front();
        }

        // Update self-similarity
        self.update_self_similarity();
    }

    /// Check Mandorla condition: |Ψₙ − Ψₙ₋₁| < 10⁻⁴
    pub fn check_mandorla_condition(&self) -> bool {
        if self.layers.len() < 2 {
            return true;
        }

        let n = self.layers.len();
        let latest = &self.layers[n - 1];
        let previous = &self.layers[n - 2];

        let delta = ((latest.operator_state.psi - previous.operator_state.psi).powi(2)
            + (latest.operator_state.rho - previous.operator_state.rho).powi(2)
            + (latest.operator_state.omega - previous.operator_state.omega).powi(2))
            .sqrt();

        delta < self.mandorla_threshold
    }

    /// Update self-similarity index
    fn update_self_similarity(&mut self) {
        if self.layers.len() < 2 {
            self.self_similarity = 1.0;
            return;
        }

        let mut similarity_sum = 0.0;
        let mut count = 0;

        for i in 1..self.layers.len() {
            let curr = &self.layers[i];
            let prev = &self.layers[i - 1];

            // Compute similarity as inverse of distance
            let distance = ((curr.operator_state.psi - prev.operator_state.psi).powi(2)
                + (curr.operator_state.rho - prev.operator_state.rho).powi(2)
                + (curr.operator_state.omega - prev.operator_state.omega).powi(2))
                .sqrt();

            let similarity = 1.0 / (1.0 + distance);
            similarity_sum += similarity;
            count += 1;
        }

        self.self_similarity = if count > 0 {
            similarity_sum / count as f64
        } else {
            1.0
        };
    }

    /// Get self-similarity index
    pub fn get_self_similarity(&self) -> f64 {
        self.self_similarity
    }

    /// Generate fractal operator archetypes
    pub fn generate_archetypes(&self, count: usize) -> Vec<Signature5D> {
        let mut archetypes = Vec::new();

        if self.layers.is_empty() {
            return archetypes;
        }

        // Use the layers to generate archetypes through interpolation
        for i in 0..count {
            let t = i as f64 / count.max(1) as f64;
            let layer_idx = (t * (self.layers.len() - 1) as f64) as usize;
            let layer_idx = layer_idx.min(self.layers.len() - 1);

            archetypes.push(self.layers[layer_idx].operator_state);
        }

        archetypes
    }
}

/// Crystalized Living Information Vector (CLIV)
///
/// Unified representation of TIC and MEF state as a living operator entity.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CrystalizedLivingInformationVector {
    /// Resonance tensor snapshot (ψρω field)
    pub psi_rho_omega_field: Signature5D,
    /// Topology graph connectivity
    pub topology_graph: Option<BettiNumbers>,
    /// Scalar resonance entropy
    pub entropy_signature: f64,
    /// Mandorla depth (fractal nesting level)
    pub mandorla_depth: usize,
    /// Current TIC cycle position
    pub temporal_layer: usize,
    /// Adaptive flag
    pub is_adaptive: bool,
    /// Self-stabilizing flag
    pub is_self_stabilizing: bool,
    /// Path-invariant flag
    pub is_path_invariant: bool,
    /// Auditability flag
    pub is_auditable: bool,
}

impl CrystalizedLivingInformationVector {
    /// Create new CLIV from TIC and MEF states
    pub fn new(
        operator: Signature5D,
        topology: Option<BettiNumbers>,
        entropy: f64,
        mef_depth: usize,
        tic_cycle: usize,
    ) -> Self {
        Self {
            psi_rho_omega_field: operator,
            topology_graph: topology,
            entropy_signature: entropy,
            mandorla_depth: mef_depth,
            temporal_layer: tic_cycle,
            is_adaptive: true,
            is_self_stabilizing: true,
            is_path_invariant: true,
            is_auditable: true,
        }
    }

    /// Compute combined invariant: |Δ(ψρω)+χη|
    pub fn compute_combined_invariant(&self) -> f64 {
        let psi_rho_omega = self.psi_rho_omega_field.psi
            * self.psi_rho_omega_field.rho
            * self.psi_rho_omega_field.omega;

        let chi_eta = self.psi_rho_omega_field.chi * self.psi_rho_omega_field.eta;

        (psi_rho_omega + chi_eta).abs()
    }

    /// Verify all CLIV properties
    pub fn verify_properties(&self) -> CLIVVerification {
        CLIVVerification {
            adaptive: self.is_adaptive,
            self_stabilizing: self.is_self_stabilizing,
            path_invariant: self.is_path_invariant,
            auditable: self.is_auditable,
            combined_invariant: self.compute_combined_invariant(),
            entropy_stable: self.entropy_signature < 0.1,
        }
    }

    /// Export as JSON for auditability
    pub fn to_json(&self) -> String {
        serde_json::to_string_pretty(self).unwrap_or_else(|_| "{}".to_string())
    }
}

/// CLIV verification result
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CLIVVerification {
    pub adaptive: bool,
    pub self_stabilizing: bool,
    pub path_invariant: bool,
    pub auditable: bool,
    pub combined_invariant: f64,
    pub entropy_stable: bool,
}

impl CLIVVerification {
    /// Check if all properties are valid
    pub fn is_valid(&self) -> bool {
        self.adaptive
            && self.self_stabilizing
            && self.path_invariant
            && self.auditable
            && self.combined_invariant < 1e-4
            && self.entropy_stable
    }
}

/// Invariant Crystal System - Unified TIC/MEF/CLIV interface
#[derive(Debug, Clone)]
pub struct InvariantCrystalSystem {
    pub tic: TemporalInformationCrystal,
    pub mef: MandorlaEigenstateFractal,
    current_cliv: Option<CrystalizedLivingInformationVector>,
}

impl InvariantCrystalSystem {
    /// Create new invariant crystal system
    pub fn new(tic_layers: usize, mef_depth: usize) -> Self {
        Self {
            tic: TemporalInformationCrystal::new(tic_layers, 1e-5),
            mef: MandorlaEigenstateFractal::new(mef_depth, 1e-4),
            current_cliv: None,
        }
    }

    /// Update system with new operator state
    pub fn update(&mut self, operator: &Signature5D, topology: Option<BettiNumbers>) -> Result<()> {
        // Add to TIC
        if self.tic.layers.len() < self.tic.num_layers {
            self.tic.add_layer(operator)?;
        }

        // Add to MEF
        self.mef.add_layer(operator);

        // Compute entropy
        let entropy = self.compute_entropy();

        // Create CLIV
        self.current_cliv = Some(CrystalizedLivingInformationVector::new(
            *operator,
            topology,
            entropy,
            self.mef.layers.len(),
            self.tic.current_cycle,
        ));

        Ok(())
    }

    /// Compute system entropy
    fn compute_entropy(&self) -> f64 {
        let mut entropy = 0.0;

        // Entropy from TIC layers
        for layer in &self.tic.layers {
            let p = layer.operator_snapshot.psi * layer.operator_snapshot.rho * layer.operator_snapshot.omega;
            if p > 0.0 {
                entropy -= p * p.ln();
            }
        }

        // Normalize
        if !self.tic.layers.is_empty() {
            entropy / self.tic.layers.len() as f64
        } else {
            0.0
        }
    }

    /// Check overall invariance
    pub fn check_invariance(&self) -> InvariantCheck {
        InvariantCheck {
            temporal_invariant: self.tic.check_temporal_invariance(),
            mandorla_condition: self.mef.check_mandorla_condition(),
            temporal_coherence: self.tic.temporal_coherence(),
            self_similarity: self.mef.get_self_similarity(),
        }
    }

    /// Get current CLIV state
    pub fn get_cliv(&self) -> Option<&CrystalizedLivingInformationVector> {
        self.current_cliv.as_ref()
    }

    /// Advance to next cycle
    pub fn advance_cycle(&mut self) {
        self.tic.advance_cycle();
    }
}

/// Invariance check result
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InvariantCheck {
    pub temporal_invariant: bool,
    pub mandorla_condition: bool,
    pub temporal_coherence: f64,
    pub self_similarity: f64,
}

impl InvariantCheck {
    /// Check if system meets all invariance requirements
    pub fn is_stable(&self) -> bool {
        self.temporal_invariant
            && self.mandorla_condition
            && self.temporal_coherence > 0.95
            && self.self_similarity > 0.97
    }

    /// Get stability percentage (0.0 to 1.0)
    pub fn stability_score(&self) -> f64 {
        let mut score = 0.0;

        if self.temporal_invariant {
            score += 0.25;
        }

        if self.mandorla_condition {
            score += 0.25;
        }

        score += self.temporal_coherence * 0.25;

        score += self.self_similarity * 0.25;

        score
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tic_creation() {
        let tic = TemporalInformationCrystal::new(64, 1e-5);
        assert_eq!(tic.num_layers, 64);
        assert_eq!(tic.layers.len(), 0);
    }

    #[test]
    fn test_tic_add_layer() {
        let mut tic = TemporalInformationCrystal::new(64, 1e-5);
        let op = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);

        let result = tic.add_layer(&op);
        assert!(result.is_ok());
        assert_eq!(tic.layers.len(), 1);
    }

    #[test]
    fn test_tic_temporal_coherence() {
        let mut tic = TemporalInformationCrystal::new(64, 1e-5);

        // Add similar operators
        for i in 0..5 {
            let op = Signature5D::new(0.5 + i as f64 * 0.001, 0.5, 0.5, 0.5, 0.5);
            tic.add_layer(&op).unwrap();
        }

        let coherence = tic.temporal_coherence();
        assert!(coherence > 0.9);
    }

    #[test]
    fn test_mef_creation() {
        let mef = MandorlaEigenstateFractal::new(12, 1e-4);
        assert_eq!(mef.depth, 12);
        assert_eq!(mef.layers.len(), 0);
    }

    #[test]
    fn test_mef_fractal_mapping() {
        let mut mef = MandorlaEigenstateFractal::new(12, 1e-4);
        let op = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);

        let mapped = mef.apply_fractal_mapping(&op);
        assert!(mapped.psi >= 0.0 && mapped.psi <= 1.0);
        assert!(mapped.rho >= 0.0 && mapped.rho <= 1.0);
    }

    #[test]
    fn test_mef_self_similarity() {
        let mut mef = MandorlaEigenstateFractal::new(12, 1e-4);

        // Add similar operators
        for i in 0..5 {
            let op = Signature5D::new(0.5, 0.5, 0.5 + i as f64 * 0.01, 0.5, 0.5);
            mef.add_layer(&op);
        }

        let similarity = mef.get_self_similarity();
        assert!(similarity > 0.0);
    }

    #[test]
    fn test_cliv_creation() {
        let op = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);
        let cliv = CrystalizedLivingInformationVector::new(op, None, 0.01, 5, 10);

        assert_eq!(cliv.mandorla_depth, 5);
        assert_eq!(cliv.temporal_layer, 10);
        assert!(cliv.is_adaptive);
    }

    #[test]
    fn test_cliv_verification() {
        let op = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);
        let cliv = CrystalizedLivingInformationVector::new(op, None, 0.01, 5, 10);

        let verification = cliv.verify_properties();
        assert!(verification.adaptive);
        assert!(verification.self_stabilizing);
    }

    #[test]
    fn test_invariant_system() {
        let mut system = InvariantCrystalSystem::new(64, 12);
        let op = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);

        let result = system.update(&op, None);
        assert!(result.is_ok());

        let cliv = system.get_cliv();
        assert!(cliv.is_some());
    }

    #[test]
    fn test_invariance_check() {
        let mut system = InvariantCrystalSystem::new(64, 12);

        // Add multiple stable operators
        for _ in 0..10 {
            let op = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);
            system.update(&op, None).unwrap();
        }

        let check = system.check_invariance();
        assert!(check.temporal_invariant);
        assert!(check.mandorla_condition);
    }
}
