//! Evolution Cycle - Time-based Evolution Controller
//!
//! Implements the Wormhole Runner - a time-based evolution controller
//! for resonance cycles.
//!
//! Cycle structure (15 ticks):
//! 1. Resonance update (symplectic flow)
//! 2. Triangulation update
//! 3. Operator evaluation
//! 4. Path traversal
//! 5. Feedback/optimization
//!
//! Synchronizes resonance_dynamics, topology_projection, and optimizer per tick.

use crate::signature::Signature5D;
use crate::resonance_dynamics::{ResonanceFlow, HamiltonianConfig};
use crate::topology_projection::{TopologyProjection, BettiNumbers};
use crate::traversal_graph::{TraversalGraph, TraversalNode, TraversalEdge};
use crate::operator_primitives::OperatorPrimitives;
use crate::error::Result;
use serde::{Deserialize, Serialize};

/// Evolution cycle configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvolutionConfig {
    /// Number of ticks per cycle
    pub ticks_per_cycle: usize,
    /// Hamiltonian configuration
    pub hamiltonian: HamiltonianConfig,
    /// Topology threshold
    pub topology_threshold: f64,
    /// Path exploration depth
    pub path_depth: usize,
}

impl Default for EvolutionConfig {
    fn default() -> Self {
        Self {
            ticks_per_cycle: 15,
            hamiltonian: HamiltonianConfig::default(),
            topology_threshold: 0.2,
            path_depth: 5,
        }
    }
}

/// Evolution cycle state
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CycleState {
    pub cycle_number: usize,
    pub tick_number: usize,
    pub current_signatures: Vec<Signature5D>,
    pub energy: f64,
    pub energy_drift: f64,
    pub betti_numbers: Option<BettiNumbers>,
    pub topological_variance: f64,
}

impl CycleState {
    pub fn new() -> Self {
        Self {
            cycle_number: 0,
            tick_number: 0,
            current_signatures: Vec::new(),
            energy: 0.0,
            energy_drift: 0.0,
            betti_numbers: None,
            topological_variance: 0.0,
        }
    }
}

impl Default for CycleState {
    fn default() -> Self {
        Self::new()
    }
}

/// Evolution cycle orchestrator
pub struct EvolutionCycle {
    pub config: EvolutionConfig,
    pub state: CycleState,
    resonance_flows: Vec<ResonanceFlow>,
    topology: TopologyProjection,
    traversal_graph: TraversalGraph,
    primitives: OperatorPrimitives,
}

impl EvolutionCycle {
    /// Create new evolution cycle
    pub fn new(config: EvolutionConfig, initial_signatures: Vec<Signature5D>) -> Self {
        // Initialize resonance flows for each signature
        let resonance_flows: Vec<ResonanceFlow> = initial_signatures
            .iter()
            .map(|sig| ResonanceFlow::new(sig, config.hamiltonian.clone()))
            .collect();

        let topology = TopologyProjection::new(config.topology_threshold);
        let traversal_graph = TraversalGraph::new();
        let primitives = OperatorPrimitives::new();

        let mut state = CycleState::new();
        state.current_signatures = initial_signatures;

        Self {
            config,
            state,
            resonance_flows,
            topology,
            traversal_graph,
            primitives,
        }
    }

    /// Execute one complete evolution cycle (15 ticks)
    pub fn run_cycle(&mut self) -> Result<CycleState> {
        for _ in 0..self.config.ticks_per_cycle {
            self.tick()?;
        }

        self.state.cycle_number += 1;
        Ok(self.state.clone())
    }

    /// Execute one tick of the evolution cycle
    pub fn tick(&mut self) -> Result<()> {
        // Step 1: Resonance update (symplectic flow)
        self.update_resonance();

        // Step 2: Triangulation update
        self.update_triangulation();

        // Step 3: Operator evaluation
        self.evaluate_operators();

        // Step 4: Path traversal
        self.explore_paths();

        // Step 5: Feedback/optimization
        self.apply_feedback();

        self.state.tick_number += 1;

        Ok(())
    }

    /// Step 1: Update resonance using symplectic flow
    fn update_resonance(&mut self) {
        let mut total_energy = 0.0;
        let mut total_drift = 0.0;

        for (i, flow) in self.resonance_flows.iter_mut().enumerate() {
            let new_sig = flow.tick();
            self.state.current_signatures[i] = new_sig;

            total_energy += flow.energy();
            total_drift += flow.energy_drift();
        }

        self.state.energy = total_energy / self.resonance_flows.len() as f64;
        self.state.energy_drift = total_drift / self.resonance_flows.len() as f64;
    }

    /// Step 2: Update topological triangulation
    fn update_triangulation(&mut self) {
        self.topology.build_from_signatures(&self.state.current_signatures);

        if let Some(betti) = self.topology.get_betti_numbers() {
            // Compute topological variance
            let variance = if let Some(prev_betti) = &self.state.betti_numbers {
                let delta_0 = (betti.beta_0 as f64 - prev_betti.beta_0 as f64).abs();
                let delta_1 = (betti.beta_1 as f64 - prev_betti.beta_1 as f64).abs();
                let delta_2 = (betti.beta_2 as f64 - prev_betti.beta_2 as f64).abs();
                (delta_0 + delta_1 + delta_2) / 3.0
            } else {
                0.0
            };

            self.state.topological_variance = variance;
            self.state.betti_numbers = Some(betti);
        }
    }

    /// Step 3: Evaluate operators using primitives
    fn evaluate_operators(&mut self) {
        // Apply sweep operator to signatures with high variance
        for sig in &mut self.state.current_signatures {
            let gradient = (sig.psi - sig.rho).abs();
            if gradient > 0.1 {
                *sig = self.primitives.sweep.apply(sig);
            }
        }
    }

    /// Step 4: Explore paths in operator manifold
    fn explore_paths(&mut self) {
        // Rebuild traversal graph from current signatures
        self.traversal_graph = TraversalGraph::new();

        for (i, sig) in self.state.current_signatures.iter().enumerate() {
            let node = TraversalNode::new(i, *sig);
            self.traversal_graph.add_node(node);
        }

        // Add edges between nearby signatures
        for i in 0..self.state.current_signatures.len() {
            for j in (i + 1)..self.state.current_signatures.len() {
                let sig_i = &self.state.current_signatures[i];
                let sig_j = &self.state.current_signatures[j];

                // Compute distance
                let dist = ((sig_i.psi - sig_j.psi).powi(2)
                    + (sig_i.rho - sig_j.rho).powi(2)
                    + (sig_i.omega - sig_j.omega).powi(2))
                    .sqrt();

                if dist < self.config.topology_threshold {
                    let delta = Signature5D::new(
                        sig_j.psi - sig_i.psi,
                        sig_j.rho - sig_i.rho,
                        sig_j.omega - sig_i.omega,
                        sig_j.chi - sig_i.chi,
                        sig_j.eta - sig_i.eta,
                    );

                    self.traversal_graph.add_edge(TraversalEdge {
                        from: i,
                        to: j,
                        weight: dist,
                        signature_delta: delta,
                    });
                }
            }
        }
    }

    /// Step 5: Apply feedback and optimization
    fn apply_feedback(&mut self) {
        // Check path invariance and apply corrections
        for sig in &mut self.state.current_signatures {
            // Ensure signatures stay in valid range
            *sig = Signature5D::new(
                sig.psi.clamp(0.0, 1.0),
                sig.rho.clamp(0.0, 1.0),
                sig.omega.clamp(0.0, 1.0),
                sig.chi.clamp(0.0, 1.0),
                sig.eta.clamp(0.0, 1.0),
            );
        }
    }

    /// Get current cycle state
    pub fn get_state(&self) -> &CycleState {
        &self.state
    }

    /// Check if system has reached equilibrium
    pub fn is_at_equilibrium(&self) -> bool {
        // System is at equilibrium if:
        // 1. Energy drift is small
        // 2. Topological variance is small
        self.state.energy_drift < 1e-4 && self.state.topological_variance < 1e-3
    }

    /// Get current signatures
    pub fn get_signatures(&self) -> &[Signature5D] {
        &self.state.current_signatures
    }

    /// Get topology map
    pub fn get_topology(&self) -> &TopologyProjection {
        &self.topology
    }

    /// Get traversal graph
    pub fn get_traversal_graph(&self) -> &TraversalGraph {
        &self.traversal_graph
    }
}

/// Evolution statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvolutionStats {
    pub total_cycles: usize,
    pub total_ticks: usize,
    pub equilibrium_cycles: usize,
    pub avg_energy_drift: f64,
    pub avg_topological_variance: f64,
}

impl EvolutionStats {
    pub fn new() -> Self {
        Self {
            total_cycles: 0,
            total_ticks: 0,
            equilibrium_cycles: 0,
            avg_energy_drift: 0.0,
            avg_topological_variance: 0.0,
        }
    }

    /// Update with cycle state
    pub fn update(&mut self, state: &CycleState, at_equilibrium: bool) {
        self.total_cycles += 1;
        self.total_ticks += state.tick_number;
        if at_equilibrium {
            self.equilibrium_cycles += 1;
        }

        // Running average
        let alpha = 0.1; // Smoothing factor
        self.avg_energy_drift = (1.0 - alpha) * self.avg_energy_drift + alpha * state.energy_drift;
        self.avg_topological_variance =
            (1.0 - alpha) * self.avg_topological_variance + alpha * state.topological_variance;
    }

    /// Get equilibrium rate
    pub fn equilibrium_rate(&self) -> f64 {
        if self.total_cycles == 0 {
            0.0
        } else {
            self.equilibrium_cycles as f64 / self.total_cycles as f64
        }
    }
}

impl Default for EvolutionStats {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_evolution_cycle_creation() {
        let signatures = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
            Signature5D::new(0.6, 0.6, 0.6, 0.6, 0.6),
        ];

        let config = EvolutionConfig::default();
        let cycle = EvolutionCycle::new(config, signatures);

        assert_eq!(cycle.state.current_signatures.len(), 2);
    }

    #[test]
    fn test_single_tick() {
        let signatures = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
        ];

        let config = EvolutionConfig::default();
        let mut cycle = EvolutionCycle::new(config, signatures);

        let result = cycle.tick();
        assert!(result.is_ok());
        assert_eq!(cycle.state.tick_number, 1);
    }

    #[test]
    fn test_complete_cycle() {
        let signatures = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
            Signature5D::new(0.6, 0.6, 0.6, 0.6, 0.6),
        ];

        let config = EvolutionConfig::default();
        let mut cycle = EvolutionCycle::new(config, signatures);

        let result = cycle.run_cycle();
        assert!(result.is_ok());
        assert_eq!(cycle.state.cycle_number, 1);
        assert_eq!(cycle.state.tick_number, 15);
    }

    #[test]
    fn test_equilibrium_check() {
        let signatures = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
        ];

        let config = EvolutionConfig::default();
        let cycle = EvolutionCycle::new(config, signatures);

        // Initially should not be at equilibrium (no data yet)
        let at_eq = cycle.is_at_equilibrium();
        assert!(!at_eq || at_eq); // Just check it doesn't panic
    }

    #[test]
    fn test_evolution_stats() {
        let mut stats = EvolutionStats::new();

        let mut state = CycleState::new();
        state.energy_drift = 0.001;
        state.topological_variance = 0.0005;

        stats.update(&state, true);

        assert_eq!(stats.total_cycles, 1);
        assert_eq!(stats.equilibrium_cycles, 1);
        assert!(stats.equilibrium_rate() > 0.9);
    }

    #[test]
    fn test_multiple_cycles() {
        let signatures = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
            Signature5D::new(0.6, 0.4, 0.5, 0.5, 0.5),
        ];

        let config = EvolutionConfig {
            ticks_per_cycle: 5,
            ..Default::default()
        };

        let mut cycle = EvolutionCycle::new(config, signatures);
        let mut stats = EvolutionStats::new();

        // Run 3 cycles
        for _ in 0..3 {
            let state = cycle.run_cycle().unwrap();
            let at_eq = cycle.is_at_equilibrium();
            stats.update(&state, at_eq);
        }

        assert_eq!(stats.total_cycles, 3);
        assert_eq!(cycle.state.cycle_number, 3);
    }
}
