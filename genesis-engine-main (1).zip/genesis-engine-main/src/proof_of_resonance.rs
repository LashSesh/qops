//! Proof-of-Resonance (PoR) Module
//!
//! Implements the mining protocol for validating and committing operators
//! using Gradient Resonance Descent (GRD) over ψρω-space.

use serde::{Deserialize, Serialize};
use chrono::{DateTime, Utc};
use sha2::{Sha512, Digest};
use crate::signature::{Signature, Signature5D};
use crate::error::Result;

/// Proof-of-Resonance ledger entry
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProofOfResonanceEntry {
    /// Unique entry ID
    pub id: String,
    
    /// Operator tensor data (ψρω)
    pub operator_tensor: OperatorTensorData,
    
    /// Topology signature (Betti numbers)
    pub topology_signature: TopologySignatureData,
    
    /// Entropy curve over time
    pub entropy_curve: Vec<f64>,
    
    /// Mandorla condition satisfied
    pub mandorla_condition: bool,
    
    /// Proof hash (SHA512)
    pub proof_hash: String,
    
    /// Timestamp of proof
    pub timestamp: DateTime<Utc>,
    
    /// Number of validation cycles
    pub validation_cycles: usize,
}

/// Operator tensor data
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorTensorData {
    pub psi: f64,
    pub rho: f64,
    pub omega: f64,
    pub chi: f64,
    pub eta: f64,
    pub energy: f64,
}

/// Topology signature data
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TopologySignatureData {
    pub betti_0: usize,
    pub betti_1: usize,
    pub betti_2: usize,
    pub symmetry_class: String,
}

/// Gradient Resonance Descent (GRD) miner
pub struct GradientResonanceDescent {
    /// Learning rate for gradient descent
    alpha: f64,
    
    /// Maximum iterations
    max_iterations: usize,
    
    /// Convergence threshold
    epsilon: f64,
    
    /// Resonance history
    resonance_history: Vec<f64>,
}

impl GradientResonanceDescent {
    /// Create a new GRD miner
    pub fn new(alpha: f64, max_iterations: usize, epsilon: f64) -> Self {
        Self {
            alpha,
            max_iterations,
            epsilon,
            resonance_history: Vec::new(),
        }
    }

    /// Mine an operator using gradient resonance descent
    /// Search over ψρω-space to find stable resonant operators
    pub fn mine(&mut self, initial_sig: Signature5D) -> Result<Signature5D> {
        let mut current = initial_sig;
        self.resonance_history.clear();
        
        for iteration in 0..self.max_iterations {
            let resonance = self.compute_resonance(&current);
            self.resonance_history.push(resonance);
            
            // Compute gradient
            let gradient = self.compute_gradient(&current);
            
            // Update signature using gradient ascent (maximize resonance)
            let next = Self::apply_gradient_step(&current, &gradient, self.alpha);
            
            // Check convergence
            let delta = current.distance(&next);
            if delta < self.epsilon {
                // Converged
                return Ok(next);
            }
            
            current = next;
            
            // Safety check: ensure we're making progress
            if iteration > 10 {
                let recent_change = (self.resonance_history[iteration] 
                    - self.resonance_history[iteration - 10]).abs();
                if recent_change < self.epsilon * 0.1 {
                    // Stuck in local optimum
                    break;
                }
            }
        }
        
        Ok(current)
    }

    /// Compute resonance field value at a signature point
    fn compute_resonance(&self, sig: &Signature5D) -> f64 {
        // Resonance is combination of spectral quality, consistency, and coherence
        // Plus topological and fluctuation components
        let base = sig.psi() * sig.rho() * sig.omega();
        let extended = sig.chi() * sig.eta();
        
        // Weighted combination
        0.6 * base + 0.4 * extended
    }

    /// Compute gradient of resonance field
    fn compute_gradient(&self, sig: &Signature5D) -> Signature5D {
        let h = 1e-6; // Small step for numerical gradient
        
        // Cache base resonance to avoid redundant computation
        let base_resonance = self.compute_resonance(sig);
        
        // Compute partial derivatives using finite differences
        let d_psi = (self.compute_resonance(&Signature5D::new(
            sig.psi() + h, sig.rho(), sig.omega(), sig.chi(), sig.eta()
        )) - base_resonance) / h;
        
        let d_rho = (self.compute_resonance(&Signature5D::new(
            sig.psi(), sig.rho() + h, sig.omega(), sig.chi(), sig.eta()
        )) - base_resonance) / h;
        
        let d_omega = (self.compute_resonance(&Signature5D::new(
            sig.psi(), sig.rho(), sig.omega() + h, sig.chi(), sig.eta()
        )) - base_resonance) / h;
        
        let d_chi = (self.compute_resonance(&Signature5D::new(
            sig.psi(), sig.rho(), sig.omega(), sig.chi() + h, sig.eta()
        )) - base_resonance) / h;
        
        let d_eta = (self.compute_resonance(&Signature5D::new(
            sig.psi(), sig.rho(), sig.omega(), sig.chi(), sig.eta() + h
        )) - base_resonance) / h;
        
        Signature5D::new(d_psi, d_rho, d_omega, d_chi, d_eta)
    }

    /// Apply gradient step with clamping to [0, 1]
    fn apply_gradient_step(current: &Signature5D, gradient: &Signature5D, alpha: f64) -> Signature5D {
        let psi = (current.psi + alpha * gradient.psi).clamp(0.0, 1.0);
        let rho = (current.rho + alpha * gradient.rho).clamp(0.0, 1.0);
        let omega = (current.omega + alpha * gradient.omega).clamp(0.0, 1.0);
        let chi = (current.chi + alpha * gradient.chi).clamp(0.0, 1.0);
        let eta = (current.eta + alpha * gradient.eta).clamp(0.0, 1.0);
        
        Signature5D::new(psi, rho, omega, chi, eta)
    }

    /// Get resonance history
    pub fn get_history(&self) -> &[f64] {
        &self.resonance_history
    }
}

/// Proof-of-Resonance validator
pub struct ProofOfResonanceValidator {
    /// Minimum cycles for validation
    min_cycles: usize,
    
    /// Stability threshold (fraction of stable cycles)
    stability_threshold: f64,

    /// Energy drift tolerance
    _energy_tolerance: f64,

    /// Entropy decay tolerance
    entropy_tolerance: f64,
}

impl ProofOfResonanceValidator {
    /// Create a new PoR validator
    pub fn new() -> Self {
        Self {
            min_cycles: 100,
            stability_threshold: 0.95,
            _energy_tolerance: 1e-5,
            entropy_tolerance: 1e-3,
        }
    }

    /// Validate an operator for Proof-of-Resonance
    pub fn validate(&self, signature: &Signature5D, entropy_curve: &[f64]) -> Result<bool> {
        if entropy_curve.len() < self.min_cycles {
            return Ok(false);
        }
        
        // Check stability: at least 95% of cycles must have stable invariants
        let stable_count = self.count_stable_cycles(signature, entropy_curve);
        let stability_rate = stable_count as f64 / entropy_curve.len() as f64;
        
        if stability_rate < self.stability_threshold {
            return Ok(false);
        }
        
        // Check monotonic entropy decay
        if !self.is_entropy_decreasing(entropy_curve) {
            return Ok(false);
        }
        
        // Check energy conservation (simplified)
        let energy = signature.psi() * signature.rho() * signature.omega();
        if energy < 0.1 {
            // Too low energy
            return Ok(false);
        }
        
        Ok(true)
    }

    /// Count stable cycles (simplified: check if entropy change is small)
    fn count_stable_cycles(&self, _signature: &Signature5D, entropy_curve: &[f64]) -> usize {
        let mut stable = 0;
        for i in 1..entropy_curve.len() {
            let delta = (entropy_curve[i] - entropy_curve[i-1]).abs();
            if delta < self.entropy_tolerance {
                stable += 1;
            }
        }
        stable
    }

    /// Check if entropy is generally decreasing (with some tolerance for fluctuations)
    fn is_entropy_decreasing(&self, entropy_curve: &[f64]) -> bool {
        if entropy_curve.len() < 2 {
            return true;
        }
        
        // Check overall trend: last value should be less than first
        let first = entropy_curve.first().unwrap();
        let last = entropy_curve.last().unwrap();
        
        last <= first
    }

    /// Create a proof-of-resonance entry
    pub fn create_proof_entry(
        &self,
        signature: &Signature5D,
        entropy_curve: Vec<f64>,
        validation_cycles: usize,
        mandorla_certified: bool,
    ) -> ProofOfResonanceEntry {
        let id = uuid::Uuid::new_v4().to_string();
        
        let operator_tensor = OperatorTensorData {
            psi: signature.psi(),
            rho: signature.rho(),
            omega: signature.omega(),
            chi: signature.chi(),
            eta: signature.eta(),
            energy: signature.psi() * signature.rho() * signature.omega(),
        };
        
        let topology_signature = TopologySignatureData {
            betti_0: 1,
            betti_1: 0,
            betti_2: 0,
            symmetry_class: "S7".to_string(),
        };
        
        // Compute SHA512 proof hash
        let mut hasher = Sha512::new();
        hasher.update(id.as_bytes());
        hasher.update(&signature.psi.to_le_bytes());
        hasher.update(&signature.rho.to_le_bytes());
        hasher.update(&signature.omega.to_le_bytes());
        let hash_bytes = hasher.finalize();
        let proof_hash = format!("{:x}", hash_bytes);
        
        ProofOfResonanceEntry {
            id,
            operator_tensor,
            topology_signature,
            entropy_curve,
            mandorla_condition: mandorla_certified,
            proof_hash,
            timestamp: Utc::now(),
            validation_cycles,
        }
    }
}

impl Default for ProofOfResonanceValidator {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::signature::Signature;

    #[test]
    fn test_grd_mining() {
        let mut miner = GradientResonanceDescent::new(0.1, 100, 1e-4);
        let initial: Signature5D = Signature::new();
        
        let result = miner.mine(initial).unwrap();
        
        // Result should be valid
        assert!(result.psi() >= 0.0 && result.psi() <= 1.0);
        assert!(result.rho() >= 0.0 && result.rho() <= 1.0);
        
        // Should have history
        assert!(miner.get_history().len() > 0);
    }

    #[test]
    fn test_resonance_computation() {
        let miner = GradientResonanceDescent::new(0.1, 100, 1e-4);
        let sig = Signature5D::new(0.8, 0.8, 0.8, 0.8, 0.8);
        
        let resonance = miner.compute_resonance(&sig);
        assert!(resonance > 0.0);
        assert!(resonance <= 1.0);
    }

    #[test]
    fn test_validator_accepts_stable_operator() {
        let validator = ProofOfResonanceValidator::new();
        let sig = Signature5D::new(0.9, 0.9, 0.9, 0.9, 0.9);
        
        // Create decreasing entropy curve with small steps (stable)
        let mut entropy_curve = vec![];
        for i in 0..150 {
            // Small decreases: 1e-4 per step, well below 1e-3 tolerance
            entropy_curve.push(1.0 - (i as f64 * 1e-4));
        }
        
        let is_valid = validator.validate(&sig, &entropy_curve).unwrap();
        assert!(is_valid);
    }

    #[test]
    fn test_validator_rejects_unstable_operator() {
        let validator = ProofOfResonanceValidator::new();
        let sig = Signature5D::new(0.1, 0.1, 0.1, 0.1, 0.1); // Low energy
        
        // Create random entropy curve (unstable)
        let entropy_curve = vec![0.5; 50]; // Too few cycles
        
        let is_valid = validator.validate(&sig, &entropy_curve).unwrap();
        assert!(!is_valid);
    }

    #[test]
    fn test_create_proof_entry() {
        let validator = ProofOfResonanceValidator::new();
        let sig = Signature5D::new(0.8, 0.8, 0.8, 0.8, 0.8);
        let entropy_curve = vec![1.0, 0.9, 0.8, 0.7, 0.6];
        
        let entry = validator.create_proof_entry(&sig, entropy_curve.clone(), 100, true);
        
        assert_eq!(entry.validation_cycles, 100);
        assert_eq!(entry.mandorla_condition, true);
        assert_eq!(entry.entropy_curve, entropy_curve);
        assert!(!entry.proof_hash.is_empty());
    }
}
