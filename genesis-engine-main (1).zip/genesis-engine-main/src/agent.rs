//! Agent Module
//!
//! Agents traverse the MetatronCube graph using heuristics to discover
//! and evolve operators. Agent behavior is based on:
//! - Local resonance perception
//! - Global field coherence
//! - Adaptive heuristics that evolve over time
//!
//! ## Traversal Strategies
//! - Gradient Search: Prioritize directions with increasing ψ
//! - Stability Maximization: Favor paths with high ω
//! - Cycle Recognition: Close self-similar paths

use crate::signature::Signature;
use crate::graph::{MetatronCube, EdgeData};
use crate::artefact::Artefact;
use crate::kernel::ResonanceKernel;
use crate::error::{Result, MogeError};
use petgraph::graph::NodeIndex;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

/// Agent traversal strategy
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TraversalStrategy {
    /// Prioritize increasing spectral quality (ψ)
    GradientAscent,
    /// Maximize structural coherence (ω)
    StabilityMaximization,
    /// Seek self-similar cycle patterns
    CycleRecognition,
    /// Balanced exploration
    Balanced,
    /// Random walk
    Random,
}

/// Agent configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentConfig {
    /// Traversal strategy
    pub strategy: TraversalStrategy,
    /// Maximum traversal steps
    pub max_steps: usize,
    /// Exploration temperature (higher = more random)
    pub temperature: f64,
    /// Enable adaptive learning
    pub adaptive: bool,
    /// Reentry threshold (for returning to promising nodes)
    pub reentry_threshold: f64,
}

impl Default for AgentConfig {
    fn default() -> Self {
        Self {
            strategy: TraversalStrategy::Balanced,
            max_steps: 100,
            temperature: 0.1,
            adaptive: true,
            reentry_threshold: 0.85,
        }
    }
}

/// Agent state during traversal
#[derive(Debug, Clone)]
pub struct AgentState {
    /// Current position in the graph
    pub position: NodeIndex,
    /// Steps taken so far
    pub steps: usize,
    /// Best resonance found
    pub best_resonance: f64,
    /// Best node found
    pub best_node: Option<NodeIndex>,
    /// Internal adaptation parameter
    pub adaptation: f64,
}

/// An agent that traverses the MetatronCube
pub struct Agent {
    /// Unique agent ID
    pub id: Uuid,
    /// Configuration
    config: AgentConfig,
    /// Current state
    state: AgentState,
    /// Artefact being constructed
    artefact: Option<Artefact>,
    /// Resonance kernel for validation
    kernel: ResonanceKernel,
}

impl Agent {
    /// Create a new agent at a starting position
    pub fn new(start_node: NodeIndex) -> Self {
        Self::with_config(start_node, AgentConfig::default())
    }

    /// Create agent with custom configuration
    pub fn with_config(start_node: NodeIndex, config: AgentConfig) -> Self {
        Self {
            id: Uuid::new_v4(),
            config,
            state: AgentState {
                position: start_node,
                steps: 0,
                best_resonance: 0.0,
                best_node: None,
                adaptation: 1.0,
            },
            artefact: None,
            kernel: ResonanceKernel::new(),
        }
    }

    /// Begin traversal from current position
    pub fn traverse(&mut self, cube: &MetatronCube) -> Result<Artefact> {
        // Initialize artefact at starting position
        let start_node_data = cube.get_node(self.state.position)
            .ok_or_else(|| MogeError::NodeNotFound(0))?;

        let start_signature = start_node_data.base_signature;
        self.artefact = Some(Artefact::new(
            start_node_data.id,
            start_signature
        ));

        // Traversal loop
        while self.state.steps < self.config.max_steps {
            // Get current node
            let current_node = cube.get_node(self.state.position)
                .ok_or_else(|| MogeError::NodeNotFound(self.state.steps))?;

            // Update best found
            let current_resonance = current_node.base_signature.resonance();
            if current_resonance > self.state.best_resonance {
                self.state.best_resonance = current_resonance;
                self.state.best_node = Some(self.state.position);
            }

            // Get neighbors
            let neighbors = cube.get_neighbors(self.state.position);
            if neighbors.is_empty() {
                break; // No more moves
            }

            // Select next node based on strategy
            let next = self.select_next_node(cube, &neighbors)?;

            // Validate transition with kernel
            let next_node_data = cube.get_node(next)
                .ok_or_else(|| MogeError::NodeNotFound(self.state.steps))?;

            let next_signature = next_node_data.base_signature;

            // Record transformation
            if let Some(ref mut artefact) = self.artefact {
                self.kernel.validate_transformation(
                    &artefact.signature,
                    &next_signature
                )?;

                artefact.record_transformation(
                    current_node.id,
                    next_node_data.id,
                    format!("{:?}", self.config.strategy),
                    next_signature
                );
            }

            // Move to next node
            self.state.position = next;
            self.state.steps += 1;

            // Adaptive learning
            if self.config.adaptive {
                self.adapt();
            }

            // Check for reentry condition
            if current_resonance > self.config.reentry_threshold {
                // High resonance found - consider stopping
                if let Some(best) = self.state.best_node {
                    if best == self.state.position {
                        break; // Returned to best node
                    }
                }
            }
        }

        // Finalize artefact
        let mut final_artefact = self.artefact.take()
            .ok_or_else(|| MogeError::AgentError("No artefact produced".to_string()))?;

        // Check Mandorla certification
        final_artefact.check_mandorla_certification(self.kernel.config().mandorla_threshold);

        Ok(final_artefact)
    }

    /// Select next node based on strategy
    fn select_next_node(
        &self,
        cube: &MetatronCube,
        neighbors: &[(NodeIndex, &EdgeData)]
    ) -> Result<NodeIndex> {
        match self.config.strategy {
            TraversalStrategy::GradientAscent => {
                self.select_gradient_ascent(cube, neighbors)
            },
            TraversalStrategy::StabilityMaximization => {
                self.select_stability_max(cube, neighbors)
            },
            TraversalStrategy::CycleRecognition => {
                self.select_cycle_recognition(cube, neighbors)
            },
            TraversalStrategy::Balanced => {
                self.select_balanced(cube, neighbors)
            },
            TraversalStrategy::Random => {
                self.select_random(neighbors)
            },
        }
    }

    /// Gradient ascent: select neighbor with highest ψ
    fn select_gradient_ascent(
        &self,
        cube: &MetatronCube,
        neighbors: &[(NodeIndex, &EdgeData)]
    ) -> Result<NodeIndex> {
        neighbors.iter()
            .max_by(|(a, _), (b, _)| {
                let sig_a = cube.get_node(*a).unwrap().base_signature.psi();
                let sig_b = cube.get_node(*b).unwrap().base_signature.psi();
                sig_a.partial_cmp(&sig_b).unwrap()
            })
            .map(|(idx, _)| *idx)
            .ok_or_else(|| MogeError::InvalidTraversal("No valid neighbor found".to_string()))
    }

    /// Stability maximization: select neighbor with highest ω
    fn select_stability_max(
        &self,
        cube: &MetatronCube,
        neighbors: &[(NodeIndex, &EdgeData)]
    ) -> Result<NodeIndex> {
        neighbors.iter()
            .max_by(|(a, _), (b, _)| {
                let sig_a = cube.get_node(*a).unwrap().base_signature.omega();
                let sig_b = cube.get_node(*b).unwrap().base_signature.omega();
                sig_a.partial_cmp(&sig_b).unwrap()
            })
            .map(|(idx, _)| *idx)
            .ok_or_else(|| MogeError::InvalidTraversal("No valid neighbor found".to_string()))
    }

    /// Cycle recognition: favor nodes that might close a cycle
    fn select_cycle_recognition(
        &self,
        cube: &MetatronCube,
        neighbors: &[(NodeIndex, &EdgeData)]
    ) -> Result<NodeIndex> {
        // Check if any neighbor connects back to visited nodes
        if let Some(ref artefact) = self.artefact {
            let path = artefact.get_path();
            for (idx, _) in neighbors {
                let node_id = cube.get_node(*idx).unwrap().id;
                if path.contains(&node_id) {
                    return Ok(*idx); // Close the cycle
                }
            }
        }

        // Otherwise, use balanced strategy
        self.select_balanced(cube, neighbors)
    }

    /// Balanced: weighted combination of all metrics
    fn select_balanced(
        &self,
        cube: &MetatronCube,
        neighbors: &[(NodeIndex, &EdgeData)]
    ) -> Result<NodeIndex> {
        neighbors.iter()
            .max_by(|(a, _), (b, _)| {
                let score_a = cube.get_node(*a).unwrap().base_signature.resonance() * self.state.adaptation;
                let score_b = cube.get_node(*b).unwrap().base_signature.resonance() * self.state.adaptation;
                score_a.partial_cmp(&score_b).unwrap()
            })
            .map(|(idx, _)| *idx)
            .ok_or_else(|| MogeError::InvalidTraversal("No valid neighbor found".to_string()))
    }

    /// Random: uniform random selection
    fn select_random(&self, neighbors: &[(NodeIndex, &EdgeData)]) -> Result<NodeIndex> {
        use rand::seq::SliceRandom;
        neighbors.choose(&mut rand::thread_rng())
            .map(|(idx, _)| *idx)
            .ok_or_else(|| MogeError::InvalidTraversal("No neighbors available".to_string()))
    }

    /// Adapt internal parameters based on performance
    fn adapt(&mut self) {
        let progress = self.state.steps as f64 / self.config.max_steps as f64;

        // Gradually reduce exploration (temperature annealing)
        let annealing = 1.0 - progress;
        self.state.adaptation = annealing * self.config.temperature + (1.0 - self.config.temperature);
    }

    /// Get current state
    pub fn state(&self) -> &AgentState {
        &self.state
    }

    /// Get configuration
    pub fn config(&self) -> &AgentConfig {
        &self.config
    }

    /// Get current node index
    pub fn current_node(&self) -> NodeIndex {
        self.state.position
    }

    /// Reset agent to new starting position
    pub fn reset(&mut self, start_node: NodeIndex) {
        self.state = AgentState {
            position: start_node,
            steps: 0,
            best_resonance: 0.0,
            best_node: None,
            adaptation: 1.0,
        };
        self.artefact = None;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::graph::MetatronCube;

    #[test]
    fn test_agent_creation() {
        let cube = MetatronCube::new();
        let agent = Agent::new(cube.seed_node());

        assert_eq!(agent.state().steps, 0);
        assert!(agent.artefact.is_none());
    }

    #[test]
    fn test_agent_traversal() {
        let cube = MetatronCube::new();
        let mut agent = Agent::with_config(
            cube.seed_node(),
            AgentConfig {
                max_steps: 10,
                ..Default::default()
            }
        );

        let result = agent.traverse(&cube);
        assert!(result.is_ok());

        let artefact = result.unwrap();
        assert!(artefact.blueprint.len() > 0);
    }

    #[test]
    fn test_gradient_ascent_strategy() {
        let cube = MetatronCube::new();
        let mut agent = Agent::with_config(
            cube.seed_node(),
            AgentConfig {
                strategy: TraversalStrategy::GradientAscent,
                max_steps: 5,
                ..Default::default()
            }
        );

        let result = agent.traverse(&cube);
        assert!(result.is_ok());
    }

    #[test]
    fn test_agent_adaptation() {
        let cube = MetatronCube::new();
        let mut agent = Agent::with_config(
            cube.seed_node(),
            AgentConfig {
                adaptive: true,
                max_steps: 20,
                temperature: 0.5,
                ..Default::default()
            }
        );

        let initial_adaptation = agent.state().adaptation;
        agent.traverse(&cube).unwrap();

        // Adaptation should have changed during traversal
        assert_ne!(initial_adaptation, 1.0);
    }

    #[test]
    fn test_agent_reset() {
        let cube = MetatronCube::new();
        let mut agent = Agent::new(cube.seed_node());

        agent.state.steps = 50;
        agent.reset(cube.seed_node());

        assert_eq!(agent.state().steps, 0);
        assert!(agent.artefact.is_none());
    }
}
