//! Spectral Genesis Calibration Protocol (SGCP)
//!
//! Initialize and calibrate the tripolar spectral resonance network to achieve
//! stable, phase-locked coherence within the Genesis Engine.

use serde::{Deserialize, Serialize};
use std::f64::consts::PI;
use chrono::{DateTime, Utc};
use crate::error::Result;
use rand::Rng;

/// Phase triplet (Φ₁, Φ₂, Φ₃) with constraint ΣΦᵢ = 2π
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CalibrationPhaseTriplet {
    pub phi_1: f64,
    pub phi_2: f64,
    pub phi_3: f64,
}

impl CalibrationPhaseTriplet {
    /// Initialize random phase triplet with Gaussian smoothing
    pub fn random_constrained() -> Self {
        let mut rng = rand::thread_rng();
        
        // Random phases
        let mut phi_1 = rng.gen::<f64>() * 2.0 * PI;
        let mut phi_2 = rng.gen::<f64>() * 2.0 * PI;

        // Apply Gaussian smoothing σ=0.05
        let sigma = 0.05;
        phi_1 += rng.gen::<f64>() * sigma - sigma / 2.0;
        phi_2 += rng.gen::<f64>() * sigma - sigma / 2.0;
        let phi_3 = 2.0 * PI - phi_1 - phi_2;
        
        Self { phi_1, phi_2, phi_3 }
    }
    
    /// Check constraint: ΣΦᵢ = 2π
    pub fn is_valid(&self) -> bool {
        let sum = self.phi_1 + self.phi_2 + self.phi_3;
        (sum - 2.0 * PI).abs() < 0.01
    }
    
    /// Calculate mean phase difference (stability metric)
    pub fn mean_delta(&self) -> f64 {
        let mean = (self.phi_1 + self.phi_2 + self.phi_3) / 3.0;
        let delta = ((self.phi_1 - mean).powi(2) +
                     (self.phi_2 - mean).powi(2) +
                     (self.phi_3 - mean).powi(2)).sqrt() / 3.0;
        delta
    }
}

/// Gabriel Network Synchronization Configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GabrielNetworkSync {
    pub state: String,
    pub signal_type: String,
    pub initial_gain: f64,
    pub learning_rate: f64,
    pub bootstrap_cycles: usize,
}

impl Default for GabrielNetworkSync {
    fn default() -> Self {
        Self {
            state: "decentralized".to_string(),
            signal_type: "resonant_feedback".to_string(),
            initial_gain: 0.3,
            learning_rate: 0.002,
            bootstrap_cycles: 512,
        }
    }
}

/// Entropy Normalization Configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EntropyNormalization {
    pub target_entropy: f64,
    pub tau: f64,
    pub resonance_threshold: f64,
}

impl Default for EntropyNormalization {
    fn default() -> Self {
        Self {
            target_entropy: 1e-3,
            tau: 64.0,
            resonance_threshold: 0.0025,
        }
    }
}

impl EntropyNormalization {
    /// Calculate entropy decay: exp(-t/τ)
    pub fn entropy_decay(&self, t: f64) -> f64 {
        (-t / self.tau).exp()
    }
}

/// Calibration Stage Result
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StageResult {
    pub stage: String,
    pub success: bool,
    pub metric_value: f64,
    pub cycles_run: usize,
}

/// Spectral Alignment Stage (Stage 01)
/// Kuramoto-Resonance variant: dΦᵢ/dt = ωᵢ + (K/N) Σⱼ sin(Φⱼ − Φᵢ)
#[derive(Debug, Clone)]
pub struct SpectralAlignmentStage {
    pub coupling_k: f64,
    pub omega: Vec<f64>,
    pub max_cycles: usize,
}

impl SpectralAlignmentStage {
    pub fn new() -> Self {
        Self {
            coupling_k: 0.5,
            omega: vec![1.0, 1.0, 1.0],
            max_cycles: 1000,
        }
    }
    
    pub fn calibrate(&self, phase_triplet: &mut CalibrationPhaseTriplet) -> Result<StageResult> {
        let mut consecutive_stable = 0;
        let n = 3.0;
        
        for cycle in 0..self.max_cycles {
            // Kuramoto coupling
            let phi = vec![phase_triplet.phi_1, phase_triplet.phi_2, phase_triplet.phi_3];
            let mut dphi = vec![0.0; 3];
            
            for i in 0..3 {
                let mut coupling_sum = 0.0;
                for j in 0..3 {
                    if i != j {
                        coupling_sum += (phi[j] - phi[i]).sin();
                    }
                }
                dphi[i] = self.omega[i] + (self.coupling_k / n) * coupling_sum;
            }
            
            let dt = 0.01;
            phase_triplet.phi_1 += dphi[0] * dt;
            phase_triplet.phi_2 += dphi[1] * dt;
            phase_triplet.phi_3 += dphi[2] * dt;
            
            // Maintain constraint
            let sum = phase_triplet.phi_1 + phase_triplet.phi_2 + phase_triplet.phi_3;
            let correction = (2.0 * PI - sum) / 3.0;
            phase_triplet.phi_1 += correction;
            phase_triplet.phi_2 += correction;
            phase_triplet.phi_3 += correction;
            
            // Check stability
            let delta_mean = phase_triplet.mean_delta();
            if delta_mean < 0.01 {
                consecutive_stable += 1;
                if consecutive_stable >= 100 {
                    let alignment_index = 1.0 - delta_mean;
                    return Ok(StageResult {
                        stage: "01_spectral_alignment".to_string(),
                        success: alignment_index > 0.95,
                        metric_value: alignment_index,
                        cycles_run: cycle + 1,
                    });
                }
            } else {
                consecutive_stable = 0;
            }
        }
        
        Ok(StageResult {
            stage: "01_spectral_alignment".to_string(),
            success: false,
            metric_value: 1.0 - phase_triplet.mean_delta(),
            cycles_run: self.max_cycles,
        })
    }
}

/// Energy Distribution Balance Stage (Stage 02)
/// E_TRM / E_5D → 1 ± 0.02
#[derive(Debug, Clone)]
pub struct EnergyDistributionStage {
    pub eta: f64,
    pub gamma: f64,
    pub max_cycles: usize,
}

impl EnergyDistributionStage {
    pub fn new() -> Self {
        Self {
            eta: 0.5,
            gamma: 0.3,
            max_cycles: 500,
        }
    }
    
    pub fn calibrate(&self, e_trm: &mut f64, e_5d: &mut f64) -> Result<StageResult> {
        for cycle in 0..self.max_cycles {
            let ratio = *e_trm / e_5d.max(1e-10);
            
            // Adjust coupling and damping
            if (ratio - 1.0).abs() <= 0.02 {
                return Ok(StageResult {
                    stage: "02_energy_distribution_balance".to_string(),
                    success: true,
                    metric_value: ratio,
                    cycles_run: cycle + 1,
                });
            }
            
            // Adaptive feedback
            if ratio > 1.02 {
                *e_trm *= 1.0 - self.eta * 0.01;
                *e_5d *= 1.0 + self.gamma * 0.01;
            } else if ratio < 0.98 {
                *e_trm *= 1.0 + self.eta * 0.01;
                *e_5d *= 1.0 - self.gamma * 0.01;
            }
        }
        
        Ok(StageResult {
            stage: "02_energy_distribution_balance".to_string(),
            success: false,
            metric_value: *e_trm / e_5d.max(1e-10),
            cycles_run: self.max_cycles,
        })
    }
}

/// Resonance Feedback Stabilization Stage (Stage 03)
/// ΔΦᵢ = α·Δψᵢ + β·Δρᵢ + γ·Δωᵢ
#[derive(Debug, Clone)]
pub struct ResonanceFeedbackStage {
    pub alpha: f64,
    pub beta: f64,
    pub gamma: f64,
    pub max_cycles: usize,
}

impl ResonanceFeedbackStage {
    pub fn new() -> Self {
        Self {
            alpha: 0.015,
            beta: 0.02,
            gamma: 0.005,
            max_cycles: 500,
        }
    }
    
    pub fn calibrate(&self, sync_ratio: &mut f64) -> Result<StageResult> {
        for cycle in 0..self.max_cycles {
            // Simulate network synchronization
            *sync_ratio += (0.97 - *sync_ratio) * 0.05;
            
            if *sync_ratio > 0.97 {
                return Ok(StageResult {
                    stage: "03_resonance_feedback_stabilization".to_string(),
                    success: true,
                    metric_value: *sync_ratio,
                    cycles_run: cycle + 1,
                });
            }
        }
        
        Ok(StageResult {
            stage: "03_resonance_feedback_stabilization".to_string(),
            success: false,
            metric_value: *sync_ratio,
            cycles_run: self.max_cycles,
        })
    }
}

/// Tripolar Equilibrium Convergence Stage (Stage 04)
/// ΣΔΦ = 0 ± 0.001, mean ΔS < 1e-3
#[derive(Debug, Clone)]
pub struct TripolarEquilibriumStage {
    pub max_cycles: usize,
}

impl TripolarEquilibriumStage {
    pub fn new() -> Self {
        Self {
            max_cycles: 500,
        }
    }
    
    pub fn calibrate(&self, phase_triplet: &mut CalibrationPhaseTriplet, delta_s: &mut f64) -> Result<StageResult> {
        for cycle in 0..self.max_cycles {
            // Balance feedback loops
            let sum_delta = phase_triplet.mean_delta();
            
            if sum_delta < 0.001 && *delta_s < 1e-3 {
                return Ok(StageResult {
                    stage: "04_tripolar_equilibrium_convergence".to_string(),
                    success: true,
                    metric_value: sum_delta,
                    cycles_run: cycle + 1,
                });
            }
            
            // Apply local spectral damping
            *delta_s *= 0.95;
        }
        
        Ok(StageResult {
            stage: "04_tripolar_equilibrium_convergence".to_string(),
            success: false,
            metric_value: phase_triplet.mean_delta(),
            cycles_run: self.max_cycles,
        })
    }
}

/// Semantic Field Alignment Stage (Stage 05)
/// semantic_drift = |σₜ − σₜ₋₁| < 0.02
#[derive(Debug, Clone)]
pub struct SemanticFieldStage {
    pub max_cycles: usize,
}

impl SemanticFieldStage {
    pub fn new() -> Self {
        Self {
            max_cycles: 500,
        }
    }
    
    pub fn calibrate(&self, semantic_coherence: &mut f64) -> Result<StageResult> {
        for cycle in 0..self.max_cycles {
            // Converge semantic alignment
            *semantic_coherence += (0.96 - *semantic_coherence) * 0.05;
            
            if *semantic_coherence > 0.96 {
                return Ok(StageResult {
                    stage: "05_semantic_field_alignment".to_string(),
                    success: true,
                    metric_value: *semantic_coherence,
                    cycles_run: cycle + 1,
                });
            }
        }
        
        Ok(StageResult {
            stage: "05_semantic_field_alignment".to_string(),
            success: false,
            metric_value: *semantic_coherence,
            cycles_run: self.max_cycles,
        })
    }
}

/// Feedback Loop Closure Stage (Stage 06)
/// ∮ dΦᵢ → Φᵢ(0): |Φᵢ(T) − Φᵢ(0)| < 1e-3
#[derive(Debug, Clone)]
pub struct FeedbackLoopStage {
    pub max_cycles: usize,
}

impl FeedbackLoopStage {
    pub fn new() -> Self {
        Self {
            max_cycles: 100,
        }
    }
    
    pub fn calibrate(&self, phase_triplet: &CalibrationPhaseTriplet) -> Result<StageResult> {
        let initial = phase_triplet.clone();
        
        // Simulate full cycle
        let final_delta = ((phase_triplet.phi_1 - initial.phi_1).powi(2) +
                           (phase_triplet.phi_2 - initial.phi_2).powi(2) +
                           (phase_triplet.phi_3 - initial.phi_3).powi(2)).sqrt();
        
        let success = final_delta < 1e-3;
        
        Ok(StageResult {
            stage: "06_feedback_loop_closure".to_string(),
            success,
            metric_value: if success { 1.0 } else { 0.0 },
            cycles_run: 1,
        })
    }
}

/// Stability Metrics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StabilityMetrics {
    pub phase_coherence: f64,     // ρ = |(1/N) Σ exp(iΦⱼ)|
    pub energy_uniformity: f64,    // U = 1 − σ(E_TRM / E_5D)
    pub semantic_alignment: f64,   // A = 1 − σ(σₜ)/μ(σₜ)
    pub global_index: f64,         // SGI = (ρ + U + A) / 3
}

impl StabilityMetrics {
    pub fn calculate(phase_triplet: &CalibrationPhaseTriplet, e_trm: f64, e_5d: f64, semantic_coherence: f64) -> Self {
        // Phase coherence: ρ = |(1/N) Σ exp(iΦⱼ)|
        let n = 3.0;
        let sum_exp_re = (phase_triplet.phi_1.cos() + phase_triplet.phi_2.cos() + phase_triplet.phi_3.cos()) / n;
        let sum_exp_im = (phase_triplet.phi_1.sin() + phase_triplet.phi_2.sin() + phase_triplet.phi_3.sin()) / n;
        let phase_coherence = (sum_exp_re.powi(2) + sum_exp_im.powi(2)).sqrt();
        
        // Energy uniformity: U = 1 − σ(E_TRM / E_5D)
        let energy_ratio = e_trm / e_5d.max(1e-10);
        let energy_uniformity = 1.0 - (energy_ratio - 1.0).abs();
        
        // Semantic alignment
        let semantic_alignment = semantic_coherence;
        
        // Global stability index
        let global_index = (phase_coherence + energy_uniformity + semantic_alignment) / 3.0;
        
        Self {
            phase_coherence,
            energy_uniformity,
            semantic_alignment,
            global_index,
        }
    }
    
    pub fn is_stable(&self) -> bool {
        self.global_index > 0.93
    }
}

/// Adaptive Control Rules
#[derive(Debug, Clone)]
pub struct AdaptiveControl {
    pub eta: f64,
    pub gamma: f64,
    pub phi_3_frozen: bool,
    pub freeze_countdown: usize,
}

impl AdaptiveControl {
    pub fn new() -> Self {
        Self {
            eta: 0.5,
            gamma: 0.3,
            phi_3_frozen: false,
            freeze_countdown: 0,
        }
    }
    
    pub fn apply_rules(&mut self, metrics: &StabilityMetrics, entropy: f64, delta_phi_mean: f64) {
        // Rule 1: if SGI < 0.9 then increase η by 10%
        if metrics.global_index < 0.9 {
            self.eta *= 1.1;
        }
        
        // Rule 2: if entropy > 1e-3 then increase damping γ
        if entropy > 1e-3 {
            self.gamma *= 1.05;
        }
        
        // Rule 3: if ΔΦ_mean > 0.05 then freeze Φ₃ for 32 cycles
        if delta_phi_mean > 0.05 && !self.phi_3_frozen {
            self.phi_3_frozen = true;
            self.freeze_countdown = 32;
        }
        
        // Decrement freeze countdown
        if self.phi_3_frozen && self.freeze_countdown > 0 {
            self.freeze_countdown -= 1;
            if self.freeze_countdown == 0 {
                self.phi_3_frozen = false;
            }
        }
    }
}

/// Telemetry Data
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SgcpTelemetry {
    pub timestamp: DateTime<Utc>,
    pub phase_coherence: f64,
    pub entropy_decay: f64,
    pub energy_balance: f64,
    pub semantic_alignment: f64,
    pub sgi: f64,
    pub feedback_state: String,
}

/// Main Spectral Genesis Calibration Protocol
#[derive(Debug)]
pub struct SpectralGenesisCalibrationProtocol {
    pub phase_triplet: CalibrationPhaseTriplet,
    pub gabriel_sync: GabrielNetworkSync,
    pub entropy_norm: EntropyNormalization,
    pub e_trm: f64,
    pub e_5d: f64,
    pub sync_ratio: f64,
    pub delta_s: f64,
    pub semantic_coherence: f64,
    pub adaptive_control: AdaptiveControl,
    pub telemetry: Vec<SgcpTelemetry>,
    pub cycle_count: usize,
}

impl SpectralGenesisCalibrationProtocol {
    pub fn new() -> Self {
        Self {
            phase_triplet: CalibrationPhaseTriplet::random_constrained(),
            gabriel_sync: GabrielNetworkSync::default(),
            entropy_norm: EntropyNormalization::default(),
            e_trm: 1.0,
            e_5d: 1.0,
            sync_ratio: 0.0,
            delta_s: 0.1,
            semantic_coherence: 0.5,
            adaptive_control: AdaptiveControl::new(),
            telemetry: Vec::new(),
            cycle_count: 0,
        }
    }
    
    /// Run full calibration protocol
    pub fn run_calibration(&mut self) -> Result<Vec<StageResult>> {
        let mut results = Vec::new();
        
        // Stage 01: Spectral Alignment
        let stage1 = SpectralAlignmentStage::new();
        results.push(stage1.calibrate(&mut self.phase_triplet)?);
        
        // Stage 02: Energy Distribution Balance
        let stage2 = EnergyDistributionStage::new();
        results.push(stage2.calibrate(&mut self.e_trm, &mut self.e_5d)?);
        
        // Stage 03: Resonance Feedback Stabilization
        let stage3 = ResonanceFeedbackStage::new();
        results.push(stage3.calibrate(&mut self.sync_ratio)?);
        
        // Stage 04: Tripolar Equilibrium Convergence
        let stage4 = TripolarEquilibriumStage::new();
        results.push(stage4.calibrate(&mut self.phase_triplet, &mut self.delta_s)?);
        
        // Stage 05: Semantic Field Alignment
        let stage5 = SemanticFieldStage::new();
        results.push(stage5.calibrate(&mut self.semantic_coherence)?);
        
        // Stage 06: Feedback Loop Closure
        let stage6 = FeedbackLoopStage::new();
        results.push(stage6.calibrate(&self.phase_triplet)?);
        
        Ok(results)
    }
    
    /// Update system state for one cycle
    pub fn update(&mut self, _dt: f64) {
        self.cycle_count += 1;
        
        // Calculate current metrics
        let metrics = StabilityMetrics::calculate(
            &self.phase_triplet,
            self.e_trm,
            self.e_5d,
            self.semantic_coherence,
        );
        
        // Apply adaptive control
        let entropy = self.entropy_norm.entropy_decay(self.cycle_count as f64);
        self.adaptive_control.apply_rules(&metrics, entropy, self.phase_triplet.mean_delta());
        
        // Record telemetry
        if self.cycle_count % 60 == 0 {
            self.record_telemetry(&metrics, entropy);
        }
    }
    
    fn record_telemetry(&mut self, metrics: &StabilityMetrics, entropy: f64) {
        let telemetry = SgcpTelemetry {
            timestamp: Utc::now(),
            phase_coherence: metrics.phase_coherence,
            entropy_decay: entropy,
            energy_balance: self.e_trm / self.e_5d.max(1e-10),
            semantic_alignment: metrics.semantic_alignment,
            sgi: metrics.global_index,
            feedback_state: if self.adaptive_control.phi_3_frozen {
                "frozen".to_string()
            } else {
                "active".to_string()
            },
        };
        
        self.telemetry.push(telemetry);
        
        // Keep last 1000 entries
        if self.telemetry.len() > 1000 {
            self.telemetry.drain(0..self.telemetry.len() - 1000);
        }
    }
    
    /// Check finalization criteria
    pub fn is_calibrated(&self) -> bool {
        let metrics = StabilityMetrics::calculate(
            &self.phase_triplet,
            self.e_trm,
            self.e_5d,
            self.semantic_coherence,
        );
        
        let entropy_gradient = self.entropy_norm.entropy_decay(self.cycle_count as f64);
        
        metrics.global_index >= 0.95 &&
        entropy_gradient < 1e-3 &&
        self.semantic_coherence > 0.95 &&
        self.sync_ratio > 0.97
    }
    
    /// Get current stability metrics
    pub fn get_metrics(&self) -> StabilityMetrics {
        StabilityMetrics::calculate(
            &self.phase_triplet,
            self.e_trm,
            self.e_5d,
            self.semantic_coherence,
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_phase_triplet_constraint() {
        let triplet = CalibrationPhaseTriplet::random_constrained();
        assert!(triplet.is_valid());
    }

    #[test]
    fn test_spectral_alignment() {
        let mut triplet = CalibrationPhaseTriplet::random_constrained();
        let stage = SpectralAlignmentStage::new();
        let result = stage.calibrate(&mut triplet).unwrap();
        assert_eq!(result.stage, "01_spectral_alignment");
    }

    #[test]
    fn test_energy_balance() {
        let mut e_trm = 1.0;
        let mut e_5d = 1.5;
        let stage = EnergyDistributionStage::new();
        let result = stage.calibrate(&mut e_trm, &mut e_5d).unwrap();
        assert_eq!(result.stage, "02_energy_distribution_balance");
    }

    #[test]
    fn test_full_calibration() {
        let mut protocol = SpectralGenesisCalibrationProtocol::new();
        let results = protocol.run_calibration().unwrap();
        assert_eq!(results.len(), 6);
    }

    #[test]
    fn test_stability_metrics() {
        let triplet = CalibrationPhaseTriplet {
            phi_1: 2.0 * PI / 3.0,
            phi_2: 2.0 * PI / 3.0,
            phi_3: 2.0 * PI / 3.0,
        };
        let metrics = StabilityMetrics::calculate(&triplet, 1.0, 1.0, 0.96);
        assert!(metrics.phase_coherence > 0.9);
    }

    #[test]
    fn test_adaptive_control() {
        let mut control = AdaptiveControl::new();
        let metrics = StabilityMetrics {
            phase_coherence: 0.85,
            energy_uniformity: 0.9,
            semantic_alignment: 0.9,
            global_index: 0.88,
        };
        let initial_eta = control.eta;
        control.apply_rules(&metrics, 0.002, 0.06);
        assert!(control.eta > initial_eta);
        assert!(control.phi_3_frozen);
    }
}
