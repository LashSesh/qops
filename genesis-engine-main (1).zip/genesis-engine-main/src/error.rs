//! Error types for the MOGE system

use thiserror::Error;

/// Result type for MOGE operations
pub type Result<T> = std::result::Result<T, MogeError>;

/// Error types that can occur in the MOGE system
#[derive(Error, Debug)]
pub enum MogeError {
    #[error("Invalid signature: {0}")]
    InvalidSignature(String),

    #[error("Node not found: {0}")]
    NodeNotFound(usize),

    #[error("Invalid traversal: {0}")]
    InvalidTraversal(String),

    #[error("Resonance kernel violation: {0}")]
    ResonanceViolation(String),

    #[error("Invalid artefact: {0}")]
    InvalidArtefact(String),

    #[error("Artefact error: {0}")]
    ArtefactError(String),

    #[error("Ledger error: {0}")]
    LedgerError(String),

    #[error("Serialization error: {0}")]
    SerializationError(#[from] serde_json::Error),

    #[error("IO error: {0}")]
    IoError(#[from] std::io::Error),

    #[error("Agent error: {0}")]
    AgentError(String),

    #[error("Simulation error: {0}")]
    SimulationError(String),

    #[error("Invalid node index: {0}")]
    InvalidNodeIndex(usize),

    #[error("Invalid input: {0}")]
    InvalidInput(String),

    #[error("Invalid state: {0}")]
    InvalidState(String),

    #[error("Invalid configuration: {0}")]
    InvalidConfiguration(String),

    #[error("Execution error: {0}")]
    ExecutionError(String),
}

/// Alias for MogeError for compatibility with new modules
pub type GenesisError = MogeError;
