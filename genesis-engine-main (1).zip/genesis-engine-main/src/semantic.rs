//! Semantic Layer - IMHK Foundation
//!
//! Infogenomic semantics bridging operators and meaning.
//! Provides bidirectional translation between signatures and semantic structures.

use crate::signature::Signature5D;
use crate::resonance_kernel::resonance;
use serde::{Deserialize, Serialize};

/// Infogenome structure - semantic encoding of operator signatures
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Infogenome {
    /// Spectral quality (ψ)
    pub psi: f64,
    /// Dynamic consistency (ρ)
    pub rho: f64,
    /// Structural coherence (ω)
    pub omega: f64,
    /// Topological path coherence (χ)
    pub chi: f64,
    /// Resonance fluctuation (η)
    pub eta: f64,
    /// Semantic tag for categorization
    pub semantic_tag: String,
    /// Shannon entropy of the infogenome
    pub entropy: f64,
}

impl Infogenome {
    /// Create infogenome from signature
    pub fn from_signature(sig: &Signature5D) -> Self {
        let entropy = compute_shannon_entropy(sig);
        let semantic_tag = derive_semantic_tag(sig);

        Self {
            psi: sig.psi,
            rho: sig.rho,
            omega: sig.omega,
            chi: sig.chi,
            eta: sig.eta,
            semantic_tag,
            entropy,
        }
    }

    /// Convert infogenome back to signature
    pub fn to_signature(&self) -> Signature5D {
        Signature5D::new(
            self.psi,
            self.rho,
            self.omega,
            self.chi,
            self.eta,
        )
    }

    /// Get semantic category
    pub fn category(&self) -> SemanticCategory {
        categorize_genome(self)
    }

    /// Compute semantic distance to another infogenome
    pub fn semantic_distance(&self, other: &Infogenome) -> f64 {
        // Euclidean distance in 5D space with entropy weighting
        let sig_dist = (
            (self.psi - other.psi).powi(2) +
            (self.rho - other.rho).powi(2) +
            (self.omega - other.omega).powi(2) +
            (self.chi - other.chi).powi(2) +
            (self.eta - other.eta).powi(2)
        ).sqrt();

        let entropy_factor = (self.entropy - other.entropy).abs();

        sig_dist * (1.0 + 0.1 * entropy_factor)
    }

    /// Check semantic compatibility
    pub fn is_compatible(&self, other: &Infogenome) -> bool {
        self.semantic_distance(other) < 0.3
    }

    /// Merge two infogenomes
    pub fn merge(&self, other: &Infogenome, weight: f64) -> Self {
        let w = weight.clamp(0.0, 1.0);

        let merged_sig = Signature5D::new(
            self.psi * w + other.psi * (1.0 - w),
            self.rho * w + other.rho * (1.0 - w),
            self.omega * w + other.omega * (1.0 - w),
            self.chi * w + other.chi * (1.0 - w),
            self.eta * w + other.eta * (1.0 - w),
        );

        Self::from_signature(&merged_sig)
    }
}

/// Semantic category enumeration
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum SemanticCategory {
    /// High spectral quality, ordered
    Crystalline,
    /// Balanced across dimensions
    Harmonic,
    /// High fluctuation, dynamic
    Chaotic,
    /// Strong topological coherence
    Topological,
    /// High structural stability
    Structural,
    /// Emerging patterns
    Emergent,
    /// Unclassified
    Uncategorized,
}

/// Compute Shannon entropy of signature
fn compute_shannon_entropy(sig: &Signature5D) -> f64 {
    let components = vec![sig.psi, sig.rho, sig.omega, sig.chi, sig.eta];

    // Normalize to probability distribution
    let sum: f64 = components.iter().sum();
    if sum < 1e-10 {
        return 0.0;
    }

    let probs: Vec<f64> = components.iter().map(|&x| x / sum).collect();

    // Compute Shannon entropy: H = -Σ p_i log(p_i)
    -probs.iter()
        .filter(|&&p| p > 1e-10)
        .map(|&p| p * p.ln())
        .sum::<f64>()
}

/// Derive semantic tag from signature
fn derive_semantic_tag(sig: &Signature5D) -> String {
    let res = resonance(sig);

    if res > 0.9 {
        "high_resonance".to_string()
    } else if res > 0.7 {
        "medium_resonance".to_string()
    } else if res > 0.5 {
        "low_resonance".to_string()
    } else if sig.psi > 0.8 {
        "spectral_dominant".to_string()
    } else if sig.omega > 0.8 {
        "structural_dominant".to_string()
    } else if sig.chi > 0.8 {
        "topological_dominant".to_string()
    } else {
        "exploratory".to_string()
    }
}

/// Categorize infogenome into semantic category
fn categorize_genome(genome: &Infogenome) -> SemanticCategory {
    // Check for crystalline (high psi, low entropy)
    if genome.psi > 0.85 && genome.entropy < 1.2 {
        return SemanticCategory::Crystalline;
    }

    // Check for harmonic (balanced components)
    let variance = compute_variance(&[
        genome.psi,
        genome.rho,
        genome.omega,
        genome.chi,
        genome.eta,
    ]);
    if variance < 0.05 {
        return SemanticCategory::Harmonic;
    }

    // Check for chaotic (high eta and entropy)
    if genome.eta > 0.7 && genome.entropy > 1.4 {
        return SemanticCategory::Chaotic;
    }

    // Check for topological (high chi)
    if genome.chi > 0.8 {
        return SemanticCategory::Topological;
    }

    // Check for structural (high omega)
    if genome.omega > 0.8 {
        return SemanticCategory::Structural;
    }

    // Check for emergent (increasing pattern)
    if genome.chi > genome.rho && genome.eta > genome.psi {
        return SemanticCategory::Emergent;
    }

    SemanticCategory::Uncategorized
}

/// Compute variance of values
fn compute_variance(values: &[f64]) -> f64 {
    if values.is_empty() {
        return 0.0;
    }

    let mean: f64 = values.iter().sum::<f64>() / values.len() as f64;
    let variance: f64 = values.iter()
        .map(|&x| (x - mean).powi(2))
        .sum::<f64>() / values.len() as f64;

    variance
}

/// Semantic network node
#[derive(Debug, Clone)]
pub struct SemanticNode {
    pub genome: Infogenome,
    pub connections: Vec<(usize, f64)>, // (node_id, strength)
}

impl SemanticNode {
    pub fn new(genome: Infogenome) -> Self {
        Self {
            genome,
            connections: Vec::new(),
        }
    }

    pub fn connect(&mut self, node_id: usize, strength: f64) {
        self.connections.push((node_id, strength));
    }
}

/// Semantic network for organizing infogenomes
#[derive(Debug, Default)]
pub struct SemanticNetwork {
    nodes: Vec<SemanticNode>,
}

impl SemanticNetwork {
    pub fn new() -> Self {
        Self { nodes: Vec::new() }
    }

    /// Add node to network
    pub fn add_node(&mut self, genome: Infogenome) -> usize {
        let node = SemanticNode::new(genome);
        self.nodes.push(node);
        self.nodes.len() - 1
    }

    /// Connect two nodes
    pub fn connect(&mut self, from: usize, to: usize, strength: f64) {
        if from < self.nodes.len() {
            self.nodes[from].connect(to, strength);
        }
    }

    /// Find nearest neighbors
    pub fn nearest_neighbors(&self, node_id: usize, k: usize) -> Vec<usize> {
        if node_id >= self.nodes.len() {
            return Vec::new();
        }

        let target = &self.nodes[node_id].genome;

        let mut distances: Vec<(usize, f64)> = self.nodes.iter()
            .enumerate()
            .filter(|(i, _)| *i != node_id)
            .map(|(i, node)| (i, target.semantic_distance(&node.genome)))
            .collect();

        distances.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());

        distances.into_iter()
            .take(k)
            .map(|(i, _)| i)
            .collect()
    }

    /// Get node count
    pub fn size(&self) -> usize {
        self.nodes.len()
    }

    /// Get node
    pub fn get(&self, id: usize) -> Option<&SemanticNode> {
        self.nodes.get(id)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_infogenome_creation() {
        let sig = Signature5D::new(0.9, 0.8, 0.7, 0.6, 0.5);
        let genome = Infogenome::from_signature(&sig);

        assert_eq!(genome.psi, 0.9);
        assert!(genome.entropy > 0.0);
        assert!(!genome.semantic_tag.is_empty());
    }

    #[test]
    fn test_signature_conversion() {
        let sig1 = Signature5D::new(0.8, 0.7, 0.6, 0.5, 0.4);
        let genome = Infogenome::from_signature(&sig1);
        let sig2 = genome.to_signature();

        assert_eq!(sig1.psi, sig2.psi);
        assert_eq!(sig1.rho, sig2.rho);
        assert_eq!(sig1.omega, sig2.omega);
    }

    #[test]
    fn test_semantic_distance() {
        let g1 = Infogenome::from_signature(&Signature5D::new(0.9, 0.8, 0.7, 0.6, 0.5));
        let g2 = Infogenome::from_signature(&Signature5D::new(0.9, 0.8, 0.7, 0.6, 0.5));
        let g3 = Infogenome::from_signature(&Signature5D::new(0.1, 0.2, 0.3, 0.4, 0.5));

        assert!(g1.semantic_distance(&g2) < 0.01);
        assert!(g1.semantic_distance(&g3) > 0.5);
    }

    #[test]
    fn test_semantic_category() {
        let crystalline = Infogenome::from_signature(&Signature5D::new(0.95, 0.5, 0.5, 0.5, 0.2));
        assert_eq!(crystalline.category(), SemanticCategory::Crystalline);

        let harmonic = Infogenome::from_signature(&Signature5D::new(0.6, 0.6, 0.6, 0.6, 0.6));
        assert_eq!(harmonic.category(), SemanticCategory::Harmonic);
    }

    #[test]
    fn test_semantic_merge() {
        let g1 = Infogenome::from_signature(&Signature5D::new(1.0, 0.0, 1.0, 0.0, 1.0));
        let g2 = Infogenome::from_signature(&Signature5D::new(0.0, 1.0, 0.0, 1.0, 0.0));

        let merged = g1.merge(&g2, 0.5);

        assert!((merged.psi - 0.5).abs() < 0.01);
        assert!((merged.rho - 0.5).abs() < 0.01);
    }

    #[test]
    fn test_semantic_network() {
        let mut network = SemanticNetwork::new();

        let g1 = Infogenome::from_signature(&Signature5D::new(0.9, 0.8, 0.7, 0.6, 0.5));
        let g2 = Infogenome::from_signature(&Signature5D::new(0.8, 0.8, 0.7, 0.6, 0.5));

        let id1 = network.add_node(g1);
        let id2 = network.add_node(g2);

        network.connect(id1, id2, 0.9);

        assert_eq!(network.size(), 2);
        assert!(network.get(id1).is_some());
    }
}
