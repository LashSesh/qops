//! Rule Matrix and Projective Domains
//!
//! Provides deterministic resonance-invariant mapping between internal operator 
//! structures and their valid domain projections, ensuring universal semantic isomorphism.
//!
//! Core equation: R_ij = φ(T_i, D_j) − φ(T_i, D_k)

use crate::resonant_language_projection::{Domain, ProjectionTensor};
use crate::error::Result;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use uuid::Uuid;

/// Rule Matrix - Resonance-invariant mapping matrix
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuleMatrix {
    /// Matrix data: R_ij for each TIC-Domain pair
    /// Outer HashMap: TIC ID -> Inner HashMap: Domain -> R value
    matrix: HashMap<Uuid, HashMap<Domain, f64>>,
    
    /// Learning rate for gradient minimization
    learning_rate: f64,
    
    /// Stability condition threshold
    stability_threshold: f64,
    
    /// Number of consecutive stable cycles
    stable_cycles: usize,
    
    /// Current convergence status
    converged: bool,
    
    /// ΔR statistics
    delta_r_mean: f64,
    delta_r_variance: f64,
}

/// Target normalization value for balanced projections
const BALANCE_TARGET: f64 = 0.5;

impl RuleMatrix {
    /// Create a new rule matrix
    pub fn new() -> Self {
        Self {
            matrix: HashMap::new(),
            learning_rate: 0.0025,
            stability_threshold: 1e-5,
            stable_cycles: 0,
            converged: false,
            delta_r_mean: 0.0,
            delta_r_variance: 0.0,
        }
    }
    
    /// Initialize matrix entry for a TIC across all domains
    pub fn initialize_tic(&mut self, tic_id: Uuid, projections: &[ProjectionTensor]) {
        let mut domain_map = HashMap::new();
        
        for proj in projections {
            // Initialize with projection's normalized value
            domain_map.insert(proj.domain, proj.normalized_value);
        }
        
        self.matrix.insert(tic_id, domain_map);
    }
    
    /// Get R_ij value for TIC-Domain pair
    pub fn get(&self, tic_id: &Uuid, domain: Domain) -> Option<f64> {
        self.matrix.get(tic_id)?.get(&domain).copied()
    }
    
    /// Update rule matrix through gradient minimization
    /// R_ij ← R_ij − η * ∂ΔR/∂t
    pub fn update(&mut self) -> Result<()> {
        let mut total_delta = 0.0;
        let mut count = 0;
        let mut deltas = Vec::new();
        
        // Calculate ΔR for all TIC-Domain pairs
        for (_tic_id, domain_map) in &self.matrix {
            let domains = Domain::all();
            
            for i in 0..domains.len() {
                for j in (i + 1)..domains.len() {
                    let r_i = domain_map.get(&domains[i]).copied().unwrap_or(0.0);
                    let r_j = domain_map.get(&domains[j]).copied().unwrap_or(0.0);
                    let delta = (r_i - r_j).abs();
                    
                    deltas.push(delta);
                    total_delta += delta;
                    count += 1;
                }
            }
        }
        
        if count == 0 {
            return Ok(());
        }
        
        // Calculate statistics
        self.delta_r_mean = total_delta / count as f64;
        
        let variance: f64 = deltas.iter()
            .map(|&d| (d - self.delta_r_mean).powi(2))
            .sum::<f64>() / count as f64;
        self.delta_r_variance = variance;
        
        // Apply gradient descent to minimize ΔR
        for (_tic_id, domain_map) in self.matrix.iter_mut() {
            for (_domain, r_value) in domain_map.iter_mut() {
                // Gradient approximation: move toward balance target
                let gradient = *r_value - BALANCE_TARGET;
                *r_value -= self.learning_rate * gradient;
                *r_value = r_value.clamp(0.0, 1.0);
            }
        }
        
        // Check convergence
        if self.delta_r_mean < self.stability_threshold {
            self.stable_cycles += 1;
            if self.stable_cycles >= 3 {
                self.converged = true;
            }
        } else {
            self.stable_cycles = 0;
            self.converged = false;
        }
        
        Ok(())
    }
    
    /// Check if matrix has converged
    pub fn is_converged(&self) -> bool {
        self.converged
    }
    
    /// Get ΔR mean
    pub fn delta_r_mean(&self) -> f64 {
        self.delta_r_mean
    }
    
    /// Get ΔR variance
    pub fn delta_r_variance(&self) -> f64 {
        self.delta_r_variance
    }
    
    /// Calculate semantic coherence index
    /// SCI = 1 − (σ_R / μ_P)
    pub fn semantic_coherence_index(&self) -> f64 {
        if self.matrix.is_empty() {
            return 0.0;
        }
        
        let mut all_values = Vec::new();
        for domain_map in self.matrix.values() {
            all_values.extend(domain_map.values().copied());
        }
        
        if all_values.is_empty() {
            return 0.0;
        }
        
        let mean: f64 = all_values.iter().sum::<f64>() / all_values.len() as f64;
        let variance: f64 = all_values.iter()
            .map(|&v| (v - mean).powi(2))
            .sum::<f64>() / all_values.len() as f64;
        let std_dev = variance.sqrt();
        
        if mean > 0.0 {
            f64::max(0.0, f64::min(1.0, 1.0 - (std_dev / mean)))
        } else {
            0.0
        }
    }
    
    /// Get matrix checksum for state verification
    pub fn checksum(&self) -> String {
        use sha2::{Sha512, Digest};
        let mut hasher = Sha512::new();
        
        // Sort for deterministic output
        let mut tic_ids: Vec<_> = self.matrix.keys().collect();
        tic_ids.sort();
        
        for tic_id in tic_ids {
            hasher.update(tic_id.as_bytes());
            if let Some(domain_map) = self.matrix.get(tic_id) {
                for domain in Domain::all() {
                    if let Some(&value) = domain_map.get(&domain) {
                        hasher.update(value.to_le_bytes());
                    }
                }
            }
        }
        
        format!("{:x}", hasher.finalize())
    }
    
    /// Export matrix state for persistence
    pub fn export_state(&self) -> RuleMatrixState {
        RuleMatrixState {
            matrix_checksum: self.checksum(),
            delta_r_mean: self.delta_r_mean,
            delta_r_variance: self.delta_r_variance,
            semantic_coherence_index: self.semantic_coherence_index(),
            status: if self.converged { "converged" } else { "calibrating" }.to_string(),
        }
    }
}

impl Default for RuleMatrix {
    fn default() -> Self {
        Self::new()
    }
}

/// Rule Matrix state snapshot
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RuleMatrixState {
    pub matrix_checksum: String,
    pub delta_r_mean: f64,
    pub delta_r_variance: f64,
    pub semantic_coherence_index: f64,
    pub status: String,
}

/// Domain mapping configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DomainMapping {
    pub id: String,
    pub description: String,
    pub basis: Vec<String>,
    pub constraint: String,
}

impl DomainMapping {
    /// Get mapping for a specific domain
    pub fn for_domain(domain: Domain) -> Self {
        match domain {
            Domain::Mathematics => Self {
                id: "D_math".to_string(),
                description: "Analytical-mathematical representation".to_string(),
                basis: vec!["ψ".into(), "ρ".into(), "ω".into(), "β".into(), "S".into()],
                constraint: "preserve operator commutativity where applicable".to_string(),
            },
            Domain::Cybernetics => Self {
                id: "D_cyber".to_string(),
                description: "Control-theoretic/kybernetic flow representation".to_string(),
                basis: vec!["feedback_gain".into(), "phase".into(), "coherence".into()],
                constraint: "closed-loop stability criterion ΔS < 1e−3".to_string(),
            },
            Domain::Geometry => Self {
                id: "D_geom".to_string(),
                description: "Geometric/topological projection (Metatron-Cube embedding)".to_string(),
                basis: vec!["vertex_index".into(), "edge_tensor".into(), "dual_projection".into()],
                constraint: "maintain adjacency Betti invariants".to_string(),
            },
            Domain::Logic => Self {
                id: "D_logic".to_string(),
                description: "Symbolic/logical operator form".to_string(),
                basis: vec!["true".into(), "false".into(), "flux".into(), "null".into()],
                constraint: "non-paradoxical resolution (no self-contradiction)".to_string(),
            },
            Domain::Physics => Self {
                id: "D_phys".to_string(),
                description: "Energetic/field projection".to_string(),
                basis: vec!["energy_density".into(), "phase_velocity".into(), "entropy_gradient".into()],
                constraint: "energy conservation within 1e−4".to_string(),
            },
        }
    }
}

/// Projection normalizer using rule matrix
pub struct ProjectionNormalizer {
    rule_matrix: RuleMatrix,
}

impl ProjectionNormalizer {
    /// Create a new projection normalizer
    pub fn new() -> Self {
        Self {
            rule_matrix: RuleMatrix::new(),
        }
    }
    
    /// Normalize projections for a TIC
    pub fn normalize(
        &mut self,
        tic_id: Uuid,
        projections: &mut [ProjectionTensor],
    ) -> Result<()> {
        // Initialize matrix entry
        self.rule_matrix.initialize_tic(tic_id, projections);
        
        // Run normalization iterations
        for _ in 0..100 {
            self.rule_matrix.update()?;
            if self.rule_matrix.is_converged() {
                break;
            }
        }
        
        // Apply normalized values back to projections
        for proj in projections.iter_mut() {
            if let Some(normalized) = self.rule_matrix.get(&tic_id, proj.domain) {
                proj.normalized_value = normalized;
            }
        }
        
        Ok(())
    }
    
    /// Get rule matrix reference
    pub fn rule_matrix(&self) -> &RuleMatrix {
        &self.rule_matrix
    }
    
    /// Get mutable rule matrix reference
    pub fn rule_matrix_mut(&mut self) -> &mut RuleMatrix {
        &mut self.rule_matrix
    }
}

impl Default for ProjectionNormalizer {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::operator::Operator;
    use crate::resonant_language_projection::TIC;
    
    #[test]
    fn test_rule_matrix_creation() {
        let matrix = RuleMatrix::new();
        assert_eq!(matrix.learning_rate, 0.0025);
        assert!(!matrix.is_converged());
    }
    
    #[test]
    fn test_rule_matrix_initialization() {
        let mut matrix = RuleMatrix::new();
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        
        let projections: Vec<_> = Domain::all()
            .iter()
            .map(|&d| ProjectionTensor::new(d, &tic))
            .collect();
        
        matrix.initialize_tic(tic.id, &projections);
        
        for domain in Domain::all() {
            assert!(matrix.get(&tic.id, domain).is_some());
        }
    }
    
    #[test]
    fn test_rule_matrix_update() {
        let mut matrix = RuleMatrix::new();
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        
        let projections: Vec<_> = Domain::all()
            .iter()
            .map(|&d| ProjectionTensor::new(d, &tic))
            .collect();
        
        matrix.initialize_tic(tic.id, &projections);
        matrix.update().unwrap();
        
        assert!(matrix.delta_r_mean() >= 0.0);
    }
    
    #[test]
    fn test_semantic_coherence_index() {
        let mut matrix = RuleMatrix::new();
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        
        let projections: Vec<_> = Domain::all()
            .iter()
            .map(|&d| ProjectionTensor::new(d, &tic))
            .collect();
        
        matrix.initialize_tic(tic.id, &projections);
        
        let sci = matrix.semantic_coherence_index();
        assert!(sci >= 0.0 && sci <= 1.0);
    }
    
    #[test]
    fn test_domain_mapping() {
        for domain in Domain::all() {
            let mapping = DomainMapping::for_domain(domain);
            assert!(!mapping.id.is_empty());
            assert!(!mapping.basis.is_empty());
        }
    }
    
    #[test]
    fn test_projection_normalizer() {
        let mut normalizer = ProjectionNormalizer::new();
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        
        let mut projections: Vec<_> = Domain::all()
            .iter()
            .map(|&d| ProjectionTensor::new(d, &tic))
            .collect();
        
        normalizer.normalize(tic.id, &mut projections).unwrap();
        
        // Verify normalization was applied
        for proj in &projections {
            assert!(proj.normalized_value >= 0.0 && proj.normalized_value <= 1.0);
        }
    }
}
