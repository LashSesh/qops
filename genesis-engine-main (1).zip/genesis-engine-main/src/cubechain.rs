//! Cubechain Module - Hypercube-DAG Ledger Architecture
//!
//! Implements the multidimensional Cubechain as an infinite directed hypergraph
//! of resonant operator cubes (5D-Hypercubes) with DK/WT/PI/SW operator basis.
//!
//! ## Core Concepts
//! - **OperatorCube**: 5D-Hypercube node with operator basis and resonance state
//! - **ResonantTransition**: Directed edge representing state transitions
//! - **DualGateMerkaba**: Mirror symmetry consensus for cube validation
//! - **Cubechain**: The complete hypergraph ledger structure

use crate::signature::Signature5D;
use crate::operator::Operator;
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};
use sha2::{Sha512, Digest};
use uuid::Uuid;
use std::collections::HashMap;

/// Operator basis types for cube transformations
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Hash)]
pub enum OperatorBasis {
    /// Double-Kick symplectic impulse; initiates cube transitions
    DK,
    /// Wave-Transform operator; mediates ψ↔ρ exchanges
    WT,
    /// Phase-Integrator; maintains temporal coherence
    PI,
    /// Swap-Operator; performs simplex reflection and path inversion
    SW,
}

impl OperatorBasis {
    /// Get all operator basis types
    pub fn all() -> Vec<OperatorBasis> {
        vec![
            OperatorBasis::DK,
            OperatorBasis::WT,
            OperatorBasis::PI,
            OperatorBasis::SW,
        ]
    }

    /// Get operator name as string
    pub fn name(&self) -> &'static str {
        match self {
            OperatorBasis::DK => "Double-Kick",
            OperatorBasis::WT => "Wave-Transform",
            OperatorBasis::PI => "Phase-Integrator",
            OperatorBasis::SW => "Swap-Operator",
        }
    }

    /// Get operator coefficient for resonance calculation
    pub fn coefficient(&self) -> f64 {
        match self {
            OperatorBasis::DK => 1.0,
            OperatorBasis::WT => 0.8,
            OperatorBasis::PI => 0.9,
            OperatorBasis::SW => 0.7,
        }
    }
}

/// 5D-Hypercube operator node in the Cubechain
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorCube {
    /// Unique cube identifier
    pub id: Uuid,
    /// 5D signature (ψ, ρ, ω, χ, η)
    pub signature: Signature5D,
    /// Operator basis composition
    pub operator_basis: HashMap<OperatorBasis, f64>,
    /// β-symmetry coefficient
    pub beta_symmetry: f64,
    /// S-field (entropy) value
    pub s_field: f64,
    /// Proof-of-Resonance score
    pub proof_score: f64,
    /// Antipode cube ID in dual simplex (Merkaba mirror)
    pub antipode_id: Option<Uuid>,
    /// Generation/depth in cubechain
    pub generation: usize,
    /// Parent cube IDs
    pub parents: Vec<Uuid>,
    /// Timestamp of cube creation
    pub created_at: chrono::DateTime<chrono::Utc>,
}

impl OperatorCube {
    /// Create a new operator cube with given signature
    pub fn new(signature: Signature5D) -> Self {
        let mut operator_basis = HashMap::new();
        operator_basis.insert(OperatorBasis::DK, 0.25);
        operator_basis.insert(OperatorBasis::WT, 0.25);
        operator_basis.insert(OperatorBasis::PI, 0.25);
        operator_basis.insert(OperatorBasis::SW, 0.25);

        Self {
            id: Uuid::new_v4(),
            signature,
            operator_basis,
            beta_symmetry: 1.0,
            s_field: 0.0,
            proof_score: 0.0,
            antipode_id: None,
            generation: 0,
            parents: Vec::new(),
            created_at: chrono::Utc::now(),
        }
    }

    /// Create cube from existing operator
    pub fn from_operator(operator: &Operator) -> Self {
        let mut cube = Self::new(operator.signature.clone());
        cube.generation = operator.generation;
        if let Some(parent_id) = operator.parent {
            cube.parents.push(parent_id);
        }
        cube
    }

    /// Set operator basis composition
    pub fn set_operator_basis(&mut self, basis: OperatorBasis, weight: f64) {
        self.operator_basis.insert(basis, weight);
    }

    /// Calculate resonance-invariant hash over ψ,ρ,ω,β,S fields
    pub fn resonance_hash(&self) -> String {
        let mut hasher = Sha512::new();
        
        // Include signature components
        hasher.update(self.signature.psi.to_le_bytes());
        hasher.update(self.signature.rho.to_le_bytes());
        hasher.update(self.signature.omega.to_le_bytes());
        hasher.update(self.signature.chi.to_le_bytes());
        hasher.update(self.signature.eta.to_le_bytes());
        
        // Include beta symmetry and S-field
        hasher.update(self.beta_symmetry.to_le_bytes());
        hasher.update(self.s_field.to_le_bytes());
        
        // Include operator basis coefficients (sorted for determinism)
        let mut basis_vec: Vec<_> = self.operator_basis.iter().collect();
        basis_vec.sort_by_key(|(basis, _)| format!("{:?}", basis));
        for (basis, weight) in basis_vec {
            hasher.update(format!("{:?}", basis).as_bytes());
            hasher.update(weight.to_le_bytes());
        }
        
        format!("{:x}", hasher.finalize())
    }

    /// Check if cube satisfies entropy limit
    pub fn is_stable(&self, entropy_limit: f64) -> bool {
        self.s_field.abs() < entropy_limit
    }

    /// Calculate total operator weight
    pub fn total_operator_weight(&self) -> f64 {
        self.operator_basis.values().sum()
    }
}

/// Directed edge representing resonant transition between cubes
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResonantTransition {
    /// Unique transition identifier
    pub id: Uuid,
    /// Source cube ID
    pub from_cube: Uuid,
    /// Target cube ID
    pub to_cube: Uuid,
    /// Dominant operator basis for this transition
    pub operator: OperatorBasis,
    /// Resonance amplitude
    pub resonance_amplitude: f64,
    /// Phase difference φ_next - φ_current
    pub phase_delta: f64,
    /// Energy change ΔH
    pub energy_delta: f64,
    /// Entropy change ΔS
    pub entropy_delta: f64,
    /// Is this transition validated?
    pub validated: bool,
}

impl ResonantTransition {
    /// Create new transition between cubes
    pub fn new(from: Uuid, to: Uuid, operator: OperatorBasis) -> Self {
        Self {
            id: Uuid::new_v4(),
            from_cube: from,
            to_cube: to,
            operator,
            resonance_amplitude: 0.0,
            phase_delta: 0.0,
            energy_delta: 0.0,
            entropy_delta: 0.0,
            validated: false,
        }
    }

    /// Validate transition using proof-of-resonance criteria
    pub fn validate(&mut self, epsilon: f64) -> bool {
        // Check resonance amplitude
        if self.resonance_amplitude < epsilon {
            return false;
        }

        // Check energy conservation
        if self.energy_delta.abs() > epsilon {
            return false;
        }

        // Check entropy decrease (required for stability)
        if self.entropy_delta > 0.0 {
            return false;
        }

        self.validated = true;
        true
    }
}

/// Dual-Gate Merkaba configuration for symmetric consensus
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DualGateMerkaba {
    /// φ₁ + φ₂ = constant for dual gate balance
    pub phase_constant: f64,
    /// Symmetry tolerance
    pub symmetry_tolerance: f64,
    /// Phase variance threshold
    pub phase_variance_threshold: f64,
}

impl Default for DualGateMerkaba {
    fn default() -> Self {
        Self {
            phase_constant: std::f64::consts::PI * 2.0,
            symmetry_tolerance: 1e-5,
            phase_variance_threshold: 1e-4,
        }
    }
}

impl DualGateMerkaba {
    /// Validate dual-gate symmetry between cube pair
    pub fn validate_symmetry(&self, cube_a: &OperatorCube, cube_b: &OperatorCube) -> bool {
        // Calculate phase values from signatures
        let phi_1 = (cube_a.signature.psi + cube_a.signature.rho).atan2(cube_a.signature.omega);
        let phi_2 = (cube_b.signature.psi + cube_b.signature.rho).atan2(cube_b.signature.omega);
        
        // Check φ₁ + φ₂ = constant
        let phase_sum = phi_1 + phi_2;
        if (phase_sum - self.phase_constant).abs() > self.symmetry_tolerance {
            return false;
        }

        // Check Ψᵢ ⊗ Ψⱼ symmetry (tensor product resonance)
        let res_a = crate::resonance_kernel::resonance(&cube_a.signature);
        let res_b = crate::resonance_kernel::resonance(&cube_b.signature);
        let tensor_product = res_a * res_b;
        
        // Symmetry should be within tolerance
        if (tensor_product - 1.0).abs() > self.symmetry_tolerance {
            return false;
        }

        true
    }

    /// Create antipode cube in dual simplex
    pub fn create_antipode(&self, cube: &OperatorCube) -> OperatorCube {
        // Mirror signature through phase inversion
        let antipode_sig = Signature5D::new(
            1.0 - cube.signature.psi,
            1.0 - cube.signature.rho,
            cube.signature.omega, // omega is symmetric
            1.0 - cube.signature.chi,
            cube.signature.eta, // eta preserved
        );

        let mut antipode = OperatorCube::new(antipode_sig);
        antipode.beta_symmetry = cube.beta_symmetry;
        antipode.s_field = -cube.s_field; // Entropy sign flip
        antipode.generation = cube.generation;
        antipode.antipode_id = Some(cube.id);
        
        // Invert operator basis using SW operator
        for (basis, weight) in &cube.operator_basis {
            antipode.operator_basis.insert(*basis, 1.0 - weight);
        }

        antipode
    }
}

/// Metatron Cube 13-Node base topology
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetatronNode {
    /// Node index (0-12)
    pub index: usize,
    /// Local 5D-HDAG subgraph cubes
    pub local_cubes: Vec<Uuid>,
    /// Position in 3D space (for visualization)
    pub position: [f64; 3],
}

impl MetatronNode {
    /// Create new Metatron node
    pub fn new(index: usize) -> Self {
        // Position nodes in Metatron Cube geometry
        let position = Self::calculate_position(index);
        Self {
            index,
            local_cubes: Vec::new(),
            position,
        }
    }

    /// Calculate 3D position for node based on Metatron Cube geometry
    fn calculate_position(index: usize) -> [f64; 3] {
        // Central node
        if index == 0 {
            return [0.0, 0.0, 0.0];
        }
        
        // 6 face centers of cube
        if index <= 6 {
            let i = index - 1;
            let angle = (i as f64) * std::f64::consts::PI / 3.0;
            return [angle.cos(), angle.sin(), 0.0];
        }
        
        // 6 vertices of octahedron
        let i = index - 7;
        let angle = (i as f64) * std::f64::consts::PI / 3.0;
        let z = if i % 2 == 0 { 1.0 } else { -1.0 };
        [angle.cos() * 0.7, angle.sin() * 0.7, z * 0.7]
    }

    /// Add cube to local HDAG
    pub fn add_cube(&mut self, cube_id: Uuid) {
        self.local_cubes.push(cube_id);
    }
}

/// The complete Cubechain hypergraph ledger
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Cubechain {
    /// All operator cubes indexed by ID
    pub cubes: HashMap<Uuid, OperatorCube>,
    /// All transitions indexed by ID
    pub transitions: HashMap<Uuid, ResonantTransition>,
    /// Metatron topology (13 nodes)
    pub metatron_nodes: Vec<MetatronNode>,
    /// Dual-Gate Merkaba consensus engine
    pub dual_gate: DualGateMerkaba,
    /// Genesis cube ID (root of chain)
    pub genesis_cube: Option<Uuid>,
    /// Configuration parameters
    pub config: CubechainConfig,
}

/// Cubechain configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CubechainConfig {
    /// Proof-of-Resonance tolerance ε
    pub epsilon: f64,
    /// Entropy limit for cube stability
    pub entropy_limit: f64,
    /// Phase variance limit
    pub phase_variance_limit: f64,
    /// Energy tolerance
    pub energy_tolerance: f64,
    /// Maximum parallel spawns during evolution
    pub max_parallel_spawns: usize,
    /// Feedback gain for resonance dynamics
    pub feedback_gain: f64,
}

impl Default for CubechainConfig {
    fn default() -> Self {
        Self {
            epsilon: 1e-5,
            entropy_limit: 1e-3,
            phase_variance_limit: 1e-4,
            energy_tolerance: 1e-5,
            max_parallel_spawns: 4,
            feedback_gain: 0.02,
        }
    }
}

impl Cubechain {
    /// Create new Cubechain with default configuration
    pub fn new() -> Self {
        Self::with_config(CubechainConfig::default())
    }

    /// Create Cubechain with custom configuration
    pub fn with_config(config: CubechainConfig) -> Self {
        // Initialize 13 Metatron nodes
        let metatron_nodes: Vec<_> = (0..13)
            .map(|i| MetatronNode::new(i))
            .collect();

        Self {
            cubes: HashMap::new(),
            transitions: HashMap::new(),
            metatron_nodes,
            dual_gate: DualGateMerkaba::default(),
            genesis_cube: None,
            config,
        }
    }

    /// Initialize genesis cube and its antipode
    pub fn bootstrap_genesis(&mut self, initial_signature: Signature5D) -> Result<Uuid> {
        // Create genesis cube
        let mut genesis = OperatorCube::new(initial_signature);
        genesis.generation = 0;
        let genesis_id = genesis.id;

        // Create antipode in dual simplex
        let antipode = self.dual_gate.create_antipode(&genesis);
        let antipode_id = antipode.id;

        // Link antipodes
        genesis.antipode_id = Some(antipode_id);

        // Add to first Metatron node
        self.metatron_nodes[0].add_cube(genesis_id);
        self.metatron_nodes[6].add_cube(antipode_id); // Opposite node

        // Store cubes
        self.cubes.insert(genesis_id, genesis);
        self.cubes.insert(antipode_id, antipode);
        self.genesis_cube = Some(genesis_id);

        Ok(genesis_id)
    }

    /// Add new cube to the chain
    pub fn add_cube(&mut self, cube: OperatorCube, node_index: usize) -> Result<()> {
        if node_index >= self.metatron_nodes.len() {
            return Err(MogeError::InvalidInput(
                format!("Invalid node index: {}", node_index)
            ));
        }

        let cube_id = cube.id;
        self.metatron_nodes[node_index].add_cube(cube_id);
        self.cubes.insert(cube_id, cube);
        Ok(())
    }

    /// Create transition between cubes
    pub fn create_transition(
        &mut self,
        from_id: Uuid,
        to_id: Uuid,
        operator: OperatorBasis,
    ) -> Result<Uuid> {
        // Verify cubes exist
        let from_cube = self.cubes.get(&from_id)
            .ok_or_else(|| MogeError::InvalidInput("From cube not found".to_string()))?;
        let to_cube = self.cubes.get(&to_id)
            .ok_or_else(|| MogeError::InvalidInput("To cube not found".to_string()))?;

        // Calculate transition properties
        let mut transition = ResonantTransition::new(from_id, to_id, operator);
        
        // Resonance amplitude
        let res_from = crate::resonance_kernel::resonance(&from_cube.signature);
        let res_to = crate::resonance_kernel::resonance(&to_cube.signature);
        transition.resonance_amplitude = (res_from * res_to).sqrt();

        // Energy delta
        transition.energy_delta = res_to - res_from;

        // Entropy delta
        transition.entropy_delta = to_cube.s_field - from_cube.s_field;

        // Validate transition
        transition.validate(self.config.epsilon);

        let transition_id = transition.id;
        self.transitions.insert(transition_id, transition);

        Ok(transition_id)
    }

    /// Validate cube-to-cube invariance and adjacency
    pub fn validate_adjacency(&self, cube_a_id: Uuid, cube_b_id: Uuid) -> bool {
        let cube_a = match self.cubes.get(&cube_a_id) {
            Some(c) => c,
            None => return false,
        };
        let cube_b = match self.cubes.get(&cube_b_id) {
            Some(c) => c,
            None => return false,
        };

        // Check Proof-of-Resonance
        let res_a = crate::resonance_kernel::resonance(&cube_a.signature);
        let res_b = crate::resonance_kernel::resonance(&cube_b.signature);
        let resonance_diff = (res_a - res_b).abs();
        
        if resonance_diff >= self.config.epsilon {
            return false;
        }

        // Check β-symmetry conservation
        let beta_diff = (cube_a.beta_symmetry - cube_b.beta_symmetry).abs();
        if beta_diff >= self.config.epsilon {
            return false;
        }

        true
    }

    /// Spawn new cube from stable parent (evolution mechanism)
    pub fn spawn_cube(&mut self, parent_id: Uuid, operator: OperatorBasis) -> Result<Uuid> {
        let parent = self.cubes.get(&parent_id)
            .ok_or_else(|| MogeError::InvalidInput("Parent cube not found".to_string()))?
            .clone();

        // Check parent stability
        if !parent.is_stable(self.config.entropy_limit) {
            return Err(MogeError::InvalidState("Parent cube not stable enough to spawn".to_string()));
        }

        // Create mutated signature based on operator
        let mutation_strength = 0.05; // Small perturbation
        let new_sig = match operator {
            OperatorBasis::DK => {
                // Double-kick: boost psi and rho
                Signature5D::new(
                    (parent.signature.psi + mutation_strength).min(1.0),
                    (parent.signature.rho + mutation_strength).min(1.0),
                    parent.signature.omega,
                    parent.signature.chi,
                    parent.signature.eta,
                )
            }
            OperatorBasis::WT => {
                // Wave-transform: exchange psi and rho
                Signature5D::new(
                    parent.signature.rho,
                    parent.signature.psi,
                    parent.signature.omega,
                    parent.signature.chi,
                    parent.signature.eta,
                )
            }
            OperatorBasis::PI => {
                // Phase-integrator: adjust chi
                Signature5D::new(
                    parent.signature.psi,
                    parent.signature.rho,
                    parent.signature.omega,
                    (parent.signature.chi + mutation_strength).min(1.0),
                    parent.signature.eta,
                )
            }
            OperatorBasis::SW => {
                // Swap: invert coordinates
                Signature5D::new(
                    1.0 - parent.signature.psi,
                    parent.signature.rho,
                    parent.signature.omega,
                    parent.signature.chi,
                    1.0 - parent.signature.eta,
                )
            }
        };

        // Create new cube
        let mut new_cube = OperatorCube::new(new_sig);
        new_cube.generation = parent.generation + 1;
        new_cube.parents.push(parent_id);
        new_cube.beta_symmetry = parent.beta_symmetry;
        
        // Inherit operator basis with small mutation
        for (basis, weight) in &parent.operator_basis {
            let mutated_weight = if *basis == operator {
                (weight + mutation_strength).min(1.0)
            } else {
                *weight
            };
            new_cube.set_operator_basis(*basis, mutated_weight);
        }

        let new_cube_id = new_cube.id;
        
        // Find node for new cube (round-robin or by topology)
        let node_index = (new_cube.generation % 13).min(12);
        self.add_cube(new_cube, node_index)?;

        // Create transition
        self.create_transition(parent_id, new_cube_id, operator)?;

        Ok(new_cube_id)
    }

    /// Get total number of cubes
    pub fn cube_count(&self) -> usize {
        self.cubes.len()
    }

    /// Get total number of validated transitions
    pub fn validated_transition_count(&self) -> usize {
        self.transitions.values().filter(|t| t.validated).count()
    }

    /// Calculate mean entropy across all cubes
    pub fn mean_entropy(&self) -> f64 {
        if self.cubes.is_empty() {
            return 0.0;
        }
        let total: f64 = self.cubes.values().map(|c| c.s_field.abs()).sum();
        total / self.cubes.len() as f64
    }

    /// Get stability index (fraction of stable cubes)
    pub fn stability_index(&self) -> f64 {
        if self.cubes.is_empty() {
            return 0.0;
        }
        let stable_count = self.cubes.values()
            .filter(|c| c.is_stable(self.config.entropy_limit))
            .count();
        stable_count as f64 / self.cubes.len() as f64
    }
}

impl Default for Cubechain {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_operator_basis() {
        let basis = OperatorBasis::DK;
        assert_eq!(basis.name(), "Double-Kick");
        assert_eq!(basis.coefficient(), 1.0);

        let all = OperatorBasis::all();
        assert_eq!(all.len(), 4);
    }

    #[test]
    fn test_operator_cube_creation() {
        let sig = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);
        let cube = OperatorCube::new(sig);
        
        assert_eq!(cube.generation, 0);
        assert_eq!(cube.operator_basis.len(), 4);
        assert_eq!(cube.total_operator_weight(), 1.0);
    }

    #[test]
    fn test_resonance_hash() {
        let sig = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);
        let cube = OperatorCube::new(sig);
        
        let hash1 = cube.resonance_hash();
        let hash2 = cube.resonance_hash();
        
        // Same cube should produce same hash
        assert_eq!(hash1, hash2);
        assert_eq!(hash1.len(), 128); // SHA-512 hex length
    }

    #[test]
    fn test_cubechain_bootstrap() {
        let mut chain = Cubechain::new();
        let sig = Signature5D::new(0.6, 0.7, 0.8, 0.5, 0.3);
        
        let genesis_id = chain.bootstrap_genesis(sig).unwrap();
        
        assert_eq!(chain.cube_count(), 2); // Genesis + antipode
        assert_eq!(chain.genesis_cube, Some(genesis_id));
        
        let genesis = chain.cubes.get(&genesis_id).unwrap();
        assert!(genesis.antipode_id.is_some());
    }

    #[test]
    fn test_dual_gate_symmetry() {
        let dual_gate = DualGateMerkaba::default();
        let sig = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);
        
        let cube_a = OperatorCube::new(sig);
        let cube_b = dual_gate.create_antipode(&cube_a);
        
        // Antipode should have inverted signature components
        assert!((cube_b.signature.psi - (1.0 - cube_a.signature.psi)).abs() < 1e-10);
        assert!((cube_b.s_field + cube_a.s_field).abs() < 1e-10);
    }

    #[test]
    fn test_cube_spawning() {
        let mut chain = Cubechain::new();
        let sig = Signature5D::new(0.6, 0.7, 0.8, 0.5, 0.3);
        let genesis_id = chain.bootstrap_genesis(sig).unwrap();
        
        // Set genesis as stable
        if let Some(genesis) = chain.cubes.get_mut(&genesis_id) {
            genesis.s_field = 0.0001; // Very low entropy
        }
        
        let spawn_result = chain.spawn_cube(genesis_id, OperatorBasis::DK);
        assert!(spawn_result.is_ok());
        
        let new_id = spawn_result.unwrap();
        let new_cube = chain.cubes.get(&new_id).unwrap();
        
        assert_eq!(new_cube.generation, 1);
        assert_eq!(new_cube.parents[0], genesis_id);
    }

    #[test]
    fn test_metatron_nodes() {
        let chain = Cubechain::new();
        assert_eq!(chain.metatron_nodes.len(), 13);
        
        // Check central node
        let central = &chain.metatron_nodes[0];
        assert_eq!(central.position, [0.0, 0.0, 0.0]);
    }
}
