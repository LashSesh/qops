//! Phase 5: Reporting and Visualization Module
//!
//! Generates comprehensive reports, visualizations, and summaries
//! for the MOGE system integrity audit.

use crate::verification::{
    VerificationSuite, SystemStatus,
    ResonanceVarianceEntry, MciLyapunovEntry, GabrielColonyMapEntry,
    SemanticDriftEntry, thresholds,
};
use crate::imhk::SystemStats;
use std::fs;
use std::path::Path;
use crate::error::Result;

/// Report generator for Phase 5 verification
pub struct ReportGenerator;

impl ReportGenerator {
    /// Generate comprehensive system integrity report (Markdown)
    pub fn generate_system_report(
        suite: &VerificationSuite,
        system_stats: &SystemStats,
        output_path: &Path,
    ) -> Result<()> {
        let metrics = suite.metrics.as_ref()
            .expect("Metrics must be aggregated before generating report");

        let mut report = String::new();

        // Header
        report.push_str("# MOGE System Integrity Report\n\n");
        report.push_str("## Phase 5: Final Verification and System Integrity Audit\n\n");

        // Use simple timestamp
        let timestamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs();
        report.push_str(&format!("**Timestamp:** {} (Unix epoch)\n\n", timestamp));
        report.push_str(&format!("**System Status:** {:?}\n\n", metrics.system_status));

        // Executive Summary
        report.push_str("## Executive Summary\n\n");
        report.push_str(&format!("Overall System Stability: **{:.2}%**\n\n", metrics.overall_stability * 100.0));

        let status_description = match metrics.system_status {
            SystemStatus::Stable => "✓ System is **STABLE** and ready for deployment.",
            SystemStatus::NeedsCalibration => "⚠ System requires calibration before deployment.",
            SystemStatus::Failed => "✗ System has failed verification criteria.",
        };
        report.push_str(&format!("{}\n\n", status_description));

        // System State
        report.push_str("## System State\n\n");
        report.push_str(&format!("- **Iteration:** {}\n", system_stats.iteration));
        report.push_str(&format!("- **Total Operators:** {}\n", system_stats.total_operators));
        report.push_str(&format!("- **Stable Operators:** {}\n", system_stats.stable_operators));
        report.push_str(&format!("- **Semantic Nodes:** {}\n", system_stats.semantic_nodes));
        report.push_str(&format!("- **Equilibrium Rate:** {:.4}\n\n", system_stats.equilibrium_rate));

        // Verification Results
        report.push_str("## Verification Results\n\n");

        // 1. Resonance Stability
        report.push_str("### 1. Resonance Kernel Stability\n\n");
        report.push_str(&format!("- **Equilibrium Score:** {:.6}\n", metrics.resonance_equilibrium_score));
        report.push_str(&format!("- **Pass Rate:** {:.2}%\n", metrics.resonance_pass_rate * 100.0));
        report.push_str(&format!("- **Mean Variance:** {:.6}\n", metrics.mean_variance));
        report.push_str(&format!("- **Threshold:** < {:.6}\n", thresholds::RESONANCE_VARIANCE_THRESHOLD));
        report.push_str(&format!("- **Status:** {}\n\n",
            if metrics.resonance_pass_rate >= thresholds::METRICS_PASS_RATE {
                "✓ PASS"
            } else {
                "✗ FAIL"
            }
        ));

        // 2. Dual Consensus
        report.push_str("### 2. Dual-Merkaba Consensus\n\n");
        report.push_str(&format!("- **Mean MCI:** {:.4}\n", metrics.mean_mci));
        report.push_str(&format!("- **Lyapunov Stable Rate:** {:.2}%\n", metrics.lyapunov_stable_rate * 100.0));
        report.push_str(&format!("- **MCI Threshold:** ≥ {:.2}\n", thresholds::MCI_THRESHOLD));
        report.push_str(&format!("- **Lyapunov Bound:** < {:.3}\n", thresholds::LYAPUNOV_BOUND));
        report.push_str(&format!("- **Status:** {}\n\n",
            if metrics.mean_mci >= thresholds::MCI_THRESHOLD &&
               metrics.lyapunov_stable_rate >= thresholds::METRICS_PASS_RATE {
                "✓ PASS"
            } else {
                "✗ FAIL"
            }
        ));

        // 3. Gabriel Colony Integrity
        report.push_str("### 3. Gabriel Cell Colony Integrity\n\n");
        report.push_str(&format!("- **Colony Efficiency:** {:.2}%\n", metrics.colony_efficiency * 100.0));
        report.push_str(&format!("- **Mean Colony Size:** {:.1}\n", metrics.mean_colony_size));
        report.push_str(&format!("- **Mean Connectivity:** {:.4}\n", metrics.mean_connectivity));
        report.push_str(&format!("- **Size Threshold:** ≥ {}\n", thresholds::MIN_COLONY_SIZE));
        report.push_str(&format!("- **Connectivity Threshold:** ≥ {:.2}\n", thresholds::MIN_CONNECTIVITY));
        report.push_str(&format!("- **Status:** {}\n\n",
            if metrics.colony_efficiency >= 0.8 {
                "✓ PASS"
            } else {
                "✗ FAIL"
            }
        ));

        // 4. Semantic Integrity
        report.push_str("### 4. Semantic Mapping Integrity\n\n");
        report.push_str(&format!("- **Mapping Fidelity:** {:.4}%\n", metrics.mapping_fidelity * 100.0));
        report.push_str(&format!("- **Semantic Integrity:** {:.4}\n", metrics.semantic_integrity));
        report.push_str(&format!("- **Error Threshold:** < {:.3}\n", thresholds::SEMANTIC_ERROR_THRESHOLD));
        report.push_str(&format!("- **Status:** {}\n\n",
            if metrics.mapping_fidelity >= 0.999 {
                "✓ PASS"
            } else {
                "✗ FAIL"
            }
        ));

        // 5. Ledger Audit
        report.push_str("### 5. Ledger Integrity Audit\n\n");
        report.push_str(&format!("- **Audit Purity:** {:.4}%\n", metrics.audit_purity * 100.0));
        report.push_str(&format!("- **Checksum Accuracy:** {:.4}%\n", metrics.checksum_accuracy * 100.0));
        report.push_str(&format!("- **Deviation Threshold:** < {:.5}\n", thresholds::LEDGER_CHECKSUM_DEVIATION));
        report.push_str(&format!("- **Status:** {}\n\n",
            if metrics.checksum_accuracy >= 0.999 {
                "✓ PASS"
            } else {
                "✗ FAIL"
            }
        ));

        // Cluster Statistics
        report.push_str("## Gabriel Cluster Statistics\n\n");
        report.push_str(&format!("- **Total Cells:** {}\n", system_stats.cluster_stats.total_cells));
        report.push_str(&format!("- **Active Cells:** {}\n", system_stats.cluster_stats.active_cells));
        report.push_str(&format!("- **Average Activity:** {:.4}\n", system_stats.cluster_stats.avg_activity));
        report.push_str(&format!("- **Total Edges:** {}\n", system_stats.cluster_stats.total_edges));
        report.push_str(&format!("- **Strong Edges:** {}\n", system_stats.cluster_stats.strong_edges));
        report.push_str(&format!("- **Generation:** {}\n\n", system_stats.cluster_stats.generation));

        // Consensus Statistics
        report.push_str("## Consensus Engine Statistics\n\n");
        report.push_str(&format!("- **Total Attempts:** {}\n", system_stats.consensus_stats.total_attempts));
        report.push_str(&format!("- **Successful:** {}\n", system_stats.consensus_stats.successful));
        report.push_str(&format!("- **Success Rate:** {:.2}%\n", system_stats.consensus_stats.success_rate * 100.0));
        report.push_str(&format!("- **Average MCI:** {:.4}\n", system_stats.consensus_stats.avg_mci));
        report.push_str(&format!("- **Average Lyapunov:** {:.6}\n\n", system_stats.consensus_stats.avg_lyapunov));

        // Certification
        report.push_str("## System Certification\n\n");
        if metrics.system_status == SystemStatus::Stable {
            report.push_str("```\n");
            report.push_str("╔═══════════════════════════════════════════════════════╗\n");
            report.push_str("║                                                       ║\n");
            report.push_str("║   KYBERNETIC ASIC MIRROR CERTIFICATION                ║\n");
            report.push_str("║                                                       ║\n");
            report.push_str("║   System: IMHK–Gabriel–DMK Unified Kernel            ║\n");
            report.push_str("║   Status: STABLE                                      ║\n");
            report.push_str(&format!("║   Overall Stability: {:.2}%                           ║\n", metrics.overall_stability * 100.0));
            report.push_str("║                                                       ║\n");
            report.push_str("║   ✓ Resonance Equilibrium Verified                   ║\n");
            report.push_str("║   ✓ Mirror Consensus Validated                       ║\n");
            report.push_str("║   ✓ Colony Integrity Confirmed                       ║\n");
            report.push_str("║   ✓ Semantic Coherence Maintained                    ║\n");
            report.push_str("║   ✓ Ledger Audit Complete                            ║\n");
            report.push_str("║                                                       ║\n");
            report.push_str("║   Ready for Deployment                                ║\n");
            report.push_str("║                                                       ║\n");
            report.push_str("╚═══════════════════════════════════════════════════════╝\n");
            report.push_str("```\n\n");
        } else {
            report.push_str(&format!("System requires further calibration. Current stability: {:.2}%\n\n",
                metrics.overall_stability * 100.0));
        }

        // Recommendations
        report.push_str("## Recommendations\n\n");
        if metrics.resonance_pass_rate < thresholds::METRICS_PASS_RATE {
            report.push_str("- ⚠ Increase resonance feedback strength to improve equilibrium convergence\n");
        }
        if metrics.mean_mci < thresholds::MCI_THRESHOLD {
            report.push_str("- ⚠ Adjust Merkaba configuration to improve mirror coherence\n");
        }
        if metrics.colony_efficiency < 0.8 {
            report.push_str("- ⚠ Optimize Gabriel cell parameters for better colony formation\n");
        }
        if metrics.mapping_fidelity < 0.999 {
            report.push_str("- ⚠ Review semantic mapping precision and entropy calculations\n");
        }
        if metrics.system_status == SystemStatus::Stable {
            report.push_str("- ✓ System is operating within all specified parameters\n");
            report.push_str("- ✓ No calibration required\n");
        }
        report.push_str("\n");

        // Footer
        report.push_str("---\n\n");
        report.push_str("*Generated by MOGE Phase 5 Verification System*\n");
        report.push_str(&format!("*MOGE Version: {}*\n", env!("CARGO_PKG_VERSION")));

        // Write report
        fs::write(output_path, report)?;
        println!("✓ System integrity report written to: {}", output_path.display());

        Ok(())
    }

    /// Generate resonance variance profile (CSV)
    pub fn generate_resonance_profile_csv(
        profile: &[ResonanceVarianceEntry],
        output_path: &Path,
    ) -> Result<()> {
        let mut csv = String::new();

        // Header
        csv.push_str("cycle,psi_mean,rho_mean,omega_mean,chi_mean,eta_mean,variance,invariant_delta\n");

        // Data rows
        for entry in profile {
            csv.push_str(&format!(
                "{},{:.6},{:.6},{:.6},{:.6},{:.6},{:.6},{:.6}\n",
                entry.cycle,
                entry.psi_mean,
                entry.rho_mean,
                entry.omega_mean,
                entry.chi_mean,
                entry.eta_mean,
                entry.variance,
                entry.invariant_delta
            ));
        }

        fs::write(output_path, csv)?;
        println!("✓ Resonance variance profile written to: {}", output_path.display());

        Ok(())
    }

    /// Generate MCI and Lyapunov log (JSON)
    pub fn generate_mci_lyapunov_log(
        log: &[MciLyapunovEntry],
        output_path: &Path,
    ) -> Result<()> {
        let json = serde_json::to_string_pretty(log)?;
        fs::write(output_path, json)?;
        println!("✓ MCI/Lyapunov log written to: {}", output_path.display());

        Ok(())
    }

    /// Generate Gabriel colony map (GraphViz DOT format)
    pub fn generate_gabriel_colony_map(
        colonies: &[GabrielColonyMapEntry],
        output_path: &Path,
    ) -> Result<()> {
        let mut dot = String::new();

        dot.push_str("digraph GabrielColonies {\n");
        dot.push_str("  rankdir=LR;\n");
        dot.push_str("  node [shape=circle];\n\n");

        for colony in colonies {
            let color = if colony.connectivity >= thresholds::MIN_CONNECTIVITY {
                "green"
            } else {
                "orange"
            };

            let _size_category = if colony.size >= thresholds::MIN_COLONY_SIZE {
                "large"
            } else {
                "small"
            };

            dot.push_str(&format!(
                "  colony_{} [label=\"Colony {}\\nSize: {}\\nConn: {:.2}\", color={}, style=filled, fillcolor=lightblue];\n",
                colony.colony_id,
                colony.colony_id,
                colony.size,
                colony.connectivity,
                color
            ));
        }

        dot.push_str("}\n");

        fs::write(output_path, dot)?;
        println!("✓ Gabriel colony map written to: {}", output_path.display());

        Ok(())
    }

    /// Generate semantic drift summary (TXT)
    pub fn generate_semantic_drift_summary(
        drift: &[SemanticDriftEntry],
        output_path: &Path,
    ) -> Result<()> {
        let mut summary = String::new();

        summary.push_str("=== SEMANTIC DRIFT SUMMARY ===\n\n");

        let successful = drift.iter().filter(|e| e.round_trip_successful).count();
        let total = drift.len();
        let success_rate = if total > 0 {
            successful as f64 / total as f64
        } else {
            0.0
        };

        summary.push_str(&format!("Total Tests: {}\n", total));
        summary.push_str(&format!("Successful Round-trips: {}\n", successful));
        summary.push_str(&format!("Success Rate: {:.4}%\n\n", success_rate * 100.0));

        let mean_error = if !drift.is_empty() {
            drift.iter().map(|e| e.signature_error).sum::<f64>() / drift.len() as f64
        } else {
            0.0
        };

        let mean_entropy_stability = if !drift.is_empty() {
            drift.iter().map(|e| e.entropy_stability).sum::<f64>() / drift.len() as f64
        } else {
            0.0
        };

        summary.push_str(&format!("Mean Signature Error: {:.6}\n", mean_error));
        summary.push_str(&format!("Mean Entropy Stability: {:.6}\n\n", mean_entropy_stability));

        summary.push_str("Threshold: < 0.001\n");
        summary.push_str(&format!("Status: {}\n\n",
            if success_rate >= 0.999 { "PASS" } else { "FAIL" }
        ));

        summary.push_str("Sample Drift Entries:\n");
        summary.push_str(&"-".repeat(60));
        summary.push_str("\n");

        for entry in drift.iter().take(20) {
            summary.push_str(&format!(
                "Test {}: Error={:.6}, Entropy={:.4}, Success={}\n",
                entry.test_index,
                entry.signature_error,
                entry.entropy_stability,
                if entry.round_trip_successful { "✓" } else { "✗" }
            ));
        }

        fs::write(output_path, summary)?;
        println!("✓ Semantic drift summary written to: {}", output_path.display());

        Ok(())
    }

    /// Generate all reports
    pub fn generate_all_reports(
        suite: &VerificationSuite,
        system_stats: &SystemStats,
        output_dir: &Path,
    ) -> Result<()> {
        // Create output directory if it doesn't exist
        fs::create_dir_all(output_dir)?;

        println!("\nGenerating verification reports...\n");

        // System integrity report
        Self::generate_system_report(
            suite,
            system_stats,
            &output_dir.join("system_integrity_report.md"),
        )?;

        // Resonance variance profile
        Self::generate_resonance_profile_csv(
            &suite.resonance_profile,
            &output_dir.join("resonance_variance_profile.csv"),
        )?;

        // MCI/Lyapunov log
        Self::generate_mci_lyapunov_log(
            &suite.mci_lyapunov_log,
            &output_dir.join("mci_lyapunov_log.json"),
        )?;

        // Gabriel colony map
        Self::generate_gabriel_colony_map(
            &suite.gabriel_colony_map,
            &output_dir.join("gabriel_colony_map_final.gv"),
        )?;

        // Semantic drift summary
        Self::generate_semantic_drift_summary(
            &suite.semantic_drift,
            &output_dir.join("semantic_drift_summary.txt"),
        )?;

        println!("\n✓ All reports generated successfully in: {}\n", output_dir.display());

        Ok(())
    }
}
