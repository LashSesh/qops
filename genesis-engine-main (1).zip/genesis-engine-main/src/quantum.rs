//! Quantum Simulator Integration Module
//!
//! Provides quantum-inspired computation for MOGE:
//! - Quantum-inspired traversal strategies
//! - Superposition of traversal paths
//! - Quantum annealing for optimization
//! - Entanglement-based graph exploration

use crate::signature::{Signature, Signature5D};
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};
use std::f64::consts::PI;

/// Quantum state representation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QuantumState {
    /// Amplitude coefficients for basis states
    pub amplitudes: Vec<Complex>,
    /// Basis state indices (node IDs)
    pub basis_states: Vec<usize>,
}

/// Complex number representation
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Complex {
    pub re: f64,
    pub im: f64,
}

impl Complex {
    pub fn new(re: f64, im: f64) -> Self {
        Self { re, im }
    }

    pub fn magnitude(&self) -> f64 {
        (self.re * self.re + self.im * self.im).sqrt()
    }

    pub fn phase(&self) -> f64 {
        self.im.atan2(self.re)
    }

    pub fn conjugate(&self) -> Self {
        Self {
            re: self.re,
            im: -self.im,
        }
    }

    pub fn multiply(&self, other: &Complex) -> Complex {
        Complex {
            re: self.re * other.re - self.im * other.im,
            im: self.re * other.im + self.im * other.re,
        }
    }
}

impl QuantumState {
    /// Create a new quantum state in equal superposition
    pub fn new(basis_states: Vec<usize>) -> Self {
        let n = basis_states.len();
        let amplitude = 1.0 / (n as f64).sqrt();
        let amplitudes = vec![Complex::new(amplitude, 0.0); n];

        Self {
            amplitudes,
            basis_states,
        }
    }

    /// Normalize the quantum state
    pub fn normalize(&mut self) {
        let norm: f64 = self.amplitudes.iter()
            .map(|a| a.magnitude() * a.magnitude())
            .sum::<f64>()
            .sqrt();

        if norm > 1e-10 {
            for amp in &mut self.amplitudes {
                amp.re /= norm;
                amp.im /= norm;
            }
        }
    }

    /// Apply a phase rotation to a specific basis state
    pub fn apply_phase(&mut self, state_idx: usize, phase: f64) -> Result<()> {
        if state_idx >= self.amplitudes.len() {
            return Err(MogeError::InvalidArtefact(
                "State index out of bounds".to_string()
            ));
        }

        let rotation = Complex::new(phase.cos(), phase.sin());
        self.amplitudes[state_idx] = self.amplitudes[state_idx].multiply(&rotation);
        Ok(())
    }

    /// Measure the quantum state (collapse to a classical state)
    pub fn measure(&self) -> usize {
        use rand::Rng;
        let mut rng = rand::thread_rng();
        let r: f64 = rng.gen();

        let mut cumulative = 0.0;
        for (i, amp) in self.amplitudes.iter().enumerate() {
            cumulative += amp.magnitude() * amp.magnitude();
            if r < cumulative {
                return self.basis_states[i];
            }
        }

        // Fallback to last state
        *self.basis_states.last().unwrap_or(&0)
    }

    /// Get probability distribution
    pub fn probabilities(&self) -> Vec<(usize, f64)> {
        self.basis_states.iter()
            .zip(self.amplitudes.iter())
            .map(|(state, amp)| (*state, amp.magnitude() * amp.magnitude()))
            .collect()
    }
}

/// Quantum-inspired traversal strategy
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QuantumTraversal {
    /// Current quantum state
    pub state: QuantumState,
    /// Temperature for annealing
    pub temperature: f64,
    /// Number of quantum steps
    pub quantum_steps: usize,
}

impl QuantumTraversal {
    /// Create a new quantum traversal
    pub fn new(initial_states: Vec<usize>, temperature: f64) -> Self {
        Self {
            state: QuantumState::new(initial_states),
            temperature,
            quantum_steps: 0,
        }
    }

    /// Perform a quantum walk step
    pub fn quantum_walk_step(&mut self, _adjacency: &[Vec<usize>]) -> Result<()> {
        // Simple quantum walk: apply phase based on node signatures
        for i in 0..self.state.basis_states.len() {
            let node = self.state.basis_states[i];

            // Calculate phase based on node properties
            let phase = (node as f64 * PI * 0.1).sin() * self.temperature;

            self.state.apply_phase(i, phase)?;
        }

        self.state.normalize();
        self.quantum_steps += 1;
        Ok(())
    }

    /// Perform quantum annealing step
    pub fn anneal_step(&mut self, energy_function: impl Fn(usize) -> f64) -> Result<()> {
        // Apply energy-based phase rotation
        for i in 0..self.state.basis_states.len() {
            let node = self.state.basis_states[i];
            let energy = energy_function(node);

            // Lower energy states get positive phase, higher energy gets negative
            let phase = -energy * self.temperature;

            self.state.apply_phase(i, phase)?;
        }

        // Reduce temperature (cooling schedule)
        self.temperature *= 0.95;

        self.state.normalize();
        Ok(())
    }

    /// Get the most probable state
    pub fn get_dominant_state(&self) -> usize {
        self.state.probabilities()
            .iter()
            .max_by(|a, b| a.1.partial_cmp(&b.1).unwrap())
            .map(|(state, _)| *state)
            .unwrap_or(0)
    }
}

/// Quantum entanglement tracker for correlated paths
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QuantumEntanglement {
    /// Entangled node pairs
    pub entangled_pairs: Vec<(usize, usize)>,
    /// Correlation strength
    pub correlation: f64,
}

impl QuantumEntanglement {
    pub fn new() -> Self {
        Self {
            entangled_pairs: Vec::new(),
            correlation: 1.0,
        }
    }

    /// Add an entangled pair
    pub fn add_pair(&mut self, node1: usize, node2: usize) {
        self.entangled_pairs.push((node1, node2));
    }

    /// Check if nodes are entangled
    pub fn are_entangled(&self, node1: usize, node2: usize) -> bool {
        self.entangled_pairs.iter().any(|(a, b)| {
            (*a == node1 && *b == node2) || (*a == node2 && *b == node1)
        })
    }

    /// Measure correlation strength
    pub fn measure_correlation(&self, node1: usize, node2: usize) -> f64 {
        if self.are_entangled(node1, node2) {
            self.correlation
        } else {
            0.0
        }
    }
}

impl Default for QuantumEntanglement {
    fn default() -> Self {
        Self::new()
    }
}

/// Quantum-inspired signature evaluation
pub fn quantum_signature_evaluation(sig: &Signature5D, temperature: f64) -> f64 {
    // Create a quantum superposition based on signature components
    let components = vec![sig.psi, sig.rho, sig.omega, sig.chi, sig.eta];

    // Calculate quantum interference
    let mut interference = 0.0;
    for i in 0..components.len() {
        for j in (i+1)..components.len() {
            let phase_diff = (components[i] - components[j]) * PI;
            interference += phase_diff.cos();
        }
    }

    // Combine classical resonance with quantum interference
    let classical = sig.resonance();
    let quantum_factor = (interference / 10.0).tanh();

    classical * (1.0 + temperature * quantum_factor)
}

/// Quantum tunneling probability for escaping local minima
pub fn tunneling_probability(
    current_resonance: f64,
    target_resonance: f64,
    temperature: f64,
) -> f64 {
    if target_resonance > current_resonance {
        // Uphill: quantum tunneling effect
        let barrier = target_resonance - current_resonance;
        (-barrier / temperature).exp()
    } else {
        // Downhill: classical transition
        1.0
    }
}

/// Quantum-inspired path exploration
pub fn quantum_path_exploration(
    paths: &[Vec<usize>],
    signatures: &[Signature5D],
    iterations: usize,
) -> Result<Vec<f64>> {
    if paths.len() != signatures.len() {
        return Err(MogeError::InvalidArtefact(
            "Paths and signatures length mismatch".to_string()
        ));
    }

    // Create quantum state over paths
    let mut state = QuantumState::new((0..paths.len()).collect());

    // Evolve quantum state based on path properties
    for _ in 0..iterations {
        for (i, sig) in signatures.iter().enumerate() {
            let quality = sig.resonance();
            let phase = quality * PI;
            state.apply_phase(i, phase)?;
        }
        state.normalize();
    }

    // Return probability distribution
    Ok(state.probabilities().iter().map(|(_, p)| *p).collect())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_complex_operations() {
        let c1 = Complex::new(3.0, 4.0);
        assert_eq!(c1.magnitude(), 5.0);

        let c2 = Complex::new(1.0, 0.0);
        let product = c1.multiply(&c2);
        assert_eq!(product.re, 3.0);
        assert_eq!(product.im, 4.0);
    }

    #[test]
    fn test_quantum_state_creation() {
        let state = QuantumState::new(vec![0, 1, 2, 3]);
        assert_eq!(state.basis_states.len(), 4);
        assert_eq!(state.amplitudes.len(), 4);

        // Check normalization
        let prob_sum: f64 = state.probabilities()
            .iter()
            .map(|(_, p)| p)
            .sum();
        assert!((prob_sum - 1.0).abs() < 1e-10);
    }

    #[test]
    fn test_quantum_measurement() {
        let state = QuantumState::new(vec![10, 20, 30]);
        let measurement = state.measure();
        assert!(vec![10, 20, 30].contains(&measurement));
    }

    #[test]
    fn test_quantum_traversal() {
        let traversal = QuantumTraversal::new(vec![0, 1, 2, 3, 4], 1.0);
        assert_eq!(traversal.quantum_steps, 0);

        let dominant = traversal.get_dominant_state();
        assert!(dominant < 5);
    }

    #[test]
    fn test_entanglement() {
        let mut entanglement = QuantumEntanglement::new();
        entanglement.add_pair(0, 5);
        entanglement.add_pair(2, 7);

        assert!(entanglement.are_entangled(0, 5));
        assert!(entanglement.are_entangled(5, 0));
        assert!(!entanglement.are_entangled(0, 7));

        let corr = entanglement.measure_correlation(0, 5);
        assert_eq!(corr, 1.0);
    }

    #[test]
    fn test_quantum_signature_evaluation() {
        let sig = Signature5D::new(0.8, 0.7, 0.6, 0.5, 0.4);
        let score = quantum_signature_evaluation(&sig, 1.0);

        // Should be close to classical resonance with quantum correction
        assert!(score > 0.0);
    }

    #[test]
    fn test_tunneling_probability() {
        // Uphill tunneling
        let p_uphill = tunneling_probability(0.5, 0.8, 0.1);
        assert!(p_uphill < 1.0);
        assert!(p_uphill > 0.0);

        // Downhill always possible
        let p_downhill = tunneling_probability(0.8, 0.5, 0.1);
        assert_eq!(p_downhill, 1.0);
    }

    #[test]
    fn test_quantum_path_exploration() {
        let paths = vec![
            vec![0, 1, 2],
            vec![0, 3, 4],
            vec![0, 5, 6],
        ];

        let signatures = vec![
            Signature5D::new(0.9, 0.8, 0.7, 0.6, 0.5),
            Signature5D::new(0.5, 0.6, 0.7, 0.8, 0.9),
            Signature5D::new(0.7, 0.7, 0.7, 0.7, 0.7),
        ];

        let result = quantum_path_exploration(&paths, &signatures, 10);
        assert!(result.is_ok());

        let probs = result.unwrap();
        assert_eq!(probs.len(), 3);

        // Probabilities should sum to ~1
        let sum: f64 = probs.iter().sum();
        assert!((sum - 1.0).abs() < 1e-6);
    }
}
