//! Operator Primitives - Core Operator Transformations
//!
//! Defines fundamental operator primitives for the Reasonate Kernel:
//! - SweepOperator: Redistributes ψ→ρ energy across the infogenomic resonance lattice
//! - TransferOperator: Shifts ω-weight between nodes in a stable resonance path
//! - PathInvarianceCheck: Verifies Δψρω=0 along operator cycles; prevents drift
//!
//! Core algorithm:
//! 1. For each operator: compute ∂ψ/∂ρ gradient
//! 2. Redistribute resonance weights proportional to local variance
//! 3. Apply damping factor λ to ensure energy equilibrium
//! 4. Verify path invariance; reject unstable operators

use crate::signature::Signature5D;
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};

/// Sweep operator configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SweepConfig {
    /// Redistribution strength
    pub strength: f64,
    /// Damping factor λ
    pub damping: f64,
    /// Variance threshold
    pub variance_threshold: f64,
}

impl Default for SweepConfig {
    fn default() -> Self {
        Self {
            strength: 0.1,
            damping: 0.95,
            variance_threshold: 0.01,
        }
    }
}

/// Sweep Operator: Redistributes ψ→ρ energy across resonance lattice
///
/// Algorithm:
/// 1. Compute ∂ψ/∂ρ gradient
/// 2. Redistribute energy proportional to local variance
/// 3. Apply damping factor λ for equilibrium
#[derive(Debug, Clone)]
pub struct SweepOperator {
    pub config: SweepConfig,
}

impl SweepOperator {
    pub fn new(config: SweepConfig) -> Self {
        Self { config }
    }

    /// Apply sweep operation to signature
    ///
    /// Redistributes energy from ψ to ρ based on gradient
    pub fn apply(&self, sig: &Signature5D) -> Signature5D {
        // Compute gradient ∂ψ/∂ρ
        let gradient = sig.psi - sig.rho;

        // Compute local variance
        let variance = (sig.psi - sig.rho).powi(2);

        // Redistribution only if variance exceeds threshold
        if variance > self.config.variance_threshold {
            let delta = self.config.strength * gradient;

            // Energy redistribution with damping
            let new_psi = (sig.psi - delta) * self.config.damping;
            let new_rho = (sig.rho + delta) * self.config.damping;

            Signature5D::new(
                new_psi.clamp(0.0, 1.0),
                new_rho.clamp(0.0, 1.0),
                sig.omega,
                sig.chi,
                sig.eta,
            )
        } else {
            // No redistribution needed
            *sig
        }
    }

    /// Apply sweep across multiple signatures (lattice)
    pub fn apply_lattice(&self, signatures: &[Signature5D]) -> Vec<Signature5D> {
        signatures.iter().map(|sig| self.apply(sig)).collect()
    }
}

/// Transfer operator configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransferConfig {
    /// Transfer weight
    pub weight: f64,
    /// Stability threshold
    pub stability_threshold: f64,
}

impl Default for TransferConfig {
    fn default() -> Self {
        Self {
            weight: 0.1,
            stability_threshold: 0.85,
        }
    }
}

/// Transfer Operator: Shifts ω-weight between nodes in stable resonance path
///
/// Only applies transfer if path is stable (ω > threshold)
#[derive(Debug, Clone)]
pub struct TransferOperator {
    pub config: TransferConfig,
}

impl TransferOperator {
    pub fn new(config: TransferConfig) -> Self {
        Self { config }
    }

    /// Transfer ω-weight from source to target
    ///
    /// Transfer only occurs if both nodes are stable
    pub fn transfer(
        &self,
        source: &Signature5D,
        target: &Signature5D,
    ) -> Result<(Signature5D, Signature5D)> {
        // Check stability
        if source.omega < self.config.stability_threshold
            || target.omega < self.config.stability_threshold
        {
            return Err(MogeError::ResonanceViolation(
                "Transfer requires stable nodes".to_string(),
            ));
        }

        // Compute transfer amount
        let transfer_amount = self.config.weight * (source.omega - target.omega).abs();

        // Determine direction
        let (new_source_omega, new_target_omega) = if source.omega > target.omega {
            (source.omega - transfer_amount, target.omega + transfer_amount)
        } else {
            (source.omega + transfer_amount, target.omega - transfer_amount)
        };

        let new_source = Signature5D::new(
            source.psi,
            source.rho,
            new_source_omega.clamp(0.0, 1.0),
            source.chi,
            source.eta,
        );

        let new_target = Signature5D::new(
            target.psi,
            target.rho,
            new_target_omega.clamp(0.0, 1.0),
            target.chi,
            target.eta,
        );

        Ok((new_source, new_target))
    }
}

/// Path invariance checker
///
/// Verifies Δψρω = 0 along operator cycles
#[derive(Debug, Clone)]
pub struct PathInvarianceCheck {
    /// Tolerance for invariance check
    pub tolerance: f64,
}

impl Default for PathInvarianceCheck {
    fn default() -> Self {
        Self { tolerance: 1e-4 }
    }
}

impl PathInvarianceCheck {
    pub fn new(tolerance: f64) -> Self {
        Self { tolerance }
    }

    /// Compute ψρω product
    fn product(sig: &Signature5D) -> f64 {
        sig.psi * sig.rho * sig.omega
    }

    /// Check invariance along a path (cycle)
    ///
    /// Returns true if Δ(ψρω) < tolerance
    pub fn check_path(&self, path: &[Signature5D]) -> bool {
        if path.is_empty() {
            return true;
        }

        if path.len() == 1 {
            return true;
        }

        // Compute products at start and end
        let start_product = Self::product(&path[0]);
        let end_product = Self::product(&path[path.len() - 1]);

        // Check if delta is within tolerance
        let delta = (end_product - start_product).abs();
        delta < self.tolerance
    }

    /// Check cycle invariance (path that returns to start)
    ///
    /// Verifies that Δ(ψρω) + χη ≈ 0
    pub fn check_cycle(&self, cycle: &[Signature5D]) -> bool {
        if cycle.len() < 2 {
            return false;
        }

        let start = &cycle[0];
        let end = &cycle[cycle.len() - 1];

        let delta_product = (Self::product(end) - Self::product(start)).abs();
        let chi_eta_term = end.chi * end.eta;

        let invariant = delta_product + chi_eta_term;

        invariant < self.tolerance
    }

    /// Verify operator stability (no drift over multiple applications)
    pub fn verify_operator_stability(&self, operator_fn: impl Fn(&Signature5D) -> Signature5D, sig: &Signature5D, iterations: usize) -> bool {
        let mut current = *sig;
        let initial_product = Self::product(sig);

        for _ in 0..iterations {
            current = operator_fn(&current);
        }

        let final_product = Self::product(&current);
        let drift = (final_product - initial_product).abs();

        drift < self.tolerance * (iterations as f64).sqrt()
    }
}

/// Combined operator primitives system
pub struct OperatorPrimitives {
    pub sweep: SweepOperator,
    pub transfer: TransferOperator,
    pub invariance: PathInvarianceCheck,
}

impl OperatorPrimitives {
    pub fn new() -> Self {
        Self {
            sweep: SweepOperator::new(SweepConfig::default()),
            transfer: TransferOperator::new(TransferConfig::default()),
            invariance: PathInvarianceCheck::default(),
        }
    }

    /// Apply sweep and verify invariance
    pub fn sweep_with_check(&self, sig: &Signature5D) -> Result<Signature5D> {
        let result = self.sweep.apply(sig);

        if !self.invariance.check_path(&[*sig, result]) {
            return Err(MogeError::ResonanceViolation(
                "Sweep operation violated path invariance".to_string(),
            ));
        }

        Ok(result)
    }

    /// Apply transfer and verify invariance
    pub fn transfer_with_check(
        &self,
        source: &Signature5D,
        target: &Signature5D,
    ) -> Result<(Signature5D, Signature5D)> {
        let (new_source, new_target) = self.transfer.transfer(source, target)?;

        // Check that total ω is conserved
        let initial_omega = source.omega + target.omega;
        let final_omega = new_source.omega + new_target.omega;

        if (final_omega - initial_omega).abs() > self.invariance.tolerance {
            return Err(MogeError::ResonanceViolation(
                "Transfer violated ω conservation".to_string(),
            ));
        }

        Ok((new_source, new_target))
    }
}

impl Default for OperatorPrimitives {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sweep_operator() {
        let config = SweepConfig::default();
        let sweep = SweepOperator::new(config);

        let sig = Signature5D::new(0.8, 0.3, 0.5, 0.5, 0.5);
        let result = sweep.apply(&sig);

        // ψ should decrease, ρ should increase
        assert!(result.psi < sig.psi);
        assert!(result.rho > sig.rho);
    }

    #[test]
    fn test_transfer_operator() {
        let config = TransferConfig::default();
        let transfer = TransferOperator::new(config);

        let source = Signature5D::new(0.5, 0.5, 0.9, 0.5, 0.5);
        let target = Signature5D::new(0.5, 0.5, 0.85, 0.5, 0.5);

        let result = transfer.transfer(&source, &target);
        assert!(result.is_ok());

        let (new_source, new_target) = result.unwrap();

        // Total ω should be conserved (approximately)
        let initial_omega = source.omega + target.omega;
        let final_omega = new_source.omega + new_target.omega;
        assert!((final_omega - initial_omega).abs() < 1e-6);
    }

    #[test]
    fn test_path_invariance() {
        let checker = PathInvarianceCheck::default();

        let path = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.3, 0.3),
            Signature5D::new(0.51, 0.49, 0.5, 0.3, 0.3),
            Signature5D::new(0.5, 0.5, 0.5, 0.3, 0.3),
        ];

        assert!(checker.check_path(&path));
    }

    #[test]
    fn test_sweep_lattice() {
        let config = SweepConfig::default();
        let sweep = SweepOperator::new(config);

        let signatures = vec![
            Signature5D::new(0.8, 0.2, 0.5, 0.5, 0.5),
            Signature5D::new(0.7, 0.3, 0.5, 0.5, 0.5),
            Signature5D::new(0.9, 0.1, 0.5, 0.5, 0.5),
        ];

        let result = sweep.apply_lattice(&signatures);
        assert_eq!(result.len(), 3);

        // All should have reduced gradient
        for (i, res) in result.iter().enumerate() {
            let gradient = (res.psi - res.rho).abs();
            let original_gradient = (signatures[i].psi - signatures[i].rho).abs();
            assert!(gradient < original_gradient || gradient < 0.1);
        }
    }

    #[test]
    fn test_operator_stability() {
        let checker = PathInvarianceCheck::new(1e-3);
        let sig = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);

        // Identity operator should be stable
        let is_stable = checker.verify_operator_stability(|s| *s, &sig, 100);
        assert!(is_stable);
    }
}
