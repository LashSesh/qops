//! # IRG Core Integration Module
//!
//! Integrates the Infogenetic Resonant Genesis Core with existing Genesis Engine systems:
//! - Meta-Cognition Layer
//! - Spectral Genesis Protocol Suite (SGCP, SAL, SRAL)
//! - Operator Evolution System
//! - Cubechain Ledger

use serde::{Deserialize, Serialize};
use crate::irg_core::{IRGCore, SpectralSignature, IRGStatus};
use crate::signature::Signature5D;
use crate::operator::Operator;
use crate::error::Result;

// ============================================================================
// META-COGNITION INTEGRATION
// ============================================================================

/// IRG-enhanced meta-cognition state
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IRGMetaCognition {
    /// IRG Core instance
    pub irg_core: IRGCore,

    /// Meta-coherence score (integration quality)
    pub meta_coherence: f64,

    /// Causal inference depth
    pub causal_depth: usize,

    /// Semantic entropy tracking
    pub semantic_entropy: f64,

    /// Self-reflection density
    pub reflection_density: f64,
}

impl IRGMetaCognition {
    /// Create new IRG-enhanced meta-cognition
    pub fn new(initial_signature: SpectralSignature, domain: &str) -> Self {
        Self {
            irg_core: IRGCore::new(initial_signature, domain),
            meta_coherence: 1.0,
            causal_depth: 0,
            semantic_entropy: 0.0,
            reflection_density: 0.0,
        }
    }

    /// Perform meta-cognitive introspection using IRG Core
    pub fn introspect(&mut self, noise: f64) -> Result<MetaIntrospectionReport> {
        // Evolve IRG Core
        self.irg_core.evolve_step(noise)?;

        // Calculate meta-cognition metrics
        let status = self.irg_core.status();
        self.meta_coherence = status.coherence_ratio;
        self.semantic_entropy = self.irg_core.spectral_entropy();

        // Generate introspection report
        Ok(MetaIntrospectionReport {
            irg_status: status,
            meta_coherence: self.meta_coherence,
            causal_depth: self.causal_depth,
            semantic_entropy: self.semantic_entropy,
            reflection_density: self.reflection_density,
            insights: self.generate_insights(),
        })
    }

    /// Generate meta-cognitive insights from IRG state
    fn generate_insights(&self) -> Vec<String> {
        let mut insights = Vec::new();

        let status = self.irg_core.status();

        if status.coherence_ratio >= 0.9 {
            insights.push("High coherence: System demonstrating strong self-consistency".to_string());
        } else if status.coherence_ratio < 0.51 {
            insights.push("WARNING: Coherence below governance threshold - recalibration needed".to_string());
        }

        if status.delta_sigma < 0.001 {
            insights.push("Near-convergence: Approaching target spectral signature".to_string());
        }

        if self.semantic_entropy > 0.01 {
            insights.push("High semantic entropy: Consider diversity reduction measures".to_string());
        }

        insights
    }

    /// Adapt learning rate based on meta-cognition
    pub fn adaptive_learning(&mut self, performance_metric: f64) {
        // Adjust IRG learning rate based on performance
        if performance_metric > 0.8 {
            self.irg_core.learning_cycle.eta *= 1.1; // Increase learning rate
        } else if performance_metric < 0.5 {
            self.irg_core.learning_cycle.eta *= 0.9; // Decrease learning rate
        }

        // Ensure learning rate stays in reasonable bounds
        self.irg_core.learning_cycle.eta = self.irg_core.learning_cycle.eta.clamp(0.0001, 0.01);
    }
}

/// Meta-introspection report
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetaIntrospectionReport {
    pub irg_status: IRGStatus,
    pub meta_coherence: f64,
    pub causal_depth: usize,
    pub semantic_entropy: f64,
    pub reflection_density: f64,
    pub insights: Vec<String>,
}

// ============================================================================
// SPECTRAL GENESIS INTEGRATION
// ============================================================================

/// IRG-enhanced spectral genesis system
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IRGSpectralGenesis {
    /// IRG Core instance
    pub irg_core: IRGCore,

    /// SGCP phase coherence
    pub phase_coherence: [f64; 3],

    /// SAL autogenesis index
    pub autogenesis_index: f64,

    /// SRAL meta-coherence index
    pub sral_meta_coherence: f64,
}

impl IRGSpectralGenesis {
    /// Create new IRG-enhanced spectral genesis
    pub fn new(initial_signature: SpectralSignature, domain: &str) -> Self {
        Self {
            irg_core: IRGCore::new(initial_signature, domain),
            phase_coherence: [1.0, 1.0, 1.0],
            autogenesis_index: 1.0,
            sral_meta_coherence: 1.0,
        }
    }

    /// Calibrate spectral genesis using IRG Core
    pub fn calibrate(&mut self, noise: f64) -> Result<SpectralCalibrationReport> {
        // Evolve IRG Core
        self.irg_core.evolve_step(noise)?;

        let status = self.irg_core.status();

        // Calculate phase coherence from IRG state
        self.phase_coherence = self.calculate_phase_coherence();

        // Calculate autogenesis index
        self.autogenesis_index = self.calculate_autogenesis_index();

        // Calculate SRAL meta-coherence
        self.sral_meta_coherence = status.coherence_ratio;

        Ok(SpectralCalibrationReport {
            irg_status: status,
            phase_coherence: self.phase_coherence,
            autogenesis_index: self.autogenesis_index,
            sral_meta_coherence: self.sral_meta_coherence,
            spectral_genesis_index: self.calculate_spectral_genesis_index(),
        })
    }

    /// Calculate phase coherence from spectral signature
    fn calculate_phase_coherence(&self) -> [f64; 3] {
        let sig = &self.irg_core.signature;

        // Map spectral components to phase triplet
        [
            (sig.psi + sig.rho) / 2.0,
            (sig.omega + sig.chi) / 2.0,
            sig.tau,
        ]
    }

    /// Calculate autogenesis index
    fn calculate_autogenesis_index(&self) -> f64 {
        let status = self.irg_core.status();

        // Autogenesis index based on convergence and coherence
        let convergence_factor = if status.has_converged { 1.0 } else { 0.5 };
        let coherence_factor = status.coherence_ratio;

        convergence_factor * coherence_factor
    }

    /// Calculate spectral genesis index (SGI)
    fn calculate_spectral_genesis_index(&self) -> f64 {
        // SGI combines phase coherence, autogenesis, and meta-coherence
        let avg_phase_coherence = self.phase_coherence.iter().sum::<f64>() / 3.0;
        (avg_phase_coherence + self.autogenesis_index + self.sral_meta_coherence) / 3.0
    }
}

/// Spectral calibration report
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpectralCalibrationReport {
    pub irg_status: IRGStatus,
    pub phase_coherence: [f64; 3],
    pub autogenesis_index: f64,
    pub sral_meta_coherence: f64,
    pub spectral_genesis_index: f64,
}

// ============================================================================
// OPERATOR EVOLUTION INTEGRATION
// ============================================================================

/// IRG-guided operator evolution
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IRGOperatorEvolution {
    /// IRG Core instance
    pub irg_core: IRGCore,

    /// Evolution generation counter
    pub generation: usize,

    /// Fitness history
    pub fitness_history: Vec<f64>,
}

impl IRGOperatorEvolution {
    /// Create new IRG-guided operator evolution
    pub fn new(initial_signature: SpectralSignature, domain: &str) -> Self {
        Self {
            irg_core: IRGCore::new(initial_signature, domain),
            generation: 0,
            fitness_history: Vec::new(),
        }
    }

    /// Evolve operator using IRG Core guidance
    pub fn evolve_operator(&mut self, operator: &Operator, noise: f64) -> Result<OperatorEvolutionReport> {
        // Evolve IRG Core
        self.irg_core.evolve_step(noise)?;

        // Extract spectral signature from operator
        let operator_signature = self.operator_to_spectral_signature(operator);

        // Calculate fitness based on alignment with IRG target
        let fitness = self.calculate_fitness(&operator_signature);
        self.fitness_history.push(fitness);

        self.generation += 1;

        Ok(OperatorEvolutionReport {
            generation: self.generation,
            fitness,
            irg_status: self.irg_core.status(),
            operator_signature,
            target_signature: self.irg_core.target.signature.clone(),
            alignment: 1.0 - self.irg_core.status().delta_sigma,
        })
    }

    /// Convert operator to spectral signature
    fn operator_to_spectral_signature(&self, operator: &Operator) -> SpectralSignature {
        let sig5d = &operator.signature;

        SpectralSignature {
            psi: sig5d.psi,
            rho: sig5d.rho,
            omega: sig5d.omega,
            chi: sig5d.chi,
            tau: sig5d.eta, // Map eta to tau
        }
    }

    /// Calculate fitness based on alignment with target
    fn calculate_fitness(&self, operator_sig: &SpectralSignature) -> f64 {
        // Fitness is inverse of distance to target
        let distance = operator_sig.distance(&self.irg_core.target.signature);
        let max_distance = (5.0_f64).sqrt();

        (1.0 - (distance / max_distance)).max(0.0)
    }

    /// Get evolution trajectory
    pub fn get_trajectory(&self) -> Vec<f64> {
        self.fitness_history.clone()
    }
}

/// Operator evolution report
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorEvolutionReport {
    pub generation: usize,
    pub fitness: f64,
    pub irg_status: IRGStatus,
    pub operator_signature: SpectralSignature,
    pub target_signature: SpectralSignature,
    pub alignment: f64,
}

// ============================================================================
// CUBECHAIN INTEGRATION
// ============================================================================

/// IRG-validated cubechain transition
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IRGCubechainValidator {
    /// IRG Core instance
    pub irg_core: IRGCore,

    /// Validation threshold
    pub validation_threshold: f64,
}

impl IRGCubechainValidator {
    /// Create new IRG cubechain validator
    pub fn new(initial_signature: SpectralSignature, domain: &str) -> Self {
        Self {
            irg_core: IRGCore::new(initial_signature, domain),
            validation_threshold: 0.51,
        }
    }

    /// Validate cubechain transition using IRG Core
    pub fn validate_transition(
        &mut self,
        from_signature: &Signature5D,
        to_signature: &Signature5D,
    ) -> Result<TransitionValidationReport> {
        // Convert to spectral signatures
        let from_spectral = SpectralSignature::from_signature_5d(from_signature);
        let to_spectral = SpectralSignature::from_signature_5d(to_signature);

        // Check if transition maintains coherence
        let transition_distance = from_spectral.distance(&to_spectral);
        let coherence_maintained = transition_distance < self.validation_threshold;

        // Check if transition moves toward target
        let from_target_distance = from_spectral.distance(&self.irg_core.target.signature);
        let to_target_distance = to_spectral.distance(&self.irg_core.target.signature);
        let improves_alignment = to_target_distance < from_target_distance;

        // Overall validation
        let is_valid = coherence_maintained && self.irg_core.cybernetic_control.is_valid();

        Ok(TransitionValidationReport {
            is_valid,
            coherence_maintained,
            improves_alignment,
            transition_distance,
            from_target_distance,
            to_target_distance,
            irg_coherence_ratio: self.irg_core.cybernetic_control.coherence_ratio,
        })
    }
}

/// Transition validation report
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransitionValidationReport {
    pub is_valid: bool,
    pub coherence_maintained: bool,
    pub improves_alignment: bool,
    pub transition_distance: f64,
    pub from_target_distance: f64,
    pub to_target_distance: f64,
    pub irg_coherence_ratio: f64,
}

// ============================================================================
// UNIFIED IRG INTEGRATION SYSTEM
// ============================================================================

/// Unified IRG integration system combining all subsystems
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UnifiedIRGIntegration {
    pub meta_cognition: IRGMetaCognition,
    pub spectral_genesis: IRGSpectralGenesis,
    pub operator_evolution: IRGOperatorEvolution,
    pub cubechain_validator: IRGCubechainValidator,
    pub system_time: f64,
}

impl UnifiedIRGIntegration {
    /// Create new unified IRG integration
    pub fn new(initial_signature: SpectralSignature, domain: &str) -> Self {
        Self {
            meta_cognition: IRGMetaCognition::new(initial_signature.clone(), domain),
            spectral_genesis: IRGSpectralGenesis::new(initial_signature.clone(), domain),
            operator_evolution: IRGOperatorEvolution::new(initial_signature.clone(), domain),
            cubechain_validator: IRGCubechainValidator::new(initial_signature, domain),
            system_time: 0.0,
        }
    }

    /// Execute unified evolution step across all subsystems
    pub fn unified_evolution_step(&mut self, operator: &Operator, noise: f64) -> Result<UnifiedEvolutionReport> {
        // Execute meta-cognition introspection
        let meta_report = self.meta_cognition.introspect(noise)?;

        // Execute spectral genesis calibration
        let spectral_report = self.spectral_genesis.calibrate(noise)?;

        // Execute operator evolution
        let evolution_report = self.operator_evolution.evolve_operator(operator, noise)?;

        // Update system time
        self.system_time += 0.064;

        Ok(UnifiedEvolutionReport {
            meta_introspection: meta_report,
            spectral_calibration: spectral_report,
            operator_evolution: evolution_report,
            system_time: self.system_time,
        })
    }

    /// Get unified system status
    pub fn unified_status(&self) -> UnifiedIRGStatus {
        UnifiedIRGStatus {
            meta_coherence: self.meta_cognition.meta_coherence,
            spectral_genesis_index: self.spectral_genesis.calculate_spectral_genesis_index(),
            evolution_generation: self.operator_evolution.generation,
            cubechain_validation_threshold: self.cubechain_validator.validation_threshold,
            system_time: self.system_time,
        }
    }
}

/// Unified evolution report
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UnifiedEvolutionReport {
    pub meta_introspection: MetaIntrospectionReport,
    pub spectral_calibration: SpectralCalibrationReport,
    pub operator_evolution: OperatorEvolutionReport,
    pub system_time: f64,
}

/// Unified IRG status
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UnifiedIRGStatus {
    pub meta_coherence: f64,
    pub spectral_genesis_index: f64,
    pub evolution_generation: usize,
    pub cubechain_validation_threshold: f64,
    pub system_time: f64,
}

// ============================================================================
// TESTS
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_meta_cognition_integration() {
        let sig = SpectralSignature {
            psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
        };

        let mut meta = IRGMetaCognition::new(sig, "test_domain");
        let report = meta.introspect(0.01).unwrap();

        assert!(report.meta_coherence >= 0.0 && report.meta_coherence <= 1.0);
        // Verify insights were generated
        let _ = report.insights.len();
    }

    #[test]
    fn test_spectral_genesis_integration() {
        let sig = SpectralSignature {
            psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
        };

        let mut spectral = IRGSpectralGenesis::new(sig, "test_domain");
        let report = spectral.calibrate(0.01).unwrap();

        assert!(report.spectral_genesis_index >= 0.0);
        assert_eq!(report.phase_coherence.len(), 3);
    }

    #[test]
    fn test_operator_evolution_integration() {
        let sig = SpectralSignature {
            psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
        };

        let mut evolution = IRGOperatorEvolution::new(sig, "test_domain");

        // Create mock operator
        let operator = Operator::from_signature(Signature5D {
            psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, eta: 0.95,
        });

        let report = evolution.evolve_operator(&operator, 0.01).unwrap();

        assert_eq!(report.generation, 1);
        assert!(report.fitness >= 0.0 && report.fitness <= 1.0);
    }

    #[test]
    fn test_cubechain_validation() {
        let sig = SpectralSignature {
            psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
        };

        let mut validator = IRGCubechainValidator::new(sig, "test_domain");

        let from_sig = Signature5D {
            psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, eta: 0.95,
        };

        let to_sig = Signature5D {
            psi: 0.81, rho: 0.91, omega: 0.86, chi: 0.76, eta: 0.96,
        };

        let report = validator.validate_transition(&from_sig, &to_sig).unwrap();

        assert!(report.transition_distance >= 0.0);
    }

    #[test]
    fn test_unified_integration() {
        let sig = SpectralSignature {
            psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
        };

        let unified = UnifiedIRGIntegration::new(sig, "test_domain");
        let status = unified.unified_status();

        assert!(status.meta_coherence >= 0.0);
        assert!(status.spectral_genesis_index >= 0.0);
        assert_eq!(status.evolution_generation, 0);
    }
}
