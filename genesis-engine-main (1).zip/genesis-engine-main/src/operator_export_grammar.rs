//! Operator Export Grammar (OEG)
//!
//! Provides deterministic, self-descriptive export format for universally valid 
//! operators with resonance signatures, domain projections, and invariance proofs.

use crate::resonant_language_projection::{TIC, ProjectionTensor, UniversalOperatorSignature};
use crate::rule_matrix::RuleMatrixState;
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use std::path::Path;
use std::fs;

/// Complete operator export package
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorExportPackage {
    /// Operator entity metadata
    pub entity: OperatorEntity,
    
    /// Resonance signature
    pub resonance_signature: ResonanceSignatureExport,
    
    /// Rule matrix state snapshot
    pub rule_matrix_state: RuleMatrixState,
    
    /// Domain projections
    pub projective_domains: Vec<ProjectionTensor>,
    
    /// Resonant context
    pub resonant_context: ResonantContext,
    
    /// Metadata and validation
    pub metadata: ExportMetadata,
}

/// Operator entity information
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorEntity {
    pub id: Uuid,
    pub name: String,
    #[serde(rename = "type")]
    pub entity_type: String,
    pub origin: String,
    pub timestamp: i64,
    pub generator_signature: String,
    pub invariance_proof: String,
    pub description: String,
}

/// Resonance signature for export
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResonanceSignatureExport {
    pub psi: f64,
    pub rho: f64,
    pub omega: f64,
    pub beta: f64,  // χ
    #[serde(rename = "S")]
    pub s: f64,     // η
    pub phase_vector: [f64; 3],
    pub entropy_index: f32,
    pub coherence_index: f32,
    pub stability_index: f32,
    pub timestamp: String,
}

impl ResonanceSignatureExport {
    /// Create from TIC
    pub fn from_tic(tic: &TIC) -> Self {
        Self {
            psi: tic.signature.psi,
            rho: tic.signature.rho,
            omega: tic.signature.omega,
            beta: tic.signature.chi,
            s: tic.signature.eta,
            phase_vector: tic.phase,
            entropy_index: tic.entropy_gradient as f32,
            coherence_index: tic.signature.omega as f32,
            stability_index: tic.stability as f32,
            timestamp: tic.timestamp.to_rfc3339(),
        }
    }
}

/// Resonant context information
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResonantContext {
    pub hypercube_node: String,
    pub metatron_address: String,
    pub dual_gate_state: String,
    pub feedback_context: String,
    pub entropy_field_snapshot: String,
    pub telemetry_source: String,
}

impl Default for ResonantContext {
    fn default() -> Self {
        Self {
            hypercube_node: "C_0".to_string(),
            metatron_address: "0x0000".to_string(),
            dual_gate_state: "superposed".to_string(),
            feedback_context: "GabrielCluster#0".to_string(),
            entropy_field_snapshot: "entropy_map_ΔS.json".to_string(),
            telemetry_source: "kernel_cycle_0".to_string(),
        }
    }
}

/// Export metadata
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExportMetadata {
    pub domain_universality: bool,
    pub isomorphism_proof: String,
    pub entropy_convergence: String,
    pub rule_matrix_equilibrium: bool,
    pub semantic_alignment: f64,
}

/// Export format specification
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExportFormat {
    Json,
    Toml,
    Binary,
}

impl ExportFormat {
    /// Get file extension for format
    pub fn extension(&self) -> &'static str {
        match self {
            ExportFormat::Json => "json",
            ExportFormat::Toml => "toml",
            ExportFormat::Binary => "bin",
        }
    }
}

/// Operator Export Grammar - Main export system
pub struct OperatorExportGrammar {
    /// Export directory base path
    export_dir: String,
}

impl OperatorExportGrammar {
    /// Create a new export grammar instance
    pub fn new(export_dir: impl Into<String>) -> Self {
        Self {
            export_dir: export_dir.into(),
        }
    }
    
    /// Create an export package from TIC and projections
    pub fn create_package(
        &self,
        tic: &TIC,
        projections: Vec<ProjectionTensor>,
        rule_matrix_state: RuleMatrixState,
        signature: &UniversalOperatorSignature,
    ) -> Result<OperatorExportPackage> {
        // Create operator entity
        let entity = OperatorEntity {
            id: signature.operator_id,
            name: format!("Operator_{}", &signature.signature_hash[..8]),
            entity_type: "resonant_operator".to_string(),
            origin: "cubechain".to_string(),
            timestamp: tic.timestamp.timestamp(),
            generator_signature: "Ed25519_placeholder".to_string(),
            invariance_proof: signature.signature_hash.clone(),
            description: "Universally normalized operator emitted from resonance kernel.".to_string(),
        };
        
        // Create resonance signature export
        let resonance_signature = ResonanceSignatureExport::from_tic(tic);
        
        // Create metadata
        let metadata = ExportMetadata {
            domain_universality: projections.len() >= 5,
            isomorphism_proof: format!("determinant(ΔP_ij) < {}", 1e-5),
            entropy_convergence: format!("ΔS < {}", tic.entropy_gradient),
            rule_matrix_equilibrium: rule_matrix_state.status == "converged",
            semantic_alignment: signature.semantic_coherence,
        };
        
        Ok(OperatorExportPackage {
            entity,
            resonance_signature,
            rule_matrix_state,
            projective_domains: projections,
            resonant_context: ResonantContext::default(),
            metadata,
        })
    }
    
    /// Validate export conditions
    /// if semantic_coherence_index > 0.95 && stability_index > 0.9
    pub fn validate_export_conditions(&self, package: &OperatorExportPackage) -> bool {
        package.metadata.semantic_alignment > 0.95
            && package.resonance_signature.stability_index > 0.9
    }
    
    /// Export package to file
    pub fn export_package(
        &self,
        package: &OperatorExportPackage,
        format: ExportFormat,
    ) -> Result<String> {
        // Validate export conditions
        if !self.validate_export_conditions(package) {
            return Err(MogeError::InvalidArtefact(
                "Export conditions not met: recalibrate and retry".to_string()
            ));
        }
        
        // Create export directory if it doesn't exist
        let export_path = Path::new(&self.export_dir);
        fs::create_dir_all(export_path)
            .map_err(|e| MogeError::InvalidArtefact(format!("Failed to create export directory: {}", e)))?;
        
        // Generate filename
        let timestamp = package.entity.timestamp;
        let filename = format!(
            "operator_{}.{}",
            timestamp,
            format.extension()
        );
        let filepath = export_path.join(&filename);
        
        // Export based on format
        match format {
            ExportFormat::Json => {
                let json = serde_json::to_string_pretty(package)
                    .map_err(|e| MogeError::InvalidArtefact(format!("JSON serialization failed: {}", e)))?;
                fs::write(&filepath, json)
                    .map_err(|e| MogeError::InvalidArtefact(format!("Failed to write JSON: {}", e)))?;
            },
            ExportFormat::Toml => {
                let toml = toml::to_string_pretty(package)
                    .map_err(|e| MogeError::InvalidArtefact(format!("TOML serialization failed: {}", e)))?;
                fs::write(&filepath, toml)
                    .map_err(|e| MogeError::InvalidArtefact(format!("Failed to write TOML: {}", e)))?;
            },
            ExportFormat::Binary => {
                // TODO: Implement proper binary format (e.g., bincode, messagepack, protobuf)
                // Currently using JSON as intermediate for compatibility
                // In production, this should use a more efficient binary serialization format
                // that preserves tensor precision and reduces file size
                let json = serde_json::to_vec(package)
                    .map_err(|e| MogeError::InvalidArtefact(format!("Binary serialization failed: {}", e)))?;
                fs::write(&filepath, json)
                    .map_err(|e| MogeError::InvalidArtefact(format!("Failed to write binary: {}", e)))?;
            },
        }
        
        Ok(filepath.to_string_lossy().to_string())
    }
    
    /// Export manifest (TOML index of all operators)
    pub fn export_manifest(
        &self,
        packages: &[OperatorExportPackage],
    ) -> Result<String> {
        #[derive(Serialize)]
        struct ManifestEntry {
            id: String,
            name: String,
            timestamp: i64,
            semantic_alignment: f64,
            status: String,
        }
        
        #[derive(Serialize)]
        struct Manifest {
            version: String,
            count: usize,
            operators: Vec<ManifestEntry>,
        }
        
        let manifest = Manifest {
            version: "1.0".to_string(),
            count: packages.len(),
            operators: packages.iter().map(|p| ManifestEntry {
                id: p.entity.id.to_string(),
                name: p.entity.name.clone(),
                timestamp: p.entity.timestamp,
                semantic_alignment: p.metadata.semantic_alignment,
                status: p.rule_matrix_state.status.clone(),
            }).collect(),
        };
        
        let export_path = Path::new(&self.export_dir);
        fs::create_dir_all(export_path)
            .map_err(|e| MogeError::InvalidArtefact(format!("Failed to create export directory: {}", e)))?;
        
        let manifest_path = export_path.join("operator_manifest.toml");
        let toml = toml::to_string_pretty(&manifest)
            .map_err(|e| MogeError::InvalidArtefact(format!("Manifest serialization failed: {}", e)))?;
        
        fs::write(&manifest_path, toml)
            .map_err(|e| MogeError::InvalidArtefact(format!("Failed to write manifest: {}", e)))?;
        
        Ok(manifest_path.to_string_lossy().to_string())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::operator::Operator;
    use crate::resonant_language_projection::{ResonantLanguageProjection, Domain};
    
    #[test]
    fn test_resonance_signature_export() {
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        
        let export = ResonanceSignatureExport::from_tic(&tic);
        assert_eq!(export.psi, tic.signature.psi);
        assert_eq!(export.phase_vector, tic.phase);
    }
    
    #[test]
    fn test_create_export_package() {
        let mut rlp = ResonantLanguageProjection::new();
        let op = Operator::new();
        
        let (tic_id, projections, signature) = rlp.process_operator(&op).unwrap();
        let tic = rlp.catalogue().get(&tic_id).unwrap().clone();
        
        let rule_matrix_state = RuleMatrixState {
            matrix_checksum: "test".to_string(),
            delta_r_mean: 0.0001,
            delta_r_variance: 0.0001,
            semantic_coherence_index: 0.96,
            status: "converged".to_string(),
        };
        
        let oeg = OperatorExportGrammar::new("/tmp/test_exports");
        let package = oeg.create_package(&tic, projections, rule_matrix_state, &signature).unwrap();
        
        assert_eq!(package.entity.entity_type, "resonant_operator");
        assert_eq!(package.projective_domains.len(), 5);
    }
    
    #[test]
    fn test_export_validation() {
        let mut package = create_test_package();
        let oeg = OperatorExportGrammar::new("/tmp/test_exports");
        
        // Should pass with high values
        package.metadata.semantic_alignment = 0.96;
        package.resonance_signature.stability_index = 0.92;
        assert!(oeg.validate_export_conditions(&package));
        
        // Should fail with low values
        package.metadata.semantic_alignment = 0.80;
        assert!(!oeg.validate_export_conditions(&package));
    }
    
    fn create_test_package() -> OperatorExportPackage {
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        let projections: Vec<_> = Domain::all()
            .iter()
            .map(|&d| ProjectionTensor::new(d, &tic))
            .collect();
        
        let rule_matrix_state = RuleMatrixState {
            matrix_checksum: "test".to_string(),
            delta_r_mean: 0.0001,
            delta_r_variance: 0.0001,
            semantic_coherence_index: 0.96,
            status: "converged".to_string(),
        };
        
        let signature = UniversalOperatorSignature::generate(&tic, &projections, "test");
        let oeg = OperatorExportGrammar::new("/tmp/test_exports");
        oeg.create_package(&tic, projections, rule_matrix_state, &signature).unwrap()
    }
}
