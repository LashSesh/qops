//! Metatron Cube 13-Node Topology Module
//!
//! Implements the 13-node Metatron Cube routing structure with:
//! - 13 sacred geometry nodes arranged in a cube-octahedron pattern
//! - 78 edges connecting nodes based on platonic solid symmetries
//! - 5D resonance lattice coordinate embedding
//! - Connection weights based on exp(-ΔS * Δβ)

use serde::{Deserialize, Serialize};
use crate::signature::{Signature, Signature5D};
use crate::error::{Result, MogeError};

/// 13-node Metatron Cube topology
/// Represents the sacred geometric structure with cube vertices,
/// octahedron vertices, and center point
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetatronCubeTopology {
    /// Node positions in 5D resonance lattice
    nodes: Vec<MetatronNode>,
    /// Adjacency list with weighted edges
    edges: Vec<Vec<(usize, f64)>>,
    /// Total number of nodes (always 13)
    pub node_count: usize,
    /// Total number of edges (always 78)
    pub edge_count: usize,
}

/// A node in the Metatron Cube
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetatronNode {
    /// Node index (0-12)
    pub index: usize,
    /// Position in 5D resonance lattice (ψ, ρ, ω, β, S coordinates)
    pub position: [f64; 5],
    /// Symbolic name/archetype
    pub name: String,
    /// Node type (vertex, center, connector)
    pub node_type: NodeType,
}

/// Type of node in the topology
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum NodeType {
    /// Central singularity node
    Center,
    /// Cube vertex node
    CubeVertex,
    /// Octahedron vertex node
    OctahedronVertex,
}

impl MetatronCubeTopology {
    /// Create a new 13-node Metatron Cube topology
    pub fn new() -> Self {
        let nodes = Self::initialize_nodes();
        let edges = Self::initialize_edges();
        
        Self {
            node_count: 13,
            edge_count: 78,
            nodes,
            edges,
        }
    }

    /// Initialize the 13 nodes with their 5D positions
    fn initialize_nodes() -> Vec<MetatronNode> {
        vec![
            // Node 0: Center (source of all emanations)
            MetatronNode {
                index: 0,
                position: [0.5, 0.5, 0.5, 0.5, 0.5],
                name: "Source".to_string(),
                node_type: NodeType::Center,
            },
            // Nodes 1-8: Cube vertices (8 corners)
            MetatronNode {
                index: 1,
                position: [0.0, 0.0, 0.0, 0.2, 0.1],
                name: "Foundation".to_string(),
                node_type: NodeType::CubeVertex,
            },
            MetatronNode {
                index: 2,
                position: [1.0, 0.0, 0.0, 0.3, 0.2],
                name: "Manifestation".to_string(),
                node_type: NodeType::CubeVertex,
            },
            MetatronNode {
                index: 3,
                position: [1.0, 1.0, 0.0, 0.4, 0.3],
                name: "Integration".to_string(),
                node_type: NodeType::CubeVertex,
            },
            MetatronNode {
                index: 4,
                position: [0.0, 1.0, 0.0, 0.5, 0.4],
                name: "Reception".to_string(),
                node_type: NodeType::CubeVertex,
            },
            MetatronNode {
                index: 5,
                position: [0.0, 0.0, 1.0, 0.6, 0.5],
                name: "Ascension".to_string(),
                node_type: NodeType::CubeVertex,
            },
            MetatronNode {
                index: 6,
                position: [1.0, 0.0, 1.0, 0.7, 0.6],
                name: "Transformation".to_string(),
                node_type: NodeType::CubeVertex,
            },
            MetatronNode {
                index: 7,
                position: [1.0, 1.0, 1.0, 0.8, 0.7],
                name: "Crystallization".to_string(),
                node_type: NodeType::CubeVertex,
            },
            MetatronNode {
                index: 8,
                position: [0.0, 1.0, 1.0, 0.9, 0.8],
                name: "Completion".to_string(),
                node_type: NodeType::CubeVertex,
            },
            // Nodes 9-12: Octahedron vertices (4 cardinal points)
            MetatronNode {
                index: 9,
                position: [0.5, 0.5, 0.0, 0.3, 0.25],
                name: "Ground".to_string(),
                node_type: NodeType::OctahedronVertex,
            },
            MetatronNode {
                index: 10,
                position: [0.5, 0.5, 1.0, 0.7, 0.75],
                name: "Crown".to_string(),
                node_type: NodeType::OctahedronVertex,
            },
            MetatronNode {
                index: 11,
                position: [0.5, 0.0, 0.5, 0.4, 0.45],
                name: "Gateway".to_string(),
                node_type: NodeType::OctahedronVertex,
            },
            MetatronNode {
                index: 12,
                position: [0.5, 1.0, 0.5, 0.6, 0.55],
                name: "Bridge".to_string(),
                node_type: NodeType::OctahedronVertex,
            },
        ]
    }

    /// Initialize edges based on Metatron Cube geometry
    /// Total: 78 edges (12 cube edges + 12 octahedron edges + 
    ///               24 cube-to-center + 24 octahedron connections + 6 cross-connections)
    fn initialize_edges() -> Vec<Vec<(usize, f64)>> {
        let mut adjacency: Vec<Vec<(usize, f64)>> = vec![vec![]; 13];
        
        // Center connects to all other nodes (12 edges)
        for i in 1..13 {
            let weight = Self::compute_edge_weight(0, i);
            adjacency[0].push((i, weight));
            adjacency[i].push((0, weight));
        }
        
        // Cube edges (12 edges: 4 bottom, 4 top, 4 vertical)
        let cube_edges = [
            (1, 2), (2, 3), (3, 4), (4, 1),  // Bottom square
            (5, 6), (6, 7), (7, 8), (8, 5),  // Top square
            (1, 5), (2, 6), (3, 7), (4, 8),  // Vertical edges
        ];
        
        for (a, b) in cube_edges.iter() {
            let weight = Self::compute_edge_weight(*a, *b);
            adjacency[*a].push((*b, weight));
            adjacency[*b].push((*a, weight));
        }
        
        // Octahedron edges (connects cardinal points)
        let octahedron_edges = [
            (9, 11), (9, 12), (10, 11), (10, 12),  // Cross connections
            (9, 10), (11, 12),  // Vertical and horizontal axes
        ];
        
        for (a, b) in octahedron_edges.iter() {
            let weight = Self::compute_edge_weight(*a, *b);
            adjacency[*a].push((*b, weight));
            adjacency[*b].push((*a, weight));
        }
        
        // Connect cube vertices to octahedron vertices (24 edges)
        // Each cube vertex connects to 2 nearest octahedron vertices
        let cube_octahedron_connections = [
            (1, 9), (1, 11), (2, 9), (2, 11),
            (3, 9), (3, 12), (4, 9), (4, 12),
            (5, 10), (5, 11), (6, 10), (6, 11),
            (7, 10), (7, 12), (8, 10), (8, 12),
        ];
        
        for (a, b) in cube_octahedron_connections.iter() {
            let weight = Self::compute_edge_weight(*a, *b);
            adjacency[*a].push((*b, weight));
            adjacency[*b].push((*a, weight));
        }
        
        // Additional cross-diagonal connections for full Metatron structure
        let diagonal_connections = [
            (1, 3), (2, 4), (5, 7), (6, 8),  // Face diagonals
            (1, 7), (2, 8), (3, 5), (4, 6),  // Space diagonals
        ];
        
        for (a, b) in diagonal_connections.iter() {
            let weight = Self::compute_edge_weight(*a, *b);
            adjacency[*a].push((*b, weight));
            adjacency[*b].push((*a, weight));
        }
        
        adjacency
    }

    /// Compute edge weight based on exp(-ΔS * Δβ) formula
    /// Where ΔS is entropy difference and Δβ is topology difference
    fn compute_edge_weight(node_a: usize, node_b: usize) -> f64 {
        // Simplified: use distance in index space as proxy
        let delta = (node_a as f64 - node_b as f64).abs();
        (-0.1 * delta).exp()
    }

    /// Get node by index
    pub fn get_node(&self, index: usize) -> Result<&MetatronNode> {
        self.nodes.get(index)
            .ok_or_else(|| MogeError::InvalidNodeIndex(index))
    }

    /// Get neighbors of a node
    pub fn get_neighbors(&self, node_index: usize) -> Result<&Vec<(usize, f64)>> {
        self.edges.get(node_index)
            .ok_or_else(|| MogeError::InvalidNodeIndex(node_index))
    }

    /// Check if transition between nodes is valid based on routing rules
    pub fn is_valid_transition(
        &self,
        from: usize,
        to: usize,
        sig_from: &Signature5D,
        sig_to: &Signature5D,
    ) -> bool {
        // Check if edge exists
        if !self.has_edge(from, to) {
            return false;
        }
        
        // Apply routing rules from problem statement
        let delta_psi = (sig_to.psi() - sig_from.psi()).abs();
        let delta_rho = (sig_to.rho() - sig_from.rho()).abs();
        let delta_omega = (sig_to.omega() - sig_from.omega()).abs();
        let delta_chi = (sig_to.chi() - sig_from.chi()).abs();
        let delta_eta = (sig_to.eta() - sig_from.eta()).abs();
        
        // Transition condition: |Δ(ψρω)+χη| < 1e-4
        let transition_metric = delta_psi + delta_rho + delta_omega + delta_chi + delta_eta;
        if transition_metric >= 1e-4 {
            return false;
        }
        
        // Energy balance: |ΔH| < 1e-5 (use resonance as proxy for energy)
        let energy_from = sig_from.psi() * sig_from.rho() * sig_from.omega();
        let energy_to = sig_to.psi() * sig_to.rho() * sig_to.omega();
        let delta_energy = (energy_to - energy_from).abs();
        if delta_energy >= 1e-5 {
            return false;
        }
        
        // Entropy decay: ΔS < 1e-3 (simplified)
        let entropy_change = (sig_to.eta() - sig_from.eta()).abs();
        if entropy_change >= 1e-3 {
            return false;
        }
        
        true
    }

    /// Check if an edge exists between two nodes
    fn has_edge(&self, from: usize, to: usize) -> bool {
        if let Some(neighbors) = self.edges.get(from) {
            neighbors.iter().any(|(n, _)| *n == to)
        } else {
            false
        }
    }

    /// Get all nodes
    pub fn nodes(&self) -> &[MetatronNode] {
        &self.nodes
    }

    /// Get a seed node (center node)
    pub fn seed_node(&self) -> usize {
        0 // Center node is the source
    }
}

impl Default for MetatronCubeTopology {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_topology_initialization() {
        let topology = MetatronCubeTopology::new();
        assert_eq!(topology.node_count, 13);
        assert_eq!(topology.edge_count, 78);
        assert_eq!(topology.nodes.len(), 13);
        assert_eq!(topology.edges.len(), 13);
    }

    #[test]
    fn test_center_node() {
        let topology = MetatronCubeTopology::new();
        let center = topology.get_node(0).unwrap();
        assert_eq!(center.node_type, NodeType::Center);
        assert_eq!(center.name, "Source");
    }

    #[test]
    fn test_node_connectivity() {
        let topology = MetatronCubeTopology::new();
        
        // Center should connect to all 12 other nodes
        let center_neighbors = topology.get_neighbors(0).unwrap();
        assert_eq!(center_neighbors.len(), 12);
    }

    #[test]
    fn test_valid_transition() {
        let topology = MetatronCubeTopology::new();
        
        // Create two very similar signatures (small delta)
        let sig1 = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);
        let sig2 = Signature5D::new(0.500001, 0.500001, 0.500001, 0.500001, 0.500001);
        
        // Transition from center to node 1 should be valid with similar signatures
        assert!(topology.is_valid_transition(0, 1, &sig1, &sig2));
    }

    #[test]
    fn test_invalid_transition_large_delta() {
        let topology = MetatronCubeTopology::new();
        
        // Create signatures with large difference
        let sig1 = Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5);
        let sig2 = Signature5D::new(0.9, 0.9, 0.9, 0.9, 0.9);
        
        // Should fail transition condition
        assert!(!topology.is_valid_transition(0, 1, &sig1, &sig2));
    }

    #[test]
    fn test_seed_node() {
        let topology = MetatronCubeTopology::new();
        assert_eq!(topology.seed_node(), 0);
    }
}
