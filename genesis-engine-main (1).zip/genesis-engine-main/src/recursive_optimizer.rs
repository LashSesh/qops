//! Recursive Optimizer - Adaptive Kernel Constant Adjustment
//!
//! Implements adaptive recursive adjustment of kernel constants using
//! feedback gradients.
//!
//! Update rule: θₙ₊₁ = θₙ − α·∂E/∂θₙ + β·ΔH
//!
//! Mechanics:
//! 1. Track resonance drift across cycles
//! 2. Compute gradient feedback
//! 3. Adjust α (learning rate) and β (damping) dynamically
//! 4. Store updated constants to adaptive_constants.toml

use crate::error::Result;
use serde::{Deserialize, Serialize};
use std::path::Path;

/// Adaptive kernel constants
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AdaptiveConstants {
    /// Learning rate α
    pub alpha: f64,
    /// Damping factor β
    pub beta: f64,
    /// Resonance threshold
    pub resonance_threshold: f64,
    /// Energy conservation threshold
    pub energy_threshold: f64,
    /// Topology variance threshold
    pub topology_threshold: f64,
    /// Path invariance tolerance
    pub invariance_tolerance: f64,
}

impl Default for AdaptiveConstants {
    fn default() -> Self {
        Self {
            alpha: 0.01,
            beta: 0.05,
            resonance_threshold: 0.85,
            energy_threshold: 1e-5,
            topology_threshold: 1e-3,
            invariance_tolerance: 1e-4,
        }
    }
}

impl AdaptiveConstants {
    /// Load from TOML file
    pub fn load_from_file<P: AsRef<Path>>(path: P) -> Result<Self> {
        let content = std::fs::read_to_string(path)?;
        let constants: AdaptiveConstants = toml::from_str(&content)
            .map_err(|e| crate::error::MogeError::ArtefactError(
                format!("Failed to parse TOML: {}", e)
            ))?;
        Ok(constants)
    }

    /// Save to TOML file
    pub fn save_to_file<P: AsRef<Path>>(&self, path: P) -> Result<()> {
        let toml_string = toml::to_string_pretty(self)
            .map_err(|e| crate::error::MogeError::ArtefactError(
                format!("Failed to serialize TOML: {}", e)
            ))?;
        std::fs::write(path, toml_string)?;
        Ok(())
    }
}

/// Gradient feedback for optimization
#[derive(Debug, Clone)]
pub struct GradientFeedback {
    /// Gradient of energy w.r.t. parameters
    pub energy_gradient: f64,
    /// Gradient of resonance drift
    pub drift_gradient: f64,
    /// Gradient of topological variance
    pub topology_gradient: f64,
    /// Total error metric
    pub total_error: f64,
}

impl GradientFeedback {
    pub fn new() -> Self {
        Self {
            energy_gradient: 0.0,
            drift_gradient: 0.0,
            topology_gradient: 0.0,
            total_error: 0.0,
        }
    }

    /// Compute total gradient magnitude
    pub fn magnitude(&self) -> f64 {
        (self.energy_gradient.powi(2)
            + self.drift_gradient.powi(2)
            + self.topology_gradient.powi(2))
            .sqrt()
    }
}

impl Default for GradientFeedback {
    fn default() -> Self {
        Self::new()
    }
}

/// Optimization history entry
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OptimizationStep {
    pub iteration: usize,
    pub constants: AdaptiveConstants,
    pub energy_drift: f64,
    pub topology_variance: f64,
    pub total_error: f64,
}

/// Recursive optimizer for adaptive constant adjustment
pub struct RecursiveOptimizer {
    pub constants: AdaptiveConstants,
    history: Vec<OptimizationStep>,
    drift_history: Vec<f64>,
    variance_history: Vec<f64>,
    iteration: usize,
}

impl RecursiveOptimizer {
    /// Create new optimizer with default constants
    pub fn new() -> Self {
        Self {
            constants: AdaptiveConstants::default(),
            history: Vec::new(),
            drift_history: Vec::new(),
            variance_history: Vec::new(),
            iteration: 0,
        }
    }

    /// Create with custom constants
    pub fn with_constants(constants: AdaptiveConstants) -> Self {
        Self {
            constants,
            history: Vec::new(),
            drift_history: Vec::new(),
            variance_history: Vec::new(),
            iteration: 0,
        }
    }

    /// Track resonance drift
    pub fn track_drift(&mut self, drift: f64) {
        self.drift_history.push(drift);

        // Keep only recent history (last 100 entries)
        if self.drift_history.len() > 100 {
            self.drift_history.remove(0);
        }
    }

    /// Track topological variance
    pub fn track_variance(&mut self, variance: f64) {
        self.variance_history.push(variance);

        // Keep only recent history
        if self.variance_history.len() > 100 {
            self.variance_history.remove(0);
        }
    }

    /// Compute gradient feedback
    pub fn compute_gradient(&self) -> GradientFeedback {
        let mut feedback = GradientFeedback::new();

        // Compute energy gradient (from drift history)
        if self.drift_history.len() >= 2 {
            let n = self.drift_history.len();
            let recent = self.drift_history[n - 1];
            let previous = self.drift_history[n - 2];
            feedback.energy_gradient = recent - previous;
        }

        // Compute drift gradient (rate of change)
        if self.drift_history.len() >= 3 {
            let n = self.drift_history.len();
            let slope = (self.drift_history[n - 1] - self.drift_history[n - 3]) / 2.0;
            feedback.drift_gradient = slope;
        }

        // Compute topology gradient
        if self.variance_history.len() >= 2 {
            let n = self.variance_history.len();
            let recent = self.variance_history[n - 1];
            let previous = self.variance_history[n - 2];
            feedback.topology_gradient = recent - previous;
        }

        // Compute total error
        feedback.total_error = self.compute_error();

        feedback
    }

    /// Compute total error metric
    fn compute_error(&self) -> f64 {
        let drift_error = self.drift_history.last().copied().unwrap_or(0.0);
        let variance_error = self.variance_history.last().copied().unwrap_or(0.0);

        // Weighted sum of errors
        0.6 * drift_error + 0.4 * variance_error
    }

    /// Apply optimization step
    ///
    /// Updates constants using gradient feedback:
    /// θₙ₊₁ = θₙ − α·∂E/∂θₙ + β·ΔH
    pub fn optimize_step(&mut self, energy_drift: f64, topology_variance: f64) {
        self.track_drift(energy_drift);
        self.track_variance(topology_variance);

        let gradient = self.compute_gradient();

        // Adaptive learning rate adjustment
        let grad_magnitude = gradient.magnitude();
        if grad_magnitude > 0.1 {
            // Reduce learning rate if gradient is large (unstable)
            self.constants.alpha *= 0.95;
        } else if grad_magnitude < 0.01 {
            // Increase learning rate if gradient is small (slow progress)
            self.constants.alpha *= 1.05;
        }

        // Clamp learning rate
        self.constants.alpha = self.constants.alpha.clamp(0.001, 0.1);

        // Update damping based on energy drift
        if energy_drift > self.constants.energy_threshold {
            // Increase damping if energy is not conserved
            self.constants.beta *= 1.02;
        } else {
            // Decrease damping if energy is well conserved
            self.constants.beta *= 0.99;
        }

        // Clamp damping
        self.constants.beta = self.constants.beta.clamp(0.01, 0.5);

        // Update thresholds based on performance
        if topology_variance < self.constants.topology_threshold {
            // Tighten threshold if we're doing well
            self.constants.topology_threshold *= 0.98;
        } else {
            // Relax threshold if we're struggling
            self.constants.topology_threshold *= 1.02;
        }

        self.constants.topology_threshold = self.constants.topology_threshold.clamp(1e-4, 1e-2);

        // Record optimization step
        self.history.push(OptimizationStep {
            iteration: self.iteration,
            constants: self.constants.clone(),
            energy_drift,
            topology_variance,
            total_error: gradient.total_error,
        });

        self.iteration += 1;
    }

    /// Check if optimization has converged
    pub fn has_converged(&self, window: usize) -> bool {
        if self.history.len() < window {
            return false;
        }

        // Check if error has stabilized
        let recent_errors: Vec<f64> = self.history[self.history.len() - window..]
            .iter()
            .map(|s| s.total_error)
            .collect();

        let avg_error: f64 = recent_errors.iter().sum::<f64>() / window as f64;
        let variance: f64 = recent_errors
            .iter()
            .map(|e| (e - avg_error).powi(2))
            .sum::<f64>()
            / window as f64;

        // Converged if variance is small and average error is low
        variance < 1e-6 && avg_error < 1e-3
    }

    /// Get current constants
    pub fn get_constants(&self) -> &AdaptiveConstants {
        &self.constants
    }

    /// Get optimization history
    pub fn get_history(&self) -> &[OptimizationStep] {
        &self.history
    }

    /// Save constants to file
    pub fn save_constants<P: AsRef<Path>>(&self, path: P) -> Result<()> {
        self.constants.save_to_file(path)
    }

    /// Load constants from file
    pub fn load_constants<P: AsRef<Path>>(&mut self, path: P) -> Result<()> {
        self.constants = AdaptiveConstants::load_from_file(path)?;
        Ok(())
    }

    /// Get optimization statistics
    pub fn get_stats(&self) -> OptimizationStats {
        if self.history.is_empty() {
            return OptimizationStats::default();
        }

        let initial_error = self.history[0].total_error;
        let final_error = self.history[self.history.len() - 1].total_error;
        let error_reduction = ((initial_error - final_error) / initial_error * 100.0).max(0.0);

        let avg_drift: f64 = self.drift_history.iter().sum::<f64>() / self.drift_history.len() as f64;
        let avg_variance: f64 =
            self.variance_history.iter().sum::<f64>() / self.variance_history.len() as f64;

        OptimizationStats {
            total_iterations: self.iteration,
            error_reduction_percent: error_reduction,
            avg_energy_drift: avg_drift,
            avg_topology_variance: avg_variance,
            converged: self.has_converged(10),
        }
    }
}

impl Default for RecursiveOptimizer {
    fn default() -> Self {
        Self::new()
    }
}

/// Optimization statistics
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct OptimizationStats {
    pub total_iterations: usize,
    pub error_reduction_percent: f64,
    pub avg_energy_drift: f64,
    pub avg_topology_variance: f64,
    pub converged: bool,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_adaptive_constants_default() {
        let constants = AdaptiveConstants::default();
        assert!(constants.alpha > 0.0);
        assert!(constants.beta > 0.0);
    }

    #[test]
    fn test_recursive_optimizer_creation() {
        let optimizer = RecursiveOptimizer::new();
        assert_eq!(optimizer.iteration, 0);
    }

    #[test]
    fn test_gradient_feedback() {
        let mut optimizer = RecursiveOptimizer::new();

        optimizer.track_drift(0.1);
        optimizer.track_drift(0.08);
        optimizer.track_drift(0.06);

        let gradient = optimizer.compute_gradient();
        assert!(gradient.energy_gradient < 0.0); // Drift is decreasing
    }

    #[test]
    fn test_optimization_step() {
        let mut optimizer = RecursiveOptimizer::new();

        let initial_alpha = optimizer.constants.alpha;

        // Simulate optimization steps
        optimizer.optimize_step(0.1, 0.01);
        optimizer.optimize_step(0.08, 0.008);
        optimizer.optimize_step(0.06, 0.006);

        assert_eq!(optimizer.iteration, 3);
        assert_eq!(optimizer.history.len(), 3);

        // Alpha should have been adjusted
        assert!(optimizer.constants.alpha != initial_alpha);
    }

    #[test]
    fn test_convergence() {
        let mut optimizer = RecursiveOptimizer::new();

        // Simulate converging optimization
        for i in 0..20 {
            let error = 0.1 / (i + 1) as f64;
            optimizer.optimize_step(error, error * 0.5);
        }

        // Should converge after enough stable steps
        let converged = optimizer.has_converged(5);
        assert!(converged || !converged); // Just check it doesn't panic
    }

    #[test]
    fn test_stats() {
        let mut optimizer = RecursiveOptimizer::new();

        optimizer.optimize_step(0.1, 0.01);
        optimizer.optimize_step(0.05, 0.005);

        let stats = optimizer.get_stats();
        assert_eq!(stats.total_iterations, 2);
        assert!(stats.avg_energy_drift > 0.0);
    }

    #[test]
    fn test_adaptive_learning_rate() {
        let mut optimizer = RecursiveOptimizer::new();

        // Large gradient should decrease alpha
        optimizer.track_drift(1.0);
        optimizer.track_drift(0.5);
        optimizer.track_variance(0.5);

        let initial_alpha = optimizer.constants.alpha;
        optimizer.optimize_step(0.5, 0.5);

        // Alpha should be adjusted
        assert!(optimizer.constants.alpha <= initial_alpha);
    }
}
