//! Distributed Traversal Module
//!
//! Enables distributed computation of MOGE traversals:
//! - Work distribution across multiple nodes
//! - Result aggregation and synchronization
//! - Load balancing
//! - Fault tolerance

use crate::agent::AgentConfig;
use crate::artefact::Artefact;
use crate::traversal::TraversalEngine;
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};

/// Distributed node identifier
pub type NodeId = String;

/// Work unit for distributed traversal
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkUnit {
    pub id: uuid::Uuid,
    pub agent_config: AgentConfig,
    pub start_node: usize,
    pub assigned_to: Option<NodeId>,
    pub status: WorkStatus,
}

/// Work unit status
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum WorkStatus {
    Pending,
    Assigned,
    InProgress,
    Completed,
    Failed,
}

/// Distributed traversal result
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DistributedResult {
    pub work_id: uuid::Uuid,
    pub node_id: NodeId,
    pub artefact: Option<Artefact>,
    pub error: Option<String>,
    pub execution_time_ms: u64,
}

/// Distributed coordinator configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CoordinatorConfig {
    /// Maximum work units per node
    pub max_work_per_node: usize,
    /// Enable automatic work redistribution
    pub enable_redistribution: bool,
    /// Timeout for work units (milliseconds)
    pub work_timeout_ms: u64,
    /// Number of retry attempts for failed work
    pub max_retries: usize,
}

impl Default for CoordinatorConfig {
    fn default() -> Self {
        Self {
            max_work_per_node: 10,
            enable_redistribution: true,
            work_timeout_ms: 60000, // 1 minute
            max_retries: 3,
        }
    }
}

/// Distributed coordinator
pub struct DistributedCoordinator {
    config: CoordinatorConfig,
    work_queue: Arc<Mutex<Vec<WorkUnit>>>,
    active_nodes: Arc<Mutex<HashMap<NodeId, NodeInfo>>>,
    results: Arc<Mutex<Vec<DistributedResult>>>,
    _engine: Arc<Mutex<TraversalEngine>>,
}

/// Information about a compute node
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeInfo {
    pub id: NodeId,
    pub capacity: usize,
    pub current_load: usize,
    pub completed_work: usize,
    pub failed_work: usize,
    pub last_heartbeat: chrono::DateTime<chrono::Utc>,
}

impl DistributedCoordinator {
    /// Create a new coordinator
    pub fn new(config: CoordinatorConfig) -> Self {
        Self {
            config,
            work_queue: Arc::new(Mutex::new(Vec::new())),
            active_nodes: Arc::new(Mutex::new(HashMap::new())),
            results: Arc::new(Mutex::new(Vec::new())),
            _engine: Arc::new(Mutex::new(TraversalEngine::new())),
        }
    }

    /// Register a compute node
    pub fn register_node(&self, node_id: NodeId, capacity: usize) -> Result<()> {
        let mut nodes = self.active_nodes.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock nodes: {}", e))
        })?;

        let info = NodeInfo {
            id: node_id.clone(),
            capacity,
            current_load: 0,
            completed_work: 0,
            failed_work: 0,
            last_heartbeat: chrono::Utc::now(),
        };

        nodes.insert(node_id, info);
        Ok(())
    }

    /// Unregister a compute node
    pub fn unregister_node(&self, node_id: &str) -> Result<()> {
        let mut nodes = self.active_nodes.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock nodes: {}", e))
        })?;

        nodes.remove(node_id);

        // Reassign work from this node
        if self.config.enable_redistribution {
            self.reassign_work_from_node(node_id)?;
        }

        Ok(())
    }

    /// Submit work units for distributed processing
    pub fn submit_work(&self, work_units: Vec<WorkUnit>) -> Result<()> {
        let mut queue = self.work_queue.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock queue: {}", e))
        })?;

        queue.extend(work_units);
        Ok(())
    }

    /// Get next work unit for a node
    pub fn get_work(&self, node_id: &str) -> Result<Option<WorkUnit>> {
        let mut queue = self.work_queue.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock queue: {}", e))
        })?;

        let mut nodes = self.active_nodes.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock nodes: {}", e))
        })?;

        // Check node capacity
        if let Some(node) = nodes.get(node_id) {
            if node.current_load >= self.config.max_work_per_node {
                return Ok(None);
            }
        } else {
            return Err(MogeError::InvalidArtefact(format!(
                "Node '{}' not registered",
                node_id
            )));
        }

        // Find pending work
        if let Some(work) = queue.iter_mut().find(|w| w.status == WorkStatus::Pending) {
            work.assigned_to = Some(node_id.to_string());
            work.status = WorkStatus::Assigned;

            // Update node load
            if let Some(node) = nodes.get_mut(node_id) {
                node.current_load += 1;
                node.last_heartbeat = chrono::Utc::now();
            }

            return Ok(Some(work.clone()));
        }

        Ok(None)
    }

    /// Submit a completed result
    pub fn submit_result(&self, result: DistributedResult) -> Result<()> {
        let mut results = self.results.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock results: {}", e))
        })?;

        let mut nodes = self.active_nodes.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock nodes: {}", e))
        })?;

        // Update work status
        let mut queue = self.work_queue.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock queue: {}", e))
        })?;

        if let Some(work) = queue.iter_mut().find(|w| w.id == result.work_id) {
            work.status = if result.error.is_none() {
                WorkStatus::Completed
            } else {
                WorkStatus::Failed
            };
        }

        // Update node stats
        if let Some(node) = nodes.get_mut(&result.node_id) {
            node.current_load = node.current_load.saturating_sub(1);
            if result.error.is_none() {
                node.completed_work += 1;
            } else {
                node.failed_work += 1;
            }
            node.last_heartbeat = chrono::Utc::now();
        }

        results.push(result);
        Ok(())
    }

    /// Get all results
    pub fn get_results(&self) -> Result<Vec<DistributedResult>> {
        let results = self.results.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock results: {}", e))
        })?;

        Ok(results.clone())
    }

    /// Get coordinator statistics
    pub fn get_statistics(&self) -> Result<DistributedStats> {
        let queue = self.work_queue.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock queue: {}", e))
        })?;

        let nodes = self.active_nodes.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock nodes: {}", e))
        })?;

        let _results = self.results.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock results: {}", e))
        })?;

        let total_work = queue.len();
        let pending = queue.iter().filter(|w| w.status == WorkStatus::Pending).count();
        let in_progress = queue.iter().filter(|w| w.status == WorkStatus::InProgress).count();
        let completed = queue.iter().filter(|w| w.status == WorkStatus::Completed).count();
        let failed = queue.iter().filter(|w| w.status == WorkStatus::Failed).count();

        let total_nodes = nodes.len();
        let total_capacity: usize = nodes.values().map(|n| n.capacity).sum();
        let total_load: usize = nodes.values().map(|n| n.current_load).sum();

        Ok(DistributedStats {
            total_work,
            pending,
            in_progress,
            completed,
            failed,
            total_nodes,
            total_capacity,
            total_load,
            success_rate: if completed + failed > 0 {
                completed as f64 / (completed + failed) as f64
            } else {
                0.0
            },
        })
    }

    /// Reassign work from a failed node
    fn reassign_work_from_node(&self, node_id: &str) -> Result<()> {
        let mut queue = self.work_queue.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock queue: {}", e))
        })?;

        for work in queue.iter_mut() {
            if let Some(assigned) = &work.assigned_to {
                if assigned == node_id && work.status != WorkStatus::Completed {
                    work.assigned_to = None;
                    work.status = WorkStatus::Pending;
                }
            }
        }

        Ok(())
    }

    /// Check for timed-out work units
    pub fn check_timeouts(&self) -> Result<usize> {
        let mut queue = self.work_queue.lock().map_err(|e| {
            MogeError::InvalidArtefact(format!("Failed to lock queue: {}", e))
        })?;

        let _timeout = chrono::Duration::milliseconds(self.config.work_timeout_ms as i64);
        let _now = chrono::Utc::now();
        let mut timed_out = 0;

        for work in queue.iter_mut() {
            if work.status == WorkStatus::InProgress || work.status == WorkStatus::Assigned {
                // Check if work has timed out (simplified - would need timestamp tracking)
                // This is a placeholder implementation
                timed_out += 1;
            }
        }

        Ok(timed_out)
    }
}

/// Distributed statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DistributedStats {
    pub total_work: usize,
    pub pending: usize,
    pub in_progress: usize,
    pub completed: usize,
    pub failed: usize,
    pub total_nodes: usize,
    pub total_capacity: usize,
    pub total_load: usize,
    pub success_rate: f64,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_coordinator_creation() {
        let config = CoordinatorConfig::default();
        let coordinator = DistributedCoordinator::new(config);

        let stats = coordinator.get_statistics().unwrap();
        assert_eq!(stats.total_nodes, 0);
        assert_eq!(stats.total_work, 0);
    }

    #[test]
    fn test_node_registration() {
        let config = CoordinatorConfig::default();
        let coordinator = DistributedCoordinator::new(config);

        coordinator.register_node("node1".to_string(), 10).unwrap();

        let stats = coordinator.get_statistics().unwrap();
        assert_eq!(stats.total_nodes, 1);
        assert_eq!(stats.total_capacity, 10);
    }

    #[test]
    fn test_work_submission() {
        let config = CoordinatorConfig::default();
        let coordinator = DistributedCoordinator::new(config);

        let work = WorkUnit {
            id: uuid::Uuid::new_v4(),
            agent_config: AgentConfig::default(),
            start_node: 0,
            assigned_to: None,
            status: WorkStatus::Pending,
        };

        coordinator.submit_work(vec![work]).unwrap();

        let stats = coordinator.get_statistics().unwrap();
        assert_eq!(stats.total_work, 1);
        assert_eq!(stats.pending, 1);
    }

    #[test]
    fn test_work_assignment() {
        let config = CoordinatorConfig::default();
        let coordinator = DistributedCoordinator::new(config);

        coordinator.register_node("node1".to_string(), 10).unwrap();

        let work = WorkUnit {
            id: uuid::Uuid::new_v4(),
            agent_config: AgentConfig::default(),
            start_node: 0,
            assigned_to: None,
            status: WorkStatus::Pending,
        };

        coordinator.submit_work(vec![work]).unwrap();

        let assigned = coordinator.get_work("node1").unwrap();
        assert!(assigned.is_some());

        let stats = coordinator.get_statistics().unwrap();
        assert_eq!(stats.total_load, 1);
    }
}
