//! KNO Potential Energy Module
//!
//! Provides polynomial potential energy functions and analysis tools
//! for the KNO framework operator evolution.

use crate::kno_framework::{PolynomialPotential, PRECISION};
use serde::{Deserialize, Serialize};

/// Potential energy analysis tools
pub struct PotentialAnalyzer {
    pub potential: PolynomialPotential,
}

impl PotentialAnalyzer {
    /// Create analyzer from potential
    pub fn new(potential: PolynomialPotential) -> Self {
        Self { potential }
    }

    /// Find all critical points (V' = 0)
    pub fn find_critical_points(&self, omega_range: (f64, f64), samples: usize) -> Vec<f64> {
        let mut critical_points = Vec::new();
        let step = (omega_range.1 - omega_range.0) / samples as f64;

        let mut prev_gradient = self.potential.gradient(omega_range.0);

        for i in 1..=samples {
            let omega = omega_range.0 + i as f64 * step;
            let gradient = self.potential.gradient(omega);

            // Check for sign change (critical point)
            if prev_gradient * gradient < 0.0 {
                // Refine using bisection
                let prev_omega = omega_range.0 + (i - 1) as f64 * step;
                if let Some(critical) = self.bisection_refine(prev_omega, omega) {
                    critical_points.push(critical);
                }
            }

            prev_gradient = gradient;
        }

        critical_points
    }

    /// Refine critical point using bisection method
    fn bisection_refine(&self, a: f64, b: f64) -> Option<f64> {
        let mut left = a;
        let mut right = b;
        let tolerance = 1e-10;
        let max_iterations = 50;

        for _ in 0..max_iterations {
            let mid = (left + right) / 2.0;
            let grad = self.potential.gradient(mid);

            if grad.abs() < tolerance {
                return Some(mid);
            }

            let grad_left = self.potential.gradient(left);
            if grad * grad_left < 0.0 {
                right = mid;
            } else {
                left = mid;
            }
        }

        Some((left + right) / 2.0)
    }

    /// Classify critical points as minima, maxima, or saddle points
    pub fn classify_critical_points(&self, critical_points: &[f64]) -> Vec<CriticalPointType> {
        critical_points
            .iter()
            .map(|&omega| {
                let v_pp = self.potential.second_derivative(omega);
                if v_pp > PRECISION {
                    CriticalPointType::Minimum
                } else if v_pp < -PRECISION {
                    CriticalPointType::Maximum
                } else {
                    CriticalPointType::Saddle
                }
            })
            .collect()
    }

    /// Compute potential energy landscape
    pub fn compute_landscape(&self, omega_range: (f64, f64), samples: usize) -> PotentialLandscape {
        let step = (omega_range.1 - omega_range.0) / samples as f64;
        let mut omega_values = Vec::new();
        let mut potential_values = Vec::new();
        let mut gradient_values = Vec::new();

        for i in 0..=samples {
            let omega = omega_range.0 + i as f64 * step;
            omega_values.push(omega);
            potential_values.push(self.potential.evaluate(omega));
            gradient_values.push(self.potential.gradient(omega));
        }

        PotentialLandscape {
            omega_values,
            potential_values,
            gradient_values,
            critical_points: self.find_critical_points(omega_range, samples * 2),
        }
    }

    /// Check if potential is bounded from below
    pub fn is_bounded_below(&self, omega_range: (f64, f64), samples: usize) -> bool {
        let step = (omega_range.1 - omega_range.0) / samples as f64;

        for i in 0..=samples {
            let omega = omega_range.0 + i as f64 * step;
            let v = self.potential.evaluate(omega);
            if v < -1e6 {
                return false; // Unbounded below
            }
        }

        true
    }
}

/// Critical point classification
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CriticalPointType {
    Minimum,
    Maximum,
    Saddle,
}

/// Potential energy landscape data
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PotentialLandscape {
    pub omega_values: Vec<f64>,
    pub potential_values: Vec<f64>,
    pub gradient_values: Vec<f64>,
    pub critical_points: Vec<f64>,
}

impl PotentialLandscape {
    /// Find global minimum
    pub fn global_minimum(&self) -> Option<(f64, f64)> {
        self.potential_values
            .iter()
            .enumerate()
            .min_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
            .map(|(i, &v)| (self.omega_values[i], v))
    }

    /// Find global maximum
    pub fn global_maximum(&self) -> Option<(f64, f64)> {
        self.potential_values
            .iter()
            .enumerate()
            .max_by(|(_, a), (_, b)| a.partial_cmp(b).unwrap())
            .map(|(i, &v)| (self.omega_values[i], v))
    }

    /// Compute mean potential energy
    pub fn mean_potential(&self) -> f64 {
        if self.potential_values.is_empty() {
            return 0.0;
        }
        self.potential_values.iter().sum::<f64>() / self.potential_values.len() as f64
    }
}

/// Harmonic potential: V(ω) = ½k(ω - ω₀)²
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HarmonicPotential {
    pub omega_0: f64,
    pub stiffness: f64,
}

impl HarmonicPotential {
    pub fn new(omega_0: f64, stiffness: f64) -> Self {
        Self { omega_0, stiffness }
    }

    pub fn evaluate(&self, omega: f64) -> f64 {
        0.5 * self.stiffness * (omega - self.omega_0).powi(2)
    }

    pub fn gradient(&self, omega: f64) -> f64 {
        self.stiffness * (omega - self.omega_0)
    }

    pub fn second_derivative(&self, _omega: f64) -> f64 {
        self.stiffness
    }

    /// Convert to polynomial potential
    pub fn to_polynomial(&self) -> PolynomialPotential {
        let c0 = 0.5 * self.stiffness * self.omega_0 * self.omega_0;
        let c1 = -self.stiffness * self.omega_0;
        let c2 = 0.5 * self.stiffness;

        PolynomialPotential {
            coefficients: vec![c0, c1, c2],
            riemann_zeros: vec![self.omega_0],
        }
    }
}

/// Quartic potential: V(ω) = a₄ω⁴ + a₂ω² + a₀
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QuarticPotential {
    pub a4: f64,
    pub a2: f64,
    pub a0: f64,
}

impl QuarticPotential {
    pub fn new(a4: f64, a2: f64, a0: f64) -> Self {
        Self { a4, a2, a0 }
    }

    pub fn evaluate(&self, omega: f64) -> f64 {
        self.a4 * omega.powi(4) + self.a2 * omega.powi(2) + self.a0
    }

    pub fn gradient(&self, omega: f64) -> f64 {
        4.0 * self.a4 * omega.powi(3) + 2.0 * self.a2 * omega
    }

    pub fn second_derivative(&self, omega: f64) -> f64 {
        12.0 * self.a4 * omega.powi(2) + 2.0 * self.a2
    }

    /// Convert to polynomial potential
    pub fn to_polynomial(&self) -> PolynomialPotential {
        PolynomialPotential {
            coefficients: vec![self.a0, 0.0, self.a2, 0.0, self.a4],
            riemann_zeros: Vec::new(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_harmonic_potential() {
        let harmonic = HarmonicPotential::new(1.0, 2.0);

        assert!((harmonic.evaluate(1.0) - 0.0).abs() < 1e-10);
        assert!((harmonic.gradient(1.0) - 0.0).abs() < 1e-10);
        assert!((harmonic.second_derivative(1.0) - 2.0).abs() < 1e-10);
    }

    #[test]
    fn test_quartic_potential() {
        let quartic = QuarticPotential::new(0.1, -1.0, 0.5);

        let v0 = quartic.evaluate(0.0);
        assert!((v0 - 0.5).abs() < 1e-10);

        let grad0 = quartic.gradient(0.0);
        assert!(grad0.abs() < 1e-10);
    }

    #[test]
    fn test_potential_analyzer() {
        let zeros = vec![14.134725, 21.022040];
        let potential = PolynomialPotential::from_riemann_zeros(zeros, 1.0);
        let analyzer = PotentialAnalyzer::new(potential);

        let landscape = analyzer.compute_landscape((10.0, 25.0), 100);
        assert!(!landscape.omega_values.is_empty());
        assert_eq!(landscape.omega_values.len(), landscape.potential_values.len());
    }

    #[test]
    fn test_critical_points() {
        let zeros = vec![15.0, 20.0];
        let potential = PolynomialPotential::from_riemann_zeros(zeros, 1.0);
        let analyzer = PotentialAnalyzer::new(potential);

        let critical = analyzer.find_critical_points((10.0, 25.0), 1000);
        assert!(!critical.is_empty());
    }

    #[test]
    fn test_bounded_below() {
        let harmonic = HarmonicPotential::new(0.0, 1.0);
        let potential = harmonic.to_polynomial();
        let analyzer = PotentialAnalyzer::new(potential);

        assert!(analyzer.is_bounded_below((-10.0, 10.0), 100));
    }

    #[test]
    fn test_landscape_statistics() {
        let harmonic = HarmonicPotential::new(5.0, 2.0);
        let potential = harmonic.to_polynomial();
        let analyzer = PotentialAnalyzer::new(potential);

        let landscape = analyzer.compute_landscape((0.0, 10.0), 50);

        let (min_omega, min_v) = landscape.global_minimum().unwrap();
        assert!((min_omega - 5.0).abs() < 0.5); // Should be near omega_0
        assert!(min_v < 1.0); // Should be small near minimum
    }

    #[test]
    fn test_classify_critical_points() {
        let harmonic = HarmonicPotential::new(3.0, 1.0);
        let potential = harmonic.to_polynomial();
        let analyzer = PotentialAnalyzer::new(potential);

        let critical = vec![3.0]; // Known minimum
        let types = analyzer.classify_critical_points(&critical);

        assert_eq!(types.len(), 1);
        assert_eq!(types[0], CriticalPointType::Minimum);
    }
}
