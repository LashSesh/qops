//! Operator Lexicon API Module
//!
//! Provides unified access to operator artifacts, resonance data, visual metadata,
//! and audit trails within the Metatron Operator Cosmos.
//!
//! Supports:
//! - REST API endpoints for operator CRUD
//! - WebSocket telemetry for real-time metrics
//! - Ledger query and analytics

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use crate::cosmic_manifest::{CosmicOperatorManifest, ViewMode, ColorScheme};
use crate::proof_of_resonance::ProofOfResonanceEntry;
use crate::error::{Result, MogeError};

/// Operator Lexicon - Main API handler
pub struct OperatorLexicon {
    /// Operator storage (in-memory, could be backed by database)
    operators: Arc<Mutex<HashMap<String, CosmicOperatorManifest>>>,
    
    /// Ledger entries
    ledger: Arc<Mutex<HashMap<String, ProofOfResonanceEntry>>>,
    
    /// Telemetry buffer for WebSocket
    telemetry_buffer: Arc<Mutex<Vec<TelemetryMessage>>>,
}

impl OperatorLexicon {
    /// Create a new operator lexicon
    pub fn new() -> Self {
        Self {
            operators: Arc::new(Mutex::new(HashMap::new())),
            ledger: Arc::new(Mutex::new(HashMap::new())),
            telemetry_buffer: Arc::new(Mutex::new(Vec::new())),
        }
    }

    /// GET /operator - List or search all operator entries
    pub fn list_operators(&self, query: OperatorQuery) -> Result<Vec<OperatorSummary>> {
        let operators = self.operators.lock().unwrap();
        
        let mut results: Vec<OperatorSummary> = operators
            .values()
            .filter(|op| self.matches_query(op, &query))
            .map(|op| OperatorSummary::from_manifest(op))
            .collect();
        
        // Sort results
        match query.sort.as_deref() {
            Some("stability") => results.sort_by(|a, b| {
                b.stability.partial_cmp(&a.stability).unwrap()
            }),
            Some("entropy") => results.sort_by(|a, b| {
                a.entropy_gradient.partial_cmp(&b.entropy_gradient).unwrap()
            }),
            Some("creation_time") => results.sort_by(|a, b| {
                b.created_at.cmp(&a.created_at)
            }),
            _ => {} // No sorting or unknown sort key
        }
        
        Ok(results)
    }

    /// Check if operator matches query filters
    fn matches_query(&self, op: &CosmicOperatorManifest, query: &OperatorQuery) -> bool {
        // Filter by tag
        if let Some(ref tag) = query.tag {
            if !op.semantic_tags.contains(tag) {
                return false;
            }
        }
        
        // Filter by minimum stability
        if let Some(min_stability) = query.stability_min {
            if op.entropic_dynamics.stability_rating < min_stability {
                return false;
            }
        }
        
        // Filter by symmetry class
        if let Some(ref symmetry) = query.symmetry {
            if &op.topology_signature.symmetry_class != symmetry {
                return false;
            }
        }
        
        true
    }

    /// POST /operator - Submit new operator artifact
    pub fn create_operator(&self, manifest: CosmicOperatorManifest) -> Result<String> {
        let id = manifest.id.clone();
        
        // Store in operators collection
        let mut operators = self.operators.lock().unwrap();
        operators.insert(id.clone(), manifest.clone());
        
        // Emit telemetry
        self.emit_telemetry(TelemetryMessage::NewOperator {
            id: id.clone(),
            stability: manifest.entropic_dynamics.stability_rating,
            symmetry_class: manifest.topology_signature.symmetry_class.clone(),
        });
        
        Ok(id)
    }

    /// GET /operator/{id} - Retrieve full manifest
    pub fn get_operator(&self, id: &str) -> Result<CosmicOperatorManifest> {
        let operators = self.operators.lock().unwrap();
        operators.get(id)
            .cloned()
            .ok_or_else(|| MogeError::ArtefactError(format!("Operator {} not found", id)))
    }

    /// DELETE /operator/{id} - Remove operator (admin only)
    pub fn delete_operator(&self, id: &str) -> Result<()> {
        let mut operators = self.operators.lock().unwrap();
        operators.remove(id)
            .ok_or_else(|| MogeError::ArtefactError(format!("Operator {} not found", id)))?;
        Ok(())
    }

    /// GET /operator/{id}/visual - Fetch visualization assets
    pub fn get_operator_visual(&self, id: &str) -> Result<VisualResponse> {
        let op = self.get_operator(id)?;
        
        Ok(VisualResponse {
            thumbnail: op.visualization_metadata.thumbnail.clone(),
            preferred_view: op.visualization_metadata.preferred_view,
            color_scheme: op.visualization_metadata.color_scheme,
            position_in_cube: op.visualization_metadata.position_in_cube,
            data_uri: None, // Would be populated with actual rendered data
        })
    }

    /// GET /operator/{id}/relations - Retrieve graph of related operators
    pub fn get_operator_relations(&self, id: &str) -> Result<RelationsResponse> {
        let op = self.get_operator(id)?;
        
        Ok(RelationsResponse {
            root: id.to_string(),
            nodes: op.relations.iter()
                .map(|r| r.target_id.clone())
                .collect(),
            edges: op.relations.clone(),
        })
    }

    /// GET /ledger - List Proof-of-Resonance ledger entries
    pub fn list_ledger(&self, validated_only: Option<bool>) -> Result<Vec<LedgerHeader>> {
        let ledger = self.ledger.lock().unwrap();
        
        let mut headers: Vec<LedgerHeader> = ledger
            .values()
            .filter(|entry| {
                if let Some(true) = validated_only {
                    entry.mandorla_condition
                } else {
                    true
                }
            })
            .map(|entry| LedgerHeader {
                id: entry.id.clone(),
                hash: entry.proof_hash.clone(),
                timestamp: entry.timestamp,
                energy: entry.operator_tensor.energy,
            })
            .collect();
        
        // Sort by timestamp descending
        headers.sort_by(|a, b| b.timestamp.cmp(&a.timestamp));
        
        Ok(headers)
    }

    /// GET /ledger/{hash} - Fetch full audit trail
    pub fn get_ledger_entry(&self, hash: &str) -> Result<AuditResponse> {
        let ledger = self.ledger.lock().unwrap();
        
        let entry = ledger.values()
            .find(|e| e.proof_hash == hash)
            .ok_or_else(|| MogeError::LedgerError(format!("Entry with hash {} not found", hash)))?;
        
        Ok(AuditResponse {
            hash: entry.proof_hash.clone(),
            cycles_validated: entry.validation_cycles,
            energy_conservation: true, // Computed from entry
            entropy_trace: entry.entropy_curve.clone(),
            proof_document: serde_json::to_string(entry)?,
        })
    }

    /// Add a ledger entry
    pub fn add_ledger_entry(&self, entry: ProofOfResonanceEntry) -> Result<()> {
        let mut ledger = self.ledger.lock().unwrap();
        ledger.insert(entry.proof_hash.clone(), entry);
        Ok(())
    }

    /// GET /analytics - Aggregate statistics
    pub fn get_analytics(&self) -> Result<AnalyticsResponse> {
        let operators = self.operators.lock().unwrap();
        
        if operators.is_empty() {
            return Ok(AnalyticsResponse {
                total_operators: 0,
                average_entropy: 0.0,
                mean_stability: 0.0,
                dominant_symmetry_class: "none".to_string(),
                recent_activity: vec![],
            });
        }
        
        let total = operators.len();
        let sum_entropy: f64 = operators.values()
            .map(|op| op.entropic_dynamics.entropy_gradient)
            .sum();
        let sum_stability: f64 = operators.values()
            .map(|op| op.entropic_dynamics.stability_rating)
            .sum();
        
        // Find dominant symmetry class
        let mut symmetry_counts: HashMap<String, usize> = HashMap::new();
        for op in operators.values() {
            *symmetry_counts.entry(op.topology_signature.symmetry_class.clone())
                .or_insert(0) += 1;
        }
        let dominant = symmetry_counts.iter()
            .max_by_key(|(_, count)| *count)
            .map(|(sym, _)| sym.clone())
            .unwrap_or_else(|| "unknown".to_string());
        
        // Recent activity (last 10)
        let mut recent: Vec<(chrono::DateTime<chrono::Utc>, String)> = operators.values()
            .map(|op| (op.creation_timestamp, op.id.clone()))
            .collect();
        recent.sort_by(|a, b| b.0.cmp(&a.0));
        recent.truncate(10);
        
        Ok(AnalyticsResponse {
            total_operators: total,
            average_entropy: sum_entropy / total as f64,
            mean_stability: sum_stability / total as f64,
            dominant_symmetry_class: dominant,
            recent_activity: recent,
        })
    }

    /// Emit telemetry message
    fn emit_telemetry(&self, message: TelemetryMessage) {
        let mut buffer = self.telemetry_buffer.lock().unwrap();
        buffer.push(message);
        
        // Keep buffer size reasonable (last 1000 messages)
        if buffer.len() > 1000 {
            buffer.drain(0..500);
        }
    }

    /// Get telemetry messages (for WebSocket consumption)
    pub fn get_telemetry(&self, since: usize) -> Vec<TelemetryMessage> {
        let buffer = self.telemetry_buffer.lock().unwrap();
        if since < buffer.len() {
            buffer[since..].to_vec()
        } else {
            vec![]
        }
    }

    /// Emit status telemetry
    pub fn emit_status(&self, status: StatusTelemetry) {
        self.emit_telemetry(TelemetryMessage::Status(status));
    }

    /// Emit alert telemetry
    pub fn emit_alert(&self, severity: String, message: String) {
        self.emit_telemetry(TelemetryMessage::Alert { severity, message });
    }
}

impl Default for OperatorLexicon {
    fn default() -> Self {
        Self::new()
    }
}

// ========== API Request/Response Types ==========

/// Query parameters for listing operators
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct OperatorQuery {
    pub tag: Option<String>,
    pub stability_min: Option<f64>,
    pub symmetry: Option<String>,
    pub sort: Option<String>,
}

/// Operator summary for list responses
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorSummary {
    pub id: String,
    pub name: Option<String>,
    pub stability: f64,
    pub entropy_gradient: f64,
    pub symmetry_class: String,
    pub mandorla_certified: bool,
    pub created_at: chrono::DateTime<chrono::Utc>,
}

impl OperatorSummary {
    fn from_manifest(manifest: &CosmicOperatorManifest) -> Self {
        Self {
            id: manifest.id.clone(),
            name: manifest.name.clone(),
            stability: manifest.entropic_dynamics.stability_rating,
            entropy_gradient: manifest.entropic_dynamics.entropy_gradient,
            symmetry_class: manifest.topology_signature.symmetry_class.clone(),
            mandorla_certified: manifest.proof_of_resonance.mandorla_condition,
            created_at: manifest.creation_timestamp,
        }
    }
}

/// Visual response
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VisualResponse {
    pub thumbnail: Option<String>,
    pub preferred_view: ViewMode,
    pub color_scheme: ColorScheme,
    pub position_in_cube: [f64; 3],
    pub data_uri: Option<String>,
}

/// Relations response
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RelationsResponse {
    pub root: String,
    pub nodes: Vec<String>,
    pub edges: Vec<crate::cosmic_manifest::OperatorRelation>,
}

/// Ledger header
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LedgerHeader {
    pub id: String,
    pub hash: String,
    pub timestamp: chrono::DateTime<chrono::Utc>,
    pub energy: f64,
}

/// Audit response
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditResponse {
    pub hash: String,
    pub cycles_validated: usize,
    pub energy_conservation: bool,
    pub entropy_trace: Vec<f64>,
    pub proof_document: String,
}

/// Analytics response
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalyticsResponse {
    pub total_operators: usize,
    pub average_entropy: f64,
    pub mean_stability: f64,
    pub dominant_symmetry_class: String,
    pub recent_activity: Vec<(chrono::DateTime<chrono::Utc>, String)>,
}

// ========== WebSocket Telemetry ==========

/// Telemetry message types
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum TelemetryMessage {
    Status(StatusTelemetry),
    NewOperator {
        id: String,
        stability: f64,
        symmetry_class: String,
    },
    Alert {
        severity: String,
        message: String,
    },
}

/// Status telemetry
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StatusTelemetry {
    pub cycle: usize,
    pub active_operator: Option<String>,
    pub delta_h: f64,
    pub delta_s: f64,
    pub psi_variance: f64,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Signature, Signature5D};

    #[test]
    fn test_lexicon_creation() {
        let lexicon = OperatorLexicon::new();
        let result = lexicon.list_operators(OperatorQuery::default()).unwrap();
        assert_eq!(result.len(), 0);
    }

    #[test]
    fn test_create_and_retrieve_operator() {
        let lexicon = OperatorLexicon::new();
        let sig: Signature5D = Signature::new();
        let manifest = CosmicOperatorManifest::from_signature(&sig, 0, 1);
        let id = manifest.id.clone();
        
        lexicon.create_operator(manifest).unwrap();
        
        let retrieved = lexicon.get_operator(&id).unwrap();
        assert_eq!(retrieved.id, id);
    }

    #[test]
    fn test_list_with_filters() {
        let lexicon = OperatorLexicon::new();
        
        // Create operators with different properties
        let sig1: Signature5D = Signature::new();
        let mut manifest1 = CosmicOperatorManifest::from_signature(&sig1, 0, 1);
        manifest1.add_tag("energy".to_string());
        manifest1.entropic_dynamics.stability_rating = 0.95;
        
        let sig2: Signature5D = Signature::new();
        let mut manifest2 = CosmicOperatorManifest::from_signature(&sig2, 1, 1);
        manifest2.add_tag("fractal".to_string());
        manifest2.entropic_dynamics.stability_rating = 0.85;
        
        lexicon.create_operator(manifest1).unwrap();
        lexicon.create_operator(manifest2).unwrap();
        
        // Filter by tag
        let query = OperatorQuery {
            tag: Some("energy".to_string()),
            ..Default::default()
        };
        let results = lexicon.list_operators(query).unwrap();
        assert_eq!(results.len(), 1);
        
        // Filter by minimum stability
        let query = OperatorQuery {
            stability_min: Some(0.90),
            ..Default::default()
        };
        let results = lexicon.list_operators(query).unwrap();
        assert_eq!(results.len(), 1);
    }

    #[test]
    fn test_analytics() {
        let lexicon = OperatorLexicon::new();
        
        let sig: Signature5D = Signature::new();
        let manifest = CosmicOperatorManifest::from_signature(&sig, 0, 1);
        lexicon.create_operator(manifest).unwrap();
        
        let analytics = lexicon.get_analytics().unwrap();
        assert_eq!(analytics.total_operators, 1);
        assert!(analytics.mean_stability > 0.0);
    }

    #[test]
    fn test_telemetry() {
        let lexicon = OperatorLexicon::new();
        
        lexicon.emit_status(StatusTelemetry {
            cycle: 1,
            active_operator: Some("test".to_string()),
            delta_h: 0.001,
            delta_s: 0.0001,
            psi_variance: 0.02,
        });
        
        let messages = lexicon.get_telemetry(0);
        assert_eq!(messages.len(), 1);
    }

    #[test]
    fn test_delete_operator() {
        let lexicon = OperatorLexicon::new();
        let sig: Signature5D = Signature::new();
        let manifest = CosmicOperatorManifest::from_signature(&sig, 0, 1);
        let id = manifest.id.clone();
        
        lexicon.create_operator(manifest).unwrap();
        assert!(lexicon.get_operator(&id).is_ok());
        
        lexicon.delete_operator(&id).unwrap();
        assert!(lexicon.get_operator(&id).is_err());
    }
}
