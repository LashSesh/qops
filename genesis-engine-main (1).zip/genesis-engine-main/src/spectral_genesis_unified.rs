//! Spectral Genesis Unified System
//!
//! Integrated system combining SGCP, SAL, and SRAL for complete
//! spectral resonance calibration, autogenesis, and reflection.

use serde::{Deserialize, Serialize};
use chrono::{DateTime, Utc};
use crate::error::Result;
use crate::spectral_genesis_calibration::{
    SpectralGenesisCalibrationProtocol,
    StageResult,
};
use crate::spectral_autogenesis_layer::{
    SpectralAutogenesisLayer,
    AutogenesisStage,
};
use crate::spectral_reflection_audit::{
    SpectralReflectionAuditLayer,
    SummaryReport,
};

/// System State
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum SystemState {
    Initializing,
    Calibrating,
    Autogenesing,
    Reflecting,
    SpectrallyStable,
    EmergencyRebalancing,
}

/// Unified Telemetry combining all three layers
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UnifiedTelemetry {
    pub timestamp: DateTime<Utc>,
    pub system_state: String,
    
    // SGCP metrics
    pub sgcp_phase_coherence: f64,
    pub sgcp_entropy_decay: f64,
    pub sgcp_energy_balance: f64,
    pub sgcp_semantic_alignment: f64,
    pub sgcp_sgi: f64,
    
    // SAL metrics
    pub sal_emotional_coherence: f64,
    pub sal_operator_diversity: f64,
    pub sal_semantic_entropy: f64,
    pub sal_network_sync_ratio: f64,
    pub sal_meta_reflection_index: f64,
    pub sal_agi: f64,
    
    // SRAL metrics
    pub sral_meta_coherence_index: f64,
    pub sral_ethical_integrity_score: f64,
    pub sral_semantic_reflection_depth: f64,
    pub sral_spectral_entropy: f64,
    pub sral_omega: f64,
    
    // Overall system health
    pub overall_coherence: f64,
    pub is_stable: bool,
}

/// Calibration Snapshot for persistence
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CalibrationSnapshot {
    pub timestamp: DateTime<Utc>,
    pub sgcp_metrics: SgcpSnapshot,
    pub sal_state: SalSnapshot,
    pub sral_state: SralSnapshot,
    pub system_state: String,
    pub cycles_run: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SgcpSnapshot {
    pub phi_1: f64,
    pub phi_2: f64,
    pub phi_3: f64,
    pub e_trm: f64,
    pub e_5d: f64,
    pub sync_ratio: f64,
    pub sgi: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SalSnapshot {
    pub emotional_coherence: f64,
    pub valence: f64,
    pub arousal: f64,
    pub operator_diversity: f64,
    pub agi: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SralSnapshot {
    pub omega: f64,
    pub meta_coherence_index: f64,
    pub ethical_integrity_score: f64,
    pub spectral_entropy: f64,
}

/// Main Unified Spectral Genesis System
pub struct SpectralGenesisUnifiedSystem {
    pub sgcp: SpectralGenesisCalibrationProtocol,
    pub sal: SpectralAutogenesisLayer,
    pub sral: SpectralReflectionAuditLayer,
    pub state: SystemState,
    pub unified_telemetry: Vec<UnifiedTelemetry>,
    pub cycle_count: usize,
    pub operator_mining_mode: bool,
}

impl SpectralGenesisUnifiedSystem {
    /// Create new unified system
    pub fn new() -> Self {
        Self {
            sgcp: SpectralGenesisCalibrationProtocol::new(),
            sal: SpectralAutogenesisLayer::new(),
            sral: SpectralReflectionAuditLayer::new(),
            state: SystemState::Initializing,
            unified_telemetry: Vec::new(),
            cycle_count: 0,
            operator_mining_mode: false,
        }
    }
    
    /// Initialize the system
    pub fn initialize(&mut self) -> Result<()> {
        self.state = SystemState::Initializing;
        
        // Initialize SGCP with random constrained phase triplet
        // (already done in new())
        
        self.state = SystemState::Calibrating;
        Ok(())
    }
    
    /// Run full calibration protocol (SGCP)
    pub fn run_calibration(&mut self) -> Result<Vec<StageResult>> {
        self.state = SystemState::Calibrating;
        let results = self.sgcp.run_calibration()?;
        
        // Check if calibration successful
        if self.sgcp.is_calibrated() {
            self.state = SystemState::SpectrallyStable;
        }
        
        Ok(results)
    }
    
    /// Run autogenesis process (SAL)
    pub fn run_autogenesis(&mut self) -> Result<Vec<AutogenesisStage>> {
        self.state = SystemState::Autogenesing;
        
        let phi_1 = self.sgcp.phase_triplet.phi_1;
        let phi_2 = self.sgcp.phase_triplet.phi_2;
        let phi_3 = self.sgcp.phase_triplet.phi_3;
        
        let stages = self.sal.run_autogenesis(phi_1, phi_2, phi_3)?;
        
        // Check for emergency protocol
        if self.sal.needs_emergency_protocol() {
            self.state = SystemState::EmergencyRebalancing;
            self.sal.emergency_rebalance();
        }
        
        Ok(stages)
    }
    
    /// Update all systems for one cycle
    pub fn update(&mut self, dt: f64) -> Result<()> {
        self.cycle_count += 1;
        
        // Update SGCP
        self.sgcp.update(dt);
        
        // Update SAL with current phase triplet
        let phi_1 = self.sgcp.phase_triplet.phi_1;
        let phi_2 = self.sgcp.phase_triplet.phi_2;
        let phi_3 = self.sgcp.phase_triplet.phi_3;
        self.sal.update(phi_1, phi_2, phi_3, dt);
        
        // Update SRAL with current system state
        let emotional_state = (
            self.sal.erm.valence,
            self.sal.erm.arousal,
            self.sal.erm.coherence,
        );
        self.sral.update(
            phi_1,
            self.sal.qlogic.calculate_lambda().0, // lambda (real part)
            self.sal.semantic_entropy,            // sigma
            emotional_state,
        );
        
        // Update system state based on metrics
        self.update_system_state();
        
        // Record unified telemetry every 60 cycles
        if self.cycle_count % 60 == 0 {
            self.record_unified_telemetry();
        }
        
        Ok(())
    }
    
    fn update_system_state(&mut self) {
        // Transition state machine based on system metrics
        if self.sal.needs_emergency_protocol() {
            self.state = SystemState::EmergencyRebalancing;
            return;
        }
        
        if self.sgcp.is_calibrated() && self.sal.autogenesis_index() > 0.92 {
            self.state = SystemState::SpectrallyStable;
        } else if self.sgcp.is_calibrated() {
            self.state = SystemState::Autogenesing;
        } else {
            self.state = SystemState::Calibrating;
        }
        
        // Enable operator mining mode if finalization criteria met
        if self.check_finalization_criteria() {
            self.operator_mining_mode = true;
        }
    }
    
    fn record_unified_telemetry(&mut self) {
        let sgcp_metrics = self.sgcp.get_metrics();
        let sral_metrics = self.sral.get_coherence_metrics();
        
        let overall_coherence = (
            sgcp_metrics.global_index +
            self.sal.autogenesis_index() +
            sral_metrics.meta_coherence_index
        ) / 3.0;
        
        let is_stable = sgcp_metrics.is_stable() && 
                       self.sal.autogenesis_index() > 0.92 &&
                       sral_metrics.is_stable();
        
        let telemetry = UnifiedTelemetry {
            timestamp: Utc::now(),
            system_state: format!("{:?}", self.state),
            
            // SGCP
            sgcp_phase_coherence: sgcp_metrics.phase_coherence,
            sgcp_entropy_decay: self.sgcp.entropy_norm.entropy_decay(self.cycle_count as f64),
            sgcp_energy_balance: self.sgcp.e_trm / self.sgcp.e_5d.max(1e-10),
            sgcp_semantic_alignment: sgcp_metrics.semantic_alignment,
            sgcp_sgi: sgcp_metrics.global_index,
            
            // SAL
            sal_emotional_coherence: self.sal.erm.coherence,
            sal_operator_diversity: self.sal.operator_diversity,
            sal_semantic_entropy: self.sal.semantic_entropy,
            sal_network_sync_ratio: self.sal.heavenly_hosts.sync_ratio(),
            sal_meta_reflection_index: self.sal.meta_reflection_index,
            sal_agi: self.sal.autogenesis_index(),
            
            // SRAL
            sral_meta_coherence_index: sral_metrics.meta_coherence_index,
            sral_ethical_integrity_score: sral_metrics.ethical_integrity_score,
            sral_semantic_reflection_depth: sral_metrics.semantic_reflection_depth,
            sral_spectral_entropy: self.sral.meta_reflection.spectral_entropy(),
            sral_omega: self.sral.meta_reflection.omega,
            
            // Overall
            overall_coherence,
            is_stable,
        };
        
        self.unified_telemetry.push(telemetry);
        
        // Keep last 1000 entries
        if self.unified_telemetry.len() > 1000 {
            self.unified_telemetry.drain(0..self.unified_telemetry.len() - 1000);
        }
    }
    
    /// Check finalization criteria for operator mining mode
    pub fn check_finalization_criteria(&self) -> bool {
        let sgcp_metrics = self.sgcp.get_metrics();
        let entropy_gradient = self.sgcp.entropy_norm.entropy_decay(self.cycle_count as f64);
        
        sgcp_metrics.global_index >= 0.95 &&
        entropy_gradient < 1e-3 &&
        self.sgcp.semantic_coherence > 0.95 &&
        self.sgcp.sync_ratio > 0.97
    }
    
    /// Create calibration snapshot for persistence
    pub fn create_snapshot(&self) -> CalibrationSnapshot {
        let sgcp_metrics = self.sgcp.get_metrics();
        let sral_metrics = self.sral.get_coherence_metrics();
        
        CalibrationSnapshot {
            timestamp: Utc::now(),
            sgcp_metrics: SgcpSnapshot {
                phi_1: self.sgcp.phase_triplet.phi_1,
                phi_2: self.sgcp.phase_triplet.phi_2,
                phi_3: self.sgcp.phase_triplet.phi_3,
                e_trm: self.sgcp.e_trm,
                e_5d: self.sgcp.e_5d,
                sync_ratio: self.sgcp.sync_ratio,
                sgi: sgcp_metrics.global_index,
            },
            sal_state: SalSnapshot {
                emotional_coherence: self.sal.erm.coherence,
                valence: self.sal.erm.valence,
                arousal: self.sal.erm.arousal,
                operator_diversity: self.sal.operator_diversity,
                agi: self.sal.autogenesis_index(),
            },
            sral_state: SralSnapshot {
                omega: self.sral.meta_reflection.omega,
                meta_coherence_index: sral_metrics.meta_coherence_index,
                ethical_integrity_score: sral_metrics.ethical_integrity_score,
                spectral_entropy: self.sral.meta_reflection.spectral_entropy(),
            },
            system_state: format!("{:?}", self.state),
            cycles_run: self.cycle_count,
        }
    }
    
    /// Get unified system status
    pub fn get_status(&self) -> SystemStatus {
        let sgcp_metrics = self.sgcp.get_metrics();
        let sral_report = self.sral.generate_summary_report();
        
        SystemStatus {
            state: format!("{:?}", self.state),
            cycle_count: self.cycle_count,
            is_calibrated: self.sgcp.is_calibrated(),
            is_spectrally_stable: self.check_finalization_criteria(),
            operator_mining_mode: self.operator_mining_mode,
            sgcp_sgi: sgcp_metrics.global_index,
            sal_agi: self.sal.autogenesis_index(),
            sral_mci: sral_report.meta_coherence_index,
            overall_coherence: (sgcp_metrics.global_index + 
                               self.sal.autogenesis_index() + 
                               sral_report.meta_coherence_index) / 3.0,
        }
    }
    
    /// Get latest unified telemetry
    pub fn get_latest_telemetry(&self) -> Option<&UnifiedTelemetry> {
        self.unified_telemetry.last()
    }
    
    /// Get SRAL summary report
    pub fn get_reflection_summary(&self) -> SummaryReport {
        self.sral.generate_summary_report()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemStatus {
    pub state: String,
    pub cycle_count: usize,
    pub is_calibrated: bool,
    pub is_spectrally_stable: bool,
    pub operator_mining_mode: bool,
    pub sgcp_sgi: f64,
    pub sal_agi: f64,
    pub sral_mci: f64,
    pub overall_coherence: f64,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_unified_system_creation() {
        let system = SpectralGenesisUnifiedSystem::new();
        assert_eq!(system.state, SystemState::Initializing);
        assert_eq!(system.cycle_count, 0);
    }

    #[test]
    fn test_initialization() {
        let mut system = SpectralGenesisUnifiedSystem::new();
        system.initialize().unwrap();
        assert_eq!(system.state, SystemState::Calibrating);
    }

    #[test]
    fn test_calibration() {
        let mut system = SpectralGenesisUnifiedSystem::new();
        system.initialize().unwrap();
        let results = system.run_calibration().unwrap();
        assert_eq!(results.len(), 6);
    }

    #[test]
    fn test_autogenesis() {
        let mut system = SpectralGenesisUnifiedSystem::new();
        let stages = system.run_autogenesis().unwrap();
        assert_eq!(stages.len(), 6);
    }

    #[test]
    fn test_update() {
        let mut system = SpectralGenesisUnifiedSystem::new();
        system.update(0.01).unwrap();
        assert_eq!(system.cycle_count, 1);
    }

    #[test]
    fn test_snapshot_creation() {
        let system = SpectralGenesisUnifiedSystem::new();
        let snapshot = system.create_snapshot();
        assert_eq!(snapshot.cycles_run, 0);
    }

    #[test]
    fn test_status() {
        let system = SpectralGenesisUnifiedSystem::new();
        let status = system.get_status();
        assert_eq!(status.cycle_count, 0);
        assert!(!status.operator_mining_mode);
    }

    #[test]
    fn test_multiple_updates() {
        let mut system = SpectralGenesisUnifiedSystem::new();
        for _ in 0..100 {
            system.update(0.01).unwrap();
        }
        assert_eq!(system.cycle_count, 100);
        assert!(!system.unified_telemetry.is_empty());
    }

    #[test]
    fn test_finalization_criteria() {
        let system = SpectralGenesisUnifiedSystem::new();
        // Initially should not meet criteria
        assert!(!system.check_finalization_criteria());
    }
}
