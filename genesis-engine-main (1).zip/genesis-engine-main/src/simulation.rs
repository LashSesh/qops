//! Simulation and Evolution Module
//!
//! Provides high-level simulation capabilities for exploring the MOGE system:
//! - Multi-agent swarm simulations
//! - Evolutionary dynamics
//! - Statistical analysis
//! - Visualization data export

use crate::agent::{AgentConfig, TraversalStrategy};
use crate::traversal::TraversalEngine;
use crate::artefact::Artefact;
use crate::signature::Signature5D;
use crate::error::Result;
use serde::{Deserialize, Serialize};

/// Simulation configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationConfig {
    /// Number of agents in the swarm
    pub agent_count: usize,
    /// Maximum steps per agent
    pub max_steps_per_agent: usize,
    /// Number of generations (iterations)
    pub generations: usize,
    /// Enable evolutionary adaptation
    pub enable_evolution: bool,
    /// Mutation rate for evolutionary dynamics
    pub mutation_rate: f64,
    /// Target signature (goal for optimization)
    pub target_signature: Option<Signature5D>,
}

impl Default for SimulationConfig {
    fn default() -> Self {
        Self {
            agent_count: 10,
            max_steps_per_agent: 50,
            generations: 10,
            enable_evolution: true,
            mutation_rate: 0.1,
            target_signature: None,
        }
    }
}

/// Simulation statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationStats {
    /// Generation number
    pub generation: usize,
    /// Total artefacts generated
    pub total_artefacts: usize,
    /// Mandorla-certified artefacts
    pub mandorla_certified: usize,
    /// Average resonance
    pub avg_resonance: f64,
    /// Best resonance
    pub best_resonance: f64,
    /// Average stability
    pub avg_stability: f64,
    /// Average path length
    pub avg_path_length: f64,
}

/// Simulation result
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationResult {
    /// Statistics per generation
    pub stats_per_generation: Vec<SimulationStats>,
    /// Best artefacts found (by resonance)
    pub best_artefacts_ids: Vec<uuid::Uuid>,
    /// Total runtime (mock for now)
    pub runtime_ms: u64,
}

/// MOGE Simulation Engine
pub struct Simulation {
    engine: TraversalEngine,
    config: SimulationConfig,
    current_generation: usize,
}

impl Simulation {
    /// Create a new simulation
    pub fn new(config: SimulationConfig) -> Self {
        Self {
            engine: TraversalEngine::new(),
            config,
            current_generation: 0,
        }
    }

    /// Run the complete simulation
    pub fn run(&mut self) -> Result<SimulationResult> {
        let mut stats_per_generation = Vec::new();
        let start_time = std::time::Instant::now();

        for gen in 0..self.config.generations {
            self.current_generation = gen;

            // Run agent swarm for this generation
            let gen_stats = self.run_generation()?;
            stats_per_generation.push(gen_stats);

            // Evolutionary step
            if self.config.enable_evolution && gen < self.config.generations - 1 {
                self.evolve()?;
            }
        }

        let runtime_ms = start_time.elapsed().as_millis() as u64;

        // Get best artefacts
        let best = self.engine.ledger().get_top_resonance(10);
        let best_ids = best.iter().map(|a| a.id).collect();

        Ok(SimulationResult {
            stats_per_generation,
            best_artefacts_ids: best_ids,
            runtime_ms,
        })
    }

    /// Run a single generation
    fn run_generation(&mut self) -> Result<SimulationStats> {
        let agent_config = self.create_agent_config();

        // Run swarm
        let artefacts = self.engine.run_swarm(
            self.config.agent_count,
            agent_config
        )?;

        // Calculate statistics
        let total = artefacts.len();
        let mandorla_count = artefacts.iter()
            .filter(|a| a.is_mandorla_certified)
            .count();

        // Guard against division by zero when no artefacts are produced
        let avg_resonance = if total > 0 {
            artefacts.iter()
                .map(|a| a.resonance())
                .sum::<f64>() / total as f64
        } else {
            0.0
        };

        let best_resonance = if total > 0 {
            artefacts.iter()
                .map(|a| a.resonance())
                .fold(0.0, f64::max)
        } else {
            0.0
        };

        let avg_stability = if total > 0 {
            artefacts.iter()
                .map(|a| a.stability)
                .sum::<f64>() / total as f64
        } else {
            0.0
        };

        let avg_path_length = if total > 0 {
            artefacts.iter()
                .map(|a| a.blueprint.len())
                .sum::<usize>() as f64 / total as f64
        } else {
            0.0
        };

        Ok(SimulationStats {
            generation: self.current_generation,
            total_artefacts: total,
            mandorla_certified: mandorla_count,
            avg_resonance,
            best_resonance,
            avg_stability,
            avg_path_length,
        })
    }

    /// Create agent configuration (can be evolved)
    fn create_agent_config(&self) -> AgentConfig {
        // Basic config
        let mut config = AgentConfig {
            max_steps: self.config.max_steps_per_agent,
            ..Default::default()
        };

        // Vary strategy based on generation (simple evolution)
        config.strategy = match self.current_generation % 4 {
            0 => TraversalStrategy::GradientAscent,
            1 => TraversalStrategy::StabilityMaximization,
            2 => TraversalStrategy::CycleRecognition,
            _ => TraversalStrategy::Balanced,
        };

        // Add some randomness
        config.temperature = 0.1 + (self.current_generation as f64 * 0.02).min(0.5);

        config
    }

    /// Evolutionary step: adapt parameters based on previous generation
    fn evolve(&mut self) -> Result<()> {
        // Get best performers from ledger
        let top = self.engine.ledger().get_top_resonance(3);

        if top.is_empty() {
            return Ok(());
        }

        // Analyze what made them successful
        // (This is a simplified evolution - in practice would be more sophisticated)

        // For now, just adjust parameters based on success
        let avg_best_resonance = top.iter()
            .map(|a| a.resonance())
            .sum::<f64>() / top.len() as f64;

        // If performance is high, reduce exploration
        if avg_best_resonance > 0.85 {
            self.config.mutation_rate *= 0.9;
        } else {
            // Increase exploration
            self.config.mutation_rate *= 1.1;
        }

        self.config.mutation_rate = self.config.mutation_rate.clamp(0.01, 0.5);

        Ok(())
    }

    /// Get current ledger state
    pub fn ledger_stats(&self) -> crate::ledger::LedgerStats {
        self.engine.ledger().stats()
    }

    /// Get best artefacts so far
    pub fn get_best(&self, n: usize) -> Vec<&Artefact> {
        self.engine.ledger().get_top_resonance(n)
    }

    /// Export simulation results for visualization
    pub fn export_visualization_data(&self) -> Result<String> {
        let stats = self.ledger_stats();
        let best = self.get_best(5);

        #[derive(Serialize)]
        struct VisualizationData {
            stats: crate::ledger::LedgerStats,
            best_signatures: Vec<Signature5D>,
        }

        let data = VisualizationData {
            stats,
            best_signatures: best.iter().map(|a| a.signature).collect(),
        };

        serde_json::to_string_pretty(&data)
            .map_err(|e| e.into())
    }
}

/// Quick simulation runner with default configuration
pub fn run_quick_simulation() -> Result<SimulationResult> {
    let config = SimulationConfig {
        agent_count: 5,
        max_steps_per_agent: 20,
        generations: 5,
        ..Default::default()
    };

    let mut sim = Simulation::new(config);
    sim.run()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_simulation_creation() {
        let config = SimulationConfig::default();
        let sim = Simulation::new(config);
        assert_eq!(sim.current_generation, 0);
    }

    #[test]
    fn test_single_generation() {
        let config = SimulationConfig {
            agent_count: 3,
            max_steps_per_agent: 5,
            generations: 1,
            enable_evolution: false,
            ..Default::default()
        };

        let mut sim = Simulation::new(config);
        let result = sim.run();

        assert!(result.is_ok());
        let result = result.unwrap();
        assert_eq!(result.stats_per_generation.len(), 1);
    }

    #[test]
    fn test_multi_generation() {
        let config = SimulationConfig {
            agent_count: 2,
            max_steps_per_agent: 5,
            generations: 3,
            enable_evolution: true,
            ..Default::default()
        };

        let mut sim = Simulation::new(config);
        let result = sim.run();

        assert!(result.is_ok());
        let result = result.unwrap();
        assert_eq!(result.stats_per_generation.len(), 3);
    }

    #[test]
    fn test_quick_simulation() {
        let result = run_quick_simulation();
        assert!(result.is_ok());

        let result = result.unwrap();
        assert!(!result.stats_per_generation.is_empty());
    }

    #[test]
    fn test_visualization_export() {
        let config = SimulationConfig {
            agent_count: 2,
            max_steps_per_agent: 5,
            generations: 1,
            enable_evolution: false,
            ..Default::default()
        };

        let mut sim = Simulation::new(config);
        sim.run().unwrap();

        let export = sim.export_visualization_data();
        assert!(export.is_ok());
    }

    #[test]
    fn test_evolution_step() {
        let config = SimulationConfig {
            agent_count: 3,
            max_steps_per_agent: 10,
            generations: 2,
            enable_evolution: true,
            mutation_rate: 0.2,
            ..Default::default()
        };

        let mut sim = Simulation::new(config);
        let result = sim.run();

        assert!(result.is_ok());
        // Mutation rate should have changed during evolution
        assert_ne!(sim.config.mutation_rate, 0.2);
    }

    #[test]
    fn test_zero_agents_no_panic() {
        // Test that simulation with zero agents doesn't panic with division by zero
        let config = SimulationConfig {
            agent_count: 0,
            max_steps_per_agent: 10,
            generations: 1,
            enable_evolution: false,
            ..Default::default()
        };

        let mut sim = Simulation::new(config);
        let result = sim.run();

        // Should succeed with empty statistics rather than panicking
        assert!(result.is_ok());
        let result = result.unwrap();
        assert_eq!(result.stats_per_generation.len(), 1);

        let stats = &result.stats_per_generation[0];
        assert_eq!(stats.total_artefacts, 0);
        assert_eq!(stats.avg_resonance, 0.0);
        assert_eq!(stats.best_resonance, 0.0);
        assert_eq!(stats.avg_stability, 0.0);
        assert_eq!(stats.avg_path_length, 0.0);
    }
}
