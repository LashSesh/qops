//! KNO/DK Simulation Pipeline
//!
//! Implements the 5-stage execution pipeline for Cyclic Conversion simulation:
//! 1. Generate DK Field
//! 2. Apply Cyclic Conversion
//! 3. Stabilize to KNO
//! 4. Spectral Decomposition
//! 5. Audit Results

use crate::kno_framework::*;
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};
use std::fs;
use std::path::Path;

/// Simulation configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationConfig {
    /// Time domain: t ∈ [0, T]
    pub time_start: f64,
    pub time_end: f64,
    pub time_steps: usize,

    /// Forward phase parameter α
    pub alpha: f64,
    /// Backward phase parameter β
    pub beta: f64,

    /// Maximum eigenstate index for spectrum
    pub max_eigenstate: usize,

    /// Maximum iterations for KNO stabilization
    pub max_stabilization_iterations: usize,

    /// Output directory
    pub output_dir: String,
}

impl Default for SimulationConfig {
    fn default() -> Self {
        let delta_phi: f64 = 0.1; // Default phase difference
        let period = if delta_phi.abs() > PRECISION {
            2.0 * std::f64::consts::PI / delta_phi
        } else {
            2.0 * std::f64::consts::PI
        };

        Self {
            time_start: 0.0,
            time_end: period,
            time_steps: 1000,
            alpha: 1.0,
            beta: 0.9,
            max_eigenstate: 10,
            max_stabilization_iterations: 1000,
            output_dir: "./kno_output".to_string(),
        }
    }
}

/// Stage 1: DK Field Generation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DKFieldData {
    pub alpha: f64,
    pub beta: f64,
    pub delta_phi: f64,
    pub time_lattice: Vec<f64>,
    pub field_values: Vec<Complex>,
}

impl DKFieldData {
    pub fn generate(config: &SimulationConfig) -> Result<Self> {
        let dk = DoubleKickOperator::new(config.alpha, config.beta);
        let dt = (config.time_end - config.time_start) / (config.time_steps as f64);

        let mut time_lattice = Vec::new();
        let mut field_values = Vec::new();

        let psi = WaveFunction::ground_state();

        for step in 0..config.time_steps {
            let t = config.time_start + (step as f64) * dt;
            time_lattice.push(t);

            let evolved = dk.apply(&psi, t);
            field_values.push(evolved.psi);
        }

        Ok(Self {
            alpha: config.alpha,
            beta: config.beta,
            delta_phi: dk.delta_phi,
            time_lattice,
            field_values,
        })
    }

    pub fn save(&self, path: &Path) -> Result<()> {
        let json = serde_json::to_string_pretty(self)
            .map_err(|e| MogeError::InvalidArtefact(format!("Serialization error: {}", e)))?;

        fs::write(path, json)
            .map_err(|e| MogeError::InvalidArtefact(format!("File write error: {}", e)))?;

        Ok(())
    }
}

/// Stage 2: Cyclic Conversion Application
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CyclicConversionData {
    pub involution_checks: Vec<InvolutionCheck>,
    pub all_passed: bool,
    pub max_error: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InvolutionCheck {
    pub time: f64,
    pub passed: bool,
    pub error: f64,
}

impl CyclicConversionData {
    pub fn apply(config: &SimulationConfig, field: &DKFieldData) -> Result<Self> {
        let dk = DoubleKickOperator::new(config.alpha, config.beta);
        let mut checks = Vec::new();
        let mut max_error: f64 = 0.0;

        for (i, &t) in field.time_lattice.iter().enumerate() {
            let psi = WaveFunction {
                psi: field.field_values[i],
                t,
                delta_phi: field.delta_phi,
            };

            // Apply D_K² and check involution
            let result = dk.apply_twice(&psi, t);
            let diff = result.psi.sub(&psi.psi);
            let error = diff.magnitude();
            max_error = max_error.max(error);

            checks.push(InvolutionCheck {
                time: t,
                passed: error < INVOLUTION_EPSILON,
                error,
            });
        }

        let all_passed = checks.iter().all(|c| c.passed);

        Ok(Self {
            involution_checks: checks,
            all_passed,
            max_error,
        })
    }

    pub fn save(&self, path: &Path) -> Result<()> {
        let json = serde_json::to_string_pretty(self)
            .map_err(|e| MogeError::InvalidArtefact(format!("Serialization error: {}", e)))?;

        fs::write(path, json)
            .map_err(|e| MogeError::InvalidArtefact(format!("File write error: {}", e)))?;

        Ok(())
    }
}

/// Stage 3: KNO Stabilization
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KNOStabilizationData {
    pub converged: bool,
    pub iterations: usize,
    pub final_delta_phi: f64,
    pub final_state: Complex,
    pub convergence_history: Vec<f64>,
}

impl KNOStabilizationData {
    pub fn stabilize(config: &SimulationConfig, field: &DKFieldData) -> Result<Self> {
        let kn = NullpunktOperator::new();
        let mut psi = WaveFunction {
            psi: field.field_values[0],
            t: 0.0,
            delta_phi: field.delta_phi,
        };

        let mut convergence_history = Vec::new();
        let mut iterations = 0;

        for i in 0..config.max_stabilization_iterations {
            convergence_history.push(psi.delta_phi.abs());

            if kn.is_converged(&psi) {
                iterations = i;
                return Ok(Self {
                    converged: true,
                    iterations,
                    final_delta_phi: psi.delta_phi,
                    final_state: psi.psi,
                    convergence_history,
                });
            }

            // Gradually reduce phase difference
            psi.delta_phi *= 0.95;
            psi = psi.apply_generator(0.01);
            iterations = i;
        }

        Ok(Self {
            converged: false,
            iterations,
            final_delta_phi: psi.delta_phi,
            final_state: psi.psi,
            convergence_history,
        })
    }

    pub fn save(&self, path: &Path) -> Result<()> {
        let json = serde_json::to_string_pretty(self)
            .map_err(|e| MogeError::InvalidArtefact(format!("Serialization error: {}", e)))?;

        fs::write(path, json)
            .map_err(|e| MogeError::InvalidArtefact(format!("File write error: {}", e)))?;

        Ok(())
    }
}

/// Stage 4: Spectral Decomposition
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpectralData {
    pub eigenfrequencies: Vec<f64>,
    pub eigenstates: Vec<(i32, f64)>,
    pub spectrum_symmetric: bool,
}

impl SpectralData {
    pub fn decompose(config: &SimulationConfig, field: &DKFieldData) -> Result<Self> {
        let analyzer = SpectrumAnalyzer::new(config.max_eigenstate, field.delta_phi);

        // Sample at middle time point
        let mid_idx = field.time_lattice.len() / 2;
        let t = field.time_lattice[mid_idx];

        let psi = WaveFunction {
            psi: field.field_values[mid_idx],
            t,
            delta_phi: field.delta_phi,
        };

        let eigenstates = analyzer.decompose(&psi, t);

        // Compute eigenfrequencies: ω_n = n·Δφ
        let mut eigenfrequencies = Vec::new();
        for n in -(config.max_eigenstate as i32)..=(config.max_eigenstate as i32) {
            eigenfrequencies.push((n as f64) * field.delta_phi);
        }

        // Check spectrum symmetry
        let spectrum_symmetric = eigenfrequencies.iter()
            .zip(eigenfrequencies.iter().rev())
            .all(|(a, b)| (a + b).abs() < PRECISION);

        Ok(Self {
            eigenfrequencies,
            eigenstates,
            spectrum_symmetric,
        })
    }

    pub fn save(&self, path: &Path) -> Result<()> {
        // Save as CSV
        let mut csv = String::new();
        csv.push_str("n,omega_n,amplitude\n");

        for (i, &freq) in self.eigenfrequencies.iter().enumerate() {
            if i < self.eigenstates.len() {
                let (n, amp) = self.eigenstates[i];
                csv.push_str(&format!("{},{},{}\n", n, freq, amp));
            }
        }

        fs::write(path, csv)
            .map_err(|e| MogeError::InvalidArtefact(format!("File write error: {}", e)))?;

        Ok(())
    }
}

/// Stage 5: Audit Results
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuditReport {
    pub hermitian_valid: bool,
    pub hermitian_error: f64,
    pub norm_conservation: bool,
    pub phase_coherence: bool,
    pub energy_error: f64,
    pub coherence_ratio: f64,
    pub all_passed: bool,
}

impl AuditReport {
    pub fn audit(config: &SimulationConfig, field: &DKFieldData) -> Result<Self> {
        let hermitian = HermitianOperator::new(config.alpha, config.beta);
        let mut validator = StabilityValidator::new();

        let mut hermitian_errors = Vec::new();
        let mut energy_errors = Vec::new();

        for (i, &t) in field.time_lattice.iter().enumerate() {
            let psi = WaveFunction {
                psi: field.field_values[i],
                t,
                delta_phi: field.delta_phi,
            };

            validator.record(&psi);

            // Check Hermiticity
            let l_psi = hermitian.apply(&psi, t);
            let left = psi.psi.conjugate().mul(&l_psi.psi);
            let right = l_psi.psi.conjugate().mul(&psi.psi);
            let diff = left.sub(&right);
            hermitian_errors.push(diff.magnitude());

            // Energy error (norm deviation)
            energy_errors.push((psi.norm_squared() - 1.0).abs());
        }

        let max_hermitian_error = hermitian_errors.iter().copied().fold(f64::NEG_INFINITY, f64::max);
        let max_energy_error = energy_errors.iter().copied().fold(f64::NEG_INFINITY, f64::max);

        let validation = validator.validate()?;

        // Coherence ratio: fraction of states with energy error < threshold
        let coherent_count = energy_errors.iter().filter(|&&e| e < 1e-10).count();
        let coherence_ratio = coherent_count as f64 / energy_errors.len() as f64;

        let hermitian_valid = max_hermitian_error < HERMITIAN_EPSILON;
        let energy_valid = max_energy_error < 1e-10;

        Ok(Self {
            hermitian_valid,
            hermitian_error: max_hermitian_error,
            norm_conservation: validation.norm_conservation,
            phase_coherence: validation.phase_coherence,
            energy_error: max_energy_error,
            coherence_ratio,
            all_passed: hermitian_valid && energy_valid && validation.all_stable,
        })
    }

    pub fn save(&self, path: &Path) -> Result<()> {
        let json = serde_json::to_string_pretty(self)
            .map_err(|e| MogeError::InvalidArtefact(format!("Serialization error: {}", e)))?;

        fs::write(path, json)
            .map_err(|e| MogeError::InvalidArtefact(format!("File write error: {}", e)))?;

        Ok(())
    }
}

/// Complete simulation pipeline
pub struct KNOSimulation {
    pub config: SimulationConfig,
}

impl KNOSimulation {
    pub fn new(config: SimulationConfig) -> Self {
        Self { config }
    }

    /// Run complete 5-stage pipeline
    pub fn run(&self) -> Result<SimulationResults> {
        // Create output directory
        fs::create_dir_all(&self.config.output_dir)
            .map_err(|e| MogeError::InvalidArtefact(format!("Failed to create output dir: {}", e)))?;

        println!("=== KNO/DK Cyclic Conversion Simulation ===");
        println!("Configuration:");
        println!("  α = {}, β = {}, Δφ = {}",
            self.config.alpha, self.config.beta, self.config.alpha - self.config.beta);
        println!("  Time domain: [{}, {}] with {} steps",
            self.config.time_start, self.config.time_end, self.config.time_steps);

        // Stage 1: Generate DK Field
        println!("\n[Stage 1] Generating Double-Kick field...");
        let field = DKFieldData::generate(&self.config)?;
        field.save(&Path::new(&format!("{}/dk_field.json", self.config.output_dir)))?;
        println!("  ✓ Generated {} field samples", field.time_lattice.len());

        // Stage 2: Apply Cyclic Conversion
        println!("\n[Stage 2] Applying cyclic conversion (D_K²)...");
        let conversion = CyclicConversionData::apply(&self.config, &field)?;
        conversion.save(&Path::new(&format!("{}/cyclic_conversion_metrics.json", self.config.output_dir)))?;
        println!("  ✓ Involution checks: {} passed, max error = {:.2e}",
            conversion.involution_checks.iter().filter(|c| c.passed).count(),
            conversion.max_error);

        // Stage 3: Stabilize to KNO
        println!("\n[Stage 3] Stabilizing to Nullpunkt...");
        let stabilization = KNOStabilizationData::stabilize(&self.config, &field)?;
        stabilization.save(&Path::new(&format!("{}/kno_stabilization.json", self.config.output_dir)))?;
        println!("  ✓ Converged: {}, iterations: {}, final Δφ = {:.2e}",
            stabilization.converged, stabilization.iterations, stabilization.final_delta_phi);

        // Stage 4: Spectral Decomposition
        println!("\n[Stage 4] Performing spectral decomposition...");
        let spectrum = SpectralData::decompose(&self.config, &field)?;
        spectrum.save(&Path::new(&format!("{}/operator_spectrum.csv", self.config.output_dir)))?;
        println!("  ✓ Computed {} eigenfrequencies, symmetric: {}",
            spectrum.eigenfrequencies.len(), spectrum.spectrum_symmetric);

        // Stage 5: Audit Results
        println!("\n[Stage 5] Auditing results...");
        let audit = AuditReport::audit(&self.config, &field)?;
        audit.save(&Path::new(&format!("{}/hermitian_validation.json", self.config.output_dir)))?;
        println!("  ✓ Hermitian: {}, error = {:.2e}", audit.hermitian_valid, audit.hermitian_error);
        println!("  ✓ Norm conservation: {}", audit.norm_conservation);
        println!("  ✓ Phase coherence: {}", audit.phase_coherence);
        println!("  ✓ Coherence ratio: {:.4}", audit.coherence_ratio);
        println!("  ✓ Energy error: {:.2e}", audit.energy_error);

        println!("\n=== Simulation Complete ===");
        println!("All tests passed: {}", audit.all_passed);
        println!("Output saved to: {}", self.config.output_dir);

        Ok(SimulationResults {
            field,
            conversion,
            stabilization,
            spectrum,
            audit,
        })
    }
}

/// Complete simulation results
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationResults {
    pub field: DKFieldData,
    pub conversion: CyclicConversionData,
    pub stabilization: KNOStabilizationData,
    pub spectrum: SpectralData,
    pub audit: AuditReport,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_dk_field_generation() {
        let config = SimulationConfig::default();
        let field = DKFieldData::generate(&config).unwrap();

        assert_eq!(field.time_lattice.len(), config.time_steps);
        assert_eq!(field.field_values.len(), config.time_steps);
    }

    #[test]
    fn test_involution_checks() {
        let config = SimulationConfig::default();
        let field = DKFieldData::generate(&config).unwrap();
        let conversion = CyclicConversionData::apply(&config, &field).unwrap();

        assert!(conversion.max_error < 1e-6);
    }

    #[test]
    fn test_kno_stabilization() {
        let mut config = SimulationConfig::default();
        config.alpha = 1.01;
        config.beta = 0.99;

        let field = DKFieldData::generate(&config).unwrap();
        let stabilization = KNOStabilizationData::stabilize(&config, &field).unwrap();

        assert!(stabilization.converged);
    }

    #[test]
    fn test_spectrum_decomposition() {
        let config = SimulationConfig::default();
        let field = DKFieldData::generate(&config).unwrap();
        let spectrum = SpectralData::decompose(&config, &field).unwrap();

        assert!(spectrum.spectrum_symmetric);
        assert!(!spectrum.eigenfrequencies.is_empty());
    }

    #[test]
    fn test_hermitian_audit() {
        let config = SimulationConfig::default();
        let field = DKFieldData::generate(&config).unwrap();
        let audit = AuditReport::audit(&config, &field).unwrap();

        assert!(audit.hermitian_valid);
        assert!(audit.coherence_ratio > 0.999);
    }
}
