//! Operator Cross-Domain Validation Protocol (OCVP)
//!
//! Ensures bidirectional integrity between exported operator projections and 
//! their resonance-origin, validating full isomorphism across all domains.

use crate::resonant_language_projection::{Domain, ProjectionTensor};
use crate::operator_export_grammar::OperatorExportPackage;
use crate::operator_reconstruction::OperatorReconstructionInterface;
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Cross-domain drift matrix
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CrossDomainDriftMatrix {
    /// Drift values between domain pairs
    pub drift: HashMap<(String, String), f64>,
    /// Maximum drift observed
    pub max_drift: f64,
    /// Mean drift across all pairs
    pub mean_drift: f64,
}

/// Validation report
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ValidationReport {
    /// Operator ID being validated
    pub operator_id: String,
    /// Timestamp of validation
    pub timestamp: String,
    /// Projection integrity check result
    pub projection_integrity: String,
    /// Mean reconstruction error
    pub mean_error: f64,
    /// Cross-domain drift matrix
    pub cross_domain_drift: CrossDomainDriftMatrix,
    /// Feedback consistency metrics
    pub feedback_consistency: FeedbackConsistency,
    /// Loop consistency error
    pub cycle_closure_error: f64,
    /// Cross-Domain Coherence Index
    pub cdci: f64,
    /// Overall validation status
    pub status: String,
}

/// Feedback consistency metrics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FeedbackConsistency {
    pub delta_s_diff: f64,
    pub delta_h_diff: f64,
    pub phi_stability_diff: f64,
    pub status: String,
}

/// Operator Cross-Domain Validation Protocol
pub struct CrossDomainValidation {
    /// Reconstruction interface
    orti: OperatorReconstructionInterface,
    /// Error tolerance for validation
    _epsilon_t: f64,
    /// Drift threshold
    drift_threshold: f64,
}

impl CrossDomainValidation {
    /// Create a new validation protocol instance
    pub fn new() -> Self {
        Self {
            orti: OperatorReconstructionInterface::new(),
            _epsilon_t: 1e-5,
            drift_threshold: 1e-4,
        }
    }
    
    /// Phase 1: Load operator projection
    pub fn load_operator_projection(&self, package: &OperatorExportPackage) -> Result<()> {
        // Verify domain coverage (≥5)
        if package.projective_domains.len() < 5 {
            return Err(MogeError::InvalidArtefact(
                format!("Insufficient domain coverage: {}", package.projective_domains.len())
            ));
        }
        
        // Validate hash consistency
        for projection in &package.projective_domains {
            if projection.checksum.is_empty() {
                return Err(MogeError::InvalidArtefact(
                    "Invalid projection checksum".to_string()
                ));
            }
        }
        
        Ok(())
    }
    
    /// Phase 2: Reverse projection (reconstruct TIC from domain)
    pub fn reverse_projection(&self, package: &OperatorExportPackage) -> Result<f64> {
        // Reconstruct TIC from package
        let reconstructed_tic = self.orti.reconstruct_tic(package)?;
        
        // Extract original signature from package
        let original_sig = &package.resonance_signature;
        
        // Calculate reconstruction error |T'_i − T_i|
        let error = (
            (reconstructed_tic.signature.psi - original_sig.psi).powi(2) +
            (reconstructed_tic.signature.rho - original_sig.rho).powi(2) +
            (reconstructed_tic.signature.omega - original_sig.omega).powi(2) +
            (reconstructed_tic.signature.chi - original_sig.beta).powi(2) +
            (reconstructed_tic.signature.eta - original_sig.s).powi(2)
        ).sqrt() / 5.0;
        
        // Just return the error - don't fail here
        // Validation will be done in the complete validate() method
        Ok(error)
    }
    
    /// Phase 3: Cross-domain differential measurement
    pub fn cross_domain_differential(&self, package: &OperatorExportPackage) -> Result<CrossDomainDriftMatrix> {
        let mut drift_map = HashMap::new();
        let mut max_drift = 0.0_f64;
        let mut total_drift = 0.0;
        let mut count = 0;
        
        // Compute ΔΦ_jk = |P_ij − P_ik| for all domain pairs
        let projections = &package.projective_domains;
        
        for i in 0..projections.len() {
            for j in (i + 1)..projections.len() {
                let p_i = &projections[i];
                let p_j = &projections[j];
                
                // Compute drift between normalized values
                let drift = (p_i.normalized_value - p_j.normalized_value).abs();
                
                let key = (p_i.domain.as_str().to_string(), p_j.domain.as_str().to_string());
                drift_map.insert(key, drift);
                
                max_drift = max_drift.max(drift);
                total_drift += drift;
                count += 1;
            }
        }
        
        let mean_drift = if count > 0 {
            total_drift / count as f64
        } else {
            0.0
        };
        
        // Don't error here - just return the drift matrix
        // Validation will be done in the complete validate() method
        Ok(CrossDomainDriftMatrix {
            drift: drift_map,
            max_drift,
            mean_drift,
        })
    }
    
    /// Phase 4: Resonance feedback validation
    pub fn resonance_feedback_validation(&self, package: &OperatorExportPackage) -> Result<FeedbackConsistency> {
        // Reconstruct TIC
        let reconstructed_tic = self.orti.reconstruct_tic(package)?;
        
        // Compare metrics with original
        let delta_s_diff = (reconstructed_tic.entropy_gradient - package.resonance_signature.entropy_index as f64).abs();
        
        // TODO: Implement proper Hamiltonian calculation
        // Hamiltonian H = ψ² + ρ² + ω² (total energy-like measure)
        // For now, approximate using signature magnitudes
        let reconstructed_h = reconstructed_tic.signature.psi.powi(2) 
            + reconstructed_tic.signature.rho.powi(2) 
            + reconstructed_tic.signature.omega.powi(2);
        let original_h = package.resonance_signature.psi.powi(2)
            + package.resonance_signature.rho.powi(2)
            + package.resonance_signature.omega.powi(2);
        let delta_h_diff = (reconstructed_h - original_h).abs();
        
        let phi_stability_diff = (reconstructed_tic.stability - package.resonance_signature.stability_index as f64).abs();
        
        // Check criteria
        let delta_s_ok = delta_s_diff < 1e-4;
        let delta_h_ok = delta_h_diff < 1e-4;
        let phi_ok = phi_stability_diff < 0.02;
        
        let status = if delta_s_ok && delta_h_ok && phi_ok {
            "ok".to_string()
        } else {
            "inconsistent".to_string()
        };
        
        Ok(FeedbackConsistency {
            delta_s_diff,
            delta_h_diff,
            phi_stability_diff,
            status,
        })
    }
    
    /// Phase 5: Loop consistency test (domain → resonance → domain)
    pub fn loop_consistency_test(&self, package: &OperatorExportPackage) -> Result<f64> {
        // Reconstruct TIC
        let tic = self.orti.reconstruct_tic(package)?;
        
        // Regenerate projections from TIC
        let new_projections: Vec<_> = Domain::all()
            .iter()
            .map(|&domain| ProjectionTensor::new(domain, &tic))
            .collect();
        
        // Compare with original projections
        let mut total_error = 0.0;
        let mut count = 0;
        
        for (new_proj, orig_proj) in new_projections.iter().zip(package.projective_domains.iter()) {
            if new_proj.domain == orig_proj.domain {
                let error = (new_proj.normalized_value - orig_proj.normalized_value).abs();
                total_error += error;
                count += 1;
            }
        }
        
        let cycle_error = if count > 0 {
            total_error / count as f64
        } else {
            0.0
        };
        
        // Don't error here - just return the cycle error
        // Validation will be done in the complete validate() method
        Ok(cycle_error)
    }
    
    /// Phase 6: Meta-validation - Calculate Cross-Domain Coherence Index
    /// CDCI = 1 − (ΣΔΦ / N_pairs) − σ_T / μ_T
    pub fn meta_validation(
        &self,
        drift_matrix: &CrossDomainDriftMatrix,
        reconstruction_error: f64,
    ) -> f64 {
        let drift_component = drift_matrix.mean_drift;
        let error_component = if reconstruction_error > 0.0 {
            reconstruction_error
        } else {
            0.0
        };
        
        let cdci = (1.0 - drift_component - error_component).max(0.0).min(1.0);
        cdci
    }
    
    /// Complete validation protocol
    pub fn validate(&mut self, package: &OperatorExportPackage) -> Result<ValidationReport> {
        // Phase 1: Load and verify
        self.load_operator_projection(package)?;
        
        // Phase 2: Reverse projection
        let reconstruction_error = self.reverse_projection(package)?;
        
        // Phase 3: Cross-domain differential
        let drift_matrix = self.cross_domain_differential(package)?;
        
        // Phase 4: Feedback validation
        let feedback = self.resonance_feedback_validation(package)?;
        
        // Phase 5: Loop consistency
        let cycle_error = self.loop_consistency_test(package)?;
        
        // Phase 6: Meta-validation
        let cdci = self.meta_validation(&drift_matrix, reconstruction_error);
        
        // Determine overall status
        let status = if cdci >= 0.95 
            && drift_matrix.max_drift < self.drift_threshold
            && feedback.status == "ok"
            && cycle_error < 1e-5 {
            "validated".to_string()
        } else if cdci >= 0.90 {
            "acceptable".to_string()
        } else {
            "failed".to_string()
        };
        
        Ok(ValidationReport {
            operator_id: package.entity.id.to_string(),
            timestamp: chrono::Utc::now().to_rfc3339(),
            projection_integrity: "ok".to_string(),
            mean_error: reconstruction_error,
            cross_domain_drift: drift_matrix,
            feedback_consistency: feedback,
            cycle_closure_error: cycle_error,
            cdci,
            status,
        })
    }
    
    /// Check if recalibration is needed
    pub fn needs_recalibration(&self, report: &ValidationReport) -> bool {
        report.cdci < 0.9 || report.cross_domain_drift.max_drift > 1e-3
    }
}

impl Default for CrossDomainValidation {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::operator::Operator;
    use crate::resonant_language_projection::ResonantLanguageProjection;
    use crate::rule_matrix::RuleMatrixState;
    use crate::operator_export_grammar::OperatorExportGrammar;
    
    fn create_test_package() -> OperatorExportPackage {
        let mut rlp = ResonantLanguageProjection::new();
        let op = Operator::new();
        
        let (tic_id, projections, signature) = rlp.process_operator(&op).unwrap();
        let tic = rlp.catalogue().get(&tic_id).unwrap().clone();
        
        let rule_matrix_state = RuleMatrixState {
            matrix_checksum: "test".to_string(),
            delta_r_mean: 0.0001,
            delta_r_variance: 0.0001,
            semantic_coherence_index: 0.96,
            status: "converged".to_string(),
        };
        
        let oeg = OperatorExportGrammar::new("/tmp/test_exports");
        oeg.create_package(&tic, projections, rule_matrix_state, &signature).unwrap()
    }
    
    #[test]
    fn test_load_operator_projection() {
        let package = create_test_package();
        let validation = CrossDomainValidation::new();
        
        let result = validation.load_operator_projection(&package);
        assert!(result.is_ok());
    }
    
    #[test]
    fn test_reverse_projection() {
        let package = create_test_package();
        let validation = CrossDomainValidation::new();
        
        let result = validation.reverse_projection(&package);
        assert!(result.is_ok());
        
        let error = result.unwrap();
        assert!(error < 1e-5);
    }
    
    #[test]
    fn test_cross_domain_differential() {
        let package = create_test_package();
        let validation = CrossDomainValidation::new();
        
        let result = validation.cross_domain_differential(&package);
        assert!(result.is_ok());
        
        let drift = result.unwrap();
        assert!(drift.max_drift >= 0.0);
    }
    
    #[test]
    fn test_feedback_validation() {
        let package = create_test_package();
        let validation = CrossDomainValidation::new();
        
        let result = validation.resonance_feedback_validation(&package);
        assert!(result.is_ok());
    }
    
    #[test]
    fn test_loop_consistency() {
        let package = create_test_package();
        let validation = CrossDomainValidation::new();
        
        let result = validation.loop_consistency_test(&package);
        assert!(result.is_ok());
    }
    
    #[test]
    fn test_complete_validation() {
        let package = create_test_package();
        let mut validation = CrossDomainValidation::new();
        
        let result = validation.validate(&package);
        assert!(result.is_ok());
        
        let report = result.unwrap();
        assert!(!report.status.is_empty());
        assert!(report.cdci >= 0.0 && report.cdci <= 1.0);
    }
}
