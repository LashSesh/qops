//! Cosmic Operator Manifest Module
//!
//! Standardized schema for representing, auditing, and visualizing resonant operators
//! within the Metatron Operator Cosmos.

use serde::{Deserialize, Serialize};
use chrono::{DateTime, Utc};
use uuid::Uuid;
use crate::signature::{Signature, Signature5D};

/// Complete Cosmic Operator Manifest
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CosmicOperatorManifest {
    /// Unique identifier (UUID or hash)
    pub id: String,
    
    /// Human-readable label (optional symbolic name)
    #[serde(skip_serializing_if = "Option::is_none")]
    pub name: Option<String>,
    
    /// Time at which the operator achieved Proof-of-Resonance
    pub creation_timestamp: DateTime<Utc>,
    
    /// Contextual lineage and generation metadata
    pub origin: OperatorOrigin,
    
    /// Core mathematical representation of ψρω dynamics
    pub resonance_tensor: ResonanceTensor,
    
    /// Topological fingerprint
    pub topology_signature: TopologySignature,
    
    /// Entropy and stability data
    pub entropic_dynamics: EntropicDynamics,
    
    /// Mandorla Eigenstate Fractal parameters
    pub mandorla_state: MandorlaState,
    
    /// Gabriel Cell cluster statistics
    pub gabriel_cluster: GabrielCluster,
    
    /// Proof-of-Resonance audit information
    pub proof_of_resonance: ProofOfResonance,
    
    /// Visualization guidance for UX layer
    pub visualization_metadata: VisualizationMetadata,
    
    /// Related operators
    #[serde(default)]
    pub relations: Vec<OperatorRelation>,
    
    /// Automatic classification tags
    #[serde(default)]
    pub semantic_tags: Vec<String>,
    
    /// User-provided notes or discoveries
    #[serde(default)]
    pub user_annotations: Vec<UserAnnotation>,
}

/// Operator origin and lineage
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorOrigin {
    /// Index (0–12) of Metatron Cube node where operator was born
    pub source_node: usize,
    
    /// Hash of parent operator, if evolved
    #[serde(skip_serializing_if = "Option::is_none")]
    pub parent_hash: Option<String>,
    
    /// Evolutionary depth in the operator lineage
    pub generation: usize,
}

/// Resonance tensor representation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResonanceTensor {
    /// Dimensions [nψ, nρ, nω]
    pub dimensions: Vec<usize>,
    
    /// Flattened tensor coefficients
    pub tensor_data: Vec<f64>,
    
    /// Average ψρω-field energy
    pub energy_density: f64,
    
    /// Variance of phase symmetry within the tensor
    pub phase_variance: f64,
}

/// Topological signature
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TopologySignature {
    /// β₀, β₁, β₂ invariants (Betti numbers)
    pub betti_numbers: Vec<usize>,
    
    /// Normalized connectivity ratio
    pub connectivity_density: f64,
    
    /// Symmetry class (C₆, D₆, S₇, etc.)
    pub symmetry_class: String,
}

/// Entropic dynamics and stability
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EntropicDynamics {
    /// Final ΔS value after mining cycle
    pub entropy_gradient: f64,
    
    /// Time-series entropy history
    pub entropy_curve: Vec<f64>,
    
    /// Normalized 0–1 stability index (1 = perfect resonance)
    pub stability_rating: f64,
}

/// Mandorla eigenstate fractal parameters
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MandorlaState {
    /// Fractal recursion depth (MEF layer count)
    pub depth: usize,
    
    /// Degree of self-similarity (0–1)
    pub similarity_index: f64,
    
    /// Mandorla dual-gate status
    pub dual_gate_state: DualGateState,
}

/// Dual-gate state enumeration
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum DualGateState {
    Open,
    Closed,
    Superposed,
}

/// Gabriel Cell cluster statistics
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GabrielCluster {
    /// Number of cells in cluster
    pub cell_count: usize,
    
    /// Mean coherence across cells
    pub mean_coherence: f64,
    
    /// Feedback loop strength
    pub feedback_strength: f64,
    
    /// Spiral memory depth
    pub spiral_memory_depth: usize,
}

/// Proof-of-Resonance audit data
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProofOfResonance {
    /// Number of cycles validated
    pub cycles_validated: usize,
    
    /// Whether Mandorla condition is satisfied
    pub mandorla_condition: bool,
    
    /// Whether energy is conserved
    pub energy_conservation: bool,
    
    /// Proof-of-Resonance SHA512 hash
    pub hash: String,
    
    /// Relative path to ledger TOML entry
    pub ledger_entry: String,
}

/// Visualization metadata for UX rendering
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VisualizationMetadata {
    /// Suggested visualization mode
    pub preferred_view: ViewMode,
    
    /// Visual mapping scheme for UI
    pub color_scheme: ColorScheme,
    
    /// Relative path to preview image
    #[serde(skip_serializing_if = "Option::is_none")]
    pub thumbnail: Option<String>,
    
    /// [x, y, z] coordinates in Metatron Cube router
    pub position_in_cube: [f64; 3],
}

/// Visualization view modes
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ViewMode {
    Heatmap,
    Fractal,
    Cube,
    Timeline,
}

/// Color schemes for visualization
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ColorScheme {
    Resonance,
    Entropy,
    Topology,
    Stability,
}

/// Relation to another operator
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorRelation {
    /// Target operator ID
    pub target_id: String,
    
    /// Type of relation
    pub relation_type: RelationType,
    
    /// Relation weight/strength
    pub weight: f64,
}

/// Types of operator relations
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum RelationType {
    Evolution,
    Resonant,
    Topological,
    Dual,
}

/// User annotation on an operator
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UserAnnotation {
    /// Author of annotation
    pub author: String,
    
    /// Timestamp of annotation
    pub timestamp: DateTime<Utc>,
    
    /// Comment text
    pub comment: String,
}

impl CosmicOperatorManifest {
    /// Create a new manifest from a Signature5D and basic metadata
    pub fn from_signature(
        signature: &Signature5D,
        source_node: usize,
        generation: usize,
    ) -> Self {
        let now = Utc::now();
        let id = Uuid::new_v4().to_string();
        
        Self {
            id: id.clone(),
            name: None,
            creation_timestamp: now,
            origin: OperatorOrigin {
                source_node,
                parent_hash: None,
                generation,
            },
            resonance_tensor: ResonanceTensor {
                dimensions: vec![5, 5, 5],
                tensor_data: vec![
                    signature.psi(), signature.rho(), signature.omega(),
                    signature.chi(), signature.eta()
                ],
                energy_density: signature.psi() * signature.rho() * signature.omega(),
                phase_variance: 0.01,
            },
            topology_signature: TopologySignature {
                betti_numbers: vec![1, 0, 0],
                connectivity_density: 0.5,
                symmetry_class: "S7".to_string(),
            },
            entropic_dynamics: EntropicDynamics {
                entropy_gradient: 0.0,
                entropy_curve: vec![],
                stability_rating: 0.95,
            },
            mandorla_state: MandorlaState {
                depth: 1,
                similarity_index: 0.8,
                dual_gate_state: DualGateState::Open,
            },
            gabriel_cluster: GabrielCluster {
                cell_count: 4,
                mean_coherence: 0.85,
                feedback_strength: 0.7,
                spiral_memory_depth: 3,
            },
            proof_of_resonance: ProofOfResonance {
                cycles_validated: 100,
                mandorla_condition: true,
                energy_conservation: true,
                hash: format!("sha512:{}", id),
                ledger_entry: format!("ledger/operators/{}.toml", id),
            },
            visualization_metadata: VisualizationMetadata {
                preferred_view: ViewMode::Cube,
                color_scheme: ColorScheme::Resonance,
                thumbnail: None,
                position_in_cube: [0.5, 0.5, 0.5],
            },
            relations: vec![],
            semantic_tags: vec!["genesis".to_string()],
            user_annotations: vec![],
        }
    }

    /// Add a semantic tag
    pub fn add_tag(&mut self, tag: String) {
        if !self.semantic_tags.contains(&tag) {
            self.semantic_tags.push(tag);
        }
    }

    /// Add a user annotation
    pub fn add_annotation(&mut self, author: String, comment: String) {
        self.user_annotations.push(UserAnnotation {
            author,
            timestamp: Utc::now(),
            comment,
        });
    }

    /// Add a relation to another operator
    pub fn add_relation(&mut self, target_id: String, relation_type: RelationType, weight: f64) {
        self.relations.push(OperatorRelation {
            target_id,
            relation_type,
            weight,
        });
    }

    /// Export as JSON
    pub fn to_json(&self) -> Result<String, serde_json::Error> {
        serde_json::to_string_pretty(self)
    }

    /// Import from JSON
    pub fn from_json(json: &str) -> Result<Self, serde_json::Error> {
        serde_json::from_str(json)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::signature::Signature;

    #[test]
    fn test_manifest_creation() {
        let sig: Signature5D = Signature::new();
        let manifest = CosmicOperatorManifest::from_signature(&sig, 0, 1);
        
        assert_eq!(manifest.origin.source_node, 0);
        assert_eq!(manifest.origin.generation, 1);
        assert_eq!(manifest.semantic_tags.len(), 1);
        assert_eq!(manifest.proof_of_resonance.mandorla_condition, true);
    }

    #[test]
    fn test_add_tag() {
        let sig: Signature5D = Signature::new();
        let mut manifest = CosmicOperatorManifest::from_signature(&sig, 0, 1);
        
        manifest.add_tag("energy".to_string());
        manifest.add_tag("fractal".to_string());
        assert_eq!(manifest.semantic_tags.len(), 3); // genesis + 2 new
    }

    #[test]
    fn test_add_annotation() {
        let sig: Signature5D = Signature::new();
        let mut manifest = CosmicOperatorManifest::from_signature(&sig, 0, 1);
        
        manifest.add_annotation("user1".to_string(), "Interesting operator".to_string());
        assert_eq!(manifest.user_annotations.len(), 1);
    }

    #[test]
    fn test_add_relation() {
        let sig: Signature5D = Signature::new();
        let mut manifest = CosmicOperatorManifest::from_signature(&sig, 0, 1);
        
        manifest.add_relation("other-id".to_string(), RelationType::Evolution, 0.9);
        assert_eq!(manifest.relations.len(), 1);
        assert_eq!(manifest.relations[0].relation_type, RelationType::Evolution);
    }

    #[test]
    fn test_json_serialization() {
        let sig: Signature5D = Signature::new();
        let manifest = CosmicOperatorManifest::from_signature(&sig, 0, 1);
        
        let json = manifest.to_json().unwrap();
        assert!(json.contains("\"id\""));
        assert!(json.contains("\"proof_of_resonance\""));
        
        let deserialized = CosmicOperatorManifest::from_json(&json).unwrap();
        assert_eq!(deserialized.id, manifest.id);
    }
}
