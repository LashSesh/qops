//! Auto-Evolution Daemon with Meta-Cognition Integration
//!
//! Orchestrates the evolution cycle with integrated meta-cognition layer
//! running introspection every 500 cycles.

use crate::evolution_cycle::{EvolutionCycle, EvolutionConfig, EvolutionStats};
use crate::meta_cognition::{
    MetaCognitionLayer, MetaCognitionConfig, TelemetryPoint,
    SelfReflectionReport,
};
use crate::signature::Signature5D;
use crate::error::Result;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use chrono::Utc;
use uuid::Uuid;

/// Configuration for the auto-evolution daemon
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AutoEvolutionConfig {
    /// Evolution cycle configuration
    pub evolution: EvolutionConfig,
    /// Meta-cognition configuration
    pub meta_cognition: MetaCognitionConfig,
    /// Maximum number of cycles to run
    pub max_cycles: Option<usize>,
    /// Enable adaptive feedback from meta-cognition
    pub enable_adaptive_feedback: bool,
}

impl Default for AutoEvolutionConfig {
    fn default() -> Self {
        Self {
            evolution: EvolutionConfig::default(),
            meta_cognition: MetaCognitionConfig::default(),
            max_cycles: None,
            enable_adaptive_feedback: true,
        }
    }
}

/// Auto-evolution daemon state
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DaemonState {
    pub running: bool,
    pub total_cycles: usize,
    pub introspections_run: usize,
    pub last_reflection: Option<SelfReflectionReport>,
}

impl DaemonState {
    pub fn new() -> Self {
        Self {
            running: false,
            total_cycles: 0,
            introspections_run: 0,
            last_reflection: None,
        }
    }
}

impl Default for DaemonState {
    fn default() -> Self {
        Self::new()
    }
}

/// Auto-Evolution Daemon with Meta-Cognition
pub struct AutoEvolutionDaemon {
    config: AutoEvolutionConfig,
    evolution: EvolutionCycle,
    meta_cognition: MetaCognitionLayer,
    stats: EvolutionStats,
    state: DaemonState,
    telemetry_buffer: Vec<TelemetryPoint>,
    operator_semantics: HashMap<String, Vec<String>>,
    cube_lineage: HashMap<Uuid, Vec<Uuid>>,
}

impl AutoEvolutionDaemon {
    /// Create new auto-evolution daemon
    pub fn new(config: AutoEvolutionConfig, initial_signatures: Vec<Signature5D>) -> Self {
        let evolution = EvolutionCycle::new(config.evolution.clone(), initial_signatures);
        let meta_cognition = MetaCognitionLayer::new(config.meta_cognition.clone());

        Self {
            config,
            evolution,
            meta_cognition,
            stats: EvolutionStats::new(),
            state: DaemonState::new(),
            telemetry_buffer: Vec::new(),
            operator_semantics: HashMap::new(),
            cube_lineage: HashMap::new(),
        }
    }

    /// Start the daemon
    pub fn start(&mut self) {
        self.state.running = true;
    }

    /// Stop the daemon
    pub fn stop(&mut self) {
        self.state.running = false;
    }

    /// Run a single cycle with meta-cognition integration
    pub fn run_cycle(&mut self) -> Result<()> {
        if !self.state.running {
            return Ok(());
        }

        // Run evolution cycle
        let cycle_state = self.evolution.run_cycle()?;
        
        // Update statistics
        let at_equilibrium = self.evolution.is_at_equilibrium();
        self.stats.update(&cycle_state, at_equilibrium);

        // Collect telemetry
        let telemetry_point = TelemetryPoint {
            cycle: cycle_state.cycle_number,
            delta_h: cycle_state.energy_drift,
            delta_s: cycle_state.topological_variance,
            stability: if at_equilibrium { 1.0 } else { 0.5 },
            mutation_rate: 0.1, // Placeholder
            hybrid_count: cycle_state.current_signatures.len(),
            timestamp: Utc::now(),
        };
        self.telemetry_buffer.push(telemetry_point);

        // Keep only recent telemetry (last 1000 cycles)
        if self.telemetry_buffer.len() > 1000 {
            self.telemetry_buffer = self.telemetry_buffer
                .split_off(self.telemetry_buffer.len() - 1000);
        }

        // Tick meta-cognition
        self.meta_cognition.tick();

        // Run meta-cognition introspection every 500 cycles
        if self.meta_cognition.should_run_introspection() {
            self.run_introspection()?;
        }

        self.state.total_cycles += 1;

        // Check if we should stop
        if let Some(max_cycles) = self.config.max_cycles {
            if self.state.total_cycles >= max_cycles {
                self.stop();
            }
        }

        Ok(())
    }

    /// Run meta-cognition introspection
    fn run_introspection(&mut self) -> Result<()> {
        // Prepare data for introspection
        let lookback = self.config.meta_cognition.lookback_cycles;
        let telemetry = if self.telemetry_buffer.len() > lookback {
            self.telemetry_buffer[self.telemetry_buffer.len() - lookback..]
                .to_vec()
        } else {
            self.telemetry_buffer.clone()
        };

        // Run introspection
        let reflection = self.meta_cognition.run_introspection(
            telemetry,
            self.operator_semantics.clone(),
            self.cube_lineage.clone(),
        )?;

        // Apply adaptive feedback if enabled
        if self.config.enable_adaptive_feedback {
            self.apply_feedback(&reflection)?;
        }

        self.state.last_reflection = Some(reflection);
        self.state.introspections_run += 1;

        Ok(())
    }

    /// Apply adaptive feedback from meta-cognition
    fn apply_feedback(&mut self, reflection: &SelfReflectionReport) -> Result<()> {
        // Adaptive feedback rules from meta-cognition spec
        
        // If confidence is low, might need parameter adjustment
        if reflection.confidence < 0.7 {
            // Could adjust mutation rate, exploration parameters, etc.
            // For now, this is a placeholder for integration with evolution parameters
        }

        // Check adaptation suggestion
        if reflection.adaptation_suggestion.contains("mutation rate") {
            // Adjust mutation rate
        } else if reflection.adaptation_suggestion.contains("feedback gain") {
            // Adjust feedback gain
        } else if reflection.adaptation_suggestion.contains("hybrid operator") {
            // Introduce hybrid operator generation bias
        }

        Ok(())
    }

    /// Add operator semantic tags
    pub fn add_operator_semantics(&mut self, operator_id: String, tags: Vec<String>) {
        self.operator_semantics.insert(operator_id, tags);
    }

    /// Add cube lineage information
    pub fn add_cube_lineage(&mut self, cube_id: Uuid, parent_ids: Vec<Uuid>) {
        self.cube_lineage.insert(cube_id, parent_ids);
    }

    /// Get daemon state
    pub fn get_state(&self) -> &DaemonState {
        &self.state
    }

    /// Get evolution statistics
    pub fn get_stats(&self) -> &EvolutionStats {
        &self.stats
    }

    /// Get meta-cognition layer
    pub fn get_meta_cognition(&self) -> &MetaCognitionLayer {
        &self.meta_cognition
    }

    /// Get current telemetry
    pub fn get_telemetry(&self) -> &[TelemetryPoint] {
        &self.telemetry_buffer
    }

    /// Get last reflection report
    pub fn get_last_reflection(&self) -> Option<&SelfReflectionReport> {
        self.state.last_reflection.as_ref()
    }

    /// Run daemon for specified number of cycles
    pub fn run_for_cycles(&mut self, cycles: usize) -> Result<()> {
        self.start();
        for _ in 0..cycles {
            self.run_cycle()?;
            if !self.state.running {
                break;
            }
        }
        Ok(())
    }

    /// Run daemon until equilibrium is reached
    pub fn run_until_equilibrium(&mut self, max_cycles: usize) -> Result<()> {
        self.start();
        for _ in 0..max_cycles {
            self.run_cycle()?;
            if self.evolution.is_at_equilibrium() {
                break;
            }
            if !self.state.running {
                break;
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_daemon_creation() {
        let config = AutoEvolutionConfig::default();
        let signatures = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
        ];
        let daemon = AutoEvolutionDaemon::new(config, signatures);
        assert!(!daemon.state.running);
        assert_eq!(daemon.state.total_cycles, 0);
    }

    #[test]
    fn test_daemon_start_stop() {
        let config = AutoEvolutionConfig::default();
        let signatures = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
        ];
        let mut daemon = AutoEvolutionDaemon::new(config, signatures);

        daemon.start();
        assert!(daemon.state.running);

        daemon.stop();
        assert!(!daemon.state.running);
    }

    #[test]
    fn test_single_cycle() {
        let config = AutoEvolutionConfig::default();
        let signatures = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
        ];
        let mut daemon = AutoEvolutionDaemon::new(config, signatures);

        daemon.start();
        let result = daemon.run_cycle();
        assert!(result.is_ok());
        assert_eq!(daemon.state.total_cycles, 1);
    }

    #[test]
    fn test_run_for_cycles() {
        let config = AutoEvolutionConfig {
            max_cycles: Some(10),
            ..Default::default()
        };
        let signatures = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
            Signature5D::new(0.6, 0.6, 0.6, 0.6, 0.6),
        ];
        let mut daemon = AutoEvolutionDaemon::new(config, signatures);

        let result = daemon.run_for_cycles(5);
        assert!(result.is_ok());
        assert_eq!(daemon.state.total_cycles, 5);
    }

    #[test]
    fn test_operator_semantics() {
        let config = AutoEvolutionConfig::default();
        let signatures = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
        ];
        let mut daemon = AutoEvolutionDaemon::new(config, signatures);

        daemon.add_operator_semantics(
            "op1".to_string(),
            vec!["coherence".to_string(), "stability".to_string()],
        );

        assert_eq!(daemon.operator_semantics.len(), 1);
    }

    #[test]
    fn test_meta_cognition_introspection_timing() {
        let config = AutoEvolutionConfig {
            meta_cognition: MetaCognitionConfig {
                frequency_cycles: 10, // Run every 10 cycles for testing
                ..Default::default()
            },
            ..Default::default()
        };
        let signatures = vec![
            Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5),
        ];
        let mut daemon = AutoEvolutionDaemon::new(config, signatures);

        // Add some semantics for introspection
        daemon.add_operator_semantics(
            "op1".to_string(),
            vec!["coherence".to_string()],
        );

        daemon.run_for_cycles(15).unwrap();

        // Should have run at least one introspection
        assert!(daemon.state.introspections_run >= 1);
    }
}
