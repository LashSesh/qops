//! MetatronCube Graph Structure
//!
//! The Metatron Cube is interpreted as a directed graph based on the symmetric
//! group S7, with |S7| = 7! = 5040 nodes representing all permutations.
//!
//! ## Structure
//! - 5040 nodes (S7 permutations)
//! - Edges represent valid transformations:
//!   - Elementary transpositions
//!   - Signature-neutral reorderings
//!   - Resonance-modulating transformations
//!
//! The full symmetry group includes 5040 operations (rotations, reflections, permutations)

use crate::signature::{Signature, Signature5D};
use petgraph::graph::{DiGraph, NodeIndex};
use petgraph::Direction;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// The size of S7 permutation group
pub const S7_SIZE: usize = 5040; // 7! = 5040

/// Type of transformation between nodes
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TransformationType {
    /// Elementary transposition (swap two adjacent elements)
    Transposition,
    /// Signature-neutral reordering
    Reordering,
    /// Resonance-modulating transformation
    Resonance,
    /// Rotational symmetry
    Rotation,
    /// Reflective symmetry
    Reflection,
}

/// Edge data storing transformation information
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EdgeData {
    /// Type of transformation
    pub transform_type: TransformationType,
    /// Weight/cost of this transformation
    pub weight: f64,
    /// Expected signature modulation
    pub signature_delta: Signature5D,
}

/// Node data storing permutation and signature
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeData {
    /// Node ID (0..5039)
    pub id: usize,
    /// Permutation representation [0,1,2,3,4,5,6] -> some permutation
    pub permutation: [usize; 7],
    /// Base signature for this node
    pub base_signature: Signature5D,
}

/// The MetatronCube graph structure
pub struct MetatronCube {
    /// Underlying directed graph
    graph: DiGraph<NodeData, EdgeData>,
    /// Map from node ID to NodeIndex
    node_map: HashMap<usize, NodeIndex>,
    /// Seed node (identity permutation)
    seed_node: NodeIndex,
}

impl MetatronCube {
    /// Create a new MetatronCube with full S7 structure
    ///
    /// Note: In a real implementation, generating all 5040! edges would be computationally
    /// intensive. This implementation creates a simplified version with key symmetries.
    pub fn new() -> Self {
        let mut graph = DiGraph::new();
        let mut node_map = HashMap::new();

        // Generate identity node (seed)
        let identity = [0, 1, 2, 3, 4, 5, 6];
        let seed_data = NodeData {
            id: 0,
            permutation: identity,
            base_signature: Signature::new(),
        };
        let seed_idx = graph.add_node(seed_data);
        node_map.insert(0, seed_idx);

        // Generate all permutations of S7 (simplified for demo)
        // In production, this would use Heap's algorithm or similar
        let permutations = Self::generate_s7_permutations();

        for (i, perm) in permutations.iter().enumerate().skip(1).take(100) {
            // Limit to 100 nodes for demo
            let node_data = NodeData {
                id: i,
                permutation: *perm,
                base_signature: Self::compute_base_signature(perm),
            };
            let idx = graph.add_node(node_data);
            node_map.insert(i, idx);
        }

        // Create edges based on transformation rules
        Self::connect_nodes(&mut graph, &node_map);

        Self {
            graph,
            node_map,
            seed_node: seed_idx,
        }
    }

    /// Generate a simplified set of S7 permutations
    /// In production, this would generate all 5040 permutations
    fn generate_s7_permutations() -> Vec<[usize; 7]> {
        let mut perms = Vec::new();
        let identity = [0, 1, 2, 3, 4, 5, 6];
        perms.push(identity);

        // Generate transpositions and rotations (simplified)
        for i in 0..7 {
            for j in (i+1)..7 {
                let mut perm = identity;
                perm.swap(i, j);
                if !perms.contains(&perm) {
                    perms.push(perm);
                }
            }
        }

        // Generate some cyclic rotations
        for shift in 1..7 {
            let perm = [
                (0 + shift) % 7,
                (1 + shift) % 7,
                (2 + shift) % 7,
                (3 + shift) % 7,
                (4 + shift) % 7,
                (5 + shift) % 7,
                (6 + shift) % 7,
            ];
            if !perms.contains(&perm) {
                perms.push(perm);
            }
        }

        perms
    }

    /// Compute base signature from permutation structure
    fn compute_base_signature(perm: &[usize; 7]) -> Signature5D {
        // Calculate "disorder" metrics
        let inversions = Self::count_inversions(perm);
        let max_inversions = (7 * 6) / 2; // Maximum possible inversions for size 7

        // ψ: Spectral quality (inversely related to inversions)
        let psi = 1.0 - (inversions as f64 / max_inversions as f64);

        // ρ: Cycle structure (number of cycles)
        let cycles = Self::count_cycles(perm);
        let rho = cycles as f64 / 7.0;

        // ω: Fixed points
        let fixed = perm.iter().enumerate().filter(|(i, &p)| i == &p).count();
        let omega = fixed as f64 / 7.0;

        // χ: Parity (even/odd permutation)
        let chi = if inversions % 2 == 0 { 1.0 } else { 0.5 };

        // η: Distance from identity
        let distance: usize = perm.iter().enumerate().map(|(i, &p)| (i as isize - p as isize).abs() as usize).sum();
        let eta = 1.0 - (distance as f64 / 21.0); // Max distance is 3*7 = 21

        Signature5D::with_values(psi, rho, omega, chi, eta).unwrap_or_else(|_| Signature::new())
    }

    /// Count inversions in a permutation
    fn count_inversions(perm: &[usize; 7]) -> usize {
        let mut count = 0;
        for i in 0..7 {
            for j in (i+1)..7 {
                if perm[i] > perm[j] {
                    count += 1;
                }
            }
        }
        count
    }

    /// Count disjoint cycles in a permutation
    fn count_cycles(perm: &[usize; 7]) -> usize {
        let mut visited = [false; 7];
        let mut cycles = 0;

        for i in 0..7 {
            if !visited[i] {
                cycles += 1;
                let mut current = i;
                while !visited[current] {
                    visited[current] = true;
                    current = perm[current];
                }
            }
        }

        cycles
    }

    /// Connect nodes with edges based on transformation rules
    fn connect_nodes(
        graph: &mut DiGraph<NodeData, EdgeData>,
        node_map: &HashMap<usize, NodeIndex>
    ) {
        let nodes: Vec<_> = node_map.values().copied().collect();

        for &node_idx in &nodes {
            // Clone the data we need before mutable borrow
            let node_perm = graph[node_idx].permutation;
            let node_sig = graph[node_idx].base_signature;

            // Find neighboring nodes (differ by one transposition)
            for &other_idx in &nodes {
                if node_idx == other_idx {
                    continue;
                }

                let other_perm = graph[other_idx].permutation;
                let other_sig = graph[other_idx].base_signature;

                // Check if nodes differ by a single transposition
                if Self::is_transposition(&node_perm, &other_perm) {
                    let delta = other_sig - node_sig;
                    let edge_data = EdgeData {
                        transform_type: TransformationType::Transposition,
                        weight: delta.distance(&Signature5D::new(0.0, 0.0, 0.0, 0.0, 0.0)),
                        signature_delta: delta,
                    };
                    graph.add_edge(node_idx, other_idx, edge_data);
                }
            }
        }
    }

    /// Check if two permutations differ by exactly one transposition
    fn is_transposition(p1: &[usize; 7], p2: &[usize; 7]) -> bool {
        let diffs: Vec<_> = p1.iter().zip(p2.iter())
            .enumerate()
            .filter(|(_, (a, b))| a != b)
            .collect();

        if diffs.len() != 2 {
            return false;
        }

        // Check if it's a swap
        let (i, (a1, b1)) = diffs[0];
        let (j, (a2, b2)) = diffs[1];

        a1 == b2 && a2 == b1 && p1[j] == p2[i] && p1[i] == p2[j]
    }

    /// Get the seed node (identity permutation)
    pub fn seed_node(&self) -> NodeIndex {
        self.seed_node
    }

    /// Get neighbors of a node
    pub fn get_neighbors(&self, node: NodeIndex) -> Vec<(NodeIndex, &EdgeData)> {
        self.graph
            .neighbors_directed(node, Direction::Outgoing)
            .map(|n| (n, self.graph.edge_weight(self.graph.find_edge(node, n).unwrap()).unwrap()))
            .collect()
    }

    /// Get node data
    pub fn get_node(&self, node: NodeIndex) -> Option<&NodeData> {
        self.graph.node_weight(node)
    }

    /// Get node by ID
    pub fn get_node_by_id(&self, id: usize) -> Option<NodeIndex> {
        self.node_map.get(&id).copied()
    }

    /// Total number of nodes
    pub fn node_count(&self) -> usize {
        self.graph.node_count()
    }

    /// Total number of edges
    pub fn edge_count(&self) -> usize {
        self.graph.edge_count()
    }

    /// Get edge data between two nodes
    pub fn get_edge(&self, from: NodeIndex, to: NodeIndex) -> Option<&EdgeData> {
        self.graph.find_edge(from, to).and_then(|edge_idx| self.graph.edge_weight(edge_idx))
    }

    /// Find nodes with high resonance signatures
    pub fn find_high_resonance_nodes(&self, threshold: f64) -> Vec<NodeIndex> {
        self.graph
            .node_indices()
            .filter(|&idx| {
                self.graph[idx].base_signature.resonance() > threshold
            })
            .collect()
    }

    /// Export graph to DOT format for visualization
    pub fn to_dot(&self) -> String {
        use petgraph::dot::{Dot, Config};
        format!("{:?}", Dot::with_config(&self.graph, &[Config::EdgeNoLabel]))
    }
}

impl Default for MetatronCube {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cube_creation() {
        let cube = MetatronCube::new();
        assert!(cube.node_count() > 0);
        assert!(cube.edge_count() > 0);
    }

    #[test]
    fn test_seed_node() {
        let cube = MetatronCube::new();
        let seed = cube.seed_node();
        let node = cube.get_node(seed).unwrap();
        assert_eq!(node.permutation, [0, 1, 2, 3, 4, 5, 6]);
    }

    #[test]
    fn test_neighbors() {
        let cube = MetatronCube::new();
        let seed = cube.seed_node();
        let neighbors = cube.get_neighbors(seed);
        assert!(!neighbors.is_empty());
    }

    #[test]
    fn test_inversions() {
        let identity = [0, 1, 2, 3, 4, 5, 6];
        assert_eq!(MetatronCube::count_inversions(&identity), 0);

        let reversed = [6, 5, 4, 3, 2, 1, 0];
        assert!(MetatronCube::count_inversions(&reversed) > 0);
    }

    #[test]
    fn test_transposition_detection() {
        let p1 = [0, 1, 2, 3, 4, 5, 6];
        let p2 = [0, 2, 1, 3, 4, 5, 6]; // Swap 1 and 2
        assert!(MetatronCube::is_transposition(&p1, &p2));

        let p3 = [0, 1, 3, 2, 4, 5, 6]; // Swap 2 and 3
        assert!(!MetatronCube::is_transposition(&p1, &p3));
    }

    #[test]
    fn test_signature_computation() {
        let identity = [0, 1, 2, 3, 4, 5, 6];
        let sig = MetatronCube::compute_base_signature(&identity);

        // Identity should have high spectral quality
        assert!(sig.psi() > 0.9);
    }

    #[test]
    fn test_find_high_resonance() {
        let cube = MetatronCube::new();
        let high_res = cube.find_high_resonance_nodes(0.7);
        assert!(!high_res.is_empty());
    }
}
