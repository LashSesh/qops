// KNO Validation and Hermitian Integrity Framework
// Implements 5-layer validation system for operator verification

use crate::kno_framework::{KNOOperator, Complex, PhaseField};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Validation tolerance levels
pub const HERMITIAN_TOLERANCE: f64 = 1e-10;
pub const STABILITY_TOLERANCE: f64 = 1e-6;
pub const COHERENCE_THRESHOLD: f64 = 0.995;
pub const BERRY_PHASE_TARGET: f64 = 6.283185307179586; // 2π
pub const BERRY_PHASE_TOLERANCE: f64 = 0.1;
pub const CHERN_NUMBER_TARGET: f64 = 1.0;
pub const CHERN_NUMBER_TOLERANCE: f64 = 0.05;
pub const AMPLITUDE_BOUND: f64 = 1e3;

/// Validation result for a single layer
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayerValidationResult {
    pub layer_name: String,
    pub passed: bool,
    pub metric_value: f64,
    pub threshold: f64,
    pub error_message: Option<String>,
    pub details: HashMap<String, f64>,
}

impl LayerValidationResult {
    pub fn new(layer_name: String) -> Self {
        Self {
            layer_name,
            passed: false,
            metric_value: 0.0,
            threshold: 0.0,
            error_message: None,
            details: HashMap::new(),
        }
    }

    pub fn passed(mut self, metric: f64, threshold: f64) -> Self {
        self.passed = true;
        self.metric_value = metric;
        self.threshold = threshold;
        self
    }

    pub fn failed(mut self, metric: f64, threshold: f64, error: String) -> Self {
        self.passed = false;
        self.metric_value = metric;
        self.threshold = threshold;
        self.error_message = Some(error);
        self
    }

    pub fn with_detail(mut self, key: String, value: f64) -> Self {
        self.details.insert(key, value);
        self
    }
}

/// Complete validation report for KNO operator
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ValidationReport {
    pub operator_id: String,
    pub timestamp: String,
    pub commit_ref: Option<String>,
    pub layer_results: Vec<LayerValidationResult>,
    pub overall_passed: bool,
    pub alerts_triggered: Vec<String>,
}

impl ValidationReport {
    pub fn new(operator_id: String) -> Self {
        Self {
            operator_id,
            timestamp: chrono::Utc::now().to_rfc3339(),
            commit_ref: None,
            layer_results: Vec::new(),
            overall_passed: false,
            alerts_triggered: Vec::new(),
        }
    }

    pub fn add_layer_result(&mut self, result: LayerValidationResult) {
        if !result.passed {
            if let Some(ref error) = result.error_message {
                self.alerts_triggered.push(format!("{}: {}", result.layer_name, error));
            }
        }
        self.layer_results.push(result);
    }

    pub fn finalize(&mut self) {
        self.overall_passed = self.layer_results.iter().all(|r| r.passed);
    }
}

/// Layer 1: Hermitianity Check
/// Verify that LΦ(K)† = LΦ(K) within numerical tolerance
pub struct HermitianityValidator;

impl HermitianityValidator {
    /// Validate Hermitian property: Re(⟨Ψ | LΦ(K)Ψ⟩) = Re(⟨LΦ(K)Ψ | Ψ⟩)
    pub fn validate(operator: &KNOOperator, primes: &[u64]) -> LayerValidationResult {
        let mut result = LayerValidationResult::new("Layer 1: Hermitianity Check".to_string());

        // Compute Ψ and dΨ/dt
        let psi = operator.phase_field.psi;
        let dpsi_dt = Self::compute_dpsi_dt(&operator.phase_field, primes);

        // Apply operator: LΦ(K)Ψ
        let l_psi = operator.apply(&psi, &dpsi_dt, operator.phase_field.phi);

        // Compute ⟨Ψ | LΦ(K)Ψ⟩
        let psi_star = psi.conjugate();
        let inner1 = psi_star.mul(&l_psi);

        // Compute ⟨LΦ(K)Ψ | Ψ⟩
        let l_psi_star = l_psi.conjugate();
        let inner2 = l_psi_star.mul(&psi);

        // Check Hermitian condition: Re(inner1) ≈ Re(inner2)
        let diff = (inner1.re - inner2.re).abs();

        result = result.with_detail("inner_product_1".to_string(), inner1.re);
        result = result.with_detail("inner_product_2".to_string(), inner2.re);
        result = result.with_detail("difference".to_string(), diff);

        if diff < HERMITIAN_TOLERANCE {
            result.passed(diff, HERMITIAN_TOLERANCE)
        } else {
            result.failed(
                diff,
                HERMITIAN_TOLERANCE,
                format!("Hermitianity violation: LΦ(K)† ≠ LΦ(K), difference = {:.2e}", diff),
            )
        }
    }

    fn compute_dpsi_dt(phase_field: &PhaseField, primes: &[u64]) -> Complex {
        let mut dpsi_dt = Complex::zero();
        let t = phase_field.time;

        for &p in primes {
            let p_f64 = p as f64;
            let amplitude = 1.0 / p_f64.sqrt();
            let log_p = p_f64.ln();
            let phase = t * log_p;

            // dΨ/dt = i Σ_p p^{-1/2} log(p) e^{i t log p}
            dpsi_dt = dpsi_dt.add(&Complex::new(
                -amplitude * log_p * phase.sin(),
                amplitude * log_p * phase.cos(),
            ));
        }

        dpsi_dt
    }
}

/// Layer 2: Potential Stability Validation
/// Evaluate V''(γ_n) for each critical point; all must satisfy V''(γ_n) > 0
pub struct StabilityValidator;

impl StabilityValidator {
    pub fn validate(operator: &KNOOperator) -> LayerValidationResult {
        let mut result = LayerValidationResult::new("Layer 2: Potential Stability".to_string());

        // Check stability for all Riemann zeros
        let stability_results = operator.potential.check_stability(STABILITY_TOLERANCE);

        let total_zeros = stability_results.len();
        let stable_count = stability_results.iter().filter(|(_, _, stable)| *stable).count();

        result = result.with_detail("total_minima".to_string(), total_zeros as f64);
        result = result.with_detail("stable_minima".to_string(), stable_count as f64);

        // Add individual zero stability
        for (i, (_gamma, v_pp, is_stable)) in stability_results.iter().enumerate() {
            result = result.with_detail(format!("gamma_{}_v_pp", i), *v_pp);
            result = result.with_detail(format!("gamma_{}_stable", i), if *is_stable { 1.0 } else { 0.0 });
        }

        let ratio = stable_count as f64 / total_zeros as f64;

        if stable_count == total_zeros {
            result.passed(ratio, 1.0)
        } else {
            let unstable: Vec<_> = stability_results
                .iter()
                .enumerate()
                .filter(|(_, (_, _, stable))| !*stable)
                .map(|(i, (gamma, v_pp, _))| format!("γ_{}={:.6} (V''={:.2e})", i, gamma, v_pp))
                .collect();

            result.failed(
                ratio,
                1.0,
                format!("Instability detected at {} zeros: {}", total_zeros - stable_count, unstable.join(", ")),
            )
        }
    }
}

/// Layer 3: Spectral Coherence Test
/// Track spectral trajectory and compute correlation to baseline
pub struct SpectralCoherenceValidator;

impl SpectralCoherenceValidator {
    /// Compute correlation: ρ = ⟨Ψ(t)Ψ*(t+Δt)⟩ / ⟨|Ψ(t)|²⟩
    pub fn validate(operator: &KNOOperator, primes: &[u64], delta_t: f64) -> LayerValidationResult {
        let mut result = LayerValidationResult::new("Layer 3: Spectral Coherence".to_string());

        let psi_t = operator.phase_field.psi;
        let t_plus_dt = operator.phase_field.time + delta_t;

        // Evaluate Ψ(t+Δt)
        let mut psi_t_dt = Complex::zero();
        for &p in primes {
            let p_f64 = p as f64;
            let amplitude = 1.0 / p_f64.sqrt();
            let phase = t_plus_dt * p_f64.ln();
            psi_t_dt = psi_t_dt.add(&Complex::new(
                amplitude * phase.cos(),
                amplitude * phase.sin(),
            ));
        }

        // Compute ⟨Ψ(t)Ψ*(t+Δt)⟩
        let psi_t_dt_star = psi_t_dt.conjugate();
        let inner = psi_t.mul(&psi_t_dt_star);

        // Compute ⟨|Ψ(t)|²⟩
        let norm_sq = psi_t.magnitude() * psi_t.magnitude();

        // Correlation coefficient
        let correlation = if norm_sq > 1e-12 {
            inner.magnitude() / norm_sq
        } else {
            0.0
        };

        result = result.with_detail("correlation".to_string(), correlation);
        result = result.with_detail("psi_magnitude".to_string(), psi_t.magnitude());
        result = result.with_detail("delta_t".to_string(), delta_t);

        if correlation > COHERENCE_THRESHOLD {
            result.passed(correlation, COHERENCE_THRESHOLD)
        } else {
            result.failed(
                correlation,
                COHERENCE_THRESHOLD,
                format!("Spectral incoherence: ρ = {:.6} < {:.6}", correlation, COHERENCE_THRESHOLD),
            )
        }
    }
}

/// Layer 4: Topological Integrity Check
/// Verify Berry phase ≈ 2π and Chern number ≈ 1
pub struct TopologicalIntegrityValidator;

impl TopologicalIntegrityValidator {
    pub fn validate(operator: &KNOOperator, berry_phase: f64) -> LayerValidationResult {
        let mut result = LayerValidationResult::new("Layer 4: Topological Integrity".to_string());

        // Check Berry phase
        let berry_error = (berry_phase - BERRY_PHASE_TARGET).abs();
        let berry_ok = berry_error < BERRY_PHASE_TOLERANCE;

        result = result.with_detail("berry_phase".to_string(), berry_phase);
        result = result.with_detail("berry_phase_target".to_string(), BERRY_PHASE_TARGET);
        result = result.with_detail("berry_phase_error".to_string(), berry_error);

        // Check Chern number
        let chern_ok = if let Some(chern) = operator.chern_number {
            let chern_error = (chern - CHERN_NUMBER_TARGET).abs();
            result = result.with_detail("chern_number".to_string(), chern);
            result = result.with_detail("chern_number_target".to_string(), CHERN_NUMBER_TARGET);
            result = result.with_detail("chern_number_error".to_string(), chern_error);

            chern_error < CHERN_NUMBER_TOLERANCE
        } else {
            result = result.with_detail("chern_number".to_string(), f64::NAN);
            false
        };

        let overall_ok = berry_ok && chern_ok;
        let combined_metric = if berry_ok && chern_ok {
            1.0
        } else if berry_ok || chern_ok {
            0.5
        } else {
            0.0
        };

        if overall_ok {
            result.passed(combined_metric, 1.0)
        } else {
            let mut errors = Vec::new();
            if !berry_ok {
                errors.push(format!("|BerryPhase - 2π| = {:.6} > {:.6}", berry_error, BERRY_PHASE_TOLERANCE));
            }
            if !chern_ok {
                errors.push("Chern number not computed or out of tolerance".to_string());
            }

            result.failed(
                combined_metric,
                1.0,
                format!("Topological violation: {}", errors.join("; ")),
            )
        }
    }
}

/// Layer 5: Divergence Detection
/// Ensure bounded amplitude over evolution period
pub struct DivergenceDetector;

impl DivergenceDetector {
    pub fn validate(amplitude_history: &[f64]) -> LayerValidationResult {
        let mut result = LayerValidationResult::new("Layer 5: Divergence Detection".to_string());

        if amplitude_history.is_empty() {
            return result.failed(
                0.0,
                AMPLITUDE_BOUND,
                "No amplitude history provided".to_string(),
            );
        }

        let max_amplitude = amplitude_history
            .iter()
            .copied()
            .fold(f64::NEG_INFINITY, f64::max);

        let mean_amplitude = amplitude_history.iter().sum::<f64>() / amplitude_history.len() as f64;

        result = result.with_detail("max_amplitude".to_string(), max_amplitude);
        result = result.with_detail("mean_amplitude".to_string(), mean_amplitude);
        result = result.with_detail("samples".to_string(), amplitude_history.len() as f64);

        if max_amplitude < AMPLITUDE_BOUND {
            result.passed(max_amplitude, AMPLITUDE_BOUND)
        } else {
            result.failed(
                max_amplitude,
                AMPLITUDE_BOUND,
                format!("Amplitude overflow: |Ψ(t)| = {:.2e} > {:.2e}", max_amplitude, AMPLITUDE_BOUND),
            )
        }
    }
}

/// Comprehensive validation system
pub struct KNOValidationSystem {
    pub operator: KNOOperator,
    pub primes: Vec<u64>,
    pub amplitude_history: Vec<f64>,
    pub berry_phase: Option<f64>,
}

impl KNOValidationSystem {
    pub fn new(operator: KNOOperator, primes: Vec<u64>) -> Self {
        Self {
            operator,
            primes,
            amplitude_history: Vec::new(),
            berry_phase: None,
        }
    }

    /// Record amplitude for divergence detection
    pub fn record_amplitude(&mut self) {
        let amplitude = self.operator.phase_field.psi.magnitude();
        self.amplitude_history.push(amplitude);
    }

    /// Set Berry phase from external computation
    pub fn set_berry_phase(&mut self, berry_phase: f64) {
        self.berry_phase = Some(berry_phase);
    }

    /// Run all 5 validation layers
    pub fn validate_all(&self) -> ValidationReport {
        let mut report = ValidationReport::new(self.operator.id.to_string());

        // Layer 1: Hermitianity
        let layer1 = HermitianityValidator::validate(&self.operator, &self.primes);
        report.add_layer_result(layer1);

        // Layer 2: Stability
        let layer2 = StabilityValidator::validate(&self.operator);
        report.add_layer_result(layer2);

        // Layer 3: Spectral Coherence
        let layer3 = SpectralCoherenceValidator::validate(&self.operator, &self.primes, 0.1);
        report.add_layer_result(layer3);

        // Layer 4: Topological Integrity
        if let Some(berry_phase) = self.berry_phase {
            let layer4 = TopologicalIntegrityValidator::validate(&self.operator, berry_phase);
            report.add_layer_result(layer4);
        } else {
            let mut layer4 = LayerValidationResult::new("Layer 4: Topological Integrity".to_string());
            layer4 = layer4.failed(0.0, 1.0, "Berry phase not computed".to_string());
            report.add_layer_result(layer4);
        }

        // Layer 5: Divergence Detection
        let layer5 = DivergenceDetector::validate(&self.amplitude_history);
        report.add_layer_result(layer5);

        report.finalize();
        report
    }

    /// Run validation and save report
    pub fn validate_and_save(&self, output_path: &str) -> std::io::Result<ValidationReport> {
        let report = self.validate_all();

        let json = serde_json::to_string_pretty(&report)?;
        std::fs::write(output_path, json)?;

        Ok(report)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_hermitianity_validator() {
        let zeros = vec![14.134725, 21.022040, 25.010858];
        let mut operator = KNOOperator::new(zeros, 1.0);
        let primes = vec![2, 3, 5, 7, 11, 13, 17, 19, 23, 29];

        operator.evolve(0.1, &primes);

        let result = HermitianityValidator::validate(&operator, &primes);
        println!("Hermitianity: passed={}, metric={:.2e}", result.passed, result.metric_value);
        assert!(result.metric_value < HERMITIAN_TOLERANCE);
    }

    #[test]
    fn test_stability_validator() {
        let zeros = vec![14.134725, 21.022040, 25.010858];
        let operator = KNOOperator::new(zeros, 1.0);

        let result = StabilityValidator::validate(&operator);
        println!("Stability: passed={}, ratio={:.3}", result.passed, result.metric_value);
        assert!(result.passed);
    }

    #[test]
    fn test_spectral_coherence() {
        let zeros = vec![14.134725, 21.022040, 25.010858];
        let mut operator = KNOOperator::new(zeros, 1.0);
        let primes = vec![2, 3, 5, 7, 11, 13, 17, 19, 23, 29];

        operator.evolve(0.1, &primes);

        let result = SpectralCoherenceValidator::validate(&operator, &primes, 0.01);
        println!("Coherence: passed={}, ρ={:.6}", result.passed, result.metric_value);
        assert!(result.metric_value > COHERENCE_THRESHOLD);
    }

    #[test]
    fn test_divergence_detector() {
        let amplitudes = vec![1.0, 1.1, 1.05, 1.15, 1.08, 1.12];

        let result = DivergenceDetector::validate(&amplitudes);
        println!("Divergence: passed={}, max={:.3}", result.passed, result.metric_value);
        assert!(result.passed);
    }

    #[test]
    fn test_full_validation_system() {
        let zeros = vec![14.134725, 21.022040, 25.010858];
        let operator = KNOOperator::new(zeros, 1.0);
        let primes = vec![2, 3, 5, 7, 11, 13, 17, 19, 23, 29];

        let mut system = KNOValidationSystem::new(operator, primes);

        // Simulate evolution and record amplitudes
        for _ in 0..10 {
            system.operator.evolve(0.1, &system.primes);
            system.record_amplitude();
        }

        // Set berry phase (simulated)
        system.set_berry_phase(6.28);

        let report = system.validate_all();
        println!("Overall validation: {}", report.overall_passed);
        println!("Layers passed: {}/{}",
            report.layer_results.iter().filter(|r| r.passed).count(),
            report.layer_results.len());

        for result in &report.layer_results {
            println!("  {}: {}", result.layer_name, if result.passed { "✓" } else { "✗" });
        }
    }
}
