//! # Metatronic Operator Genesis Engine (MOGE)
//!
//! A holistic system for emergent operator mining and resonance-based recursion.
//!
//! ## Architecture
//!
//! MOGE is built on the topological structure of the Metatron Cube, enabling:
//! - Signature-driven operator navigation
//! - Topological recursion in permutation space
//! - Resonance-based feedback and evolution
//!
//! ## Core Modules
//!
//! - `signature`: Signature space and operator structure (ψ, ρ, ω vectors)
//! - `artefact`: Artefact instances with blueprint history
//! - `graph`: MetatronCube graph structure (5040-node S7 permutation topology)
//! - `agent`: Traversal agents with heuristics and decision feedback
//! - `kernel`: Resonance Invariant Kernel (RIK) for invariant checking
//! - `ledger`: Artefact storage, archiving, and replay system
//! - `traversal`: Core traversal API and operator mining layer
//! - `simulation`: Simulation and evolution engine
//!
//! ## Usage Example
//!
//! ```rust,no_run
//! use genesis_engine::{graph::MetatronCube, agent::Agent, signature::Signature};
//!
//! // Initialize the Metatron Cube graph
//! let cube = MetatronCube::new();
//!
//! // Create an agent with default heuristics
//! let mut agent = Agent::new(cube.seed_node());
//!
//! // Traverse and mine operators
//! // let artefact = agent.traverse(&cube);
//! ```

pub mod signature;
pub mod artefact;
pub mod graph;
pub mod agent;
pub mod kernel;
pub mod ledger;
pub mod traversal;
pub mod simulation;
pub mod error;
pub mod export;
pub mod plugin;
pub mod distributed;
pub mod quantum;
pub mod wasm;

// IMHK Foundation Modules
pub mod operator;
pub mod semantic;
pub mod resonance_kernel;
pub mod gabriel_cells;
pub mod consensus;
pub mod imhk;
pub mod verification;
pub mod reporting;

// Reasonate Kernel Modules
pub mod resonance_dynamics;
pub mod operator_primitives;
pub mod topology_projection;
pub mod traversal_graph;
pub mod evolution_cycle;
pub mod recursive_optimizer;

// Invariant Crystal Architecture
pub mod invariant_crystal;
pub mod hybrid_kernel;
pub mod web_api;

// MOGE Unified Matrix - Metatron Operator Cosmos
pub mod metatron_topology;
pub mod cosmic_manifest;
pub mod proof_of_resonance;
pub mod operator_lexicon_api;
pub mod moge_unified_matrix;

// Cubechain - Hypercube-DAG Ledger Architecture
pub mod cubechain;

// Metatron Meta-Cognition Layer (Ω.∞)
pub mod meta_cognition;

// Auto-Evolution Daemon with Meta-Cognition Integration
pub mod auto_evolution_daemon;

// Resonant Language Projection Layer and Associated Systems
pub mod resonant_language_projection;
pub mod rule_matrix;
pub mod operator_export_grammar;
pub mod operator_reconstruction;
pub mod operator_validation;
pub mod metatron_resonance_pipeline;

// Meta Pipeline Execution, Zero State Boot Genesis, and ScorpioSync Integration
pub mod meta_pipeline_execution;
pub mod zero_state_boot_genesis;
pub mod scorpio_sync_integration;

// Spectral Genesis Protocol Suite
pub mod spectral_genesis_calibration;
pub mod spectral_autogenesis_layer;
pub mod spectral_reflection_audit;
pub mod spectral_genesis_unified;

// Infogenetic Resonant Genesis Core (IRG_Core)
pub mod irg_core;
pub mod irg_integration;

// Cyclic Conversion Operator Model (KNO/DK Framework)
pub mod kno_framework;
pub mod kno_core;
pub mod kno_potential;
pub mod kno_simulation;
pub mod kno_archival;
pub mod kno_validation;

// Re-export commonly used types
pub use signature::{Signature, Signature3D, Signature5D};
pub use artefact::Artefact;
pub use graph::MetatronCube;
pub use agent::Agent;
pub use kernel::ResonanceKernel;
pub use ledger::Ledger;
pub use error::{Result, MogeError};
pub use irg_core::{IRGCore, SpectralSignature, CelestialResonanceImpulse, CyberneticControl};
pub use kno_framework::{
    DoubleKickOperator, NullpunktOperator, HermitianOperator, WaveFunction,
    KNOOperator, PhaseField, PolynomialPotential, BerryConnection, Complex
};
pub use kno_core::{KNOMiningCore, MiningConfig, EvaluationReport};
pub use kno_simulation::{KNOSimulation, SimulationConfig};
pub use kno_archival::{KNOArchivalSystem, OperatorLedger};

/// MOGE version and metadata
pub const VERSION: &str = env!("CARGO_PKG_VERSION");
pub const SYSTEM_NAME: &str = "Metatronic Operator Genesis Engine";
pub const CUBE_NODES: usize = 5040; // |S7| = 7! permutations

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_system_metadata() {
        assert_eq!(CUBE_NODES, 5040);
        assert!(!VERSION.is_empty());
    }
}
