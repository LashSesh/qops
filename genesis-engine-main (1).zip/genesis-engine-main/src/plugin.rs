//! Plugin System Module
//!
//! Provides a flexible plugin system for extending MOGE functionality:
//! - Custom traversal strategies
//! - Custom signature evaluation functions
//! - Post-processing hooks
//! - Event listeners

use crate::artefact::Artefact;
use crate::signature::Signature5D;
use crate::agent::Agent;
use crate::error::{Result, MogeError};
use std::collections::HashMap;

/// Plugin trait for custom behavior
pub trait Plugin: Send + Sync {
    /// Plugin name
    fn name(&self) -> &str;

    /// Plugin version
    fn version(&self) -> &str;

    /// Initialize the plugin
    fn initialize(&mut self) -> Result<()> {
        Ok(())
    }

    /// Called before traversal starts
    fn on_traversal_start(&mut self, _agent: &Agent) -> Result<()> {
        Ok(())
    }

    /// Called after each step
    fn on_step(&mut self, _agent: &Agent, _current_node: usize) -> Result<()> {
        Ok(())
    }

    /// Called when an artefact is created
    fn on_artefact_created(&mut self, _artefact: &Artefact) -> Result<()> {
        Ok(())
    }

    /// Called after traversal completes
    fn on_traversal_complete(&mut self, _artefact: &Artefact) -> Result<()> {
        Ok(())
    }

    /// Custom signature evaluation
    fn evaluate_signature(&self, _signature: &Signature5D) -> Option<f64> {
        None
    }
}

/// Plugin manager
pub struct PluginManager {
    plugins: HashMap<String, Box<dyn Plugin>>,
    enabled: bool,
}

impl PluginManager {
    /// Create a new plugin manager
    pub fn new() -> Self {
        Self {
            plugins: HashMap::new(),
            enabled: true,
        }
    }

    /// Register a plugin
    pub fn register(&mut self, plugin: Box<dyn Plugin>) -> Result<()> {
        let name = plugin.name().to_string();
        if self.plugins.contains_key(&name) {
            return Err(MogeError::InvalidArtefact(format!(
                "Plugin '{}' already registered",
                name
            )));
        }
        self.plugins.insert(name, plugin);
        Ok(())
    }

    /// Unregister a plugin
    pub fn unregister(&mut self, name: &str) -> Result<()> {
        self.plugins.remove(name).ok_or_else(|| {
            MogeError::InvalidArtefact(format!("Plugin '{}' not found", name))
        })?;
        Ok(())
    }

    /// Get a plugin by name
    pub fn get(&self, name: &str) -> Option<&dyn Plugin> {
        self.plugins.get(name).map(|p| p.as_ref())
    }

    /// Initialize all plugins
    pub fn initialize_all(&mut self) -> Result<()> {
        for plugin in self.plugins.values_mut() {
            plugin.initialize()?;
        }
        Ok(())
    }

    /// Trigger on_traversal_start for all plugins
    pub fn on_traversal_start(&mut self, agent: &Agent) -> Result<()> {
        if !self.enabled {
            return Ok(());
        }
        for plugin in self.plugins.values_mut() {
            plugin.on_traversal_start(agent)?;
        }
        Ok(())
    }

    /// Trigger on_step for all plugins
    pub fn on_step(&mut self, agent: &Agent, current_node: usize) -> Result<()> {
        if !self.enabled {
            return Ok(());
        }
        for plugin in self.plugins.values_mut() {
            plugin.on_step(agent, current_node)?;
        }
        Ok(())
    }

    /// Trigger on_artefact_created for all plugins
    pub fn on_artefact_created(&mut self, artefact: &Artefact) -> Result<()> {
        if !self.enabled {
            return Ok(());
        }
        for plugin in self.plugins.values_mut() {
            plugin.on_artefact_created(artefact)?;
        }
        Ok(())
    }

    /// Trigger on_traversal_complete for all plugins
    pub fn on_traversal_complete(&mut self, artefact: &Artefact) -> Result<()> {
        if !self.enabled {
            return Ok(());
        }
        for plugin in self.plugins.values_mut() {
            plugin.on_traversal_complete(artefact)?;
        }
        Ok(())
    }

    /// Enable or disable all plugins
    pub fn set_enabled(&mut self, enabled: bool) {
        self.enabled = enabled;
    }

    /// Get list of registered plugin names
    pub fn list_plugins(&self) -> Vec<String> {
        self.plugins.keys().cloned().collect()
    }

    /// Get number of registered plugins
    pub fn count(&self) -> usize {
        self.plugins.len()
    }
}

impl Default for PluginManager {
    fn default() -> Self {
        Self::new()
    }
}

/// Example: Statistics collection plugin
pub struct StatisticsPlugin {
    name: String,
    version: String,
    total_steps: usize,
    total_artefacts: usize,
    avg_resonance: f64,
}

impl StatisticsPlugin {
    pub fn new() -> Self {
        Self {
            name: "statistics".to_string(),
            version: "0.1.0".to_string(),
            total_steps: 0,
            total_artefacts: 0,
            avg_resonance: 0.0,
        }
    }

    pub fn get_statistics(&self) -> (usize, usize, f64) {
        (self.total_steps, self.total_artefacts, self.avg_resonance)
    }
}

impl Plugin for StatisticsPlugin {
    fn name(&self) -> &str {
        &self.name
    }

    fn version(&self) -> &str {
        &self.version
    }

    fn on_step(&mut self, _agent: &Agent, _current_node: usize) -> Result<()> {
        self.total_steps += 1;
        Ok(())
    }

    fn on_artefact_created(&mut self, artefact: &Artefact) -> Result<()> {
        self.total_artefacts += 1;
        let prev_total = self.avg_resonance * (self.total_artefacts - 1) as f64;
        self.avg_resonance = (prev_total + artefact.resonance()) / self.total_artefacts as f64;
        Ok(())
    }
}

impl Default for StatisticsPlugin {
    fn default() -> Self {
        Self::new()
    }
}

/// Example: Logging plugin
pub struct LoggingPlugin {
    name: String,
    version: String,
    verbose: bool,
    log_buffer: Vec<String>,
}

impl LoggingPlugin {
    pub fn new(verbose: bool) -> Self {
        Self {
            name: "logging".to_string(),
            version: "0.1.0".to_string(),
            verbose,
            log_buffer: Vec::new(),
        }
    }

    pub fn get_logs(&self) -> &[String] {
        &self.log_buffer
    }

    pub fn clear_logs(&mut self) {
        self.log_buffer.clear();
    }
}

impl Plugin for LoggingPlugin {
    fn name(&self) -> &str {
        &self.name
    }

    fn version(&self) -> &str {
        &self.version
    }

    fn on_traversal_start(&mut self, agent: &Agent) -> Result<()> {
        if self.verbose {
            self.log_buffer.push(format!(
                "Traversal started at node {:?}",
                agent.current_node()
            ));
        }
        Ok(())
    }

    fn on_artefact_created(&mut self, artefact: &Artefact) -> Result<()> {
        self.log_buffer.push(format!(
            "Artefact created: {} (resonance: {:.4})",
            artefact.id,
            artefact.resonance()
        ));
        Ok(())
    }
}

/// Example: Custom resonance evaluation plugin
pub struct CustomResonancePlugin {
    name: String,
    version: String,
    weights: [f64; 5],
}

impl CustomResonancePlugin {
    pub fn new(weights: [f64; 5]) -> Self {
        Self {
            name: "custom_resonance".to_string(),
            version: "0.1.0".to_string(),
            weights,
        }
    }
}

impl Plugin for CustomResonancePlugin {
    fn name(&self) -> &str {
        &self.name
    }

    fn version(&self) -> &str {
        &self.version
    }

    fn evaluate_signature(&self, signature: &Signature5D) -> Option<f64> {
        Some(
            self.weights[0] * signature.psi +
            self.weights[1] * signature.rho +
            self.weights[2] * signature.omega +
            self.weights[3] * signature.chi +
            self.weights[4] * signature.eta
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::signature::Signature5D;

    #[test]
    fn test_plugin_manager() {
        let mut manager = PluginManager::new();
        assert_eq!(manager.count(), 0);

        let plugin = Box::new(StatisticsPlugin::new());
        manager.register(plugin).unwrap();

        assert_eq!(manager.count(), 1);
        assert!(manager.get("statistics").is_some());
    }

    #[test]
    fn test_statistics_plugin() {
        let mut plugin = StatisticsPlugin::new();
        assert_eq!(plugin.name(), "statistics");

        let sig = Signature5D::new(0.8, 0.7, 0.6, 0.5, 0.4);
        let mut artefact = Artefact::new(0, sig);
        artefact.stability = 0.75;
        artefact.is_mandorla_certified = false;
        
        // Add blueprint entries
        artefact.record_transformation(0, 1, "step1".to_string(), sig);
        artefact.record_transformation(1, 2, "step2".to_string(), sig);

        plugin.on_artefact_created(&artefact).unwrap();

        let (_, count, _) = plugin.get_statistics();
        assert_eq!(count, 1);
    }

    #[test]
    fn test_logging_plugin() {
        let mut plugin = LoggingPlugin::new(true);
        assert_eq!(plugin.name(), "logging");

        let sig = Signature5D::new(0.8, 0.7, 0.6, 0.5, 0.4);
        let mut artefact = Artefact::new(0, sig);
        artefact.stability = 0.75;
        artefact.is_mandorla_certified = false;
        
        // Add blueprint entries
        artefact.record_transformation(0, 1, "step1".to_string(), sig);
        artefact.record_transformation(1, 2, "step2".to_string(), sig);

        plugin.on_artefact_created(&artefact).unwrap();

        assert_eq!(plugin.get_logs().len(), 1);
    }

    #[test]
    fn test_custom_resonance_plugin() {
        let weights = [0.2, 0.2, 0.2, 0.2, 0.2];
        let plugin = CustomResonancePlugin::new(weights);

        let sig = Signature5D::new(1.0, 1.0, 1.0, 1.0, 1.0);
        let resonance = plugin.evaluate_signature(&sig);

        assert!(resonance.is_some());
        assert!((resonance.unwrap() - 1.0).abs() < 1e-6);
    }

    #[test]
    fn test_plugin_manager_disable() {
        let mut manager = PluginManager::new();
        let plugin = Box::new(StatisticsPlugin::new());
        manager.register(plugin).unwrap();

        manager.set_enabled(false);

        let sig = Signature5D::new(0.8, 0.7, 0.6, 0.5, 0.4);
        let mut artefact = Artefact::new(0, sig);
        artefact.stability = 0.75;
        artefact.is_mandorla_certified = false;
        
        // Add blueprint entries
        artefact.record_transformation(0, 1, "step1".to_string(), sig);
        artefact.record_transformation(1, 2, "step2".to_string(), sig);

        // Should not trigger when disabled
        manager.on_artefact_created(&artefact).unwrap();
    }
}
