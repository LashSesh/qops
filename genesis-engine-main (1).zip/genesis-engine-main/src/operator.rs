//! Operator Layer - IMHK Foundation
//!
//! Core operator structures for the IUL-Metatron Hybrid Kernel.
//! Operators are fundamental computational units with 5D signatures.

use crate::signature::Signature5D;
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

/// Operator state enumeration
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum OperatorState {
    /// Initial state, not yet evaluated
    Dormant,
    /// Currently being evaluated
    Active,
    /// Passed resonance validation
    Validated,
    /// Failed validation
    Rejected,
    /// Committed to ledger
    Committed,
    /// In feedback cycle
    Mutating,
}

/// Core operator structure
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Operator {
    /// Unique operator identifier
    pub id: Uuid,
    /// 5D signature (ψ, ρ, ω, χ, η)
    pub signature: Signature5D,
    /// Current operational state
    pub state: OperatorState,
    /// Generation number
    pub generation: usize,
    /// Parent operator ID (if mutated)
    pub parent: Option<Uuid>,
    /// Mutation history depth
    pub depth: usize,
    /// Resonance score
    pub resonance_score: f64,
}

impl Operator {
    /// Create a new operator with random signature
    pub fn new() -> Self {
        use rand::Rng;
        let mut rng = rand::thread_rng();

        let signature = Signature5D::new(
            rng.gen_range(0.0..1.0),
            rng.gen_range(0.0..1.0),
            rng.gen_range(0.0..1.0),
            rng.gen_range(0.0..1.0),
            rng.gen_range(0.0..1.0),
        );

        Self {
            id: Uuid::new_v4(),
            signature,
            state: OperatorState::Dormant,
            generation: 0,
            parent: None,
            depth: 0,
            resonance_score: 0.0,
        }
    }

    /// Create operator from signature
    pub fn from_signature(signature: Signature5D) -> Self {
        Self {
            id: Uuid::new_v4(),
            signature,
            state: OperatorState::Dormant,
            generation: 0,
            parent: None,
            depth: 0,
            resonance_score: 0.0,
        }
    }

    /// Activate the operator
    pub fn activate(&mut self) {
        self.state = OperatorState::Active;
    }

    /// Mark as validated
    pub fn validate(&mut self, score: f64) {
        self.state = OperatorState::Validated;
        self.resonance_score = score;
    }

    /// Mark as rejected
    pub fn reject(&mut self) {
        self.state = OperatorState::Rejected;
    }

    /// Commit to ledger
    pub fn commit(&mut self) {
        if self.state == OperatorState::Validated {
            self.state = OperatorState::Committed;
        }
    }

    /// Check if operator is stable (validated or committed)
    pub fn is_stable(&self) -> bool {
        matches!(self.state, OperatorState::Validated | OperatorState::Committed)
    }
}

impl Default for Operator {
    fn default() -> Self {
        Self::new()
    }
}

/// Evaluate operator signature and compute resonance
pub fn evaluate_signature(op: &Operator) -> Signature5D {
    // Return the operator's current signature
    // This can be extended with transformations
    op.signature
}

/// Mutate operator through controlled perturbation
pub fn mutate_operator(op: &mut Operator, mutation_strength: f64) {
    use rand::Rng;
    let mut rng = rand::thread_rng();

    op.state = OperatorState::Mutating;
    op.parent = Some(op.id);
    op.id = Uuid::new_v4();
    op.depth += 1;
    op.generation += 1;

    // Perturb each signature component
    let delta = mutation_strength;

    op.signature.psi += rng.gen_range(-delta..delta);
    op.signature.rho += rng.gen_range(-delta..delta);
    op.signature.omega += rng.gen_range(-delta..delta);
    op.signature.chi += rng.gen_range(-delta..delta);
    op.signature.eta += rng.gen_range(-delta..delta);

    // Clamp to valid range [0, 1]
    op.signature.psi = op.signature.psi.clamp(0.0, 1.0);
    op.signature.rho = op.signature.rho.clamp(0.0, 1.0);
    op.signature.omega = op.signature.omega.clamp(0.0, 1.0);
    op.signature.chi = op.signature.chi.clamp(0.0, 1.0);
    op.signature.eta = op.signature.eta.clamp(0.0, 1.0);

    op.state = OperatorState::Dormant;
}

/// Create offspring operator through crossover
pub fn crossover_operators(op1: &Operator, op2: &Operator, blend: f64) -> Operator {
    let blend = blend.clamp(0.0, 1.0);

    let signature = Signature5D::new(
        op1.signature.psi * blend + op2.signature.psi * (1.0 - blend),
        op1.signature.rho * blend + op2.signature.rho * (1.0 - blend),
        op1.signature.omega * blend + op2.signature.omega * (1.0 - blend),
        op1.signature.chi * blend + op2.signature.chi * (1.0 - blend),
        op1.signature.eta * blend + op2.signature.eta * (1.0 - blend),
    );

    Operator {
        id: Uuid::new_v4(),
        signature,
        state: OperatorState::Dormant,
        generation: op1.generation.max(op2.generation) + 1,
        parent: Some(op1.id),
        depth: op1.depth.max(op2.depth) + 1,
        resonance_score: 0.0,
    }
}

/// Operator pool for managing collections
#[derive(Debug, Default)]
pub struct OperatorPool {
    operators: Vec<Operator>,
    max_size: usize,
}

impl OperatorPool {
    /// Create new operator pool
    pub fn new(max_size: usize) -> Self {
        Self {
            operators: Vec::new(),
            max_size,
        }
    }

    /// Add operator to pool
    pub fn add(&mut self, op: Operator) -> Result<()> {
        if self.operators.len() >= self.max_size {
            return Err(MogeError::InvalidArtefact("Pool full".to_string()));
        }
        self.operators.push(op);
        Ok(())
    }

    /// Get operator by ID
    pub fn get(&self, id: &Uuid) -> Option<&Operator> {
        self.operators.iter().find(|op| op.id == *id)
    }

    /// Get mutable operator by ID
    pub fn get_mut(&mut self, id: &Uuid) -> Option<&mut Operator> {
        self.operators.iter_mut().find(|op| op.id == *id)
    }

    /// Get all stable operators
    pub fn get_stable(&self) -> Vec<&Operator> {
        self.operators.iter().filter(|op| op.is_stable()).collect()
    }

    /// Get operators by state
    pub fn get_by_state(&self, state: OperatorState) -> Vec<&Operator> {
        self.operators.iter().filter(|op| op.state == state).collect()
    }

    /// Remove operator
    pub fn remove(&mut self, id: &Uuid) -> Option<Operator> {
        if let Some(pos) = self.operators.iter().position(|op| op.id == *id) {
            Some(self.operators.remove(pos))
        } else {
            None
        }
    }

    /// Get pool size
    pub fn size(&self) -> usize {
        self.operators.len()
    }

    /// Clear pool
    pub fn clear(&mut self) {
        self.operators.clear();
    }

    /// Get top N operators by resonance score
    pub fn top_n(&self, n: usize) -> Vec<&Operator> {
        let mut sorted: Vec<&Operator> = self.operators.iter().collect();
        sorted.sort_by(|a, b| b.resonance_score.partial_cmp(&a.resonance_score).unwrap());
        sorted.into_iter().take(n).collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_operator_creation() {
        let op = Operator::new();
        assert_eq!(op.state, OperatorState::Dormant);
        assert_eq!(op.generation, 0);
        assert_eq!(op.depth, 0);
    }

    #[test]
    fn test_operator_lifecycle() {
        let mut op = Operator::new();

        op.activate();
        assert_eq!(op.state, OperatorState::Active);

        op.validate(0.85);
        assert_eq!(op.state, OperatorState::Validated);
        assert_eq!(op.resonance_score, 0.85);
        assert!(op.is_stable());

        op.commit();
        assert_eq!(op.state, OperatorState::Committed);
    }

    #[test]
    fn test_operator_mutation() {
        let mut op = Operator::from_signature(Signature5D::new(0.5, 0.5, 0.5, 0.5, 0.5));
        let original_id = op.id;

        mutate_operator(&mut op, 0.1);

        assert_ne!(op.id, original_id);
        assert_eq!(op.parent, Some(original_id));
        assert_eq!(op.depth, 1);
        assert_eq!(op.generation, 1);
    }

    #[test]
    fn test_operator_crossover() {
        let op1 = Operator::from_signature(Signature5D::new(1.0, 0.0, 1.0, 0.0, 1.0));
        let op2 = Operator::from_signature(Signature5D::new(0.0, 1.0, 0.0, 1.0, 0.0));

        let offspring = crossover_operators(&op1, &op2, 0.5);

        assert!((offspring.signature.psi - 0.5).abs() < 1e-6);
        assert!((offspring.signature.rho - 0.5).abs() < 1e-6);
        assert_eq!(offspring.generation, 1);
    }

    #[test]
    fn test_operator_pool() {
        let mut pool = OperatorPool::new(10);

        let op1 = Operator::new();
        let op2 = Operator::new();

        pool.add(op1.clone()).unwrap();
        pool.add(op2.clone()).unwrap();

        assert_eq!(pool.size(), 2);
        assert!(pool.get(&op1.id).is_some());

        let stable = pool.get_stable();
        assert_eq!(stable.len(), 0);
    }
}
