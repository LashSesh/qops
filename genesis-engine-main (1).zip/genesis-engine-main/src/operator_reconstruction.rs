//! Operator Reconstruction and Translation Interface (ORTI)
//!
//! Reconstructs, interprets, and translates exported universal operators into 
//! specific domain representations with preserved invariance and resonance semantics.

use crate::resonant_language_projection::{TIC, Domain, ProjectionTensor};
use crate::operator_export_grammar::OperatorExportPackage;
use crate::signature::Signature5D;
use crate::error::{Result, MogeError};
use serde::{Deserialize, Serialize};
use std::path::Path;
use std::fs;

/// Domain-specific representation formats
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "format")]
pub enum DomainRepresentation {
    /// LaTeX mathematical equation
    Mathematics {
        equation: String,
        variables: Vec<String>,
    },
    /// Control system JSON
    Cybernetics {
        gain: f64,
        phase: f64,
        stability: f64,
    },
    /// 3D geometric representation
    Geometry {
        vertices: Vec<[f64; 3]>,
        edges: Vec<[usize; 2]>,
        curvature: f64,
    },
    /// Logical expression
    Logic {
        expression: String,
        truth_value: bool,
    },
    /// Differential equation
    Physics {
        equation: String,
        energy: f64,
        entropy: f64,
    },
    /// Generative art parameters
    Aesthetic {
        color: [f64; 3],
        tone: f64,
        modulation: f64,
    },
}

/// Translation engine for domain-specific outputs
pub struct TranslationEngine {
    /// Active domain context
    active_domain: Option<Domain>,
}

impl TranslationEngine {
    /// Create a new translation engine
    pub fn new() -> Self {
        Self {
            active_domain: None,
        }
    }
    
    /// Set active domain
    pub fn set_domain(&mut self, domain: Domain) {
        self.active_domain = Some(domain);
    }
    
    /// Translate TIC and projection to domain representation
    pub fn translate(
        &self,
        tic: &TIC,
        projection: &ProjectionTensor,
    ) -> Result<DomainRepresentation> {
        match projection.domain {
            Domain::Mathematics => self.translate_mathematics(tic, projection),
            Domain::Cybernetics => self.translate_cybernetics(tic, projection),
            Domain::Geometry => self.translate_geometry(tic, projection),
            Domain::Logic => self.translate_logic(tic, projection),
            Domain::Physics => self.translate_physics(tic, projection),
        }
    }
    
    /// Translate to mathematical representation
    fn translate_mathematics(&self, tic: &TIC, _proj: &ProjectionTensor) -> Result<DomainRepresentation> {
        let sig = &tic.signature;
        let equation = format!(
            "\\Phi(x) = {:.3}\\psi\\rho - {:.3}\\omega\\beta + {:.3}S^2",
            sig.psi * sig.rho,
            sig.omega * sig.chi,
            sig.eta
        );
        
        Ok(DomainRepresentation::Mathematics {
            equation,
            variables: vec!["ψ".into(), "ρ".into(), "ω".into(), "β".into(), "S".into()],
        })
    }
    
    /// Translate to cybernetics (control system)
    fn translate_cybernetics(&self, tic: &TIC, _proj: &ProjectionTensor) -> Result<DomainRepresentation> {
        let sig = &tic.signature;
        let gain = if sig.chi > 0.0 {
            sig.psi * sig.rho / sig.chi
        } else {
            sig.psi * sig.rho
        };
        
        Ok(DomainRepresentation::Cybernetics {
            gain,
            phase: sig.omega,
            stability: tic.stability,
        })
    }
    
    /// Translate to geometric representation
    fn translate_geometry(&self, tic: &TIC, _proj: &ProjectionTensor) -> Result<DomainRepresentation> {
        let sig = &tic.signature;
        
        // Create simple geometric shape based on signature
        let vertices = vec![
            [sig.psi, sig.rho, sig.omega],
            [sig.chi, sig.eta, tic.stability],
            [tic.phase[0] / std::f64::consts::TAU, tic.phase[1] / std::f64::consts::TAU, tic.phase[2] / std::f64::consts::TAU],
        ];
        
        let edges = vec![[0, 1], [1, 2], [2, 0]];
        let curvature = tic.entropy_gradient;
        
        Ok(DomainRepresentation::Geometry {
            vertices,
            edges,
            curvature,
        })
    }
    
    /// Translate to logical expression
    fn translate_logic(&self, tic: &TIC, _proj: &ProjectionTensor) -> Result<DomainRepresentation> {
        let sig = &tic.signature;
        let expression = if sig.psi > sig.rho {
            format!("(ψ > ρ) ⇒ ω = {:.3}", sig.omega)
        } else {
            format!("(ψ ≤ ρ) ⇒ β = {:.3}", sig.chi)
        };
        
        let truth_value = sig.psi > sig.rho;
        
        Ok(DomainRepresentation::Logic {
            expression,
            truth_value,
        })
    }
    
    /// Translate to physics (differential equation)
    fn translate_physics(&self, tic: &TIC, _proj: &ProjectionTensor) -> Result<DomainRepresentation> {
        let sig = &tic.signature;
        let energy = sig.psi * sig.psi + sig.rho * sig.rho - sig.omega * sig.omega;
        
        let equation = format!(
            "∂²ψ/∂t² = {:.3} + {:.3} - {:.3}",
            sig.psi * sig.psi,
            sig.rho * sig.rho,
            sig.omega * sig.omega
        );
        
        Ok(DomainRepresentation::Physics {
            equation,
            energy,
            entropy: tic.entropy_gradient,
        })
    }
}

impl Default for TranslationEngine {
    fn default() -> Self {
        Self::new()
    }
}

/// Operator Reconstruction and Translation Interface
pub struct OperatorReconstructionInterface {
    /// Translation engine
    translation_engine: TranslationEngine,
}

impl OperatorReconstructionInterface {
    /// Create a new ORTI instance
    pub fn new() -> Self {
        Self {
            translation_engine: TranslationEngine::new(),
        }
    }
    
    /// Import and verify operator package
    pub fn import_operator(&self, filepath: &str) -> Result<OperatorExportPackage> {
        let path = Path::new(filepath);
        if !path.exists() {
            return Err(MogeError::InvalidArtefact(
                format!("Operator file not found: {}", filepath)
            ));
        }
        
        let content = fs::read_to_string(path)
            .map_err(|e| MogeError::InvalidArtefact(format!("Failed to read file: {}", e)))?;
        
        // Try JSON first
        if let Ok(package) = serde_json::from_str::<OperatorExportPackage>(&content) {
            self.verify_package(&package)?;
            return Ok(package);
        }
        
        // Try TOML
        if let Ok(package) = toml::from_str::<OperatorExportPackage>(&content) {
            self.verify_package(&package)?;
            return Ok(package);
        }
        
        Err(MogeError::InvalidArtefact(
            "Failed to parse operator package (tried JSON and TOML)".to_string()
        ))
    }
    
    /// Verify package integrity
    fn verify_package(&self, package: &OperatorExportPackage) -> Result<()> {
        // Verify semantic coherence
        if package.metadata.semantic_alignment < 0.95 {
            return Err(MogeError::InvalidArtefact(
                format!("Low semantic coherence: {}", package.metadata.semantic_alignment)
            ));
        }
        
        // Verify rule matrix equilibrium
        if package.rule_matrix_state.status != "converged" {
            return Err(MogeError::InvalidArtefact(
                "Rule matrix not converged".to_string()
            ));
        }
        
        // Verify entropy convergence
        if package.resonance_signature.entropy_index > 1e-3 as f32 {
            return Err(MogeError::InvalidArtefact(
                format!("High entropy gradient: {}", package.resonance_signature.entropy_index)
            ));
        }
        
        Ok(())
    }
    
    /// Reconstruct TIC from package
    pub fn reconstruct_tic(&self, package: &OperatorExportPackage) -> Result<TIC> {
        let sig_export = &package.resonance_signature;
        
        let signature = Signature5D::new(
            sig_export.psi,
            sig_export.rho,
            sig_export.omega,
            sig_export.beta,
            sig_export.s,
        );
        
        let timestamp = chrono::DateTime::from_timestamp(package.entity.timestamp, 0)
            .unwrap_or_else(chrono::Utc::now);
        
        Ok(TIC {
            id: package.entity.id,
            signature,
            phase: sig_export.phase_vector,
            entropy_gradient: sig_export.entropy_index as f64,
            stability: sig_export.stability_index as f64,
            timestamp,
            kick_threshold: 0.92,
        })
    }
    
    /// Translate operator to specific domain
    pub fn translate_to_domain(
        &mut self,
        package: &OperatorExportPackage,
        domain: Domain,
    ) -> Result<DomainRepresentation> {
        // Reconstruct TIC
        let tic = self.reconstruct_tic(package)?;
        
        // Find projection for domain
        let projection = package.projective_domains.iter()
            .find(|p| p.domain == domain)
            .ok_or_else(|| MogeError::InvalidArtefact(
                format!("Domain {:?} not found in projections", domain)
            ))?;
        
        // Set active domain and translate
        self.translation_engine.set_domain(domain);
        self.translation_engine.translate(&tic, projection)
    }
    
    /// Translate to all available domains
    pub fn translate_all_domains(
        &mut self,
        package: &OperatorExportPackage,
    ) -> Result<Vec<(Domain, DomainRepresentation)>> {
        let tic = self.reconstruct_tic(package)?;
        
        let mut results = Vec::new();
        for projection in &package.projective_domains {
            let representation = self.translation_engine.translate(&tic, projection)?;
            results.push((projection.domain, representation));
        }
        
        Ok(results)
    }
}

impl Default for OperatorReconstructionInterface {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::operator::Operator;
    use crate::resonant_language_projection::ResonantLanguageProjection;
    use crate::rule_matrix::RuleMatrixState;
    use crate::operator_export_grammar::OperatorExportGrammar;
    
    fn create_test_package() -> OperatorExportPackage {
        let mut rlp = ResonantLanguageProjection::new();
        let op = Operator::new();
        
        let (tic_id, projections, signature) = rlp.process_operator(&op).unwrap();
        let tic = rlp.catalogue().get(&tic_id).unwrap().clone();
        
        let rule_matrix_state = RuleMatrixState {
            matrix_checksum: "test".to_string(),
            delta_r_mean: 0.0001,
            delta_r_variance: 0.0001,
            semantic_coherence_index: 0.96,
            status: "converged".to_string(),
        };
        
        let oeg = OperatorExportGrammar::new("/tmp/test_exports");
        oeg.create_package(&tic, projections, rule_matrix_state, &signature).unwrap()
    }
    
    #[test]
    fn test_translation_engine() {
        let engine = TranslationEngine::new();
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        let proj = ProjectionTensor::new(Domain::Mathematics, &tic);
        
        let result = engine.translate(&tic, &proj);
        assert!(result.is_ok());
    }
    
    #[test]
    fn test_all_domain_translations() {
        let engine = TranslationEngine::new();
        let op = Operator::new();
        let tic = TIC::from_operator(&op, 0.92, 0.001).unwrap();
        
        for domain in Domain::all() {
            let proj = ProjectionTensor::new(domain, &tic);
            let result = engine.translate(&tic, &proj);
            assert!(result.is_ok(), "Failed for domain {:?}", domain);
        }
    }
    
    #[test]
    fn test_reconstruct_tic() {
        let package = create_test_package();
        let orti = OperatorReconstructionInterface::new();
        
        let tic = orti.reconstruct_tic(&package);
        assert!(tic.is_ok());
        
        let tic = tic.unwrap();
        assert_eq!(tic.id, package.entity.id);
    }
    
    #[test]
    fn test_translate_to_domain() {
        let package = create_test_package();
        let mut orti = OperatorReconstructionInterface::new();
        
        let result = orti.translate_to_domain(&package, Domain::Mathematics);
        assert!(result.is_ok());
    }
    
    #[test]
    fn test_translate_all_domains() {
        let package = create_test_package();
        let mut orti = OperatorReconstructionInterface::new();
        
        let results = orti.translate_all_domains(&package);
        assert!(results.is_ok());
        
        let results = results.unwrap();
        assert_eq!(results.len(), 5);
    }
}
