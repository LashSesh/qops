// KNO Operator Archival System
// Records and stores KNO operators, eigenmodes, phase-lock states, and stability logs

use crate::kno_framework::KNOOperator;
use serde::{Deserialize, Serialize};
use std::fs::{self, File};
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use uuid::Uuid;

/// Archived operator state snapshot
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ArchivedOperatorState {
    pub timestamp: String,
    pub operator_id: Uuid,
    pub time: f64,
    pub psi_real: f64,
    pub psi_imag: f64,
    pub phi: f64,
    pub omega: f64,
    pub is_phase_locked: bool,
    pub is_stable: bool,
    pub chern_number: Option<f64>,
    pub berry_connection_components: Vec<f64>,
}

/// Operator eigenmode record
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorEigenmode {
    pub operator_id: Uuid,
    pub mode_index: usize,
    pub eigenvalue: f64,
    pub energy: f64,
    pub stability: f64,
    pub mode_type: String, // "stable", "unstable", "critical"
}

/// Phase-lock event record
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PhaseLockEvent {
    pub timestamp: String,
    pub operator_id: Uuid,
    pub time_locked: f64,
    pub omega_at_lock: f64,
    pub omega_dot_at_lock: f64,
    pub riemann_zero_index: Option<usize>,
    pub distance_to_zero: Option<f64>,
}

/// Stability log entry
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StabilityLogEntry {
    pub timestamp: String,
    pub operator_id: Uuid,
    pub time: f64,
    pub stability_index: f64,
    pub v_second_derivative: f64,
    pub is_stable: bool,
    pub notes: String,
}

/// Operator Ledger - central archive for all KNO operators
#[derive(Debug, Serialize, Deserialize)]
pub struct OperatorLedger {
    /// Archived operator states
    pub states: Vec<ArchivedOperatorState>,
    /// Eigenmode records
    pub eigenmodes: Vec<OperatorEigenmode>,
    /// Phase-lock events
    pub phase_lock_events: Vec<PhaseLockEvent>,
    /// Stability logs
    pub stability_logs: Vec<StabilityLogEntry>,
    /// Metadata
    pub metadata: LedgerMetadata,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct LedgerMetadata {
    pub creation_time: String,
    pub last_updated: String,
    pub total_operators: usize,
    pub total_states: usize,
    pub total_phase_locks: usize,
    pub framework_version: String,
}

impl OperatorLedger {
    /// Create new operator ledger
    pub fn new() -> Self {
        let now = chrono::Utc::now().to_rfc3339();
        Self {
            states: Vec::new(),
            eigenmodes: Vec::new(),
            phase_lock_events: Vec::new(),
            stability_logs: Vec::new(),
            metadata: LedgerMetadata {
                creation_time: now.clone(),
                last_updated: now,
                total_operators: 0,
                total_states: 0,
                total_phase_locks: 0,
                framework_version: "KNO_v1.0".to_string(),
            },
        }
    }

    /// Archive operator state
    pub fn archive_state(&mut self, operator: &KNOOperator) {
        let now = chrono::Utc::now().to_rfc3339();

        let state = ArchivedOperatorState {
            timestamp: now.clone(),
            operator_id: operator.id,
            time: operator.phase_field.time,
            psi_real: operator.phase_field.psi.re,
            psi_imag: operator.phase_field.psi.im,
            phi: operator.phase_field.phi,
            omega: operator.phase_field.omega,
            is_phase_locked: operator.is_phase_locked,
            is_stable: operator.is_stable,
            chern_number: operator.chern_number,
            berry_connection_components: operator.berry_connection.components.clone(),
        };

        self.states.push(state);
        self.metadata.total_states = self.states.len();
        self.metadata.last_updated = now;
    }

    /// Record eigenmode
    pub fn record_eigenmode(&mut self, operator_id: Uuid, mode_index: usize,
                           eigenvalue: f64, energy: f64, stability: f64) {
        let mode_type = if stability > 0.0 {
            "stable"
        } else if stability < 0.0 {
            "unstable"
        } else {
            "critical"
        };

        let eigenmode = OperatorEigenmode {
            operator_id,
            mode_index,
            eigenvalue,
            energy,
            stability,
            mode_type: mode_type.to_string(),
        };

        self.eigenmodes.push(eigenmode);
        self.metadata.last_updated = chrono::Utc::now().to_rfc3339();
    }

    /// Record phase-lock event
    pub fn record_phase_lock(&mut self, operator: &KNOOperator, riemann_zeros: &[f64]) {
        let now = chrono::Utc::now().to_rfc3339();

        // Find nearest Riemann zero
        let mut nearest_index = None;
        let mut min_distance = f64::INFINITY;

        for (i, &zero) in riemann_zeros.iter().enumerate() {
            let distance = (operator.phase_field.omega - zero).abs();
            if distance < min_distance {
                min_distance = distance;
                nearest_index = Some(i);
            }
        }

        let v_pp = operator.potential.second_derivative(operator.phase_field.omega);
        let omega_dot = -v_pp;

        let event = PhaseLockEvent {
            timestamp: now.clone(),
            operator_id: operator.id,
            time_locked: operator.phase_field.time,
            omega_at_lock: operator.phase_field.omega,
            omega_dot_at_lock: omega_dot,
            riemann_zero_index: nearest_index,
            distance_to_zero: if min_distance < f64::INFINITY {
                Some(min_distance)
            } else {
                None
            },
        };

        self.phase_lock_events.push(event);
        self.metadata.total_phase_locks = self.phase_lock_events.len();
        self.metadata.last_updated = now;
    }

    /// Log stability information
    pub fn log_stability(&mut self, operator: &KNOOperator, notes: String) {
        let now = chrono::Utc::now().to_rfc3339();

        let v_pp = operator.potential.second_derivative(operator.phase_field.omega);

        let entry = StabilityLogEntry {
            timestamp: now.clone(),
            operator_id: operator.id,
            time: operator.phase_field.time,
            stability_index: v_pp,
            v_second_derivative: v_pp,
            is_stable: operator.is_stable,
            notes,
        };

        self.stability_logs.push(entry);
        self.metadata.last_updated = now;
    }

    /// Update metadata counts
    pub fn update_metadata(&mut self) {
        let unique_operators: std::collections::HashSet<_> =
            self.states.iter().map(|s| s.operator_id).collect();

        self.metadata.total_operators = unique_operators.len();
        self.metadata.total_states = self.states.len();
        self.metadata.total_phase_locks = self.phase_lock_events.len();
        self.metadata.last_updated = chrono::Utc::now().to_rfc3339();
    }

    /// Save ledger to JSON file
    pub fn save_to_file<P: AsRef<Path>>(&self, path: P) -> io::Result<()> {
        let json = serde_json::to_string_pretty(self)?;
        let mut file = File::create(path)?;
        file.write_all(json.as_bytes())?;
        Ok(())
    }

    /// Load ledger from JSON file
    pub fn load_from_file<P: AsRef<Path>>(path: P) -> io::Result<Self> {
        let contents = fs::read_to_string(path)?;
        let ledger: OperatorLedger = serde_json::from_str(&contents)?;
        Ok(ledger)
    }

    /// Get summary statistics
    pub fn get_summary(&self) -> LedgerSummary {
        let stable_operators = self.states.iter().filter(|s| s.is_stable).count();
        let phase_locked_operators = self.states.iter().filter(|s| s.is_phase_locked).count();

        let avg_chern = if !self.states.is_empty() {
            let sum: f64 = self.states.iter()
                .filter_map(|s| s.chern_number)
                .sum();
            let count = self.states.iter().filter(|s| s.chern_number.is_some()).count();
            if count > 0 { Some(sum / count as f64) } else { None }
        } else {
            None
        };

        LedgerSummary {
            total_operators: self.metadata.total_operators,
            total_states: self.metadata.total_states,
            total_eigenmodes: self.eigenmodes.len(),
            total_phase_locks: self.metadata.total_phase_locks,
            total_stability_logs: self.stability_logs.len(),
            stable_operators,
            phase_locked_operators,
            average_chern_number: avg_chern,
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct LedgerSummary {
    pub total_operators: usize,
    pub total_states: usize,
    pub total_eigenmodes: usize,
    pub total_phase_locks: usize,
    pub total_stability_logs: usize,
    pub stable_operators: usize,
    pub phase_locked_operators: usize,
    pub average_chern_number: Option<f64>,
}

/// Archival manager for KNO system
pub struct KNOArchivalSystem {
    pub ledger: OperatorLedger,
    pub output_directory: PathBuf,
}

impl KNOArchivalSystem {
    /// Create new archival system
    pub fn new<P: AsRef<Path>>(output_directory: P) -> io::Result<Self> {
        let output_dir = output_directory.as_ref().to_path_buf();
        fs::create_dir_all(&output_dir)?;

        Ok(Self {
            ledger: OperatorLedger::new(),
            output_directory: output_dir,
        })
    }

    /// Archive operator with automatic state saving
    pub fn archive_operator(&mut self, operator: &KNOOperator, riemann_zeros: &[f64]) {
        // Archive state
        self.ledger.archive_state(operator);

        // Record phase-lock if applicable
        if operator.is_phase_locked {
            self.ledger.record_phase_lock(operator, riemann_zeros);
        }

        // Log stability
        let notes = format!(
            "Archived at t={:.3}, ω={:.6}, stable={}, locked={}",
            operator.phase_field.time,
            operator.phase_field.omega,
            operator.is_stable,
            operator.is_phase_locked
        );
        self.ledger.log_stability(operator, notes);

        // Update metadata
        self.ledger.update_metadata();
    }

    /// Save current ledger to file
    pub fn save_ledger(&self) -> io::Result<PathBuf> {
        let filename = format!(
            "operator_ledger_{}.json",
            chrono::Utc::now().format("%Y%m%d_%H%M%S")
        );
        let path = self.output_directory.join(filename);
        self.ledger.save_to_file(&path)?;
        Ok(path)
    }

    /// Export summary report
    pub fn export_summary(&self) -> io::Result<PathBuf> {
        let summary = self.ledger.get_summary();
        let filename = format!(
            "operator_summary_{}.json",
            chrono::Utc::now().format("%Y%m%d_%H%M%S")
        );
        let path = self.output_directory.join(filename);

        let json = serde_json::to_string_pretty(&summary)?;
        let mut file = File::create(&path)?;
        file.write_all(json.as_bytes())?;

        Ok(path)
    }

    /// Export markdown report
    pub fn export_markdown_report(&self) -> io::Result<PathBuf> {
        let summary = self.ledger.get_summary();
        let filename = format!(
            "operator_report_{}.md",
            chrono::Utc::now().format("%Y%m%d_%H%M%S")
        );
        let path = self.output_directory.join(filename);

        let mut file = File::create(&path)?;

        writeln!(file, "# KNO Operator Ledger Report")?;
        writeln!(file)?;
        writeln!(file, "**Generated:** {}", chrono::Utc::now().to_rfc3339())?;
        writeln!(file, "**Framework Version:** {}", self.ledger.metadata.framework_version)?;
        writeln!(file)?;

        writeln!(file, "## Summary Statistics")?;
        writeln!(file)?;
        writeln!(file, "| Metric | Count |")?;
        writeln!(file, "|--------|-------|")?;
        writeln!(file, "| Total Operators | {} |", summary.total_operators)?;
        writeln!(file, "| Total States | {} |", summary.total_states)?;
        writeln!(file, "| Total Eigenmodes | {} |", summary.total_eigenmodes)?;
        writeln!(file, "| Phase-Lock Events | {} |", summary.total_phase_locks)?;
        writeln!(file, "| Stability Logs | {} |", summary.total_stability_logs)?;
        writeln!(file, "| Stable Operators | {} |", summary.stable_operators)?;
        writeln!(file, "| Phase-Locked Operators | {} |", summary.phase_locked_operators)?;
        if let Some(avg_chern) = summary.average_chern_number {
            writeln!(file, "| Average Chern Number | {:.6} |", avg_chern)?;
        }
        writeln!(file)?;

        writeln!(file, "## Recent Phase-Lock Events")?;
        writeln!(file)?;
        let recent_locks: Vec<_> = self.ledger.phase_lock_events.iter()
            .rev()
            .take(10)
            .collect();

        if !recent_locks.is_empty() {
            writeln!(file, "| Timestamp | Operator ID | Time | ω | ω̇ | Riemann Zero |")?;
            writeln!(file, "|-----------|-------------|------|---|---|--------------|")?;
            for event in recent_locks {
                let zero_info = if let Some(idx) = event.riemann_zero_index {
                    format!("γ_{} (dist: {:.6})", idx + 1, event.distance_to_zero.unwrap_or(0.0))
                } else {
                    "N/A".to_string()
                };
                writeln!(
                    file,
                    "| {} | {} | {:.3} | {:.6} | {:.2e} | {} |",
                    event.timestamp.split('T').next().unwrap_or(""),
                    event.operator_id.to_string().split('-').next().unwrap_or(""),
                    event.time_locked,
                    event.omega_at_lock,
                    event.omega_dot_at_lock,
                    zero_info
                )?;
            }
        } else {
            writeln!(file, "*No phase-lock events recorded*")?;
        }
        writeln!(file)?;

        writeln!(file, "## Operator Stability Analysis")?;
        writeln!(file)?;
        let stable_count = summary.stable_operators;
        let total_count = summary.total_states;
        let stability_ratio = if total_count > 0 {
            stable_count as f64 / total_count as f64 * 100.0
        } else {
            0.0
        };

        writeln!(file, "**Stability Ratio:** {:.2}% ({}/{})", stability_ratio, stable_count, total_count)?;
        writeln!(file)?;

        Ok(path)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::kno_framework::KNOOperator;

    #[test]
    fn test_ledger_creation() {
        let ledger = OperatorLedger::new();
        assert_eq!(ledger.states.len(), 0);
        assert_eq!(ledger.metadata.framework_version, "KNO_v1.0");
    }

    #[test]
    fn test_archive_state() {
        let mut ledger = OperatorLedger::new();
        let zeros = vec![14.134725, 21.022040];
        let operator = KNOOperator::new(zeros, 1.0);

        ledger.archive_state(&operator);
        assert_eq!(ledger.states.len(), 1);
        assert_eq!(ledger.metadata.total_states, 1);
    }

    #[test]
    fn test_archival_system() {
        let temp_dir = std::env::temp_dir().join("kno_test");
        let mut system = KNOArchivalSystem::new(&temp_dir).unwrap();

        let zeros = vec![14.134725, 21.022040];
        let operator = KNOOperator::new(zeros.clone(), 1.0);

        system.archive_operator(&operator, &zeros);
        assert_eq!(system.ledger.states.len(), 1);

        // Cleanup
        let _ = std::fs::remove_dir_all(temp_dir);
    }

    #[test]
    fn test_summary() {
        let mut ledger = OperatorLedger::new();
        let zeros = vec![14.134725, 21.022040];

        for _ in 0..5 {
            let operator = KNOOperator::new(zeros.clone(), 1.0);
            ledger.archive_state(&operator);
        }

        ledger.update_metadata();
        let summary = ledger.get_summary();

        assert_eq!(summary.total_states, 5);
    }
}
