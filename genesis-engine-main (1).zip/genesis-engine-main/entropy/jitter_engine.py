#!/usr/bin/env python3
"""
Δψ-Jitter Engine - Adaptive Entropy Dynamics
=============================================

Implements ScorpioSync-inspired Δψ-jitter mechanism for controlled
entropy injection and adaptive exploration in the ORIPHIEL evolution loop.

Key features:
- Gaussian noise injection with configurable σ (sigma)
- Sinusoidal modulation with amplitude ε (epsilon)
- Per-operator Δψ perturbation
- Adaptive exploration without destroying stability

Mathematical model:
    Δψ_new = Δψ_old + ε·sin(φ) + N(0, σ²)

where:
    - ε: sinusoidal amplitude (default: 0.05)
    - φ: random phase ∈ [0, 2π]
    - σ: Gaussian noise std deviation (default: 0.03)
"""

import json
import math
import random
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional


class JitterEngine:
    """
    Δψ-Jitter Dynamics Engine

    Applies controlled entropy perturbations to operator ontology,
    enabling adaptive exploration while maintaining system coherence.
    """

    def __init__(
        self,
        ontology_path: str = 'data/operator_ontology.json',
        sigma: float = 0.03,
        epsilon: float = 0.05,
        seed: Optional[int] = None
    ):
        """
        Initialize jitter engine.

        Args:
            ontology_path: Path to operator ontology JSON
            sigma: Gaussian noise standard deviation
            epsilon: Sinusoidal amplitude
            seed: Random seed for reproducibility (optional)
        """
        self.path = Path(ontology_path)
        self.sigma = sigma
        self.epsilon = epsilon

        if seed is not None:
            random.seed(seed)
            np.random.seed(seed)

        # Load ontology
        if self.path.exists():
            with open(self.path, 'r') as f:
                self.ops = json.load(f)
            print(f"⚡ Loaded {len(self.ops)} operators for jitter dynamics")
        else:
            self.ops = []
            print("⚠ Warning: Operator ontology not found, using empty set")

        # Initialize jitter history
        self.jitter_history = []

    def apply_jitter(self, adaptive: bool = False) -> dict:
        """
        Apply Δψ-jitter to all operators in ontology.

        Args:
            adaptive: If True, modulate jitter based on operator stability

        Returns:
            Dictionary with jitter statistics
        """
        if not self.ops:
            print("⚠ No operators to apply jitter to")
            return {'operators_modified': 0}

        print(f"⚡ Applying Δψ-jitter (σ={self.sigma}, ε={self.epsilon})...")

        jitter_stats = {
            'operators_modified': 0,
            'avg_jitter': 0.0,
            'max_jitter': 0.0,
            'min_jitter': float('inf')
        }

        jitter_values = []

        for op in self.ops:
            # Extract current Δψ (or initialize if missing)
            delta_psi = op.get('Δψ') or op.get('delta_psi')
            if delta_psi is None:
                # Initialize from other parameters or random
                delta_psi = random.uniform(-0.1, 0.1)

            # Adaptive modulation based on stability
            if adaptive:
                stability = op.get('stability', 0.5)
                # Reduce jitter for stable operators
                adaptive_sigma = self.sigma * (1.0 - 0.5 * stability)
                adaptive_epsilon = self.epsilon * (1.0 - 0.3 * stability)
            else:
                adaptive_sigma = self.sigma
                adaptive_epsilon = self.epsilon

            # Generate jitter components
            phi = random.uniform(0, 2 * math.pi)  # Random phase
            sinusoidal_jitter = adaptive_epsilon * math.sin(phi)
            gaussian_jitter = np.random.normal(0, adaptive_sigma)

            # Total jitter
            total_jitter = sinusoidal_jitter + gaussian_jitter

            # Apply jitter
            new_delta_psi = delta_psi + total_jitter

            # Update operator
            op['Δψ'] = round(new_delta_psi, 6)
            op['delta_psi'] = round(new_delta_psi, 6)  # Alias for compatibility

            # Record jitter
            jitter_values.append(abs(total_jitter))
            jitter_stats['operators_modified'] += 1

            # Track in history
            self.jitter_history.append({
                'operator_id': op['id'],
                'delta_psi_old': round(delta_psi, 6),
                'delta_psi_new': round(new_delta_psi, 6),
                'jitter': round(total_jitter, 6),
                'sinusoidal': round(sinusoidal_jitter, 6),
                'gaussian': round(gaussian_jitter, 6)
            })

        # Compute statistics
        if jitter_values:
            jitter_stats['avg_jitter'] = round(np.mean(jitter_values), 6)
            jitter_stats['max_jitter'] = round(max(jitter_values), 6)
            jitter_stats['min_jitter'] = round(min(jitter_values), 6)
            jitter_stats['std_jitter'] = round(np.std(jitter_values), 6)

        # Save updated ontology
        with open(self.path, 'w') as f:
            json.dump(self.ops, f, indent=2)

        print(f"  ✓ Modified {jitter_stats['operators_modified']} operators")
        print(f"  ✓ Avg jitter: {jitter_stats['avg_jitter']:.6f}")
        print(f"  ✓ Jitter range: [{jitter_stats['min_jitter']:.6f}, {jitter_stats['max_jitter']:.6f}]")

        return jitter_stats

    def save_jitter_history(self, output_path: Optional[str] = None):
        """
        Save jitter history to JSON file.

        Args:
            output_path: Output path (default: reports/reflexivity/jitter_history.json)
        """
        if output_path is None:
            output_dir = Path('reports/reflexivity')
            output_dir.mkdir(parents=True, exist_ok=True)
            output_path = output_dir / 'jitter_history.json'
        else:
            output_path = Path(output_path)

        with open(output_path, 'w') as f:
            json.dump(self.jitter_history, f, indent=2)

        print(f"💾 Jitter history saved to {output_path}")

    def analyze_jitter_impact(self) -> dict:
        """
        Analyze impact of jitter on operator distribution.

        Returns:
            Dictionary with impact analysis
        """
        if not self.jitter_history:
            return {'error': 'No jitter history available'}

        # Compute delta_psi distribution before/after
        deltas_old = [h['delta_psi_old'] for h in self.jitter_history]
        deltas_new = [h['delta_psi_new'] for h in self.jitter_history]

        analysis = {
            'total_jitters': len(self.jitter_history),
            'delta_psi_old': {
                'mean': round(np.mean(deltas_old), 6),
                'std': round(np.std(deltas_old), 6),
                'min': round(min(deltas_old), 6),
                'max': round(max(deltas_old), 6)
            },
            'delta_psi_new': {
                'mean': round(np.mean(deltas_new), 6),
                'std': round(np.std(deltas_new), 6),
                'min': round(min(deltas_new), 6),
                'max': round(max(deltas_new), 6)
            },
            'entropy_increase': round(np.std(deltas_new) - np.std(deltas_old), 6)
        }

        return analysis


def main():
    """Standalone execution for jitter dynamics."""
    engine = JitterEngine()

    # Apply jitter
    stats = engine.apply_jitter(adaptive=True)

    print()
    print("=" * 80)
    print("Δψ-Jitter Dynamics Complete")
    print("=" * 80)
    print(f"Operators Modified: {stats['operators_modified']}")
    print(f"Average Jitter: {stats['avg_jitter']:.6f}")
    print(f"Jitter Range: [{stats['min_jitter']:.6f}, {stats['max_jitter']:.6f}]")
    print(f"Jitter Std Dev: {stats['std_jitter']:.6f}")
    print("=" * 80)

    # Save history
    engine.save_jitter_history()

    # Analyze impact
    impact = engine.analyze_jitter_impact()
    print()
    print("=" * 80)
    print("Jitter Impact Analysis")
    print("=" * 80)
    print(f"Δψ Mean Shift: {impact['delta_psi_old']['mean']:.6f} → {impact['delta_psi_new']['mean']:.6f}")
    print(f"Δψ Std Change: {impact['delta_psi_old']['std']:.6f} → {impact['delta_psi_new']['std']:.6f}")
    print(f"Entropy Increase: {impact['entropy_increase']:.6f}")
    print("=" * 80)


if __name__ == '__main__':
    main()
