"""
Entropy Module - Adaptive Dynamics and Jitter
==============================================

Provides entropy injection and jitter dynamics for the ORIPHIEL framework.
"""

from .jitter_engine import JitterEngine

__all__ = ['JitterEngine']
