# Metatronic Operator Genesis Engine (MOGE)

![License](https://img.shields.io/badge/license-CC--BY--4.0-blue.svg)
![Rust](https://img.shields.io/badge/rust-1.70+-orange.svg)

A holistic system for emergent operator mining and resonance-based recursion built upon the topological structure of the Metatron Cube.

## Overview

MOGE is a recursive operator mining system that combines:
- **Topological Structure**: Based on the Metatron Cube (S7 permutation group with 5040 nodes)
- **Signature-Driven Navigation**: Operators characterized by multi-dimensional signature vectors
- **Resonance-Based Feedback**: Self-organizing evolution through resonance gradients
- **Mandorla Certification**: Automatic identification of stable operator attractors

## Architecture

```
MOGE
├── Signature Space (σ)
│   ├── ψ (psi): Spectral quality
│   ├── ρ (rho): Dynamic consistency
│   ├── ω (omega): Structural coherence
│   ├── χ (chi): Topological path coherence [5D]
│   └── η (eta): Resonance fluctuation [5D]
│
├── MetatronCube Graph
│   ├── 5040 nodes (S7 permutations)
│   ├── Transformations: transpositions, rotations, reflections
│   └── Signature-based edge weights
│
├── Traversal Agents
│   ├── Gradient Ascent (maximize ψ)
│   ├── Stability Maximization (maximize ω)
│   ├── Cycle Recognition (seek self-similar patterns)
│   ├── Balanced (weighted combination)
│   └── Random (exploratory walk)
│
├── Resonance Invariant Kernel (RIK)
│   ├── Invariance condition: Δv · R ≤ ε
│   ├── Mandorla zone detection
│   └── Adaptive transformation validation
│
└── Ledger
    ├── Persistent artefact storage
    ├── Blueprint compression
    ├── Replay capability
    └── Query by signature properties
```

## Core Concepts

### Artefacts
Nodes in the graph with:
- Unique ID and signature
- Blueprint history (transformation sequence)
- Stability metrics
- Mandorla certification status

### Resonance Kernel
Ensures system coherence by validating that transformations preserve invariance:
```
Δv · R ≤ ε
```
where Δv is the signature change, R is the resonance function, and ε is the coherence threshold.

### Mandorla Zones
Signature regions with stable feedback cycles where operators self-stabilize. Artefacts reaching Mandorla zones are automatically certified and archived.

## Installation

### Standalone Library/CLI

```bash
# Clone the repository
git clone https://github.com/LashSesh/genesis-engine.git
cd genesis-engine

# Build the project
cargo build --release

# Run tests
cargo test

# Install the CLI
cargo install --path .
```

### Full System Deployment (Docker Compose)

For deploying the complete Metatron Operator Cosmos Stack with API and UI:

```bash
# Quick start with Docker Compose
make all
# OR manually:
docker-compose up -d
./genesis_routine.sh

# Access the dashboard
open http://localhost:3000
```

See [DEPLOYMENT.md](DEPLOYMENT.md) for detailed deployment instructions, including Kubernetes deployment.

## Usage

### CLI Interface

```bash
# Quick demo
moge-cli quick

# Run a simulation
moge-cli simulate --agents 10 --steps 50 --gen 10

# Single agent traversal
moge-cli traverse --steps 100 --strategy gradient

# System information
moge-cli info

# Query the ledger
moge-cli ledger --min-resonance 0.8 --mandorla
```

### Library Usage

```rust
use genesis_engine::{
    simulation::{Simulation, SimulationConfig},
    traversal::TraversalEngine,
    agent::{AgentConfig, TraversalStrategy},
};

// Run a simulation
let config = SimulationConfig {
    agent_count: 10,
    max_steps_per_agent: 50,
    generations: 10,
    enable_evolution: true,
    ..Default::default()
};

let mut sim = Simulation::new(config);
let result = sim.run()?;

// Access results
for stats in result.stats_per_generation {
    println!("Generation {}: Avg Resonance = {:.3}",
        stats.generation, stats.avg_resonance);
}
```

### Single Traversal

```rust
use genesis_engine::traversal::TraversalEngine;
use genesis_engine::agent::AgentConfig;

let mut engine = TraversalEngine::new();
let config = AgentConfig::default();

let artefact = engine.run_single(config)?;

println!("Resonance: {:.3}", artefact.resonance());
println!("Path: {:?}", artefact.get_path());
```

## Traversal Strategies

| Strategy | Description | Use Case |
|----------|-------------|----------|
| **Gradient Ascent** | Maximize spectral quality (ψ) | Finding high-quality operators |
| **Stability Maximization** | Maximize structural coherence (ω) | Seeking stable attractors |
| **Cycle Recognition** | Close self-similar paths | Pattern discovery |
| **Balanced** | Weighted combination of all metrics | General exploration |
| **Random** | Uniform random walk | Baseline/exploration |

## API Documentation

Generate and view the API documentation:

```bash
cargo doc --open
```

## Testing

```bash
# Run all tests
cargo test

# Run with output
cargo test -- --nocapture

# Run specific module tests
cargo test signature
cargo test graph
cargo test agent
```

## Benchmarking

```bash
cargo bench
```

## Project Structure

```
genesis-engine/
├── src/
│   ├── lib.rs              # Main library entry point
│   ├── signature.rs        # Signature space (3D/5D vectors)
│   ├── artefact.rs         # Artefact class with blueprint history
│   ├── graph.rs            # MetatronCube graph structure
│   ├── agent.rs            # Traversal agents with heuristics
│   ├── kernel.rs           # Resonance Invariant Kernel (RIK)
│   ├── ledger.rs           # Artefact storage and archiving
│   ├── traversal.rs        # High-level traversal API
│   ├── simulation.rs       # Simulation and evolution engine
│   ├── error.rs            # Error types
│   └── bin/
│       └── moge-cli.rs     # Command-line interface
├── docs/                   # Architecture documentation (PDFs)
├── benches/                # Performance benchmarks
├── tests/                  # Integration tests
├── Cargo.toml
└── README.md
```

## Examples

See the `examples/` directory for complete usage examples:

- `basic_traversal.rs`: Simple agent traversal
- `multi_agent.rs`: Multi-agent swarm simulation
- `signature_analysis.rs`: Analyzing signature distributions
- `mandorla_search.rs`: Finding Mandorla-certified operators

## Performance

MOGE is designed for efficiency:
- Graph operations leverage `petgraph` for optimal performance
- Signature calculations use `nalgebra` for fast linear algebra
- Parallel traversal support (planned)
- WASM compilation target for web deployment

## Roadmap

- [x] Core architecture (signature, graph, agent, kernel, ledger)
- [x] CLI interface
- [x] Simulation engine with evolution
- [x] **Cubechain - Hypercube-DAG Ledger** (see [CUBECHAIN_ARCHITECTURE.md](CUBECHAIN_ARCHITECTURE.md))
- [x] **Metatron Meta-Cognition Layer (Ω.∞)** - Introspective self-reasoning (see [docs/META_COGNITION.md](docs/META_COGNITION.md))
- [ ] WebAssembly compilation
- [x] Web-based visualization UI (React + CubechainNavigator)
- [ ] Graphviz export for path visualization
- [ ] Plugin system for custom behaviors
- [ ] Quantum simulator integration
- [ ] Distributed multi-node traversal
- [ ] Advanced evolutionary algorithms

## Deployment Architecture

The MOGE system can be deployed as a complete stack with web UI and API:

### Components

- **Resonance Kernel** (Rust) - Core computation engine on port 7000
- **Lexicon API** (Python/FastAPI) - REST API and WebSocket telemetry on port 8080
- **Dashboard UI** (React/TypeScript) - Interactive visualization on port 3000
- **PostgreSQL** - Persistent operator and ledger storage

### Quick Deploy

```bash
# Local deployment with Docker Compose
make all

# Or step by step
docker-compose up -d
./genesis_routine.sh

# Access points
# - Dashboard: http://localhost:3000
# - API: http://localhost:8080
# - API Docs: http://localhost:8080/docs
```

### Production Deployment

```bash
# Kubernetes deployment
make build
make deploy-k8s

# See DEPLOYMENT.md for detailed instructions
```

**Features:**
- Real-time operator mining visualization
- Searchable Operator Lexicon
- Proof-of-Resonance ledger replay
- **Cubechain Navigator** - 5D hypergraph viewer with operator coloring
- **Meta-Cognition Dashboard** - Self-reflection and pattern analysis (Ω.∞)
- WebSocket telemetry streaming
- Auto-scaling (Kubernetes)

See [DEPLOYMENT.md](DEPLOYMENT.md) for complete deployment documentation.
See [CUBECHAIN_ARCHITECTURE.md](CUBECHAIN_ARCHITECTURE.md) for Cubechain details.

## Documentation

Comprehensive architectural documentation is available in the `docs/` directory:

- **moge.pdf**: Complete system architecture and mathematical framework
- **MetatronsCube_Model.pdf**: Topological foundation and geometric structure
- **MetatronsCube_Matrix.pdf**: Matrix representation and symmetry groups
- **Resonant_Invariant_Kernel_for_Cybernetic_Architectures.pdf**: RIK theory
- **4DTrichter_CubeExpansion.pdf**: Hypercube-funnel coupling dynamics
- **5D_System_Framework.pdf**: Extended 5D signature space

## Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## License

This project is licensed under the Creative Commons Attribution 4.0 International License (CC BY 4.0).

See [LICENSE](LICENSE) for details.

## Citation

If you use MOGE in your research, please cite:

```bibtex
@software{moge2025,
  title={Metatronic Operator Genesis Engine},
  author={MOGE Development Team},
  year={2025},
  url={https://github.com/YourOrg/genesis-engine}
}
```

## Contact

For questions, issues, or contributions, please open an issue on GitHub.

---

**Metatronic Operator Genesis Engine** – Where geometry meets meaning, and resonance becomes recursion.
