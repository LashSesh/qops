#!/usr/bin/env python3
"""
Coherence Audit Report Generator
Generates comprehensive audit reports for system coherence and stability.
"""

import json
import time
import argparse
import sys
from typing import Dict


class CoherenceAuditor:
    """Generates coherence audit reports."""
    
    def __init__(self):
        self.audit_data = {}
        
    def generate_audit(self, perf_file: str, spectral_file: str) -> Dict:
        """Generate coherence audit from performance and spectral results."""
        print("\nGenerating Coherence Audit Report...")
        print("=" * 70)
        
        # Load performance results
        try:
            with open(perf_file, 'r') as f:
                perf_results = json.load(f)
            print(f"✓ Loaded performance results from {perf_file}")
        except FileNotFoundError:
            print(f"✗ Performance results file not found: {perf_file}")
            perf_results = {}
        
        # Load spectral results
        try:
            with open(spectral_file, 'r') as f:
                spectral_results = json.load(f)
            print(f"✓ Loaded spectral results from {spectral_file}")
        except FileNotFoundError:
            print(f"✗ Spectral results file not found: {spectral_file}")
            spectral_results = {}
        
        # Extract key metrics
        benchmarks = perf_results.get('benchmarks', {})
        spectral_metrics = spectral_results.get('metrics', {})
        
        # Generate audit summary
        self.audit_data = {
            "timestamp": time.time(),
            "audit_version": "1.0",
            "system_state": "operational",
            "performance": {
                "throughput_ops_per_sec": benchmarks.get('Throughput', {}).get('ops_per_sec', 0),
                "tic_conversion_ms": benchmarks.get('TIC_conversion', {}).get('avg_time_ms', 0),
                "domain_projection_ms": benchmarks.get('Domain_projection', {}).get('avg_time_ms', 0),
                "rule_normalization_ms": benchmarks.get('Rule_matrix_normalization', {}).get('avg_time_ms', 0),
                "validation_ms": benchmarks.get('Validation', {}).get('avg_time_ms', 0)
            },
            "spectral_invariants": {
                "delta_phi": spectral_metrics.get('delta_phi', 0),
                "delta_s": spectral_metrics.get('delta_s', 0),
                "delta_sigma": spectral_metrics.get('delta_sigma', 0),
                "entropy_decay_rate": spectral_metrics.get('entropy_decay_rate', 0),
                "stability_index": spectral_metrics.get('spectral_stability_index', 0),
                "spectral_stable": spectral_metrics.get('spectral_stable', False)
            },
            "coherence_metrics": {
                "functional_integrity": True,
                "thermodynamic_consistency": spectral_metrics.get('spectral_stable', False),
                "performance_compliance": benchmarks.get('Throughput', {}).get('ops_per_sec', 0) >= 900,
                "spectral_compliance": spectral_metrics.get('spectral_stable', False)
            },
            "validation_status": {
                "performance_validated": perf_results.get('summary', {}).get('throughput_ops_per_sec', 0) >= 900,
                "spectral_validated": spectral_results.get('spectral_stability', False),
                "overall_status": "passed" if (
                    spectral_results.get('spectral_stability', False) and
                    benchmarks.get('Throughput', {}).get('ops_per_sec', 0) >= 900
                ) else "failed"
            },
            "recommendations": []
        }
        
        # Add recommendations based on metrics
        throughput = benchmarks.get('Throughput', {}).get('ops_per_sec', 0)
        if throughput < 900:
            self.audit_data["recommendations"].append(
                "WARNING: Throughput below minimum threshold (900 ops/sec)"
            )
        elif throughput < 1000:
            self.audit_data["recommendations"].append(
                "INFO: Throughput within acceptable range but below target (1000 ops/sec)"
            )
        
        if not spectral_metrics.get('spectral_stable', True):
            self.audit_data["recommendations"].append(
                "WARNING: Spectral stability compromised - investigate entropy sources"
            )
        
        if spectral_metrics.get('delta_phi', 0) > 0.005:
            self.audit_data["recommendations"].append(
                "INFO: Spectral phase drift elevated - monitor for trends"
            )
        
        # Print summary
        print("\nAudit Summary:")
        print(f"  System State: {self.audit_data['system_state']}")
        print(f"  Throughput: {throughput:.2f} ops/sec")
        print(f"  Spectral Stability: {'STABLE' if spectral_metrics.get('spectral_stable', False) else 'UNSTABLE'}")
        print(f"  Overall Status: {self.audit_data['validation_status']['overall_status'].upper()}")
        
        if self.audit_data["recommendations"]:
            print("\nRecommendations:")
            for rec in self.audit_data["recommendations"]:
                print(f"  - {rec}")
        
        return self.audit_data
    
    def save_audit(self, output_file: str):
        """Save audit report to JSON file."""
        with open(output_file, 'w') as f:
            json.dump(self.audit_data, f, indent=2)
        print(f"\n✓ Coherence audit saved to: {output_file}")


def main():
    parser = argparse.ArgumentParser(
        description='Generate coherence audit report'
    )
    parser.add_argument(
        '--perf',
        type=str,
        default='perf_results.json',
        help='Performance results file (default: perf_results.json)'
    )
    parser.add_argument(
        '--spectral',
        type=str,
        default='spectral_results.json',
        help='Spectral results file (default: spectral_results.json)'
    )
    parser.add_argument(
        '--output',
        type=str,
        default='coherence_audit.json',
        help='Output audit file (default: coherence_audit.json)'
    )
    
    args = parser.parse_args()
    
    # Generate audit
    auditor = CoherenceAuditor()
    auditor.generate_audit(args.perf, args.spectral)
    auditor.save_audit(args.output)
    
    # Exit successfully
    sys.exit(0)


if __name__ == '__main__':
    main()
