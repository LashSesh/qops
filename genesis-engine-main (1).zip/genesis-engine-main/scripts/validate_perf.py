#!/usr/bin/env python3
"""
Performance Validation Script
Validates benchmark results against performance targets.
"""

import json
import argparse
import sys
from typing import Dict, List, Tuple


class PerformanceValidator:
    """Validates performance benchmarks against targets."""
    
    def __init__(self, targets_file: str, results_file: str):
        self.targets = self.load_json(targets_file)
        self.results = self.load_json(results_file)
        self.failures = []
        self.warnings = []
        
    @staticmethod
    def load_json(filepath: str) -> Dict:
        """Load JSON file."""
        try:
            with open(filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"Error: File not found: {filepath}")
            sys.exit(1)
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON in {filepath}: {e}")
            sys.exit(1)
    
    def validate_benchmark(self, name: str, result: Dict, target: Dict) -> Tuple[bool, str]:
        """Validate a single benchmark result against its target."""
        if name == "Throughput":
            return self.validate_throughput(result, target)
        else:
            return self.validate_time_benchmark(name, result, target)
    
    def validate_time_benchmark(self, name: str, result: Dict, target: Dict) -> Tuple[bool, str]:
        """Validate a time-based benchmark."""
        target_time = target.get('target_time_ms', 0)
        avg_time = result.get('avg_time_ms', float('inf'))
        
        if avg_time <= target_time:
            return True, f"✓ {name}: {avg_time:.4f} ms (target: {target_time} ms)"
        else:
            excess = ((avg_time - target_time) / target_time) * 100
            return False, f"✗ {name}: {avg_time:.4f} ms exceeds target of {target_time} ms by {excess:.1f}%"
    
    def validate_throughput(self, result: Dict, target: Dict) -> Tuple[bool, str]:
        """Validate throughput benchmark."""
        target_ops = target.get('target_ops_per_sec', 0)
        tolerance = target.get('acceptance_tolerance', 0.1)
        actual_ops = result.get('ops_per_sec', 0)
        
        min_acceptable = target_ops * (1 - tolerance)
        max_acceptable = target_ops * (1 + tolerance)
        
        if min_acceptable <= actual_ops <= max_acceptable:
            deviation = ((actual_ops - target_ops) / target_ops) * 100
            return True, f"✓ Throughput: {actual_ops:.2f} ops/sec (target: {target_ops} ±{tolerance*100}%, deviation: {deviation:+.1f}%)"
        elif actual_ops < min_acceptable:
            deficit = ((target_ops - actual_ops) / target_ops) * 100
            return False, f"✗ Throughput: {actual_ops:.2f} ops/sec is below minimum of {min_acceptable:.2f} ops/sec (deficit: {deficit:.1f}%)"
        else:
            # Above max is still acceptable, just a warning
            excess = ((actual_ops - target_ops) / target_ops) * 100
            return True, f"⚠ Throughput: {actual_ops:.2f} ops/sec exceeds expected range (excess: {excess:.1f}%)"
    
    def validate_all(self) -> bool:
        """Validate all benchmarks and return overall pass/fail."""
        print("\nValidating Performance Benchmarks")
        print("=" * 70)
        
        benchmarks = self.results.get('benchmarks', {})
        targets = self.targets.get('benchmarks', {})
        
        all_passed = True
        
        for name, result in benchmarks.items():
            if name not in targets:
                self.warnings.append(f"⚠ No target defined for benchmark: {name}")
                continue
            
            target = targets[name]
            passed, message = self.validate_benchmark(name, result, target)
            
            print(f"\n{message}")
            
            if not passed:
                self.failures.append(message)
                all_passed = False
        
        # Print summary
        print("\n" + "=" * 70)
        if all_passed:
            print("✓ All performance benchmarks PASSED")
        else:
            print(f"✗ Performance validation FAILED ({len(self.failures)} benchmark(s) failed)")
            print("\nFailed benchmarks:")
            for failure in self.failures:
                print(f"  {failure}")
        
        if self.warnings:
            print("\nWarnings:")
            for warning in self.warnings:
                print(f"  {warning}")
        
        return all_passed
    
    def get_summary(self) -> Dict:
        """Get validation summary."""
        benchmarks = self.results.get('benchmarks', {})
        
        return {
            "validation_passed": len(self.failures) == 0,
            "total_benchmarks": len(benchmarks),
            "failed_benchmarks": len(self.failures),
            "warnings": len(self.warnings),
            "throughput_ops_per_sec": benchmarks.get('Throughput', {}).get('ops_per_sec', 0),
            "failures": self.failures,
            "warnings": self.warnings
        }


def main():
    parser = argparse.ArgumentParser(
        description='Validate performance benchmark results against targets'
    )
    parser.add_argument(
        '--target',
        type=str,
        default='perf_targets.json',
        help='Performance targets JSON file (default: perf_targets.json)'
    )
    parser.add_argument(
        '--results',
        type=str,
        default='perf_results.json',
        help='Benchmark results JSON file (default: perf_results.json)'
    )
    parser.add_argument(
        '--output',
        type=str,
        help='Optional output file for validation summary (JSON format)'
    )
    
    args = parser.parse_args()
    
    # Run validation
    validator = PerformanceValidator(args.target, args.results)
    passed = validator.validate_all()
    
    # Save summary if requested
    if args.output:
        summary = validator.get_summary()
        with open(args.output, 'w') as f:
            json.dump(summary, f, indent=2)
        print(f"\nValidation summary saved to: {args.output}")
    
    # Exit with appropriate code
    sys.exit(0 if passed else 1)


if __name__ == '__main__':
    main()
