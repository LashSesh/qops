#!/usr/bin/env python3
"""
ORIPHIEL-5D Spiral Memory Engine
=================================

Implements 5-dimensional semantic spiral memory with field operators:
- ψ (psi): Wave function amplitude - semantic intensity
- ρ (rho): Radial density - conceptual distance from origin
- ω (omega): Angular frequency - rate of semantic evolution
- θ (theta): Polar angle - vertical semantic axis
- φ (phi): Azimuthal angle - horizontal semantic plane

Spiral trajectories encode operator evolution paths in phase space.
"""

import random
import math
import time
from decimal import Decimal, getcontext
from typing import Dict, List, Tuple
from pathlib import Path
import json

getcontext().prec = 64


class SpiralSeed:
    """
    A single seed in the ORIPHIEL-5D spiral memory.

    Represents a point in 5D semantic phase space with evolutionary trajectory.
    """

    def __init__(self, seed_id: int, psi: float, rho: float, omega: float,
                 theta: float, phi: float, alpha: float = None, beta: float = None):
        self.id = seed_id
        self.psi = Decimal(str(psi))      # Wave amplitude (semantic intensity)
        self.rho = Decimal(str(rho))      # Radial density
        self.omega = Decimal(str(omega))  # Angular frequency
        self.theta = Decimal(str(theta))  # Polar angle [0, π]
        self.phi = Decimal(str(phi))      # Azimuthal angle [0, 2π]

        # Optional: Link to KNO operator parameters
        self.alpha = Decimal(str(alpha)) if alpha is not None else None
        self.beta = Decimal(str(beta)) if beta is not None else None

        # Metadata
        self.timestamp = time.time()
        self.generation = 0
        self.mutations = 0

    def to_dict(self) -> dict:
        """Export seed as dictionary"""
        return {
            'id': self.id,
            'psi': float(self.psi),
            'rho': float(self.rho),
            'omega': float(self.omega),
            'theta': float(self.theta),
            'phi': float(self.phi),
            'alpha': float(self.alpha) if self.alpha else None,
            'beta': float(self.beta) if self.beta else None,
            'timestamp': self.timestamp,
            'generation': self.generation,
            'mutations': self.mutations
        }

    def spiral_distance(self, other: 'SpiralSeed') -> Decimal:
        """
        Compute semantic distance between two seeds in 5D spiral space.

        Uses modified Euclidean metric with spiral weighting:
        d = √(|ψ₁-ψ₂|² + ρ²|θ₁-θ₂|² + ρ²sin²θ|φ₁-φ₂|² + |ω₁-ω₂|²)
        """
        dpsi = (self.psi - other.psi) ** 2
        dtheta = self.rho ** 2 * (self.theta - other.theta) ** 2
        dphi = self.rho ** 2 * (Decimal(str(math.sin(float(self.theta)))) ** 2) * (self.phi - other.phi) ** 2
        domega = (self.omega - other.omega) ** 2

        return (dpsi + dtheta + dphi + domega).sqrt()


class SpiralMemory:
    """
    5-Dimensional Semantic Spiral Memory System

    Manages a collection of spiral seeds and provides operations for:
    - Seed injection (encoding new operators)
    - Field topology computation
    - Semantic trajectory tracking
    - Mutation and evolution
    """

    def __init__(self, capacity: int = 10000):
        self.capacity = capacity
        self.seeds: List[SpiralSeed] = []
        self.field_topology = {}
        self.evolution_log = []

    def inject_seed(self, alpha: float, beta: float) -> SpiralSeed:
        """
        Inject a new seed based on KNO operator parameters (α, β).

        Maps operator phase space to 5D spiral coordinates:
        - ψ = |α - β| (phase difference magnitude)
        - ρ = (α + β) / 2 (phase centroid)
        - ω = α - β (angular frequency)
        - θ = arctan2(β, α) (polar angle)
        - φ = (α + β) mod 2π (azimuthal angle)
        """
        delta_phi = alpha - beta

        psi = abs(delta_phi)
        rho = (alpha + beta) / 2.0
        omega = delta_phi
        theta = math.atan2(beta, alpha)
        phi = (alpha + beta) % (2 * math.pi)

        # Normalize angles
        if theta < 0:
            theta += math.pi

        seed = SpiralSeed(
            seed_id=len(self.seeds),
            psi=psi,
            rho=rho,
            omega=omega,
            theta=theta,
            phi=phi,
            alpha=alpha,
            beta=beta
        )

        self.seeds.append(seed)

        # Maintain capacity limit
        if len(self.seeds) > self.capacity:
            self.seeds = self.seeds[-self.capacity:]

        return seed

    def inject_random(self, batch_size: int = 100) -> List[Dict]:
        """
        Inject a batch of random seeds for exploration.

        Returns list of seed dictionaries.
        """
        seeds = []
        for _ in range(batch_size):
            alpha = random.uniform(0, 2 * math.pi)
            beta = random.uniform(0, 2 * math.pi)
            seed = self.inject_seed(alpha, beta)
            seeds.append(seed.to_dict())

        return seeds

    def mutate(self, seed_dict: dict, semantics: dict) -> dict:
        """
        Mutate a seed based on semantic resonance feedback.

        Args:
            seed_dict: Seed dictionary
            semantics: Semantic analysis from QLOGIC grammar

        Returns:
            Mutation delta dictionary
        """
        # Extract resonance strength
        resonance_strength = semantics.get('resonance_strength', 0.0)
        coherence = semantics.get('coherence', 0.5)

        # Compute mutation magnitude (inversely proportional to coherence)
        mutation_scale = (1.0 - coherence) * 0.1

        # Perturb spiral coordinates
        delta_psi = random.gauss(0, mutation_scale)
        delta_omega = random.gauss(0, mutation_scale * 0.5)
        delta_theta = random.gauss(0, mutation_scale * 0.2)
        delta_phi = random.gauss(0, mutation_scale * 0.2)

        return {
            'delta_psi': delta_psi,
            'delta_omega': delta_omega,
            'delta_theta': delta_theta,
            'delta_phi': delta_phi,
            'mutation_scale': mutation_scale,
            'resonance_strength': resonance_strength
        }

    def consolidate(self, evaluated_seeds: List[dict]) -> dict:
        """
        Consolidate a batch of evaluated seeds into field topology update.

        Args:
            evaluated_seeds: List of evaluated and mutated seeds

        Returns:
            Field topology statistics
        """
        stable_count = sum(1 for s in evaluated_seeds if abs(s.get('delta_psi', 1.0)) < 0.2)
        stability_rate = stable_count / len(evaluated_seeds) if evaluated_seeds else 0.0

        # Compute field statistics
        avg_psi = sum(s.get('psi', 0) for s in evaluated_seeds) / len(evaluated_seeds) if evaluated_seeds else 0
        avg_omega = sum(s.get('omega', 0) for s in evaluated_seeds) / len(evaluated_seeds) if evaluated_seeds else 0

        topology = {
            'total_seeds': len(self.seeds),
            'stable_seeds': stable_count,
            'stability_rate': stability_rate,
            'avg_psi': avg_psi,
            'avg_omega': avg_omega,
            'timestamp': time.time()
        }

        self.field_topology = topology
        self.evolution_log.append(topology)

        return topology

    def get_nearest_neighbors(self, seed: SpiralSeed, k: int = 5) -> List[SpiralSeed]:
        """
        Find k nearest neighbors to given seed in 5D spiral space.

        Uses spiral distance metric.
        """
        if not self.seeds:
            return []

        distances = [(s, seed.spiral_distance(s)) for s in self.seeds if s.id != seed.id]
        distances.sort(key=lambda x: x[1])

        return [s for s, d in distances[:k]]

    def export_topology(self, filepath: Path):
        """Export current field topology to JSON"""
        with open(filepath, 'w') as f:
            json.dump({
                'field_topology': self.field_topology,
                'evolution_log': self.evolution_log,
                'seed_count': len(self.seeds),
                'capacity': self.capacity
            }, f, indent=2)
