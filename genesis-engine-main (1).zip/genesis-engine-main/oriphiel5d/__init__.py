"""
ORIPHIEL-5D: 5-Dimensional Semantic Spiral Memory System
=========================================================

A recursive memory architecture that encodes semantic trajectories
as spiral fields in 5D phase space (ψ, ρ, ω, θ, φ).
"""

__version__ = "1.0.0"
__author__ = "ORIPHIEL Development Team"
