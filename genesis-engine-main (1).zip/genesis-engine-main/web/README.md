# MOGE Web Interface

Interactive browser-based visualization for the Metatronic Operator Genesis Engine.

## Features

- 🎨 Real-time WebGL visualization
- 📊 Live statistics dashboard
- 🎮 Interactive controls
- 🌈 Color-coded resonance display
- 📈 Generation tracking

## Quick Start

### 1. Build the WASM Module

```bash
# From the project root
wasm-pack build --target web --features wasm
```

### 2. Serve the Web Interface

```bash
cd web
python3 -m http.server 8000
```

Or use any static file server:

```bash
# Using Node.js
npx http-server

# Using PHP
php -S localhost:8000
```

### 3. Open in Browser

Navigate to `http://localhost:8000`

## Usage

### Simulation Controls

- **Number of Agents**: Set the swarm size (1-100 agents)
- **Max Steps per Agent**: Maximum traversal length (10-1000 steps)
- **Generations**: Number of evolution cycles (1-50)
- **Traversal Strategy**: Choose algorithm
  - **Balanced**: Weighted combination of all metrics
  - **Gradient Ascent**: Maximize spectral quality (ψ)
  - **Stability Maximization**: Maximize structural coherence (ω)
  - **Cycle Recognition**: Seek self-similar patterns
  - **Random Walk**: Exploratory traversal

### Buttons

- **Run Simulation**: Execute multi-generation simulation
- **Single Traversal**: Run one agent traversal
- **Clear**: Reset visualization and output

### Statistics Display

Four real-time metrics:

1. **Total Artefacts**: Number of operators discovered
2. **Avg Resonance**: Mean quality across all artefacts
3. **Best Resonance**: Highest quality artefact found
4. **Mandorla Certified**: Artefacts meeting invariance criteria

### Visualization Legend

- 🟢 **Green**: High resonance (> 0.8)
- 🟡 **Yellow**: Medium resonance (0.5-0.8)
- 🔴 **Red**: Low resonance (< 0.5)

## Architecture

```
┌─────────────────────────────────────┐
│         HTML/CSS/JavaScript         │
│   (User Interface & Visualization)  │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│         WebAssembly Module          │
│     (MOGE Core - Rust compiled)     │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│            WebGL Renderer           │
│    (3D Graph Visualization)         │
└─────────────────────────────────────┘
```

## WebGL Rendering

The visualization uses WebGL for hardware-accelerated 3D rendering:

- **Nodes**: Artefact states in signature space
- **Edges**: Traversal paths between states
- **Colors**: Resonance quality mapping
- **Animation**: Real-time updates during simulation

## Integration with WASM

The web interface communicates with the Rust core through WebAssembly:

```javascript
// Initialize WASM module
import init, { WasmSimulation } from '../pkg/genesis_engine.js';
await init();

// Create simulation
const sim = new WasmSimulation(agents, steps, generations);

// Run and get results
const result = JSON.parse(sim.run());

// Update visualization
updateVisualization(result);
```

## Browser Compatibility

- ✅ Chrome 80+
- ✅ Firefox 75+
- ✅ Safari 14+
- ✅ Edge 80+

Requirements:
- WebAssembly support
- WebGL 1.0+
- ES6 modules

## Development

### Building for Development

```bash
# Watch mode with auto-reload
wasm-pack build --target web --features wasm --dev

# Production build (optimized)
wasm-pack build --target web --features wasm --release
```

### File Structure

```
web/
├── index.html          # Main application
├── README.md           # This file
└── pkg/                # Generated WASM files
    ├── genesis_engine.js
    ├── genesis_engine_bg.wasm
    └── genesis_engine.d.ts
```

### Customizing the Interface

Edit `index.html` to customize:

- **Styling**: Modify the `<style>` section
- **Layout**: Adjust the `.dashboard` grid
- **Controls**: Add new input fields
- **Visualization**: Extend the WebGL rendering code

## Performance Tips

1. **Limit Agents**: Use fewer agents (5-20) for smooth browser performance
2. **Reduce Steps**: Keep max steps under 100 for real-time feedback
3. **Use Web Workers**: For background computation (future enhancement)
4. **Cache Results**: Store computed artefacts in localStorage

## Troubleshooting

### WASM Module Not Found

```
Error: Cannot find module '../pkg/genesis_engine.js'
```

**Solution**: Build the WASM module first:
```bash
wasm-pack build --target web --features wasm
```

### WebGL Not Supported

```
⚠️ WebGL not available. Visualization disabled.
```

**Solution**: Use a modern browser or enable WebGL in settings.

### CORS Errors

```
Access to script blocked by CORS policy
```

**Solution**: Serve files through a web server, not `file://` protocol.

### Performance Issues

If simulation is slow:

1. Reduce number of agents
2. Reduce max steps
3. Reduce generations
4. Close other browser tabs
5. Use a desktop browser instead of mobile

## Future Enhancements

- [ ] 3D camera controls (rotate, zoom, pan)
- [ ] Node selection and inspection
- [ ] Path highlighting
- [ ] Animation playback controls
- [ ] Export visualization as image/video
- [ ] Real-time collaboration (multi-user)
- [ ] VR/AR support

## API Reference

### WasmSimulation

```typescript
class WasmSimulation {
  constructor(agent_count: number, max_steps: number, generations: number);
  run(): string; // Returns JSON
  get_stats(): string; // Returns JSON
}
```

### WasmTraversal

```typescript
class WasmTraversal {
  constructor();
  run_single(max_steps: number, strategy: string): string; // Returns JSON
  get_ledger(): string; // Returns JSON
}
```

### Utility Functions

```typescript
function get_version(): string;
function create_signature(psi: number, rho: number, omega: number,
                         chi: number, eta: number): string;
function calculate_resonance(signature_json: string): number;
```

## Contributing

To contribute to the web interface:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test in multiple browsers
5. Submit a pull request

## License

CC-BY-4.0 (same as MOGE)

---

For more information, see the main [FEATURES.md](../FEATURES.md) documentation.
