#!/usr/bin/env python3
"""
ORIPHIEL-QLOGIC Recursive Evolution Framework
==============================================

Integrates ORIPHIEL-5D semantic spiral memory with QLOGIC v2.0 resonant logic
to create a self-evolving operator mining system.

Recursion Loop:
1. Seed Injection: ORIPHIEL encodes operators as 5D spiral seeds
2. Resonant Evaluation: QLOGIC oscillator computes phase coherence
3. Semantic Processing: Spectral grammar analyzes resonance patterns
4. Mutation: Seeds perturbed based on semantic directives
5. Consolidation: ORIPHIEL integrates stable seeds into memory
6. Reflection: QLOGIC self-model analyzes stability and entropy
7. Iteration: Loop repeats until convergence or saturation

Exit Codes:
- 0: Evolution converged successfully
- 1: Evolution failed or critical error
"""

import json
import time
import os
import sys
from pathlib import Path
from decimal import Decimal, getcontext

# Set high precision
getcontext().prec = 64

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import ORIPHIEL and QLOGIC modules
from oriphiel5d.core.spiral_engine import SpiralMemory
from qlogic.logic.oscillator_core import OscillatorCore
from qlogic.logic.spectral_grammar import SpectralGrammar
from qlogic.vm.qlogic_self_model import SelfModel

# Import Ontology, Reflexivity, and Metatron modules
from ontology.operator_lexicon import OperatorLexicon
from kernel.reflexivity_core import ReflexivityKernel
from metatron.metatron_feedback import MetatronFeedback

# Configuration
MAX_CYCLES = int(os.getenv('EVOLUTION_CYCLES', '10'))
BATCH_SIZE = int(os.getenv('EVOLUTION_BATCH', '1000'))
CONVERGENCE_THRESHOLD = float(os.getenv('CONVERGENCE_THRESHOLD', '0.01'))
POR_THRESHOLD = float(os.getenv('POR_THRESHOLD', '0.7'))

# Output directory
EVO_DIR = Path('reports/oriphiel_evolution')
EVO_DIR.mkdir(parents=True, exist_ok=True)


def print_header():
    """Print evolution framework header"""
    print("=" * 80)
    print("ORIPHIEL-QLOGIC Recursive Evolution Framework")
    print("=" * 80)
    print(f"Max Cycles: {MAX_CYCLES}")
    print(f"Batch Size: {BATCH_SIZE}")
    print(f"PoR Threshold: {POR_THRESHOLD}")
    print(f"Convergence Threshold: {CONVERGENCE_THRESHOLD}")
    print("=" * 80)
    print()


def evolution_cycle(cycle_num: int, spiral: SpiralMemory, oscillator: OscillatorCore,
                    grammar: SpectralGrammar, self_model: SelfModel) -> dict:
    """
    Execute a single evolution cycle.

    Args:
        cycle_num: Cycle number
        spiral: ORIPHIEL spiral memory instance
        oscillator: QLOGIC oscillator core instance
        grammar: QLOGIC spectral grammar instance
        self_model: QLOGIC self-model instance

    Returns:
        Cycle statistics dictionary
    """
    cycle_start = time.time()

    print(f"🌀 Cycle {cycle_num} | Phase 1: Seed Injection")

    # Phase 1: Seed Injection
    seeds = spiral.inject_random(batch_size=BATCH_SIZE)

    print(f"  ✓ Injected {len(seeds)} seeds into 5D spiral memory")

    # Phase 2: Resonant Evaluation
    print(f"🌀 Cycle {cycle_num} | Phase 2: Resonant Evaluation")

    resonances = oscillator.batch_evaluate(seeds)
    ensemble_coherence = oscillator.measure_ensemble_coherence(resonances)

    print(f"  ✓ Evaluated {len(resonances)} seeds")
    print(f"  ✓ Ensemble coherence: {ensemble_coherence:.3f}")

    # Phase 3: Semantic Processing
    print(f"🌀 Cycle {cycle_num} | Phase 3: Semantic Processing")

    semantics = grammar.batch_process(resonances)
    semantic_summary = grammar.generate_summary(semantics)

    print(f"  ✓ Processed {len(semantics)} semantic patterns")
    print(f"  ✓ States: STABLE={semantic_summary['stable']}, "
          f"CHAOTIC={semantic_summary['chaotic']}, "
          f"DORMANT={semantic_summary['dormant']}, "
          f"NOISE={semantic_summary['noise']}")

    # Phase 4: Mutation
    print(f"🌀 Cycle {cycle_num} | Phase 4: Mutation")

    evaluated = []
    mutation_count = 0

    for seed, semantic in zip(seeds, semantics):
        mutation = spiral.mutate(seed, semantic)
        evaluated.append({**seed, **mutation, **semantic})

        if semantic['action'] in ['MUTATE_AGGRESSIVE', 'PERTURB_GENTLE']:
            mutation_count += 1

    print(f"  ✓ Mutated {mutation_count} seeds based on semantic directives")

    # Phase 5: Consolidation
    print(f"🌀 Cycle {cycle_num} | Phase 5: Consolidation")

    topology = spiral.consolidate(evaluated)
    stability_rate = topology['stability_rate']

    print(f"  ✓ Consolidated {topology['stable_seeds']} stable seeds")
    print(f"  ✓ Stability rate: {stability_rate:.3f}")

    # Phase 6: Reflection
    print(f"🌀 Cycle {cycle_num} | Phase 6: Reflection")

    entropy = self_model.measure_entropy(evaluated)
    stability_drift = self_model.measure_stability_drift(stability_rate)
    convergence = self_model.analyze_convergence()
    recommendations = self_model.recommend_adjustments(
        convergence, entropy, stability_rate
    )

    print(f"  ✓ System entropy: {entropy:.3f}")
    print(f"  ✓ Stability drift: {stability_drift:+.3f}")
    print(f"  ✓ Converging: {convergence['converging']}")

    # Cycle statistics
    cycle_duration = time.time() - cycle_start

    cycle_stats = {
        'cycle': cycle_num,
        'timestamp': int(time.time()),
        'duration_s': round(cycle_duration, 3),
        'batch_size': BATCH_SIZE,
        'stability_rate': stability_rate,
        'entropy': entropy,
        'stability_drift': stability_drift,
        'ensemble_coherence': ensemble_coherence,
        'semantic_summary': semantic_summary,
        'convergence': convergence,
        'recommendations': recommendations,
        'por_threshold': POR_THRESHOLD
    }

    # Log cycle to self-model
    self_model.log_cycle(cycle_stats)

    # Save cycle log
    cycle_log_path = EVO_DIR / f'cycle_{cycle_num}.json'
    with open(cycle_log_path, 'w') as f:
        json.dump(cycle_stats, f, indent=2)

    print(f"  ✓ Saved cycle log: {cycle_log_path}")
    print()

    return cycle_stats


def main():
    """Main evolution execution"""
    print_header()

    start_time = time.time()

    # Initialize systems
    print("🔧 Initializing ORIPHIEL-QLOGIC systems...")
    spiral = SpiralMemory(capacity=10000)
    oscillator = OscillatorCore(threshold_por=POR_THRESHOLD)
    grammar = SpectralGrammar()
    self_model = SelfModel()
    print("  ✓ Systems initialized")
    print()

    # Evolution loop
    converged = False
    cycle_stats_list = []

    # Initialize ontology system
    lexicon = OperatorLexicon()

    for cycle in range(1, MAX_CYCLES + 1):
        try:
            stats = evolution_cycle(cycle, spiral, oscillator, grammar, self_model)
            cycle_stats_list.append(stats)

            # Register evolved operators in ontology
            print(f"📚 Registering operators in ontology...")
            for seed in spiral.seeds[-BATCH_SIZE:]:  # Last batch
                op_dict = seed.to_dict()
                op_dict['origin_cycle'] = cycle
                op_dict['stable'] = abs(op_dict.get('psi', 0) - 1.0) < 0.2
                op_dict['entropy'] = stats['entropy']
                # Compute delta_phi from alpha and beta
                if op_dict.get('alpha') is not None and op_dict.get('beta') is not None:
                    op_dict['delta_phi'] = op_dict['alpha'] - op_dict['beta']
                else:
                    op_dict['delta_phi'] = op_dict.get('omega', 0.0)  # omega = delta_phi
                lexicon.register_operator(op_dict)
            print(f"  ✓ Registered {min(len(spiral.seeds), BATCH_SIZE)} operators")

            # Check convergence
            if stats['convergence']['converging']:
                print(f"✅ Convergence detected at cycle {cycle}")
                converged = True
                break

            # Check recommendations
            if not stats['recommendations']['continue_evolution']:
                print(f"✅ Evolution complete at cycle {cycle} (recommended halt)")
                converged = True
                break

        except Exception as e:
            print(f"❌ Error in cycle {cycle}: {e}")
            import traceback
            traceback.print_exc()
            break

    # Save ontology after evolution
    lexicon.save()

    # Phase 7: Reflexivity Analysis
    print()
    print("=" * 80)
    print("Phase 7: Reflexivity Analysis")
    print("=" * 80)
    kernel = ReflexivityKernel()
    reflexivity_summary = kernel.analyze()
    print()

    # Phase 8: Metatron Geometric Projection
    print("=" * 80)
    print("Phase 8: Metatron Geometric Projection")
    print("=" * 80)
    metatron = MetatronFeedback()
    metatron_summary = metatron.project_to_geometry()
    print()

    # Final consolidation
    print("=" * 80)
    print("Final Consolidation")
    print("=" * 80)

    total_duration = time.time() - start_time
    final_stability = cycle_stats_list[-1]['stability_rate'] if cycle_stats_list else 0.0
    final_entropy = cycle_stats_list[-1]['entropy'] if cycle_stats_list else 0.0

    # Export final state
    final_state = {
        'evolution_complete': converged,
        'total_cycles': len(cycle_stats_list),
        'total_duration_s': round(total_duration, 3),
        'final_stability': final_stability,
        'final_entropy': final_entropy,
        'convergence_achieved': converged,
        'cycle_history': cycle_stats_list,
        'self_model_history': self_model.export_history()
    }

    # Save final state
    final_state_path = EVO_DIR / 'evolution_final_state.json'
    with open(final_state_path, 'w') as f:
        json.dump(final_state, f, indent=2)

    print(f"Total Cycles: {len(cycle_stats_list)}")
    print(f"Duration: {total_duration:.2f}s")
    print(f"Final Stability: {final_stability:.3f}")
    print(f"Final Entropy: {final_entropy:.3f}")
    print(f"Status: {'✓ CONVERGED' if converged else '✗ NOT CONVERGED'}")
    print()
    print(f"Final State: {final_state_path}")
    print("=" * 80)

    # Export spiral memory topology
    spiral.export_topology(EVO_DIR / 'spiral_memory_topology.json')

    # Exit code
    sys.exit(0 if converged or len(cycle_stats_list) > 0 else 1)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(f"\n❌ CRITICAL ERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)
