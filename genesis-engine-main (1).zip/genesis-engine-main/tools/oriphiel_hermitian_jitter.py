#!/usr/bin/env python3
"""
ORIPHIEL Hermitian Jitter - Integrated Reflexive Evolution Pipeline
====================================================================

Orchestrates the complete KNO-ORIPHIEL reflexive evolution framework:
1. Applies Δψ-jitter dynamics for adaptive exploration
2. Performs Hermitian cluster analysis via reflexivity kernel
3. Executes operator ontology queries and analytics

This script implements the integration pipeline described in the
task architecture, running post-evolution analysis and feedback cycles.

Usage:
    python3 tools/oriphiel_hermitian_jitter.py [--cycles N] [--adaptive]

Options:
    --cycles N      Number of evolution cycles (default: 1)
    --adaptive      Enable adaptive jitter based on stability
    --sigma SIGMA   Jitter Gaussian std deviation (default: 0.03)
    --epsilon EPS   Jitter sinusoidal amplitude (default: 0.05)
    --ontology PATH Path to operator ontology (default: data/operator_ontology.json)
"""

import sys
import argparse
import json
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from kernel.reflexivity_core import ReflexivityKernel
from entropy.jitter_engine import JitterEngine
from ontology.operator_queries import OperatorQueries


class OriphielHermitianJitter:
    """
    Integrated ORIPHIEL Hermitian-Jitter Evolution Framework

    Coordinates the reflexivity kernel, jitter engine, and query system
    for closed-loop operator evolution with Hermitian clustering.
    """

    def __init__(
        self,
        ontology_path: str = 'data/operator_ontology.json',
        sigma: float = 0.03,
        epsilon: float = 0.05
    ):
        """
        Initialize the integrated framework.

        Args:
            ontology_path: Path to operator ontology JSON
            sigma: Jitter Gaussian noise std deviation
            epsilon: Jitter sinusoidal amplitude
        """
        self.ontology_path = ontology_path
        self.sigma = sigma
        self.epsilon = epsilon

        print("=" * 80)
        print("ORIPHIEL Hermitian-Jitter Evolution Framework")
        print("=" * 80)
        print(f"Ontology: {ontology_path}")
        print(f"Jitter parameters: σ={sigma}, ε={epsilon}")
        print("=" * 80)
        print()

        # Initialize components
        self.kernel = ReflexivityKernel(ontology_path=ontology_path)
        self.jitter = JitterEngine(
            ontology_path=ontology_path,
            sigma=sigma,
            epsilon=epsilon
        )
        self.queries = OperatorQueries(ontology_path=ontology_path)

    def run_cycle(self, cycle_num: int, adaptive: bool = False) -> dict:
        """
        Execute one complete evolution cycle.

        Pipeline:
        1. Apply Δψ-jitter dynamics
        2. Analyze Hermitian clusters
        3. Run reflexivity analysis
        4. Execute ontology queries

        Args:
            cycle_num: Cycle number for logging
            adaptive: Enable adaptive jitter

        Returns:
            Dictionary with cycle metrics
        """
        print()
        print("=" * 80)
        print(f"Evolution Cycle {cycle_num}")
        print("=" * 80)
        print()

        # Step 1: Apply Δψ-jitter dynamics
        print(">>> Step 1: Applying Δψ-Jitter Dynamics")
        print("-" * 80)
        jitter_stats = self.jitter.apply_jitter(adaptive=adaptive)
        print()

        # Reload data after jitter modification
        self.kernel = ReflexivityKernel(ontology_path=self.ontology_path)
        self.queries = OperatorQueries(ontology_path=self.ontology_path)

        # Step 2: Analyze Hermitian clusters
        print(">>> Step 2: Analyzing Hermitian Clusters")
        print("-" * 80)
        cluster_stats = self.kernel.analyze_clusters()
        print()

        # Step 3: Run reflexivity analysis
        print(">>> Step 3: Running Reflexivity Analysis")
        print("-" * 80)
        reflex_stats = self.kernel.analyze()
        print()

        # Step 4: Execute ontology queries
        print(">>> Step 4: Ontology Query & Analytics")
        print("-" * 80)
        query_summary = self.queries.summary()
        print()

        # Step 5: Additional analytics
        print(">>> Step 5: Advanced Analytics")
        print("-" * 80)
        landscape = self.queries.analyze_stability_landscape()
        correlations = self.queries.find_correlations()
        print()

        # Save jitter history
        self.jitter.save_jitter_history()

        # Compile cycle metrics
        cycle_metrics = {
            'cycle': cycle_num,
            'jitter': {
                'operators_modified': jitter_stats['operators_modified'],
                'avg_jitter': jitter_stats['avg_jitter'],
                'jitter_range': [jitter_stats['min_jitter'], jitter_stats['max_jitter']]
            },
            'clusters': {
                'total_analyzed': cluster_stats['total_analyzed'],
                'cluster_count': len(cluster_stats['clusters']),
                'clusters': cluster_stats['clusters']
            },
            'reflexivity': {
                'total_analyzed': reflex_stats['total_analyzed'],
                'hermitian_rate': reflex_stats['hermitian_rate'],
                'unitary_rate': reflex_stats['unitary_rate']
            },
            'ontology': {
                'total_operators': query_summary['total_operators'],
                'avg_entropy': query_summary['avg_entropy'],
                'avg_stability': query_summary['avg_stability'],
                'stable_fraction': landscape['stable_fraction']
            },
            'correlations': correlations
        }

        return cycle_metrics

    def run_multi_cycle(self, num_cycles: int, adaptive: bool = False) -> list:
        """
        Execute multiple evolution cycles.

        Args:
            num_cycles: Number of cycles to run
            adaptive: Enable adaptive jitter

        Returns:
            List of cycle metrics
        """
        all_metrics = []

        for cycle in range(1, num_cycles + 1):
            metrics = self.run_cycle(cycle, adaptive=adaptive)
            all_metrics.append(metrics)

        # Save aggregate report
        self._save_evolution_report(all_metrics)

        return all_metrics

    def _save_evolution_report(self, all_metrics: list):
        """
        Save comprehensive evolution report.

        Args:
            all_metrics: List of cycle metrics
        """
        report_dir = Path('reports/reflexivity')
        report_dir.mkdir(parents=True, exist_ok=True)

        report_path = report_dir / 'hermitian_jitter_evolution.json'

        report = {
            'framework': 'ORIPHIEL-Hermitian-Jitter',
            'total_cycles': len(all_metrics),
            'parameters': {
                'sigma': self.sigma,
                'epsilon': self.epsilon,
                'ontology_path': self.ontology_path
            },
            'cycles': all_metrics
        }

        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)

        print()
        print("=" * 80)
        print("Evolution Report Saved")
        print("=" * 80)
        print(f"Report: {report_path}")
        print(f"Total Cycles: {len(all_metrics)}")
        print("=" * 80)


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description='ORIPHIEL Hermitian-Jitter Evolution Framework'
    )
    parser.add_argument(
        '--cycles',
        type=int,
        default=1,
        help='Number of evolution cycles (default: 1)'
    )
    parser.add_argument(
        '--adaptive',
        action='store_true',
        help='Enable adaptive jitter based on stability'
    )
    parser.add_argument(
        '--sigma',
        type=float,
        default=0.03,
        help='Jitter Gaussian std deviation (default: 0.03)'
    )
    parser.add_argument(
        '--epsilon',
        type=float,
        default=0.05,
        help='Jitter sinusoidal amplitude (default: 0.05)'
    )
    parser.add_argument(
        '--ontology',
        type=str,
        default='data/operator_ontology.json',
        help='Path to operator ontology (default: data/operator_ontology.json)'
    )

    args = parser.parse_args()

    # Initialize framework
    framework = OriphielHermitianJitter(
        ontology_path=args.ontology,
        sigma=args.sigma,
        epsilon=args.epsilon
    )

    # Run evolution cycles
    framework.run_multi_cycle(
        num_cycles=args.cycles,
        adaptive=args.adaptive
    )

    print()
    print("=" * 80)
    print("ORIPHIEL Hermitian-Jitter Evolution Complete")
    print("=" * 80)


if __name__ == '__main__':
    main()
