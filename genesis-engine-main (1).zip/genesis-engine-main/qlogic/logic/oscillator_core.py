#!/usr/bin/env python3
"""
QLOGIC Oscillator Core
======================

Implements resonant evaluation of semantic seeds through oscillatory analysis.

Core Concepts:
- Phase Coherence: Alignment of semantic oscillations
- Resonance Strength: Amplitude of constructive interference
- Spectral Signature: Frequency decomposition of seed trajectory
- Proof-of-Resonance (PoR): Deterministic threshold validation
"""

import math
import cmath
from decimal import Decimal, getcontext
from typing import Dict

getcontext().prec = 64


class OscillatorCore:
    """
    QLOGIC Resonant Oscillator for Semantic Evaluation

    Evaluates seeds through oscillatory analysis in complex phase space.
    """

    def __init__(self, threshold_por: float = 0.7):
        """
        Initialize oscillator core.

        Args:
            threshold_por: Proof-of-Resonance threshold (0.0 - 1.0)
        """
        self.threshold_por = threshold_por
        self.evaluation_count = 0

    def evaluate(self, seed: dict) -> dict:
        """
        Evaluate a spiral seed through resonant oscillator analysis.

        Computes:
        - Phase coherence (alignment)
        - Resonance strength (amplitude)
        - Spectral signature (frequency components)
        - PoR validation (pass/fail)

        Args:
            seed: Spiral seed dictionary with ψ, ρ, ω, θ, φ

        Returns:
            Resonance analysis dictionary
        """
        self.evaluation_count += 1

        psi = seed.get('psi', 0.0)
        rho = seed.get('rho', 0.0)
        omega = seed.get('omega', 0.0)
        theta = seed.get('theta', 0.0)
        phi = seed.get('phi', 0.0)

        # Construct complex oscillator state
        # z = ψ · e^(iω) where ω encodes phase dynamics
        z = complex(psi * math.cos(omega), psi * math.sin(omega))

        # Phase coherence: alignment with reference axis
        # Coherence ∈ [0, 1] where 1 = perfect alignment
        coherence = abs(math.cos(omega / 2))

        # Resonance strength: magnitude of oscillatory component
        # Strength ∈ [0, 1] normalized by maximum amplitude
        resonance_strength = abs(z) / (1.0 + abs(z))

        # Spectral signature: decompose into fundamental + harmonics
        fundamental_freq = omega
        second_harmonic = 2 * omega
        third_harmonic = 3 * omega

        spectral_power = {
            'fundamental': abs(cmath.exp(1j * fundamental_freq)),
            'second_harmonic': abs(cmath.exp(1j * second_harmonic)) * 0.5,
            'third_harmonic': abs(cmath.exp(1j * third_harmonic)) * 0.25
        }

        # Total spectral energy
        spectral_energy = sum(spectral_power.values())

        # Interference pattern: constructive vs destructive
        # Positive = constructive, Negative = destructive
        interference = math.cos(omega) * coherence

        # Proof-of-Resonance validation
        por_score = (coherence + resonance_strength) / 2.0
        por_valid = por_score >= self.threshold_por

        return {
            'coherence': coherence,
            'resonance_strength': resonance_strength,
            'spectral_energy': spectral_energy,
            'spectral_power': spectral_power,
            'interference': interference,
            'por_score': por_score,
            'por_valid': por_valid,
            'oscillator_state': {
                'real': z.real,
                'imag': z.imag,
                'magnitude': abs(z),
                'phase': cmath.phase(z)
            }
        }

    def batch_evaluate(self, seeds: list) -> list:
        """
        Evaluate a batch of seeds in parallel.

        Args:
            seeds: List of seed dictionaries

        Returns:
            List of resonance analysis dictionaries
        """
        return [self.evaluate(seed) for seed in seeds]

    def measure_ensemble_coherence(self, resonances: list) -> float:
        """
        Measure collective coherence across an ensemble of resonances.

        Args:
            resonances: List of resonance dictionaries

        Returns:
            Ensemble coherence score [0, 1]
        """
        if not resonances:
            return 0.0

        coherence_values = [r['coherence'] for r in resonances]
        mean_coherence = sum(coherence_values) / len(coherence_values)

        # Coherence variance (lower = more synchronized)
        variance = sum((c - mean_coherence) ** 2 for c in coherence_values) / len(coherence_values)

        # Ensemble coherence penalized by variance
        ensemble_coherence = mean_coherence * (1.0 - min(variance, 1.0))

        return ensemble_coherence
