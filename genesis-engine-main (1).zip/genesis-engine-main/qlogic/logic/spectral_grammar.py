#!/usr/bin/env python3
"""
QLOGIC Spectral Grammar
=======================

Processes resonance patterns into structured semantic interpretations.

Grammar Rules:
- High coherence + high resonance = STABLE (conserve)
- Low coherence + high resonance = CHAOTIC (mutate aggressively)
- High coherence + low resonance = DORMANT (perturb gently)
- Low coherence + low resonance = NOISE (discard or re-seed)
"""

import math
from typing import Dict, List


class SpectralGrammar:
    """
    QLOGIC Spectral Grammar Parser

    Transforms resonance patterns into semantic classifications
    and mutation directives.
    """

    def __init__(self):
        self.grammar_rules = {
            'STABLE': {'coherence_min': 0.7, 'resonance_min': 0.6},
            'CHAOTIC': {'coherence_max': 0.4, 'resonance_min': 0.6},
            'DORMANT': {'coherence_min': 0.6, 'resonance_max': 0.4},
            'NOISE': {'coherence_max': 0.4, 'resonance_max': 0.4}
        }

    def process(self, resonance: dict) -> dict:
        """
        Process resonance data through spectral grammar rules.

        Args:
            resonance: Resonance dictionary from OscillatorCore

        Returns:
            Semantic interpretation with mutation directives
        """
        coherence = resonance.get('coherence', 0.0)
        resonance_strength = resonance.get('resonance_strength', 0.0)
        spectral_energy = resonance.get('spectral_energy', 0.0)
        por_valid = resonance.get('por_valid', False)

        # Classify semantic state
        semantic_state = self._classify_state(coherence, resonance_strength)

        # Generate mutation directive
        mutation_directive = self._generate_mutation_directive(
            semantic_state, coherence, resonance_strength
        )

        # Compute semantic metrics
        semantic_density = coherence * resonance_strength
        semantic_entropy = 1.0 - semantic_density
        semantic_potential = spectral_energy * (1.0 - coherence)

        # Determine action
        if semantic_state == 'STABLE' and por_valid:
            action = 'CONSOLIDATE'
            mutation_scale = 0.01  # Minimal perturbation
        elif semantic_state == 'CHAOTIC':
            action = 'MUTATE_AGGRESSIVE'
            mutation_scale = 0.3  # Large perturbation
        elif semantic_state == 'DORMANT':
            action = 'PERTURB_GENTLE'
            mutation_scale = 0.1  # Moderate perturbation
        else:  # NOISE
            action = 'RESEED'
            mutation_scale = 0.5  # Maximum perturbation or discard

        return {
            'semantic_state': semantic_state,
            'mutation_directive': mutation_directive,
            'action': action,
            'mutation_scale': mutation_scale,
            'semantic_density': semantic_density,
            'semantic_entropy': semantic_entropy,
            'semantic_potential': semantic_potential,
            'coherence': coherence,
            'resonance_strength': resonance_strength
        }

    def _classify_state(self, coherence: float, resonance_strength: float) -> str:
        """
        Classify semantic state based on coherence and resonance.

        Args:
            coherence: Coherence value [0, 1]
            resonance_strength: Resonance strength [0, 1]

        Returns:
            State classification string
        """
        if coherence >= 0.7 and resonance_strength >= 0.6:
            return 'STABLE'
        elif coherence < 0.4 and resonance_strength >= 0.6:
            return 'CHAOTIC'
        elif coherence >= 0.6 and resonance_strength < 0.4:
            return 'DORMANT'
        else:
            return 'NOISE'

    def _generate_mutation_directive(self, state: str, coherence: float,
                                      resonance_strength: float) -> dict:
        """
        Generate mutation directive based on semantic state.

        Args:
            state: Semantic state classification
            coherence: Coherence value
            resonance_strength: Resonance strength

        Returns:
            Mutation directive dictionary
        """
        if state == 'STABLE':
            return {
                'preserve': True,
                'mutation_rate': 0.01,
                'exploration_bias': 0.0,
                'consolidation_weight': 1.0
            }
        elif state == 'CHAOTIC':
            return {
                'preserve': False,
                'mutation_rate': 0.3,
                'exploration_bias': 0.8,
                'consolidation_weight': 0.2
            }
        elif state == 'DORMANT':
            return {
                'preserve': True,
                'mutation_rate': 0.1,
                'exploration_bias': 0.3,
                'consolidation_weight': 0.5
            }
        else:  # NOISE
            return {
                'preserve': False,
                'mutation_rate': 0.5,
                'exploration_bias': 1.0,
                'consolidation_weight': 0.0
            }

    def batch_process(self, resonances: list) -> list:
        """
        Process a batch of resonances through grammar.

        Args:
            resonances: List of resonance dictionaries

        Returns:
            List of semantic interpretation dictionaries
        """
        return [self.process(r) for r in resonances]

    def generate_summary(self, semantics: list) -> dict:
        """
        Generate summary statistics for a batch of semantic interpretations.

        Args:
            semantics: List of semantic dictionaries

        Returns:
            Summary statistics dictionary
        """
        if not semantics:
            return {
                'total': 0,
                'stable': 0,
                'chaotic': 0,
                'dormant': 0,
                'noise': 0
            }

        state_counts = {
            'STABLE': 0,
            'CHAOTIC': 0,
            'DORMANT': 0,
            'NOISE': 0
        }

        for s in semantics:
            state = s.get('semantic_state', 'NOISE')
            state_counts[state] = state_counts.get(state, 0) + 1

        avg_entropy = sum(s.get('semantic_entropy', 0) for s in semantics) / len(semantics)
        avg_density = sum(s.get('semantic_density', 0) for s in semantics) / len(semantics)

        return {
            'total': len(semantics),
            'stable': state_counts['STABLE'],
            'chaotic': state_counts['CHAOTIC'],
            'dormant': state_counts['DORMANT'],
            'noise': state_counts['NOISE'],
            'avg_entropy': avg_entropy,
            'avg_density': avg_density,
            'stability_rate': state_counts['STABLE'] / len(semantics)
        }
