"""QLOGIC Logic Core Components"""

from .oscillator_core import OscillatorCore
from .spectral_grammar import SpectralGrammar

__all__ = ['OscillatorCore', 'SpectralGrammar']
