#!/usr/bin/env python3
"""
QLOGIC Self-Model
=================

Meta-interpreter that analyzes the QLOGIC system's own state,
measuring stability, entropy, and evolutionary dynamics.

Self-Referential Analysis:
- System entropy: measure of semantic disorder
- Stability drift: rate of change in coherence distribution
- Resonance convergence: approach to equilibrium state
- Grammar effectiveness: mutation success rate
"""

import math
from typing import Dict, List


class SelfModel:
    """
    QLOGIC Self-Referential Model

    Analyzes the system's own evolutionary trajectory and adjusts
    internal parameters for optimal performance.
    """

    def __init__(self):
        self.history = []
        self.entropy_history = []
        self.stability_history = []

    def measure_entropy(self, evaluated_seeds: list) -> float:
        """
        Measure semantic entropy across evaluated seed ensemble.

        Shannon entropy adapted for semantic phase space:
        H = -Σ p_i log(p_i)

        Where p_i is the probability of each semantic state.

        Args:
            evaluated_seeds: List of evaluated seed dictionaries

        Returns:
            Entropy value [0, log(4)] for 4 states
        """
        if not evaluated_seeds:
            return 0.0

        # Count semantic states (assuming they have semantic_state field)
        # If not available, use delta_psi as proxy
        state_counts = {}

        for seed in evaluated_seeds:
            # Use delta_psi as entropy indicator
            delta_psi = abs(seed.get('delta_psi', 0.0))

            if delta_psi < 0.1:
                state = 'STABLE'
            elif delta_psi < 0.3:
                state = 'DORMANT'
            elif delta_psi < 0.6:
                state = 'CHAOTIC'
            else:
                state = 'NOISE'

            state_counts[state] = state_counts.get(state, 0) + 1

        # Compute Shannon entropy
        total = len(evaluated_seeds)
        entropy = 0.0

        for count in state_counts.values():
            if count > 0:
                p = count / total
                entropy -= p * math.log(p + 1e-10)  # Add epsilon to avoid log(0)

        self.entropy_history.append(entropy)

        return entropy

    def measure_stability_drift(self, current_stability: float) -> float:
        """
        Measure rate of change in system stability.

        Args:
            current_stability: Current stability rate [0, 1]

        Returns:
            Stability drift (positive = increasing, negative = decreasing)
        """
        self.stability_history.append(current_stability)

        if len(self.stability_history) < 2:
            return 0.0

        # Compute drift as derivative
        drift = self.stability_history[-1] - self.stability_history[-2]

        return drift

    def analyze_convergence(self) -> dict:
        """
        Analyze system convergence toward equilibrium.

        Returns:
            Convergence analysis dictionary
        """
        if len(self.entropy_history) < 3:
            return {
                'converging': False,
                'entropy_trend': 'UNKNOWN',
                'stability_trend': 'UNKNOWN',
                'cycles_to_equilibrium': None
            }

        # Entropy trend (decreasing = converging to order)
        recent_entropy = self.entropy_history[-3:]
        entropy_slope = (recent_entropy[-1] - recent_entropy[0]) / 3

        if abs(entropy_slope) < 0.01:
            entropy_trend = 'STABLE'
        elif entropy_slope < 0:
            entropy_trend = 'DECREASING'
        else:
            entropy_trend = 'INCREASING'

        # Stability trend
        if len(self.stability_history) >= 3:
            recent_stability = self.stability_history[-3:]
            stability_slope = (recent_stability[-1] - recent_stability[0]) / 3

            if abs(stability_slope) < 0.01:
                stability_trend = 'STABLE'
            elif stability_slope > 0:
                stability_trend = 'INCREASING'
            else:
                stability_trend = 'DECREASING'
        else:
            stability_trend = 'UNKNOWN'

        # Convergence detection
        converging = (entropy_trend == 'STABLE' and stability_trend in ['STABLE', 'INCREASING'])

        # Estimate cycles to equilibrium
        if converging:
            cycles_to_equilibrium = 0  # Already converged
        elif abs(entropy_slope) > 0.001:
            # Rough estimate: current_entropy / |slope|
            cycles_to_equilibrium = int(abs(self.entropy_history[-1] / entropy_slope))
        else:
            cycles_to_equilibrium = None

        return {
            'converging': converging,
            'entropy_trend': entropy_trend,
            'stability_trend': stability_trend,
            'entropy_slope': entropy_slope,
            'cycles_to_equilibrium': cycles_to_equilibrium
        }

    def recommend_adjustments(self, convergence: dict, entropy: float,
                               stability: float) -> dict:
        """
        Recommend system parameter adjustments based on analysis.

        Args:
            convergence: Convergence analysis from analyze_convergence()
            entropy: Current entropy value
            stability: Current stability rate

        Returns:
            Recommended adjustments dictionary
        """
        recommendations = {
            'continue_evolution': True,
            'adjust_mutation_rate': 0.0,
            'adjust_por_threshold': 0.0,
            'increase_exploration': False,
            'consolidate_memory': False
        }

        # If entropy too high, increase exploration
        if entropy > 1.5:
            recommendations['increase_exploration'] = True
            recommendations['adjust_mutation_rate'] = 0.1

        # If converging with high stability, consolidate
        if convergence['converging'] and stability > 0.7:
            recommendations['consolidate_memory'] = True
            recommendations['continue_evolution'] = False

        # If stability decreasing, tighten PoR threshold
        if convergence['stability_trend'] == 'DECREASING':
            recommendations['adjust_por_threshold'] = 0.05

        # If entropy increasing rapidly, reduce mutation
        if convergence['entropy_trend'] == 'INCREASING':
            recommendations['adjust_mutation_rate'] = -0.05

        return recommendations

    def log_cycle(self, cycle_data: dict):
        """
        Log evolution cycle data to history.

        Args:
            cycle_data: Dictionary with cycle statistics
        """
        self.history.append(cycle_data)

    def export_history(self) -> dict:
        """
        Export complete evolution history.

        Returns:
            History dictionary
        """
        return {
            'cycles': self.history,
            'entropy_history': self.entropy_history,
            'stability_history': self.stability_history,
            'total_cycles': len(self.history)
        }
