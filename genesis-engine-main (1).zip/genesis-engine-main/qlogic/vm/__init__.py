"""QLOGIC Virtual Machine Components"""

from .qlogic_self_model import SelfModel

__all__ = ['SelfModel']
