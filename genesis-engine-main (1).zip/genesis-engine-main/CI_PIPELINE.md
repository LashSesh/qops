# Genesis Engine CI/CD Pipeline

## Overview

The Genesis Continuous Integration and Performance Validation pipeline provides automated build, test, and spectral-performance validation for the Genesis Engine ecosystem.

## Pipeline Architecture

The CI/CD pipeline consists of five main stages:

### 1. Build Stage (`01_build`)
- **Description**: Compile core components and ensure environment consistency
- **Commands**:
  - `cargo build --release` - Build Rust components
  - `python3 -m compileall ./api` - Compile Python modules
- **Expected**: Build status = success

### 2. Unit Tests Stage (`02_unit_tests`)
- **Description**: Run Python and Rust unit tests across all modules
- **Commands**:
  - `pytest --disable-warnings -q` (if Python tests exist)
  - `cargo test --release`
- **Expected**: Test pass rate ≥ 98%
- **Note**: Some existing tests may fail due to the current state of the codebase

### 3. Benchmarks Stage (`03_benchmarks`)
- **Description**: Benchmark core operations
- **Benchmarks**:
  - **TIC Conversion**: O(1) complexity, target: 1.0 ms
  - **Domain Projection**: O(n) complexity (n=5), target: 5.0 ms
  - **Rule Matrix Normalization**: O(k) complexity (k=100), target: 50.0 ms
  - **Validation**: O(n²) complexity (n=5), target: 25.0 ms
  - **Throughput**: Target: 1000 ops/sec (±10% tolerance)
- **Commands**:
  - `python benchmarks/run_benchmarks.py --output perf_results.json`
  - `python scripts/validate_perf.py --target perf_targets.json --results perf_results.json`
- **Expected**: Throughput ≥ 900 ops/sec

### 4. Spectral Validation Stage (`04_spectral_validation`)
- **Description**: Ensure spectral and thermodynamic invariants are within expected ranges
- **Metrics**:
  - **ΔΦ** (spectral phase drift): < 0.01
  - **ΔS** (entropy change): < 1e-3
  - **ΔΣ** (variance change): < 0.02
  - **Entropy decay rate**: < 0.001
- **Commands**:
  - `python scripts/validate_spectral.py --log spectral_results.json`
- **Expected**: Spectral stability = true

### 5. Audit and Reporting Stage (`05_audit_and_reporting`)
- **Description**: Generate audit, performance, and stability reports
- **Outputs**:
  - `perf_results.json` - Performance benchmark results
  - `spectral_results.json` - Spectral validation results
  - `coherence_audit.json` - Comprehensive coherence audit
  - `meta_reflection_summary.md` - Meta-reflection summary
- **Expected**: 3+ reports generated

## Running Locally

### Prerequisites
- Rust ≥ 1.80
- Python ≥ 3.10
- pytest ≥ 8.0
- numpy ≥ 2.0

### Run Individual Stages

#### Build
```bash
cargo build --release
python3 -m compileall ./api
```

#### Unit Tests
```bash
pytest --disable-warnings -q  # If Python tests exist
cargo test --release
```

#### Benchmarks
```bash
python benchmarks/run_benchmarks.py --output perf_results.json
python scripts/validate_perf.py --target perf_targets.json --results perf_results.json
```

#### Spectral Validation
```bash
python scripts/validate_spectral.py --target perf_targets.json --log spectral_results.json
```

#### Audit Generation
```bash
python scripts/generate_audit.py --perf perf_results.json --spectral spectral_results.json --output coherence_audit.json
```

### Run Complete Pipeline
```bash
# Build
cargo build --release

# Run benchmarks
python benchmarks/run_benchmarks.py --output perf_results.json

# Validate performance
python scripts/validate_perf.py --target perf_targets.json --results perf_results.json

# Validate spectral metrics
python scripts/validate_spectral.py --target perf_targets.json --log spectral_results.json

# Generate audit
python scripts/generate_audit.py --perf perf_results.json --spectral spectral_results.json --output coherence_audit.json
```

## Performance Targets

Performance targets are defined in `perf_targets.json`:

```json
{
  "benchmarks": {
    "TIC_conversion": {
      "complexity": "O(1)",
      "target_time_ms": 1.0
    },
    "Domain_projection": {
      "complexity": "O(n)",
      "n": 5,
      "target_time_ms": 5.0
    },
    "Rule_matrix_normalization": {
      "complexity": "O(k)",
      "k": 100,
      "target_time_ms": 50.0
    },
    "Validation": {
      "complexity": "O(n^2)",
      "n": 5,
      "target_time_ms": 25.0
    },
    "Throughput": {
      "target_ops_per_sec": 1000,
      "acceptance_tolerance": 0.10
    }
  },
  "spectral_metrics": {
    "delta_phi": { "max_value": 0.01 },
    "delta_s": { "max_value": 0.001 },
    "delta_sigma": { "max_value": 0.02 },
    "entropy_decay_rate": { "max_value": 0.001 }
  }
}
```

## Failure Policy

The pipeline follows these failure policies:

- **On Failure**:
  - Mark pipeline as unstable
  - Notify via GitHub Actions status
  - Artifact retention for debugging (30 days)

- **Rollback Condition**:
  - Throughput < 900 ops/sec, OR
  - ΔΦ > 0.01

## Telemetry Integration

The pipeline integrates with telemetry systems:

- **Metrics Collected**:
  - Build time
  - Test pass rate
  - Throughput (ops/sec)
  - Entropy gradient
  - Spectral stability index

- **Update Interval**: 120s (configurable)

- **Integration Options**:
  - Prometheus exporter: Available
  - Grafana dashboard: Configuration ready
  - WebSocket telemetry: `ws://lexicon_api:8080/ci`

## Artifact Storage

CI artifacts are stored with the following retention:

- **Path**: GitHub Actions artifacts
- **Artifacts**:
  - `perf_results.json`
  - `spectral_results.json`
  - `coherence_audit.json`
  - `meta_reflection_summary.md`
  - Build artifacts (binaries)
- **Retention**: 30 days

## Expected Outcomes

The CI/CD pipeline guarantees:

1. **Functional integrity** of Genesis Core
2. **Operator throughput** ≥ 1000 ops/sec (±10%)
3. **Spectral invariants** maintained within bounds
4. **Automatic regression detection**

## Scientific Value

This pipeline provides:

1. **Benchmark reproducibility** of resonance-based computation
2. **Evidence for deterministic operator throughput** under spectral constraints
3. **Validation of cross-domain stability** and scaling performance

## Troubleshooting

### Benchmark Failures
- Check `perf_results.json` for detailed timing information
- Ensure system has adequate resources (CPU, RAM)
- Run benchmarks multiple times to account for variance

### Spectral Validation Failures
- Review `spectral_results.json` for specific metrics out of range
- Check for entropy sources or instabilities in the system
- Verify thermodynamic consistency

### Build Failures
- Check Rust version: `cargo --version` (should be ≥ 1.80)
- Verify dependencies are up to date: `cargo update`
- Check Python version: `python3 --version` (should be ≥ 3.10)

## Contributing

When contributing to the CI/CD pipeline:

1. Update `perf_targets.json` if adding new benchmarks
2. Add corresponding validation logic to `validate_perf.py`
3. Document any new metrics in this README
4. Ensure all scripts are executable and have proper error handling
5. Test locally before pushing to CI

## License

CC-BY-4.0 - See repository LICENSE for details
