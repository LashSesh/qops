# Quick Start Guide - Metatron Operator Cosmos Stack

## 5-Minute Deployment

### Prerequisites
- Docker 20.10+ and Docker Compose 2.0+
- 4GB RAM available
- 10GB disk space

### Steps

1. **Clone and Enter Directory**
   ```bash
   git clone https://github.com/LashSesh/genesis-engine.git
   cd genesis-engine
   ```

2. **Configure Environment**
   ```bash
   # Create .env file from template
   cp .env.example .env
   
   # Edit .env and set secure passwords/keys
   # At minimum, change:
   # - POSTGRES_PASSWORD
   # - API_KEY (generate with: openssl rand -hex 32)
   ```

3. **Start Everything**
   ```bash
   make all
   ```
   
   This will:
   - Build all Docker images
   - Start all services (Kernel, API, UI, Database)
   - Run the Genesis Routine to initialize the system
   - Seed the operator lexicon with initial operators

4. **Access the System**
   - **Dashboard**: http://localhost:3000
   - **API**: http://localhost:8080
   - **API Docs**: http://localhost:8080/docs

### What You'll See

**Dashboard** displays three main views:
- **Operator Lexicon** - List of mined operators with stability metrics
- **Analytics** - System-wide statistics
- **Telemetry** - Real-time system metrics (ΔH, ΔS, ψρω variance)

### Common Commands

```bash
# View logs
make logs

# Stop everything
make down

# Restart services
make restart

# Clean reset (deletes all data)
make clean

# Check status
make status
```

### Troubleshooting

**Services won't start:**
```bash
docker-compose ps  # Check status
docker-compose logs -f  # View logs
```

**Genesis routine fails:**
```bash
# Wait for services to be fully ready (30-60 seconds)
sleep 30
./genesis_routine.sh
```

**Port conflicts:**
Edit `docker-compose.yml` and change port mappings:
```yaml
ports:
  - "8080:8080"  # Change first number to use different port
```

### Next Steps

1. Explore the operator lexicon at http://localhost:3000
2. Try the API at http://localhost:8080/docs
3. Watch real-time telemetry streaming
4. Read [DEPLOYMENT.md](DEPLOYMENT.md) for advanced configuration
5. Check [README.md](README.md) for CLI usage

### Manual Deployment (Without Make)

```bash
# Build images
docker build -f kernel/Dockerfile -t metatron/resonance-kernel:latest .
docker build -f api/Dockerfile -t metatron/lexicon-api:latest .
docker build -f ui/Dockerfile -t metatron/dashboard-ui:latest .

# Start services
docker-compose up -d

# Wait for services (30-60 seconds)
sleep 30

# Initialize system
./genesis_routine.sh
```

## Architecture Overview

```
┌─────────────────┐
│  Dashboard UI   │  ← http://localhost:3000
│   (React/TS)    │
└────────┬────────┘
         │
┌────────▼────────┐
│  Lexicon API    │  ← http://localhost:8080
│ (FastAPI/Python)│
└────┬────────┬───┘
     │        │
┌────▼────┐ ┌▼──────────┐
│ Kernel  │ │PostgreSQL │
│ (Rust)  │ │    DB     │
└─────────┘ └───────────┘
```

## System Requirements

**Minimum:**
- CPU: 2 cores
- RAM: 4GB
- Disk: 10GB

**Recommended:**
- CPU: 4+ cores
- RAM: 8GB+
- Disk: 20GB+ SSD

## Support

- Issues: https://github.com/LashSesh/genesis-engine/issues
- Documentation: See `docs/` directory
- Deployment Guide: [DEPLOYMENT.md](DEPLOYMENT.md)
