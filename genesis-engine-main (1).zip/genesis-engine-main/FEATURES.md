# MOGE New Features

This document describes the new features added to the Metatronic Operator Genesis Engine (MOGE).

## Table of Contents

1. [Graphviz Path Export](#graphviz-path-export)
2. [Plugin System](#plugin-system)
3. [Distributed Traversal](#distributed-traversal)
4. [Quantum Simulator Integration](#quantum-simulator-integration)
5. [WebAssembly Support](#webassembly-support)
6. [Web-based Visualization](#web-based-visualization)

---

## Graphviz Path Export

Export artefact traversal paths as Graphviz DOT files for visualization.

### Usage

```bash
# Export as Graphviz DOT
moge-cli export --format graphviz --output paths

# Export as CSV
moge-cli export --format csv --output stats

# Export as JSON
moge-cli export --format json --output data
```

### Visualizing Graphviz Output

```bash
# Generate PNG
dot -Tpng paths.dot -o paths.png

# Generate SVG
dot -Tsvg paths.dot -o paths.svg

# Generate interactive HTML
dot -Tsvg paths.dot | your-browser
```

### API Usage

```rust
use genesis_engine::export::{export_artefact_path_graphviz, GraphvizOptions};
use genesis_engine::graph::MetatronCube;

let graph = MetatronCube::new();
let options = GraphvizOptions {
    show_weights: true,
    show_deltas: true,
    highlight_mandorla: true,
    color_scheme: "spectral".to_string(),
    max_nodes: Some(100),
};

let dot = export_artefact_path_graphviz(&artefact, &graph, &options)?;
std::fs::write("path.dot", dot)?;
```

### Color Schemes

- **spectral**: Blue → Green → Red gradient
- **plasma**: Purple → Orange → Yellow gradient
- **viridis**: Dark blue → Green → Yellow gradient

---

## Plugin System

Extend MOGE functionality with custom plugins.

### Built-in Plugins

1. **StatisticsPlugin**: Collects traversal statistics
2. **LoggingPlugin**: Logs events during traversal
3. **CustomResonancePlugin**: Custom signature evaluation

### Creating a Plugin

```rust
use genesis_engine::plugin::{Plugin, PluginManager};
use genesis_engine::artefact::Artefact;
use genesis_engine::error::Result;

struct MyPlugin {
    name: String,
}

impl Plugin for MyPlugin {
    fn name(&self) -> &str {
        &self.name
    }

    fn version(&self) -> &str {
        "1.0.0"
    }

    fn on_artefact_created(&mut self, artefact: &Artefact) -> Result<()> {
        println!("Artefact created: {}", artefact.id);
        Ok(())
    }
}
```

### Using Plugins

```rust
let mut manager = PluginManager::new();
manager.register(Box::new(MyPlugin { name: "my_plugin".to_string() }))?;
manager.initialize_all()?;

// Plugins will be called during traversal
manager.on_artefact_created(&artefact)?;
```

### Plugin Events

- `initialize()`: Called when plugin is loaded
- `on_traversal_start(agent)`: Called before traversal begins
- `on_step(agent, node)`: Called after each traversal step
- `on_artefact_created(artefact)`: Called when artefact is created
- `on_traversal_complete(artefact)`: Called after traversal finishes
- `evaluate_signature(signature)`: Custom signature evaluation

---

## Distributed Traversal

Distribute MOGE computations across multiple nodes.

### Architecture

```
┌──────────────────┐
│   Coordinator    │
│  (Work Manager)  │
└────────┬─────────┘
         │
    ┌────┴────┬────────┬────────┐
    │         │        │        │
┌───▼───┐ ┌──▼───┐ ┌──▼───┐ ┌──▼───┐
│Node 1 │ │Node 2│ │Node 3│ │Node N│
│(Worker)│(Worker)│(Worker)│(Worker)
└───────┘ └──────┘ └──────┘ └──────┘
```

### Usage

```rust
use genesis_engine::distributed::{DistributedCoordinator, CoordinatorConfig, WorkUnit};
use genesis_engine::agent::AgentConfig;

// Create coordinator
let config = CoordinatorConfig::default();
let coordinator = DistributedCoordinator::new(config);

// Register compute nodes
coordinator.register_node("node1".to_string(), 10)?;
coordinator.register_node("node2".to_string(), 10)?;

// Submit work
let work_units = vec![
    WorkUnit {
        id: uuid::Uuid::new_v4(),
        agent_config: AgentConfig::default(),
        start_node: 0,
        assigned_to: None,
        status: WorkStatus::Pending,
    },
    // ... more work units
];

coordinator.submit_work(work_units)?;

// Workers get work
if let Some(work) = coordinator.get_work("node1")? {
    // Process work...
    let result = DistributedResult {
        work_id: work.id,
        node_id: "node1".to_string(),
        artefact: Some(artefact),
        error: None,
        execution_time_ms: 1000,
    };
    coordinator.submit_result(result)?;
}

// Get statistics
let stats = coordinator.get_statistics()?;
println!("Completed: {} / {}", stats.completed, stats.total_work);
```

### Features

- Automatic work distribution
- Load balancing
- Fault tolerance with work reassignment
- Timeout detection
- Retry mechanism for failed work

---

## Quantum Simulator Integration

Quantum-inspired traversal strategies and optimization.

### Quantum State

```rust
use genesis_engine::quantum::{QuantumState, QuantumTraversal};

// Create quantum state over nodes
let state = QuantumState::new(vec![0, 1, 2, 3, 4]);

// Measure (collapse to classical state)
let node = state.measure();
```

### Quantum Traversal

```rust
let mut traversal = QuantumTraversal::new(vec![0, 1, 2, 3], 1.0);

// Quantum walk step
traversal.quantum_walk_step(&adjacency)?;

// Quantum annealing
traversal.anneal_step(|node| {
    // Energy function
    signature_quality(node)
})?;

// Get most probable state
let best_node = traversal.get_dominant_state();
```

### Quantum Features

- **Quantum Superposition**: Explore multiple paths simultaneously
- **Quantum Annealing**: Escape local minima
- **Quantum Tunneling**: Probabilistic barrier crossing
- **Entanglement**: Correlated path exploration
- **Interference**: Enhanced path selection

### Quantum-Enhanced Signature Evaluation

```rust
use genesis_engine::quantum::quantum_signature_evaluation;

let score = quantum_signature_evaluation(&signature, temperature);
```

---

## WebAssembly Support

Run MOGE in the browser with WebAssembly.

### Building for WASM

```bash
# Install wasm-pack
curl https://rustwasm.github.io/wasm-pack/installer/init.sh -sSf | sh

# Build WASM module
wasm-pack build --target web --features wasm

# Output will be in pkg/
```

### Using in JavaScript

```html
<script type="module">
  import init, { WasmSimulation, get_version } from './pkg/genesis_engine.js';

  await init();

  console.log('MOGE Version:', get_version());

  const sim = new WasmSimulation(10, 50, 5);
  const result = sim.run();
  console.log(JSON.parse(result));
</script>
```

### WASM API

- `WasmSimulation::new(agents, steps, generations)`: Create simulation
- `WasmSimulation::run()`: Run simulation, returns JSON
- `WasmSimulation::get_stats()`: Get ledger statistics
- `WasmTraversal::new()`: Create traversal engine
- `WasmTraversal::run_single(steps, strategy)`: Run single traversal
- `get_version()`: Get MOGE version
- `create_signature(psi, rho, omega, chi, eta)`: Create signature
- `calculate_resonance(signature_json)`: Calculate resonance

---

## Web-based Visualization

Interactive browser-based visualization with WebGL.

### Features

- Real-time WebGL rendering
- Interactive graph exploration
- Color-coded resonance visualization
- Live statistics dashboard
- Export capabilities

### Running the Web Interface

```bash
# Serve the web directory
cd web
python3 -m http.server 8000

# Open in browser
open http://localhost:8000
```

### Web Interface Controls

- **Number of Agents**: Set swarm size (1-100)
- **Max Steps**: Set traversal length (10-1000)
- **Generations**: Set evolution cycles (1-50)
- **Strategy**: Choose traversal algorithm
  - Balanced
  - Gradient Ascent
  - Stability Maximization
  - Cycle Recognition
  - Random Walk

### Visualization Legend

- 🟢 **Green**: High resonance (> 0.8)
- 🟡 **Yellow**: Medium resonance (0.5-0.8)
- 🔴 **Red**: Low resonance (< 0.5)

### Integration with WASM

The web interface uses the WASM module for computation:

```javascript
// Load WASM module
import init, { WasmSimulation } from './pkg/genesis_engine.js';
await init();

// Run simulation
const sim = new WasmSimulation(agents, steps, generations);
const result = JSON.parse(sim.run());

// Update visualization
updateWebGL(result);
```

---

## Performance Considerations

### Graphviz Export

- Large graphs (>1000 nodes) may be slow to render
- Use `max_nodes` option to limit output size
- Consider exporting subgraphs for complex artefacts

### Plugin System

- Plugins add overhead to each event
- Disable plugins when not needed: `manager.set_enabled(false)`
- Use asynchronous plugins for non-blocking operations

### Distributed Traversal

- Network latency affects performance
- Use larger work units to reduce coordination overhead
- Enable work redistribution for fault tolerance

### Quantum Simulation

- Quantum state grows exponentially with basis size
- Keep basis states to reasonable numbers (<1000)
- Use quantum annealing for optimization, not exploration

### WebAssembly

- WASM has ~10-20% overhead compared to native
- Large simulations may be slower in browser
- Use web workers for background computation

---

## Examples

See the `examples/` directory for complete working examples:

- `examples/graphviz_export.rs`: Export visualization data
- `examples/plugin_usage.rs`: Using the plugin system
- `examples/distributed_sim.rs`: Distributed computation
- `examples/quantum_traversal.rs`: Quantum-inspired traversal
- `examples/wasm_demo.html`: Web interface demo

---

## License

All new features are released under the same CC-BY-4.0 license as MOGE.
