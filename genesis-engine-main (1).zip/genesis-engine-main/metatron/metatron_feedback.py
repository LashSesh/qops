#!/usr/bin/env python3
"""
Metatron Feedback Coupler - Geometric Operator Mapping
=======================================================

Projects operators onto a 5D Metatron geometry (hyperspherical coordinates)
and generates feedback vectors based on spatial clustering and resonance patterns.

The geometric topology influences mutation heuristics:
- Operators in dense regions receive conservative mutations
- Operators in sparse regions receive exploratory mutations
- Resonance gradients guide search direction

Metatron Geometry: S⁴ × ℝ (4-sphere cross real line)
Coordinates: (x, y, z, w, t) where x²+y²+z²+w² = 1, t ∈ ℝ
"""

import json
import math
from pathlib import Path
from typing import Dict, List, Tuple


class MetatronFeedback:
    """
    Metatron Geometric Feedback System

    Maps operators to geometric positions and computes feedback vectors
    for adaptive mutation guidance.
    """

    def __init__(self, ontology_path: str = 'data/operator_ontology.json'):
        """
        Initialize Metatron feedback system.

        Args:
            ontology_path: Path to operator ontology
        """
        self.ontology_path = Path(ontology_path)
        self.map_path = Path('data/metatron_map.json')
        self.map_path.parent.mkdir(parents=True, exist_ok=True)

        # Load operator ontology
        if self.ontology_path.exists():
            with open(self.ontology_path, 'r') as f:
                self.ops = json.load(f)
            print(f"🔷 Loaded {len(self.ops)} operators for geometric projection")
        else:
            self.ops = []
            print("⚠ Warning: Operator ontology not found")

    def project_to_geometry(self) -> dict:
        """
        Project all operators onto Metatron 5D geometry.

        Returns:
            Projection summary dictionary
        """
        if not self.ops:
            print("⚠ No operators to project")
            return {'total_projected': 0}

        print("🔷 Projecting operators to Metatron geometry...")

        mapped = []

        for i, op in enumerate(self.ops):
            # Extract operator parameters
            psi = op.get('psi', 0.0)
            omega = op.get('omega', 0.0)
            entropy = op.get('entropy', 0.0)

            # Compute 5D hyperspherical coordinates
            # Use operator index and parameters for deterministic mapping
            theta = (i * math.pi / 12 + psi) % (2 * math.pi)
            phi = (i * math.pi / 8 + omega) % (2 * math.pi)
            psi_angle = (entropy * math.pi) % (2 * math.pi)

            # 4-sphere embedding (x, y, z, w)
            x = math.sin(theta) * math.cos(phi) * math.cos(psi_angle)
            y = math.sin(theta) * math.sin(phi) * math.cos(psi_angle)
            z = math.cos(theta) * math.cos(psi_angle)
            w = math.sin(psi_angle)

            # 5th dimension: temporal evolution coordinate
            t = op.get('origin_cycle', 0) * 0.1

            # Assign geometry node
            geometry_node = {
                'x': round(x, 6),
                'y': round(y, 6),
                'z': round(z, 6),
                'w': round(w, 6),
                't': round(t, 6),
                'radius': round(math.sqrt(x**2 + y**2 + z**2 + w**2), 6)
            }

            op['geometry_node'] = geometry_node
            mapped.append(op)

        # Compute spatial density and feedback vectors
        mapped = self._compute_feedback_vectors(mapped)

        # Save geometric map
        with open(self.map_path, 'w') as f:
            json.dump(mapped, f, indent=2)

        # Generate projection summary
        summary = {
            'total_projected': len(mapped),
            'avg_radius': round(sum(op['geometry_node']['radius'] for op in mapped) / len(mapped), 3),
            'temporal_range': (
                min(op['geometry_node']['t'] for op in mapped),
                max(op['geometry_node']['t'] for op in mapped)
            )
        }

        summary_path = Path('reports/reflexivity/metatron_summary.json')
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=2)

        print(f"  ✓ Projected {len(mapped)} operators")
        print(f"  ✓ Average radius: {summary['avg_radius']}")
        print(f"  ✓ Temporal range: {summary['temporal_range']}")
        print(f"  ✓ Geometric map saved to {self.map_path}")

        return summary

    def _compute_feedback_vectors(self, operators: List[Dict]) -> List[Dict]:
        """
        Compute feedback vectors based on spatial density.

        Operators in dense regions get conservative feedback (small mutations).
        Operators in sparse regions get exploratory feedback (large mutations).

        Args:
            operators: List of operators with geometry nodes

        Returns:
            Operators with feedback vectors attached
        """
        for i, op in enumerate(operators):
            # Compute spatial density (average distance to nearest neighbors)
            distances = []
            node_i = op['geometry_node']

            for j, other_op in enumerate(operators):
                if i == j:
                    continue

                node_j = other_op['geometry_node']
                distance = self._hyperspherical_distance(node_i, node_j)
                distances.append(distance)

            # Sort and take 5 nearest neighbors
            distances.sort()
            local_density = sum(distances[:5]) / 5 if len(distances) >= 5 else sum(distances) / max(len(distances), 1)

            # Feedback vector: inversely proportional to density
            # High density → small feedback (conservative)
            # Low density → large feedback (exploratory)
            feedback_magnitude = min(1.0 / (local_density + 0.1), 2.0)

            # Direction: away from center of mass of neighbors
            feedback_vector = {
                'magnitude': round(feedback_magnitude, 6),
                'local_density': round(local_density, 6),
                'mutation_strategy': 'conservative' if local_density < 0.5 else 'exploratory'
            }

            op['feedback_vector'] = feedback_vector

        return operators

    def _hyperspherical_distance(self, node_a: dict, node_b: dict) -> float:
        """
        Compute distance between two points in 5D space.

        Args:
            node_a: First geometry node
            node_b: Second geometry node

        Returns:
            Euclidean distance in 5D
        """
        dx = node_a['x'] - node_b['x']
        dy = node_a['y'] - node_b['y']
        dz = node_a['z'] - node_b['z']
        dw = node_a['w'] - node_b['w']
        dt = node_a['t'] - node_b['t']

        return math.sqrt(dx**2 + dy**2 + dz**2 + dw**2 + dt**2)

    def get_feedback_for_operator(self, operator_id: str) -> dict:
        """
        Retrieve feedback vector for specific operator.

        Args:
            operator_id: Operator ID

        Returns:
            Feedback vector dictionary
        """
        if not self.map_path.exists():
            return {'error': 'Geometric map not yet generated'}

        with open(self.map_path, 'r') as f:
            mapped_ops = json.load(f)

        operator = next((op for op in mapped_ops if op['id'] == operator_id), None)

        if not operator:
            return {'error': f'Operator {operator_id} not found in geometric map'}

        return operator.get('feedback_vector', {})


def main():
    """Standalone execution for Metatron feedback generation."""
    metatron = MetatronFeedback()
    summary = metatron.project_to_geometry()

    print()
    print("=" * 80)
    print("Metatron Geometric Projection Complete")
    print("=" * 80)
    print(f"Total Operators Projected: {summary['total_projected']}")
    print(f"Average Radius: {summary.get('avg_radius', 0)}")
    print(f"Temporal Range: {summary.get('temporal_range', (0, 0))}")
    print("=" * 80)


if __name__ == '__main__':
    main()
