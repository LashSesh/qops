"""
Operator Lexicon API - FastAPI Server
Exposes the Operator Lexicon and Ledger data via REST API and WebSocket
"""

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel
import json
import os
import asyncio
from collections import defaultdict

app = FastAPI(
    title="Metatron Operator Lexicon API",
    description="HTTP/REST API exposing the Operator Lexicon and Ledger data",
    version="1.0.0"
)

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configuration from environment
DB_URL = os.getenv("DB_URL")
if not DB_URL:
    raise ValueError("DB_URL environment variable must be set")
LEDGER_PATH = os.getenv("LEDGER_PATH", "/data/ledger")
ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY")
if not ENCRYPTION_KEY:
    raise ValueError("ENCRYPTION_KEY environment variable must be set")
ENABLE_WEBSOCKETS = os.getenv("ENABLE_WEBSOCKETS", "true").lower() == "true"

# In-memory storage (would be backed by PostgreSQL in production)
operators_db = {}
ledger_db = {}
telemetry_buffer = []
cubechain_db = {
    "cubes": {},
    "transitions": {},
    "enabled": False,
    "genesis_id": None
}

# Meta-cognition database
meta_cognition_db = {
    "patterns": {},
    "reasoning_rules": {},
    "meta_reports": {},
    "telemetry": [],
    "enabled": False
}

# IRG Core database
irg_core_db = {
    "cores": {},  # IRG Core instances
    "signatures": {},  # Spectral signatures
    "learning_history": {},  # Learning cycle history
    "mutations": [],  # Mutation events
    "telemetry": [],  # IRG telemetry
    "enabled": False
}

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except:
                pass

manager = ConnectionManager()

# ========== API Models ==========

class OperatorSummary(BaseModel):
    id: str
    name: Optional[str] = None
    stability: float
    entropy_gradient: float
    symmetry_class: str
    mandorla_certified: bool
    created_at: datetime

class OperatorManifest(BaseModel):
    id: str
    name: Optional[str] = None
    creation_timestamp: datetime
    origin: dict
    resonance_tensor: dict
    topology_signature: dict
    entropic_dynamics: dict
    mandorla_state: dict
    gabriel_cluster: dict
    proof_of_resonance: dict
    visualization_metadata: dict
    relations: List[dict] = []
    semantic_tags: List[str] = []
    user_annotations: List[dict] = []

class LedgerHeader(BaseModel):
    id: str
    hash: str
    timestamp: datetime
    energy: float

class AnalyticsResponse(BaseModel):
    total_operators: int
    average_entropy: float
    mean_stability: float
    dominant_symmetry_class: str
    recent_activity: List[tuple]

class CubeManifest(BaseModel):
    id: str
    signature: dict  # {psi, rho, omega, chi, eta}
    operator_basis: dict  # {DK, WT, PI, SW}
    beta_symmetry: float
    s_field: float
    proof_score: float
    antipode_id: Optional[str] = None
    generation: int
    parents: List[str] = []
    created_at: datetime

class TransitionManifest(BaseModel):
    id: str
    from_cube: str
    to_cube: str
    operator: str  # DK, WT, PI, or SW
    resonance_amplitude: float
    phase_delta: float
    energy_delta: float
    entropy_delta: float
    validated: bool

class CubechainStats(BaseModel):
    total_cubes: int
    validated_transitions: int
    mean_entropy: float
    stability_index: float
    metatron_nodes: int

class StatusResponse(BaseModel):
    status: str
    version: str
    database: str
    ledger_path: str
    operators_count: int
    ledger_entries: int

class TelemetryMessage(BaseModel):
    type: str
    cycle: Optional[int] = None
    delta_h: Optional[float] = None
    delta_s: Optional[float] = None
    psi_variance: Optional[float] = None
    message: Optional[str] = None

# Meta-Cognition Models
class CoherencePattern(BaseModel):
    pattern_id: str
    name: str
    description: str
    confidence: float
    operator_families: List[str]
    temporal_signature: List[float]
    stability_correlation: float

class PatternSpectrum(BaseModel):
    patterns: List[CoherencePattern]
    mean_confidence: float
    dominant_pattern: Optional[str]
    generated_at: datetime

class EmergentTopic(BaseModel):
    topic_id: str
    label: str
    keywords: List[str]
    correlation_strength: float
    operator_count: int

class SemanticMap(BaseModel):
    topics: List[EmergentTopic]
    latent_dimensions: List[tuple]
    generated_at: datetime

class ReasoningRule(BaseModel):
    rule_id: str
    axiom: str
    inference_logic: str
    bayesian_prior_strength: float
    applications: int
    success_rate: float
    created_at: datetime

class SelfReflectionReport(BaseModel):
    timestamp: datetime
    cycle: int
    dominant_pattern: str
    reasoning_trace: str
    confidence: float
    adaptation_suggestion: str
    meta_insights: List[str]

class MetaTelemetry(BaseModel):
    meta_coherence_score: float
    causal_inference_depth: int
    semantic_entropy: float
    self_reflection_density: float
    timestamp: datetime

# IRG Core Models
class SpectralSignatureModel(BaseModel):
    psi: float
    rho: float
    omega: float
    chi: float
    tau: float

class TargetSignatureModel(BaseModel):
    signature: SpectralSignatureModel
    entropy_minimum: float
    domain: str

class IRGStatus(BaseModel):
    current_phase: str  # Initialization, Observation, Mutation, Calibration, Integration
    iteration: int
    delta_sigma: float
    coherence_ratio: float
    is_valid: bool
    has_converged: bool

class IRGTelemetryModel(BaseModel):
    timestamp: int
    spectral_entropy: float
    operator_throughput: int
    coherence_ratio: float
    semantic_integrity: float
    delta_phi_drift: float
    entropy_growth: float

class IRGCoreManifest(BaseModel):
    id: str
    signature: SpectralSignatureModel
    target: TargetSignatureModel
    status: IRGStatus
    system_time: float
    created_at: datetime
    last_updated: datetime

class MutationEvent(BaseModel):
    event_id: str
    core_id: str
    mutation_type: str  # PhaseShift, AmplitudeModulation, SignatureFusion
    before_signature: SpectralSignatureModel
    after_signature: SpectralSignatureModel
    stability_check: bool
    timestamp: datetime

class LearningHistoryEntry(BaseModel):
    core_id: str
    iteration: int
    phase: str
    delta_sigma: float
    current_signature: SpectralSignatureModel
    timestamp: datetime

# ========== API Endpoints ==========

@app.get("/status", response_model=StatusResponse)
async def get_status():
    """Get API status and health information"""
    return StatusResponse(
        status="operational",
        version="1.0.0",
        database=DB_URL,
        ledger_path=LEDGER_PATH,
        operators_count=len(operators_db),
        ledger_entries=len(ledger_db)
    )

@app.get("/operator", response_model=List[OperatorSummary])
async def list_operators(
    tag: Optional[str] = Query(None, description="Filter by semantic tag"),
    stability_min: Optional[float] = Query(None, description="Minimum stability rating"),
    symmetry: Optional[str] = Query(None, description="Filter by symmetry class"),
    sort: Optional[str] = Query(None, description="Sort field (stability, entropy, creation_time)")
):
    """List or search operator entries"""
    results = []
    
    for op_id, op in operators_db.items():
        # Apply filters
        if tag and tag not in op.get("semantic_tags", []):
            continue
        if stability_min and op.get("entropic_dynamics", {}).get("stability_rating", 0) < stability_min:
            continue
        if symmetry and op.get("topology_signature", {}).get("symmetry_class") != symmetry:
            continue
        
        # Create summary
        summary = OperatorSummary(
            id=op["id"],
            name=op.get("name"),
            stability=op.get("entropic_dynamics", {}).get("stability_rating", 0),
            entropy_gradient=op.get("entropic_dynamics", {}).get("entropy_gradient", 0),
            symmetry_class=op.get("topology_signature", {}).get("symmetry_class", "unknown"),
            mandorla_certified=op.get("proof_of_resonance", {}).get("mandorla_condition", False),
            created_at=datetime.fromisoformat(op.get("creation_timestamp", datetime.utcnow().isoformat()))
        )
        results.append(summary)
    
    # Sort results
    if sort == "stability":
        results.sort(key=lambda x: x.stability, reverse=True)
    elif sort == "entropy":
        results.sort(key=lambda x: x.entropy_gradient)
    elif sort == "creation_time":
        results.sort(key=lambda x: x.created_at, reverse=True)
    
    return results

@app.post("/operator")
async def create_operator(manifest: OperatorManifest):
    """Submit new operator artifact"""
    operators_db[manifest.id] = manifest.dict()
    
    # Broadcast telemetry
    await manager.broadcast({
        "type": "new_operator",
        "id": manifest.id,
        "stability": manifest.entropic_dynamics.get("stability_rating", 0),
        "timestamp": datetime.utcnow().isoformat()
    })
    
    return {"id": manifest.id, "status": "created"}

@app.get("/operator/{operator_id}", response_model=OperatorManifest)
async def get_operator(operator_id: str):
    """Retrieve full operator manifest"""
    if operator_id not in operators_db:
        raise HTTPException(status_code=404, detail=f"Operator {operator_id} not found")
    
    return operators_db[operator_id]

@app.delete("/operator/{operator_id}")
async def delete_operator(operator_id: str):
    """Remove operator (admin only)"""
    if operator_id not in operators_db:
        raise HTTPException(status_code=404, detail=f"Operator {operator_id} not found")
    
    del operators_db[operator_id]
    return {"status": "deleted", "id": operator_id}

@app.get("/operator/{operator_id}/visual")
async def get_operator_visual(operator_id: str):
    """Fetch visualization assets for an operator"""
    if operator_id not in operators_db:
        raise HTTPException(status_code=404, detail=f"Operator {operator_id} not found")
    
    op = operators_db[operator_id]
    viz = op.get("visualization_metadata", {})
    
    return {
        "thumbnail": viz.get("thumbnail"),
        "preferred_view": viz.get("preferred_view", "cube"),
        "color_scheme": viz.get("color_scheme", "resonance"),
        "position_in_cube": viz.get("position_in_cube", [0.5, 0.5, 0.5]),
        "data_uri": None
    }

@app.get("/operator/{operator_id}/relations")
async def get_operator_relations(operator_id: str):
    """Retrieve graph of related operators"""
    if operator_id not in operators_db:
        raise HTTPException(status_code=404, detail=f"Operator {operator_id} not found")
    
    op = operators_db[operator_id]
    relations = op.get("relations", [])
    
    return {
        "root": operator_id,
        "nodes": [r["target_id"] for r in relations],
        "edges": relations
    }

@app.get("/ledger", response_model=List[LedgerHeader])
async def list_ledger(validated_only: Optional[bool] = Query(None)):
    """List Proof-of-Resonance ledger entries"""
    results = []
    
    for ledger_id, entry in ledger_db.items():
        if validated_only and not entry.get("mandorla_condition", False):
            continue
        
        header = LedgerHeader(
            id=entry["id"],
            hash=entry["proof_hash"],
            timestamp=datetime.fromisoformat(entry.get("timestamp", datetime.utcnow().isoformat())),
            energy=entry.get("operator_tensor", {}).get("energy", 0)
        )
        results.append(header)
    
    # Sort by timestamp descending
    results.sort(key=lambda x: x.timestamp, reverse=True)
    return results

@app.get("/ledger/{hash}")
async def get_ledger_entry(hash: str):
    """Fetch full audit trail for a ledger entry"""
    for entry in ledger_db.values():
        if entry.get("proof_hash") == hash:
            return {
                "hash": entry["proof_hash"],
                "cycles_validated": entry.get("validation_cycles", 0),
                "energy_conservation": True,
                "entropy_trace": entry.get("entropy_curve", []),
                "proof_document": json.dumps(entry)
            }
    
    raise HTTPException(status_code=404, detail=f"Ledger entry with hash {hash} not found")

@app.get("/analytics", response_model=AnalyticsResponse)
async def get_analytics():
    """Get aggregate statistics"""
    if not operators_db:
        return AnalyticsResponse(
            total_operators=0,
            average_entropy=0.0,
            mean_stability=0.0,
            dominant_symmetry_class="none",
            recent_activity=[]
        )
    
    total = len(operators_db)
    sum_entropy = sum(op.get("entropic_dynamics", {}).get("entropy_gradient", 0) for op in operators_db.values())
    sum_stability = sum(op.get("entropic_dynamics", {}).get("stability_rating", 0) for op in operators_db.values())
    
    # Find dominant symmetry class
    symmetry_counts = defaultdict(int)
    for op in operators_db.values():
        sym = op.get("topology_signature", {}).get("symmetry_class", "unknown")
        symmetry_counts[sym] += 1
    
    dominant = max(symmetry_counts.items(), key=lambda x: x[1])[0] if symmetry_counts else "unknown"
    
    # Recent activity
    recent = [(op.get("creation_timestamp", datetime.utcnow().isoformat()), op["id"]) 
              for op in operators_db.values()]
    recent.sort(reverse=True)
    recent = recent[:10]
    
    return AnalyticsResponse(
        total_operators=total,
        average_entropy=sum_entropy / total,
        mean_stability=sum_stability / total,
        dominant_symmetry_class=dominant,
        recent_activity=recent
    )

# ========== Cubechain Endpoints ==========

@app.post("/cubechain/enable")
async def enable_cubechain():
    """Enable cubechain mode"""
    cubechain_db["enabled"] = True
    
    await manager.broadcast({
        "type": "cubechain_enabled",
        "timestamp": datetime.utcnow().isoformat()
    })
    
    return {"status": "enabled", "message": "Cubechain mode activated"}

@app.get("/cubechain/status")
async def get_cubechain_status():
    """Get cubechain status"""
    if not cubechain_db["enabled"]:
        return {"enabled": False, "message": "Cubechain not enabled"}
    
    return {
        "enabled": True,
        "total_cubes": len(cubechain_db["cubes"]),
        "total_transitions": len(cubechain_db["transitions"]),
        "genesis_cube": cubechain_db["genesis_id"]
    }

@app.get("/cubechain/stats", response_model=CubechainStats)
async def get_cubechain_stats():
    """Get cubechain statistics"""
    if not cubechain_db["enabled"]:
        raise HTTPException(status_code=400, detail="Cubechain not enabled")
    
    validated = sum(1 for t in cubechain_db["transitions"].values() if t.get("validated", False))
    
    # Calculate mean entropy
    cubes = cubechain_db["cubes"].values()
    mean_entropy = sum(abs(c.get("s_field", 0)) for c in cubes) / len(cubes) if cubes else 0.0
    
    # Calculate stability index (fraction with low entropy)
    stable_count = sum(1 for c in cubes if abs(c.get("s_field", 0)) < 0.001)
    stability_index = stable_count / len(cubes) if cubes else 0.0
    
    return CubechainStats(
        total_cubes=len(cubechain_db["cubes"]),
        validated_transitions=validated,
        mean_entropy=mean_entropy,
        stability_index=stability_index,
        metatron_nodes=13
    )

@app.post("/cubechain/commit")
async def commit_cube(cube: CubeManifest):
    """Commit a new cube to the cubechain"""
    if not cubechain_db["enabled"]:
        raise HTTPException(status_code=400, detail="Cubechain not enabled")
    
    cube_dict = cube.dict()
    cubechain_db["cubes"][cube.id] = cube_dict
    
    # Set as genesis if first cube
    if cubechain_db["genesis_id"] is None:
        cubechain_db["genesis_id"] = cube.id
    
    # Broadcast telemetry
    await manager.broadcast({
        "type": "cube_created",
        "cube_id": cube.id,
        "generation": cube.generation,
        "s_field": cube.s_field,
        "proof_score": cube.proof_score,
        "timestamp": datetime.utcnow().isoformat()
    })
    
    return {"status": "committed", "cube_id": cube.id}

@app.get("/cubechain/cube/{cube_id}")
async def get_cube(cube_id: str):
    """Retrieve a cube by ID"""
    if not cubechain_db["enabled"]:
        raise HTTPException(status_code=400, detail="Cubechain not enabled")
    
    if cube_id not in cubechain_db["cubes"]:
        raise HTTPException(status_code=404, detail=f"Cube {cube_id} not found")
    
    return cubechain_db["cubes"][cube_id]

@app.post("/cubechain/transition")
async def commit_transition(transition: TransitionManifest):
    """Commit a new transition to the cubechain"""
    if not cubechain_db["enabled"]:
        raise HTTPException(status_code=400, detail="Cubechain not enabled")
    
    # Verify cubes exist
    if transition.from_cube not in cubechain_db["cubes"]:
        raise HTTPException(status_code=404, detail=f"Source cube {transition.from_cube} not found")
    if transition.to_cube not in cubechain_db["cubes"]:
        raise HTTPException(status_code=404, detail=f"Target cube {transition.to_cube} not found")
    
    transition_dict = transition.dict()
    cubechain_db["transitions"][transition.id] = transition_dict
    
    # Broadcast telemetry
    await manager.broadcast({
        "type": "transition_created",
        "transition_id": transition.id,
        "operator": transition.operator,
        "validated": transition.validated,
        "resonance_amplitude": transition.resonance_amplitude,
        "timestamp": datetime.utcnow().isoformat()
    })
    
    return {"status": "committed", "transition_id": transition.id}

@app.get("/cubechain/cube/{cube_id}/transitions")
async def get_cube_transitions(cube_id: str, direction: Optional[str] = Query("both", description="in, out, or both")):
    """Get transitions connected to a cube"""
    if not cubechain_db["enabled"]:
        raise HTTPException(status_code=400, detail="Cubechain not enabled")
    
    if cube_id not in cubechain_db["cubes"]:
        raise HTTPException(status_code=404, detail=f"Cube {cube_id} not found")
    
    transitions = []
    for t_id, t in cubechain_db["transitions"].items():
        if direction in ["in", "both"] and t["to_cube"] == cube_id:
            transitions.append({"id": t_id, "direction": "in", **t})
        if direction in ["out", "both"] and t["from_cube"] == cube_id:
            transitions.append({"id": t_id, "direction": "out", **t})
    
    return {
        "cube_id": cube_id,
        "transitions": transitions
    }

@app.get("/cubechain/export")
async def export_cubechain():
    """Export entire cubechain as JSON"""
    if not cubechain_db["enabled"]:
        raise HTTPException(status_code=400, detail="Cubechain not enabled")
    
    return {
        "cubes": cubechain_db["cubes"],
        "transitions": cubechain_db["transitions"],
        "genesis_id": cubechain_db["genesis_id"],
        "exported_at": datetime.utcnow().isoformat()
    }

# ========== Meta-Cognition Endpoints ==========

@app.post("/meta/enable")
async def enable_meta_cognition():
    """Enable meta-cognition layer"""
    meta_cognition_db["enabled"] = True
    
    await manager.broadcast({
        "type": "meta_cognition_enabled",
        "timestamp": datetime.utcnow().isoformat()
    })
    
    return {"status": "enabled", "message": "Meta-cognition layer activated"}

@app.get("/meta/status")
async def get_meta_status():
    """Get meta-cognition status"""
    if not meta_cognition_db["enabled"]:
        return {"enabled": False, "message": "Meta-cognition not enabled"}
    
    return {
        "enabled": True,
        "patterns_count": len(meta_cognition_db["patterns"]),
        "rules_count": len(meta_cognition_db["reasoning_rules"]),
        "reports_count": len(meta_cognition_db["meta_reports"]),
        "telemetry_count": len(meta_cognition_db["telemetry"])
    }

@app.get("/meta/patterns", response_model=PatternSpectrum)
async def get_pattern_spectrum():
    """Retrieve pattern spectrum from meta-cognition analysis"""
    if not meta_cognition_db["enabled"]:
        raise HTTPException(status_code=400, detail="Meta-cognition not enabled")
    
    patterns = [
        CoherencePattern(**p) for p in meta_cognition_db["patterns"].values()
    ]
    
    mean_conf = sum(p.confidence for p in patterns) / len(patterns) if patterns else 0.0
    dominant = max(patterns, key=lambda p: p.confidence).name if patterns else None
    
    return PatternSpectrum(
        patterns=patterns,
        mean_confidence=mean_conf,
        dominant_pattern=dominant,
        generated_at=datetime.utcnow()
    )

@app.post("/meta/patterns")
async def add_pattern(pattern: CoherencePattern):
    """Add a new coherence pattern"""
    if not meta_cognition_db["enabled"]:
        raise HTTPException(status_code=400, detail="Meta-cognition not enabled")
    
    pattern_dict = pattern.dict()
    meta_cognition_db["patterns"][pattern.pattern_id] = pattern_dict
    
    await manager.broadcast({
        "type": "pattern_detected",
        "pattern_id": pattern.pattern_id,
        "name": pattern.name,
        "confidence": pattern.confidence,
        "timestamp": datetime.utcnow().isoformat()
    })
    
    return {"status": "added", "pattern_id": pattern.pattern_id}

@app.get("/meta/semantic", response_model=SemanticMap)
async def get_semantic_map():
    """Retrieve semantic map from meta-cognition introspection"""
    if not meta_cognition_db["enabled"]:
        raise HTTPException(status_code=400, detail="Meta-cognition not enabled")
    
    # Return semantic map if available
    # For now, return a sample structure
    topics = []
    for pattern in meta_cognition_db["patterns"].values():
        for family in pattern.get("operator_families", []):
            topics.append(EmergentTopic(
                topic_id=f"topic_{family}",
                label=family,
                keywords=[family],
                correlation_strength=pattern.get("stability_correlation", 0.8),
                operator_count=10
            ))
    
    return SemanticMap(
        topics=topics[:5],  # Limit to top 5
        latent_dimensions=[
            ("coherence", 0.85),
            ("inversion", 0.82),
            ("recursion", 0.88)
        ],
        generated_at=datetime.utcnow()
    )

@app.get("/meta/reasoning", response_model=List[ReasoningRule])
async def get_reasoning_rules(
    min_success_rate: Optional[float] = Query(None, description="Minimum success rate")
):
    """Retrieve reasoning rules from meta-cognition"""
    if not meta_cognition_db["enabled"]:
        raise HTTPException(status_code=400, detail="Meta-cognition not enabled")
    
    rules = [
        ReasoningRule(**r) for r in meta_cognition_db["reasoning_rules"].values()
    ]
    
    if min_success_rate is not None:
        rules = [r for r in rules if r.success_rate >= min_success_rate]
    
    return rules

@app.post("/meta/reasoning")
async def add_reasoning_rule(rule: ReasoningRule):
    """Add a new reasoning rule"""
    if not meta_cognition_db["enabled"]:
        raise HTTPException(status_code=400, detail="Meta-cognition not enabled")
    
    rule_dict = rule.dict()
    meta_cognition_db["reasoning_rules"][rule.rule_id] = rule_dict
    
    await manager.broadcast({
        "type": "reasoning_rule_created",
        "rule_id": rule.rule_id,
        "axiom": rule.axiom,
        "success_rate": rule.success_rate,
        "timestamp": datetime.utcnow().isoformat()
    })
    
    return {"status": "added", "rule_id": rule.rule_id}

@app.get("/meta/reflections", response_model=List[SelfReflectionReport])
async def get_self_reflections(
    limit: Optional[int] = Query(10, description="Maximum number of reports to return")
):
    """Retrieve self-reflection reports"""
    if not meta_cognition_db["enabled"]:
        raise HTTPException(status_code=400, detail="Meta-cognition not enabled")
    
    reports = [
        SelfReflectionReport(**r) for r in meta_cognition_db["meta_reports"].values()
    ]
    
    # Sort by timestamp descending
    reports.sort(key=lambda x: x.timestamp, reverse=True)
    
    return reports[:limit]

@app.post("/meta/reflections")
async def add_self_reflection(report: SelfReflectionReport):
    """Add a new self-reflection report"""
    if not meta_cognition_db["enabled"]:
        raise HTTPException(status_code=400, detail="Meta-cognition not enabled")
    
    report_dict = report.dict()
    report_id = f"report_{report.cycle}_{int(report.timestamp.timestamp())}"
    meta_cognition_db["meta_reports"][report_id] = report_dict
    
    await manager.broadcast({
        "type": "self_reflection",
        "cycle": report.cycle,
        "dominant_pattern": report.dominant_pattern,
        "confidence": report.confidence,
        "adaptation_suggestion": report.adaptation_suggestion,
        "timestamp": datetime.utcnow().isoformat()
    })
    
    return {"status": "added", "report_id": report_id}

@app.get("/meta/telemetry", response_model=List[MetaTelemetry])
async def get_meta_telemetry(
    limit: Optional[int] = Query(100, description="Maximum number of telemetry points")
):
    """Retrieve meta-cognition telemetry history"""
    if not meta_cognition_db["enabled"]:
        raise HTTPException(status_code=400, detail="Meta-cognition not enabled")
    
    telemetry = [
        MetaTelemetry(**t) for t in meta_cognition_db["telemetry"]
    ]
    
    # Return most recent entries
    return telemetry[-limit:]

@app.post("/meta/telemetry")
async def add_meta_telemetry(telemetry: MetaTelemetry):
    """Add meta-cognition telemetry point"""
    if not meta_cognition_db["enabled"]:
        raise HTTPException(status_code=400, detail="Meta-cognition not enabled")
    
    telemetry_dict = telemetry.dict()
    meta_cognition_db["telemetry"].append(telemetry_dict)
    
    # Keep only last 1000 points
    if len(meta_cognition_db["telemetry"]) > 1000:
        meta_cognition_db["telemetry"] = meta_cognition_db["telemetry"][-1000:]
    
    return {"status": "added"}

@app.websocket("/telemetry")
async def telemetry_websocket(websocket: WebSocket):
    """WebSocket endpoint for real-time telemetry streaming"""
    await manager.connect(websocket)
    
    try:
        # Send initial connection message
        await websocket.send_json({
            "type": "connected",
            "message": "Telemetry stream connected",
            "timestamp": datetime.utcnow().isoformat()
        })
        
        # Keep connection alive and send periodic status
        while True:
            await asyncio.sleep(1)
            
            # Send periodic status update
            await websocket.send_json({
                "type": "status",
                "cycle": len(telemetry_buffer),
                "delta_h": 0.00001,  # Simulated
                "delta_s": 0.0001,   # Simulated
                "psi_variance": 0.02, # Simulated
                "timestamp": datetime.utcnow().isoformat()
            })
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)

@app.websocket("/meta")
async def meta_cognition_websocket(websocket: WebSocket):
    """WebSocket endpoint for meta-cognition telemetry streaming"""
    await manager.connect(websocket)
    
    try:
        # Send initial connection message
        await websocket.send_json({
            "type": "connected",
            "message": "Meta-cognition stream connected",
            "timestamp": datetime.utcnow().isoformat()
        })
        
        # Keep connection alive and send meta-cognition updates
        while True:
            await asyncio.sleep(120)  # Update every 120s as per spec
            
            if meta_cognition_db["enabled"] and meta_cognition_db["telemetry"]:
                # Send latest meta-cognition telemetry
                latest = meta_cognition_db["telemetry"][-1]
                await websocket.send_json({
                    "type": "meta_telemetry",
                    "meta_coherence_score": latest["meta_coherence_score"],
                    "causal_inference_depth": latest["causal_inference_depth"],
                    "semantic_entropy": latest["semantic_entropy"],
                    "self_reflection_density": latest["self_reflection_density"],
                    "timestamp": latest["timestamp"]
                })
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)

# ========== IRG Core Endpoints ==========

@app.post("/irg/enable")
async def enable_irg_core():
    """Enable IRG Core system"""
    irg_core_db["enabled"] = True
    return {"status": "enabled", "message": "IRG Core system enabled"}

@app.get("/irg/status")
async def get_irg_status():
    """Get IRG Core system status"""
    return {
        "enabled": irg_core_db["enabled"],
        "total_cores": len(irg_core_db["cores"]),
        "total_signatures": len(irg_core_db["signatures"]),
        "total_mutations": len(irg_core_db["mutations"]),
        "telemetry_entries": len(irg_core_db["telemetry"])
    }

@app.post("/irg/core")
async def create_irg_core(manifest: IRGCoreManifest):
    """Create new IRG Core instance"""
    if not irg_core_db["enabled"]:
        raise HTTPException(status_code=400, detail="IRG Core system not enabled")

    irg_core_db["cores"][manifest.id] = manifest.dict()
    irg_core_db["signatures"][manifest.id] = manifest.signature.dict()

    # Initialize learning history
    irg_core_db["learning_history"][manifest.id] = []

    # Broadcast event
    await manager.broadcast({
        "type": "irg_core_created",
        "id": manifest.id,
        "domain": manifest.target.domain,
        "timestamp": datetime.utcnow().isoformat()
    })

    return {"id": manifest.id, "status": "created"}

@app.get("/irg/core", response_model=List[IRGCoreManifest])
async def list_irg_cores(
    domain: Optional[str] = Query(None, description="Filter by target domain"),
    converged: Optional[bool] = Query(None, description="Filter by convergence status"),
    min_coherence: Optional[float] = Query(None, description="Minimum coherence ratio")
):
    """List all IRG Core instances with optional filters"""
    if not irg_core_db["enabled"]:
        raise HTTPException(status_code=400, detail="IRG Core system not enabled")

    results = []
    for core_id, core_data in irg_core_db["cores"].items():
        # Apply filters
        if domain and core_data["target"]["domain"] != domain:
            continue
        if converged is not None and core_data["status"]["has_converged"] != converged:
            continue
        if min_coherence and core_data["status"]["coherence_ratio"] < min_coherence:
            continue

        results.append(IRGCoreManifest(**core_data))

    return results

@app.get("/irg/core/{core_id}", response_model=IRGCoreManifest)
async def get_irg_core(core_id: str):
    """Get specific IRG Core instance"""
    if not irg_core_db["enabled"]:
        raise HTTPException(status_code=400, detail="IRG Core system not enabled")

    if core_id not in irg_core_db["cores"]:
        raise HTTPException(status_code=404, detail=f"IRG Core {core_id} not found")

    return IRGCoreManifest(**irg_core_db["cores"][core_id])

@app.post("/irg/core/{core_id}/evolve")
async def evolve_irg_core(core_id: str, noise: Optional[float] = 0.01):
    """Execute one evolution step for IRG Core"""
    if not irg_core_db["enabled"]:
        raise HTTPException(status_code=400, detail="IRG Core system not enabled")

    if core_id not in irg_core_db["cores"]:
        raise HTTPException(status_code=404, detail=f"IRG Core {core_id} not found")

    # Mock evolution step (in production, this would call Rust IRG Core)
    core_data = irg_core_db["cores"][core_id]

    # Update iteration
    core_data["status"]["iteration"] += 1

    # Simulate convergence
    if core_data["status"]["delta_sigma"] > 0.0001:
        core_data["status"]["delta_sigma"] *= 0.95

    # Update timestamp
    core_data["last_updated"] = datetime.utcnow().isoformat()

    # Record in learning history
    history_entry = {
        "core_id": core_id,
        "iteration": core_data["status"]["iteration"],
        "phase": core_data["status"]["current_phase"],
        "delta_sigma": core_data["status"]["delta_sigma"],
        "current_signature": core_data["signature"],
        "timestamp": datetime.utcnow().isoformat()
    }
    irg_core_db["learning_history"][core_id].append(history_entry)

    # Broadcast update
    await manager.broadcast({
        "type": "irg_evolution_step",
        "core_id": core_id,
        "iteration": core_data["status"]["iteration"],
        "delta_sigma": core_data["status"]["delta_sigma"],
        "timestamp": datetime.utcnow().isoformat()
    })

    return {
        "status": "evolved",
        "iteration": core_data["status"]["iteration"],
        "delta_sigma": core_data["status"]["delta_sigma"],
        "has_converged": core_data["status"]["has_converged"]
    }

@app.get("/irg/core/{core_id}/history", response_model=List[LearningHistoryEntry])
async def get_learning_history(
    core_id: str,
    limit: Optional[int] = Query(100, description="Maximum entries to return")
):
    """Get learning history for IRG Core"""
    if not irg_core_db["enabled"]:
        raise HTTPException(status_code=400, detail="IRG Core system not enabled")

    if core_id not in irg_core_db["learning_history"]:
        raise HTTPException(status_code=404, detail=f"No history for IRG Core {core_id}")

    history = irg_core_db["learning_history"][core_id]

    # Return most recent entries up to limit
    return [LearningHistoryEntry(**entry) for entry in history[-limit:]]

@app.post("/irg/mutation")
async def record_mutation(event: MutationEvent):
    """Record a mutation event"""
    if not irg_core_db["enabled"]:
        raise HTTPException(status_code=400, detail="IRG Core system not enabled")

    irg_core_db["mutations"].append(event.dict())

    # Broadcast mutation event
    await manager.broadcast({
        "type": "irg_mutation",
        "event_id": event.event_id,
        "core_id": event.core_id,
        "mutation_type": event.mutation_type,
        "stability_check": event.stability_check,
        "timestamp": event.timestamp.isoformat()
    })

    return {"event_id": event.event_id, "status": "recorded"}

@app.get("/irg/mutations", response_model=List[MutationEvent])
async def list_mutations(
    core_id: Optional[str] = Query(None, description="Filter by core ID"),
    mutation_type: Optional[str] = Query(None, description="Filter by mutation type"),
    limit: Optional[int] = Query(100, description="Maximum entries to return")
):
    """List mutation events"""
    if not irg_core_db["enabled"]:
        raise HTTPException(status_code=400, detail="IRG Core system not enabled")

    mutations = irg_core_db["mutations"]

    # Apply filters
    filtered = []
    for mutation in mutations:
        if core_id and mutation["core_id"] != core_id:
            continue
        if mutation_type and mutation["mutation_type"] != mutation_type:
            continue
        filtered.append(mutation)

    # Return most recent up to limit
    return [MutationEvent(**m) for m in filtered[-limit:]]

@app.get("/irg/telemetry", response_model=List[IRGTelemetryModel])
async def get_irg_telemetry(
    limit: Optional[int] = Query(100, description="Maximum entries to return")
):
    """Get IRG Core telemetry data"""
    if not irg_core_db["enabled"]:
        raise HTTPException(status_code=400, detail="IRG Core system not enabled")

    telemetry = irg_core_db["telemetry"]
    return [IRGTelemetryModel(**t) for t in telemetry[-limit:]]

@app.post("/irg/telemetry")
async def record_irg_telemetry(telemetry: IRGTelemetryModel):
    """Record IRG Core telemetry data"""
    if not irg_core_db["enabled"]:
        raise HTTPException(status_code=400, detail="IRG Core system not enabled")

    irg_core_db["telemetry"].append(telemetry.dict())

    # Broadcast telemetry
    await manager.broadcast({
        "type": "irg_telemetry",
        **telemetry.dict()
    })

    return {"status": "recorded", "timestamp": telemetry.timestamp}

@app.get("/irg/signature/{signature_id}", response_model=SpectralSignatureModel)
async def get_spectral_signature(signature_id: str):
    """Get spectral signature by ID"""
    if not irg_core_db["enabled"]:
        raise HTTPException(status_code=400, detail="IRG Core system not enabled")

    if signature_id not in irg_core_db["signatures"]:
        raise HTTPException(status_code=404, detail=f"Signature {signature_id} not found")

    return SpectralSignatureModel(**irg_core_db["signatures"][signature_id])

@app.websocket("/ws/irg")
async def irg_core_websocket(websocket: WebSocket):
    """WebSocket endpoint for IRG Core telemetry streaming"""
    await manager.connect(websocket)

    try:
        # Send initial connection message
        await websocket.send_json({
            "type": "connected",
            "message": "IRG Core telemetry stream connected",
            "timestamp": datetime.utcnow().isoformat()
        })

        # Keep connection alive and send IRG telemetry updates
        while True:
            await asyncio.sleep(64)  # Update every 64ms as per RFI spec

            if irg_core_db["enabled"] and irg_core_db["telemetry"]:
                # Send latest IRG telemetry
                latest = irg_core_db["telemetry"][-1]
                await websocket.send_json({
                    "type": "irg_telemetry",
                    **latest,
                    "timestamp": datetime.utcnow().isoformat()
                })

            # Also send evolution updates for all cores
            for core_id, core_data in irg_core_db["cores"].items():
                await websocket.send_json({
                    "type": "irg_status",
                    "core_id": core_id,
                    "status": core_data["status"],
                    "timestamp": datetime.utcnow().isoformat()
                })

    except WebSocketDisconnect:
        manager.disconnect(websocket)

# ========== Spectral Genesis Protocol Endpoints ==========

# In-memory spectral protocol state
spectral_db = {
    "sgcp": {
        "enabled": False,
        "telemetry": [],
        "calibration_results": []
    },
    "sal": {
        "enabled": False,
        "telemetry": [],
        "autogenesis_stages": []
    },
    "sral": {
        "enabled": False,
        "telemetry": [],
        "reflection_reports": []
    },
    "unified": {
        "enabled": False,
        "state": "Initializing",
        "telemetry": [],
        "snapshots": []
    }
}

@app.post("/sgcp/initialize")
async def initialize_sgcp():
    """Initialize Spectral Genesis Calibration Protocol"""
    spectral_db["sgcp"]["enabled"] = True
    spectral_db["unified"]["enabled"] = True
    spectral_db["unified"]["state"] = "Calibrating"
    
    await manager.broadcast({
        "type": "sgcp_initialized",
        "timestamp": datetime.utcnow().isoformat()
    })
    
    return {"status": "initialized", "protocol": "SGCP"}

@app.get("/sgcp/telemetry")
async def get_sgcp_telemetry(limit: Optional[int] = Query(100, description="Maximum entries")):
    """Get SGCP telemetry data"""
    if not spectral_db["sgcp"]["enabled"]:
        raise HTTPException(status_code=400, detail="SGCP not enabled")
    
    telemetry = spectral_db["sgcp"]["telemetry"][-limit:]
    return {"telemetry": telemetry, "count": len(telemetry)}

@app.post("/sal/initialize")
async def initialize_sal():
    """Initialize Spectral Autogenesis Layer"""
    spectral_db["sal"]["enabled"] = True
    
    await manager.broadcast({
        "type": "sal_initialized",
        "timestamp": datetime.utcnow().isoformat()
    })
    
    return {"status": "initialized", "protocol": "SAL"}

@app.get("/sal/telemetry")
async def get_sal_telemetry(limit: Optional[int] = Query(100, description="Maximum entries")):
    """Get SAL telemetry data"""
    if not spectral_db["sal"]["enabled"]:
        raise HTTPException(status_code=400, detail="SAL not enabled")
    
    telemetry = spectral_db["sal"]["telemetry"][-limit:]
    return {"telemetry": telemetry, "count": len(telemetry)}

@app.post("/sral/initialize")
async def initialize_sral():
    """Initialize Spectral Reflection and Audit Layer"""
    spectral_db["sral"]["enabled"] = True
    
    await manager.broadcast({
        "type": "sral_initialized",
        "timestamp": datetime.utcnow().isoformat()
    })
    
    return {"status": "initialized", "protocol": "SRAL"}

@app.get("/sral/telemetry")
async def get_sral_telemetry(limit: Optional[int] = Query(100, description="Maximum entries")):
    """Get SRAL telemetry data"""
    if not spectral_db["sral"]["enabled"]:
        raise HTTPException(status_code=400, detail="SRAL not enabled")
    
    telemetry = spectral_db["sral"]["telemetry"][-limit:]
    return {"telemetry": telemetry, "count": len(telemetry)}

@app.get("/sral/summary")
async def get_sral_summary():
    """Get SRAL summary reflection report"""
    if not spectral_db["sral"]["enabled"]:
        raise HTTPException(status_code=400, detail="SRAL not enabled")
    
    if not spectral_db["sral"]["reflection_reports"]:
        return {"message": "No reflection reports available yet"}
    
    return spectral_db["sral"]["reflection_reports"][-1]

@app.get("/spectral/status")
async def get_spectral_status():
    """Get unified spectral genesis system status"""
    return {
        "unified_enabled": spectral_db["unified"]["enabled"],
        "system_state": spectral_db["unified"]["state"],
        "sgcp_enabled": spectral_db["sgcp"]["enabled"],
        "sal_enabled": spectral_db["sal"]["enabled"],
        "sral_enabled": spectral_db["sral"]["enabled"],
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/spectral/telemetry")
async def get_unified_telemetry(limit: Optional[int] = Query(100, description="Maximum entries")):
    """Get unified spectral telemetry combining all three protocols"""
    if not spectral_db["unified"]["enabled"]:
        raise HTTPException(status_code=400, detail="Unified spectral system not enabled")
    
    telemetry = spectral_db["unified"]["telemetry"][-limit:]
    return {"telemetry": telemetry, "count": len(telemetry)}

@app.post("/spectral/snapshot")
async def create_spectral_snapshot():
    """Create calibration snapshot"""
    if not spectral_db["unified"]["enabled"]:
        raise HTTPException(status_code=400, detail="Unified spectral system not enabled")
    
    snapshot = {
        "timestamp": datetime.utcnow().isoformat(),
        "system_state": spectral_db["unified"]["state"],
        "sgcp_enabled": spectral_db["sgcp"]["enabled"],
        "sal_enabled": spectral_db["sal"]["enabled"],
        "sral_enabled": spectral_db["sral"]["enabled"],
    }
    
    spectral_db["unified"]["snapshots"].append(snapshot)
    
    # Broadcast snapshot creation
    await manager.broadcast({
        "type": "snapshot_created",
        "timestamp": snapshot["timestamp"]
    })
    
    return {"status": "created", "snapshot": snapshot}

@app.websocket("/ws/sgcp")
async def websocket_sgcp(websocket: WebSocket):
    """WebSocket endpoint for SGCP telemetry streaming"""
    await manager.connect(websocket)
    try:
        await websocket.send_json({
            "type": "connected",
            "message": "SGCP telemetry stream connected",
            "timestamp": datetime.utcnow().isoformat()
        })
        
        while True:
            await asyncio.sleep(60)  # Update every 60s as per spec
            
            if spectral_db["sgcp"]["enabled"] and spectral_db["sgcp"]["telemetry"]:
                latest = spectral_db["sgcp"]["telemetry"][-1]
                await websocket.send_json({
                    "type": "sgcp_telemetry",
                    **latest,
                    "timestamp": datetime.utcnow().isoformat()
                })
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)

@app.websocket("/ws/sal")
async def websocket_sal(websocket: WebSocket):
    """WebSocket endpoint for SAL telemetry streaming"""
    await manager.connect(websocket)
    try:
        await websocket.send_json({
            "type": "connected",
            "message": "SAL telemetry stream connected",
            "timestamp": datetime.utcnow().isoformat()
        })
        
        while True:
            await asyncio.sleep(120)  # Update every 120s as per spec
            
            if spectral_db["sal"]["enabled"] and spectral_db["sal"]["telemetry"]:
                latest = spectral_db["sal"]["telemetry"][-1]
                await websocket.send_json({
                    "type": "sal_telemetry",
                    **latest,
                    "timestamp": datetime.utcnow().isoformat()
                })
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)

@app.websocket("/ws/sral")
async def websocket_sral(websocket: WebSocket):
    """WebSocket endpoint for SRAL telemetry streaming"""
    await manager.connect(websocket)
    try:
        await websocket.send_json({
            "type": "connected",
            "message": "SRAL telemetry stream connected",
            "timestamp": datetime.utcnow().isoformat()
        })
        
        while True:
            await asyncio.sleep(300)  # Update every 300s as per spec
            
            if spectral_db["sral"]["enabled"] and spectral_db["sral"]["telemetry"]:
                latest = spectral_db["sral"]["telemetry"][-1]
                await websocket.send_json({
                    "type": "sral_telemetry",
                    **latest,
                    "timestamp": datetime.utcnow().isoformat()
                })
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)

@app.on_event("startup")
async def startup_event():
    """Initialize API on startup"""
    print(f"Starting Metatron Operator Lexicon API v1.0.0")
    print(f"Database: {DB_URL}")
    print(f"Ledger Path: {LEDGER_PATH}")
    print(f"WebSocket telemetry: {ENABLE_WEBSOCKETS}")

    # Ensure ledger directory exists
    os.makedirs(LEDGER_PATH, exist_ok=True)
    os.makedirs(os.path.join(LEDGER_PATH, "operators"), exist_ok=True)

    # Ensure IRG data directories exist
    os.makedirs("/data/irg/audit", exist_ok=True)
    os.makedirs("/data/irg/signatures", exist_ok=True)
    os.makedirs("/data/irg/mutations", exist_ok=True)
    print("IRG Core data directories initialized")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
