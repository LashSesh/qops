//! Integration tests for IRG Core (Infogenetic Resonant Genesis Core)

use genesis_engine::irg_core::*;
use genesis_engine::irg_integration::*;
use genesis_engine::signature::Signature5D;
use genesis_engine::operator::Operator;

// ============================================================================
// SPECTRAL SIGNATURE TESTS
// ============================================================================

#[test]
fn test_spectral_signature_creation() {
    let sig = SpectralSignature {
        psi: 0.8,
        rho: 0.9,
        omega: 0.85,
        chi: 0.75,
        tau: 0.95,
    };

    assert_eq!(sig.psi, 0.8);
    assert_eq!(sig.rho, 0.9);
    assert_eq!(sig.omega, 0.85);
    assert_eq!(sig.chi, 0.75);
    assert_eq!(sig.tau, 0.95);
}

#[test]
fn test_spectral_signature_from_5d() {
    let sig5d = Signature5D {
        psi: 0.8,
        rho: 0.9,
        omega: 0.85,
        chi: 0.75,
        eta: 0.95,
    };

    let spectral = SpectralSignature::from_signature_5d(&sig5d);

    assert_eq!(spectral.psi, 0.8);
    assert_eq!(spectral.rho, 0.9);
    assert_eq!(spectral.omega, 0.85);
    assert_eq!(spectral.chi, 0.75);
    assert_eq!(spectral.tau, 0.95);
}

#[test]
fn test_spectral_signature_fft_encoding() {
    let sig = SpectralSignature {
        psi: 0.8,
        rho: 0.9,
        omega: 0.85,
        chi: 0.75,
        tau: 0.95,
    };

    let spectrum = sig.fft_encode();

    assert_eq!(spectrum.len(), 5);
    for magnitude in spectrum {
        assert!(magnitude >= 0.0); // FFT magnitudes should be non-negative
    }
}

#[test]
fn test_spectral_signature_distance() {
    let sig1 = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let sig2 = SpectralSignature {
        psi: 0.81, rho: 0.91, omega: 0.86, chi: 0.76, tau: 0.96,
    };

    let distance = sig1.distance(&sig2);

    assert!(distance > 0.0);
    assert!(distance < 0.1); // Should be small for similar signatures

    // Test with identical signatures
    let distance_zero = sig1.distance(&sig1);
    assert_eq!(distance_zero, 0.0);
}

#[test]
fn test_stable_linkage() {
    let sig1 = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let sig2 = SpectralSignature {
        psi: 0.81, rho: 0.91, omega: 0.86, chi: 0.76, tau: 0.96,
    };

    // With large epsilon
    assert!(sig1.is_stable_linkage(&sig2, 1.0));

    // With very small epsilon
    assert!(!sig1.is_stable_linkage(&sig2, 0.0001));
}

// ============================================================================
// CELESTIAL RESONANCE IMPULSE TESTS
// ============================================================================

#[test]
fn test_cri_creation() {
    let cri = CelestialResonanceImpulse::new(CRIMode::ResonanceSynchronization);

    assert_eq!(cri.alpha, 1.0);
    assert_eq!(cri.beta, 0.5);
    assert_eq!(cri.mode, CRIMode::ResonanceSynchronization);
}

#[test]
fn test_cri_intensity_at_zero() {
    let cri = CelestialResonanceImpulse::new(CRIMode::MutationImpulse);
    let intensity = cri.intensity(0.0);

    // At t=0: α·sin(Φ_res + 0) + β·e^0 = α·sin(0) + β = 0 + 0.5
    assert!((intensity - 0.5).abs() < 1e-10);
}

#[test]
fn test_cri_trigger_conditions() {
    // Should trigger with high delta_sigma
    assert!(CelestialResonanceImpulse::should_trigger(0.05, 0.0));

    // Should trigger with high phi_entropy
    assert!(CelestialResonanceImpulse::should_trigger(0.0, 0.002));

    // Should not trigger with both low
    assert!(!CelestialResonanceImpulse::should_trigger(0.01, 0.0001));
}

#[test]
fn test_cri_apply_transformation() {
    let cri = CelestialResonanceImpulse::new(CRIMode::ResonanceSynchronization);

    let current = SpectralSignature {
        psi: 0.5, rho: 0.5, omega: 0.5, chi: 0.5, tau: 0.5,
    };

    let target = SpectralSignature {
        psi: 0.8, rho: 0.8, omega: 0.8, chi: 0.8, tau: 0.8,
    };

    let transformed = cri.apply(&current, &target, 0.0);

    // Transformed signature should be between current and target
    assert!(transformed.psi >= current.psi && transformed.psi <= target.psi);
    assert!(transformed.rho >= current.rho && transformed.rho <= target.rho);
}

// ============================================================================
// 5D CYBERNETIC CONTROL TESTS
// ============================================================================

#[test]
fn test_cybernetic_control_creation() {
    let initial = SpectralSignature {
        psi: 0.5, rho: 0.5, omega: 0.5, chi: 0.5, tau: 0.5,
    };

    let target = SpectralSignature {
        psi: 0.8, rho: 0.8, omega: 0.8, chi: 0.8, tau: 0.8,
    };

    let control = CyberneticControl::new(initial, target);

    assert_eq!(control.mode, ControlMode::ResonantConsensus);
    assert!(control.coherence_ratio > 0.0);
}

#[test]
fn test_cybernetic_control_update() {
    let initial = SpectralSignature {
        psi: 0.5, rho: 0.5, omega: 0.5, chi: 0.5, tau: 0.5,
    };

    let target = SpectralSignature {
        psi: 0.6, rho: 0.6, omega: 0.6, chi: 0.6, tau: 0.6,
    };

    let mut control = CyberneticControl::new(initial, target);

    let result = control.update(0.0);
    assert!(result.is_ok());

    // Phi should move toward target
    assert!(control.phi.psi > 0.5);
}

#[test]
fn test_coherence_ratio_governance() {
    let initial = SpectralSignature {
        psi: 0.5, rho: 0.5, omega: 0.5, chi: 0.5, tau: 0.5,
    };

    let target = SpectralSignature {
        psi: 0.51, rho: 0.51, omega: 0.51, chi: 0.51, tau: 0.51,
    };

    let control = CyberneticControl::new(initial, target);

    // Should be valid with high coherence
    assert!(control.is_valid());
    assert!(control.coherence_ratio >= 0.51);
}

// ============================================================================
// RESONANT FIELD INTERFACE TESTS
// ============================================================================

#[test]
fn test_rfi_creation() {
    let field = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let rfi = ResonantFieldInterface::new(field);

    assert_eq!(rfi.coherence_threshold, 0.95);
    assert_eq!(rfi.update_interval_ms, 64);
    assert!(!rfi.phase_locked);
}

#[test]
fn test_rfi_synchronization() {
    let field = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let mut rfi = ResonantFieldInterface::new(field.clone());

    let target = SpectralSignature {
        psi: 0.81, rho: 0.91, omega: 0.86, chi: 0.76, tau: 0.96,
    };

    let result = rfi.synchronize(&target);
    assert!(result.is_ok());
}

#[test]
fn test_rfi_adaptive_retune() {
    let field = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let mut rfi = ResonantFieldInterface::new(field);
    let mut cri = CelestialResonanceImpulse::new(CRIMode::ResonanceSynchronization);

    let initial_alpha = cri.alpha;

    // High delta_sigma should increase alpha
    rfi.adaptive_retune(&mut cri, 0.05);
    assert!(cri.alpha > initial_alpha);
}

// ============================================================================
// MUTATION PROTOCOL TESTS
// ============================================================================

#[test]
fn test_mutation_protocol_phase_shift() {
    let protocol = MutationProtocol::new(MutationType::PhaseShift);

    let sig = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.5, chi: 0.75, tau: 0.95,
    };

    let mutated = protocol.mutate(&sig, 1.0);

    // Omega should have changed due to phase shift
    assert_ne!(mutated.omega, sig.omega);
}

#[test]
fn test_mutation_protocol_amplitude_modulation() {
    let protocol = MutationProtocol::new(MutationType::AmplitudeModulation);

    let sig = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let mutated = protocol.mutate(&sig, 1.5);

    // Psi and rho should be scaled
    assert_eq!(mutated.psi, sig.psi * 1.5);
    assert_eq!(mutated.rho, sig.rho * 1.5);
}

#[test]
fn test_mandorla_fusion() {
    let protocol = MutationProtocol::new(MutationType::SignatureFusion);

    let sig1 = SpectralSignature {
        psi: 1.0, rho: 1.0, omega: 1.0, chi: 1.0, tau: 1.0,
    };

    let sig2 = SpectralSignature {
        psi: 0.0, rho: 0.0, omega: 0.0, chi: 0.0, tau: 0.0,
    };

    let fused = protocol.mandorla_fusion(&sig1, &sig2);

    // Fused signature should be average
    assert!((fused.psi - 0.5).abs() < 1e-10);
    assert!((fused.rho - 0.5).abs() < 1e-10);
}

// ============================================================================
// LEARNING CYCLE TESTS
// ============================================================================

#[test]
fn test_learning_cycle_creation() {
    let seed = SpectralSignature {
        psi: 0.5, rho: 0.5, omega: 0.5, chi: 0.5, tau: 0.5,
    };

    let target = SpectralSignature {
        psi: 0.8, rho: 0.8, omega: 0.8, chi: 0.8, tau: 0.8,
    };

    let cycle = LearningCycle::new(seed, target);

    assert_eq!(cycle.phase, LearningPhase::Initialization);
    assert_eq!(cycle.iteration, 0);
    assert_eq!(cycle.eta, 0.0025);
}

#[test]
fn test_learning_cycle_update() {
    let seed = SpectralSignature {
        psi: 0.5, rho: 0.5, omega: 0.5, chi: 0.5, tau: 0.5,
    };

    let target = SpectralSignature {
        psi: 0.6, rho: 0.6, omega: 0.6, chi: 0.6, tau: 0.6,
    };

    let mut cycle = LearningCycle::new(seed, target);

    let updated = cycle.update(0.0);

    assert_eq!(cycle.iteration, 1);
    assert!(updated.psi > 0.5); // Should move toward target
    assert!(cycle.delta_sigma_history.len() == 1);
}

#[test]
fn test_learning_cycle_convergence() {
    let seed = SpectralSignature {
        psi: 0.5, rho: 0.5, omega: 0.5, chi: 0.5, tau: 0.5,
    };

    let target = SpectralSignature {
        psi: 0.50001, rho: 0.50001, omega: 0.50001, chi: 0.50001, tau: 0.50001,
    };

    let mut cycle = LearningCycle::new(seed, target);

    // Run multiple iterations
    for _ in 0..5 {
        cycle.update(0.0);
    }

    assert!(cycle.should_stop());
}

#[test]
fn test_learning_cycle_phase_advancement() {
    let seed = SpectralSignature {
        psi: 0.5, rho: 0.5, omega: 0.5, chi: 0.5, tau: 0.5,
    };

    let target = SpectralSignature {
        psi: 0.8, rho: 0.8, omega: 0.8, chi: 0.8, tau: 0.8,
    };

    let mut cycle = LearningCycle::new(seed, target);

    assert_eq!(cycle.phase, LearningPhase::Initialization);

    cycle.next_phase();
    assert_eq!(cycle.phase, LearningPhase::Observation);

    cycle.next_phase();
    assert_eq!(cycle.phase, LearningPhase::Mutation);
}

// ============================================================================
// VALIDATION AND AUDIT TESTS
// ============================================================================

#[test]
fn test_validation_criteria_defaults() {
    let criteria = ValidationCriteria::default();

    assert_eq!(criteria.spectral_entropy_max, 1e-3);
    assert_eq!(criteria.operator_throughput_min, 1000);
    assert_eq!(criteria.coherence_ratio_min, 0.51);
    assert_eq!(criteria.semantic_integrity_min, 0.97);
}

#[test]
fn test_validation_audit_creation() {
    let audit = ValidationAudit::new();

    assert!(audit.auto_recalibration_enabled);
    assert_eq!(audit.telemetry_history.len(), 0);
}

#[test]
fn test_validation_audit_validate() {
    let audit = ValidationAudit::new();

    let good_telemetry = IRGTelemetry {
        timestamp: 0,
        spectral_entropy: 1e-4,
        operator_throughput: 1500,
        coherence_ratio: 0.9,
        semantic_integrity: 0.98,
        delta_phi_drift: 0.01,
        entropy_growth: 1e-4,
    };

    assert!(audit.validate(&good_telemetry).is_ok());

    let bad_telemetry = IRGTelemetry {
        timestamp: 0,
        spectral_entropy: 0.1, // Too high
        operator_throughput: 500, // Too low
        coherence_ratio: 0.3, // Too low
        semantic_integrity: 0.9, // Too low
        delta_phi_drift: 0.01,
        entropy_growth: 1e-4,
    };

    assert!(audit.validate(&bad_telemetry).is_err());
}

#[test]
fn test_validation_audit_recalibration_trigger() {
    let audit = ValidationAudit::new();

    let telemetry_needs_recal = IRGTelemetry {
        timestamp: 0,
        spectral_entropy: 1e-4,
        operator_throughput: 1500,
        coherence_ratio: 0.9,
        semantic_integrity: 0.98,
        delta_phi_drift: 0.03, // High drift
        entropy_growth: 1e-4,
    };

    assert!(audit.should_recalibrate(&telemetry_needs_recal));
}

// ============================================================================
// IRG CORE SYSTEM TESTS
// ============================================================================

#[test]
fn test_irg_core_creation() {
    let sig = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let core = IRGCore::new(sig, "test_domain");

    assert_eq!(core.system_time, 0.0);
    assert!(!core.has_converged());
}

#[test]
fn test_irg_core_evolution_step() {
    let sig = SpectralSignature {
        psi: 0.7, rho: 0.8, omega: 0.75, chi: 0.65, tau: 0.85,
    };

    let mut core = IRGCore::new(sig, "test_domain");

    let result = core.evolve_step(0.01);
    assert!(result.is_ok());

    assert!(core.system_time > 0.0);
}

#[test]
fn test_irg_core_status() {
    let sig = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let core = IRGCore::new(sig, "test_domain");
    let status = core.status();

    assert!(status.coherence_ratio >= 0.0 && status.coherence_ratio <= 1.0);
    assert!(status.delta_sigma >= 0.0);
    assert_eq!(status.iteration, 0);
}

// ============================================================================
// INTEGRATION TESTS
// ============================================================================

#[test]
fn test_meta_cognition_integration() {
    let sig = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let mut meta = IRGMetaCognition::new(sig, "test_domain");
    let report = meta.introspect(0.01).unwrap();

    assert!(report.meta_coherence >= 0.0);
    // Note: insights.len() >= 0 is always true for Vec, so we just verify the call succeeds
}

#[test]
fn test_spectral_genesis_integration() {
    let sig = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let mut spectral = IRGSpectralGenesis::new(sig, "test_domain");
    let report = spectral.calibrate(0.01).unwrap();

    assert!(report.spectral_genesis_index >= 0.0);
    assert_eq!(report.phase_coherence.len(), 3);
}

#[test]
fn test_operator_evolution_integration() {
    let sig = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let mut evolution = IRGOperatorEvolution::new(sig, "test_domain");

    let operator = Operator::from_signature(Signature5D {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, eta: 0.95,
    });

    let report = evolution.evolve_operator(&operator, 0.01).unwrap();

    assert_eq!(report.generation, 1);
    assert!(report.fitness >= 0.0 && report.fitness <= 1.0);
}

#[test]
fn test_cubechain_validation_integration() {
    let sig = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let mut validator = IRGCubechainValidator::new(sig, "test_domain");

    let from_sig = Signature5D {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, eta: 0.95,
    };

    let to_sig = Signature5D {
        psi: 0.81, rho: 0.91, omega: 0.86, chi: 0.76, eta: 0.96,
    };

    let report = validator.validate_transition(&from_sig, &to_sig).unwrap();

    assert!(report.transition_distance >= 0.0);
}

#[test]
fn test_unified_integration_creation() {
    let sig = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let unified = UnifiedIRGIntegration::new(sig, "test_domain");

    assert_eq!(unified.system_time, 0.0);

    let status = unified.unified_status();
    assert!(status.meta_coherence >= 0.0);
}

#[test]
fn test_unified_integration_evolution() {
    let sig = SpectralSignature {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, tau: 0.95,
    };

    let mut unified = UnifiedIRGIntegration::new(sig, "test_domain");

    let operator = Operator::from_signature(Signature5D {
        psi: 0.8, rho: 0.9, omega: 0.85, chi: 0.75, eta: 0.95,
    });

    let report = unified.unified_evolution_step(&operator, 0.01).unwrap();

    assert!(report.system_time > 0.0);
    assert!(unified.system_time > 0.0);
}
