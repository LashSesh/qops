//! Integration test for the complete Spectral Genesis Protocol Suite

#[cfg(test)]
mod integration_tests {
    use genesis_engine::spectral_genesis_unified::SpectralGenesisUnifiedSystem;
    
    #[test]
    fn test_complete_spectral_genesis_workflow() {
        // Create unified system
        let mut system = SpectralGenesisUnifiedSystem::new();
        
        // Step 1: Initialize
        system.initialize().expect("Initialization should succeed");
        
        // Step 2: Run calibration (SGCP)
        let calibration_results = system.run_calibration()
            .expect("Calibration should complete");
        assert_eq!(calibration_results.len(), 6, "Should complete all 6 calibration stages");
        
        // Verify SGCP metrics
        let sgcp_metrics = system.sgcp.get_metrics();
        assert!(sgcp_metrics.phase_coherence >= 0.0 && sgcp_metrics.phase_coherence <= 1.0);
        assert!(sgcp_metrics.global_index >= 0.0 && sgcp_metrics.global_index <= 1.0);
        
        // Step 3: Run autogenesis (SAL)
        let autogenesis_stages = system.run_autogenesis()
            .expect("Autogenesis should complete");
        assert_eq!(autogenesis_stages.len(), 6, "Should complete all 6 autogenesis stages");
        
        // Verify SAL metrics
        let agi = system.sal.autogenesis_index();
        assert!(agi >= 0.0 && agi <= 1.0, "AGI should be in valid range");
        
        // Step 4: Update system multiple cycles
        for i in 0..100 {
            system.update(0.01).expect(&format!("Update cycle {} should succeed", i));
        }
        assert_eq!(system.cycle_count, 100, "Should complete 100 cycles");
        
        // Step 5: Verify SRAL is tracking
        let sral_metrics = system.sral.get_coherence_metrics();
        assert!(sral_metrics.meta_coherence_index >= 0.0 && sral_metrics.meta_coherence_index <= 1.0);
        
        // Step 6: Get system status
        let status = system.get_status();
        assert!(status.cycle_count == 100);
        assert!(status.overall_coherence >= 0.0 && status.overall_coherence <= 1.0);
        
        // Step 7: Create snapshot
        let snapshot = system.create_snapshot();
        assert_eq!(snapshot.cycles_run, 100);
        
        // Step 8: Get reflection summary
        let reflection = system.get_reflection_summary();
        assert!(!reflection.reflections.is_empty(), "Should have reflections");
        
        // Step 9: Verify telemetry collected
        assert!(!system.unified_telemetry.is_empty(), "Should have telemetry data");
        
        let latest_telemetry = system.get_latest_telemetry();
        assert!(latest_telemetry.is_some(), "Should have latest telemetry");
    }
    
    #[test]
    fn test_telemetry_limits() {
        let mut system = SpectralGenesisUnifiedSystem::new();
        system.initialize().unwrap();
        
        // Generate lots of telemetry by running many cycles
        for _ in 0..2000 {
            system.update(0.01).unwrap();
        }
        
        // Verify telemetry is bounded (should be <= 1000)
        assert!(system.unified_telemetry.len() <= 1000, 
                "Unified telemetry should be limited to 1000 entries");
        assert!(system.sgcp.telemetry.len() <= 1000,
                "SGCP telemetry should be limited to 1000 entries");
        assert!(system.sal.telemetry.len() <= 1000,
                "SAL telemetry should be limited to 1000 entries");
        assert!(system.sral.telemetry.len() <= 1000,
                "SRAL telemetry should be limited to 1000 entries");
    }
}
