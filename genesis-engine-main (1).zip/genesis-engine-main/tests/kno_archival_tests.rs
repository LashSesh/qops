//! Comprehensive tests for KNO Archival System
//!
//! Tests cover:
//! - Ledger creation and persistence
//! - Operator archival
//! - State recording
//! - Phase-lock event tracking
//! - Stability logging
//! - Summary generation

use genesis_engine::kno_archival::{KNOArchivalSystem, OperatorLedger};
use genesis_engine::kno_framework::KNOOperator;
use std::path::PathBuf;
use std::fs;

fn create_test_operator() -> KNOOperator {
    let zeros = vec![14.134725, 21.022040, 25.010858];
    KNOOperator::new(zeros, 1.0)
}

fn get_test_dir() -> PathBuf {
    let dir = std::env::temp_dir().join(format!("kno_test_{}", uuid::Uuid::new_v4()));
    fs::create_dir_all(&dir).unwrap();
    dir
}

fn cleanup_test_dir(dir: &PathBuf) {
    let _ = fs::remove_dir_all(dir);
}

#[test]
fn test_operator_ledger_creation() {
    let ledger = OperatorLedger::new();

    assert_eq!(ledger.states.len(), 0);
    assert_eq!(ledger.eigenmodes.len(), 0);
    assert_eq!(ledger.phase_lock_events.len(), 0);
    assert_eq!(ledger.stability_logs.len(), 0);
    assert_eq!(ledger.metadata.framework_version, "KNO_v1.0");
}

#[test]
fn test_archive_operator_state() {
    let mut ledger = OperatorLedger::new();
    let operator = create_test_operator();

    ledger.archive_state(&operator);

    assert_eq!(ledger.states.len(), 1);
    assert_eq!(ledger.metadata.total_states, 1);

    let state = &ledger.states[0];
    assert_eq!(state.operator_id, operator.id);
    assert_eq!(state.time, operator.phase_field.time);
}

#[test]
fn test_archive_multiple_states() {
    let mut ledger = OperatorLedger::new();
    let operator1 = create_test_operator();
    let operator2 = create_test_operator();

    ledger.archive_state(&operator1);
    ledger.archive_state(&operator2);

    assert_eq!(ledger.states.len(), 2);
    assert_eq!(ledger.metadata.total_states, 2);
}

#[test]
fn test_record_eigenmode() {
    let mut ledger = OperatorLedger::new();
    let operator = create_test_operator();

    ledger.record_eigenmode(operator.id, 0, 1.0, 0.5, 0.1);

    assert_eq!(ledger.eigenmodes.len(), 1);

    let eigenmode = &ledger.eigenmodes[0];
    assert_eq!(eigenmode.operator_id, operator.id);
    assert_eq!(eigenmode.mode_index, 0);
    assert_eq!(eigenmode.eigenvalue, 1.0);
    assert_eq!(eigenmode.energy, 0.5);
    assert_eq!(eigenmode.mode_type, "stable");
}

#[test]
fn test_eigenmode_classification() {
    let mut ledger = OperatorLedger::new();
    let operator = create_test_operator();

    // Stable mode
    ledger.record_eigenmode(operator.id, 0, 1.0, 0.5, 0.1);
    assert_eq!(ledger.eigenmodes[0].mode_type, "stable");

    // Unstable mode
    ledger.record_eigenmode(operator.id, 1, 1.0, 0.5, -0.1);
    assert_eq!(ledger.eigenmodes[1].mode_type, "unstable");

    // Critical mode
    ledger.record_eigenmode(operator.id, 2, 1.0, 0.5, 0.0);
    assert_eq!(ledger.eigenmodes[2].mode_type, "critical");
}

#[test]
fn test_record_phase_lock_event() {
    let mut ledger = OperatorLedger::new();
    let mut operator = create_test_operator();
    operator.is_phase_locked = true;

    let riemann_zeros = vec![14.134725, 21.022040, 25.010858];
    ledger.record_phase_lock(&operator, &riemann_zeros);

    assert_eq!(ledger.phase_lock_events.len(), 1);
    assert_eq!(ledger.metadata.total_phase_locks, 1);

    let event = &ledger.phase_lock_events[0];
    assert_eq!(event.operator_id, operator.id);
}

#[test]
fn test_phase_lock_finds_nearest_zero() {
    let mut ledger = OperatorLedger::new();
    let mut operator = create_test_operator();
    operator.phase_field.omega = 14.5; // Near first zero
    operator.is_phase_locked = true;

    let riemann_zeros = vec![14.134725, 21.022040];
    ledger.record_phase_lock(&operator, &riemann_zeros);

    let event = &ledger.phase_lock_events[0];
    assert_eq!(event.riemann_zero_index, Some(0)); // Should find first zero
    assert!(event.distance_to_zero.unwrap() < 1.0);
}

#[test]
fn test_log_stability() {
    let mut ledger = OperatorLedger::new();
    let operator = create_test_operator();

    ledger.log_stability(&operator, "Test stability entry".to_string());

    assert_eq!(ledger.stability_logs.len(), 1);

    let log = &ledger.stability_logs[0];
    assert_eq!(log.operator_id, operator.id);
    assert_eq!(log.is_stable, operator.is_stable);
    assert_eq!(log.notes, "Test stability entry");
}

#[test]
fn test_update_metadata() {
    let mut ledger = OperatorLedger::new();

    // Add multiple states from different operators
    for _ in 0..5 {
        let operator = create_test_operator();
        ledger.archive_state(&operator);
    }

    ledger.update_metadata();

    assert!(ledger.metadata.total_operators > 0);
    assert_eq!(ledger.metadata.total_states, 5);
}

#[test]
fn test_ledger_summary() {
    let mut ledger = OperatorLedger::new();

    // Create multiple operators and archive them
    for _ in 0..10 {
        let mut operator = create_test_operator();
        operator.is_stable = true;
        ledger.archive_state(&operator);
    }

    ledger.update_metadata();
    let summary = ledger.get_summary();

    assert_eq!(summary.total_states, 10);
    assert_eq!(summary.stable_operators, 10);
}

#[test]
fn test_ledger_save_and_load() {
    let test_dir = get_test_dir();
    let file_path = test_dir.join("ledger.json");

    // Create and populate ledger
    let mut ledger = OperatorLedger::new();
    let operator = create_test_operator();
    ledger.archive_state(&operator);

    // Save
    ledger.save_to_file(&file_path).unwrap();
    assert!(file_path.exists());

    // Load
    let loaded_ledger = OperatorLedger::load_from_file(&file_path).unwrap();
    assert_eq!(loaded_ledger.states.len(), 1);
    assert_eq!(loaded_ledger.states[0].operator_id, operator.id);

    cleanup_test_dir(&test_dir);
}

#[test]
fn test_archival_system_creation() {
    let test_dir = get_test_dir();

    let system = KNOArchivalSystem::new(&test_dir).unwrap();

    assert!(test_dir.exists());
    assert_eq!(system.ledger.states.len(), 0);

    cleanup_test_dir(&test_dir);
}

#[test]
fn test_archive_operator_full() {
    let test_dir = get_test_dir();
    let mut system = KNOArchivalSystem::new(&test_dir).unwrap();

    let operator = create_test_operator();
    let riemann_zeros = vec![14.134725, 21.022040, 25.010858];

    system.archive_operator(&operator, &riemann_zeros);

    assert_eq!(system.ledger.states.len(), 1);
    assert_eq!(system.ledger.stability_logs.len(), 1);

    cleanup_test_dir(&test_dir);
}

#[test]
fn test_archive_phase_locked_operator() {
    let test_dir = get_test_dir();
    let mut system = KNOArchivalSystem::new(&test_dir).unwrap();

    let mut operator = create_test_operator();
    operator.is_phase_locked = true;

    let riemann_zeros = vec![14.134725, 21.022040, 25.010858];
    system.archive_operator(&operator, &riemann_zeros);

    assert_eq!(system.ledger.states.len(), 1);
    assert_eq!(system.ledger.phase_lock_events.len(), 1);
    assert_eq!(system.ledger.stability_logs.len(), 1);

    cleanup_test_dir(&test_dir);
}

#[test]
fn test_save_ledger() {
    let test_dir = get_test_dir();
    let mut system = KNOArchivalSystem::new(&test_dir).unwrap();

    let operator = create_test_operator();
    system.archive_operator(&operator, &vec![14.134725]);

    let saved_path = system.save_ledger().unwrap();

    assert!(saved_path.exists());
    assert!(saved_path.to_str().unwrap().contains("operator_ledger_"));

    cleanup_test_dir(&test_dir);
}

#[test]
fn test_export_summary() {
    let test_dir = get_test_dir();
    let mut system = KNOArchivalSystem::new(&test_dir).unwrap();

    // Archive multiple operators
    for _ in 0..5 {
        let operator = create_test_operator();
        system.archive_operator(&operator, &vec![14.134725]);
    }

    let summary_path = system.export_summary().unwrap();

    assert!(summary_path.exists());
    assert!(summary_path.to_str().unwrap().contains("operator_summary_"));

    cleanup_test_dir(&test_dir);
}

#[test]
fn test_export_markdown_report() {
    let test_dir = get_test_dir();
    let mut system = KNOArchivalSystem::new(&test_dir).unwrap();

    // Archive operators
    for i in 0..3 {
        let mut operator = create_test_operator();
        operator.is_stable = i % 2 == 0;
        system.archive_operator(&operator, &vec![14.134725, 21.022040]);
    }

    let report_path = system.export_markdown_report().unwrap();

    assert!(report_path.exists());
    assert!(report_path.to_str().unwrap().contains("operator_report_"));
    assert!(report_path.extension().unwrap() == "md");

    // Read and verify content
    let content = fs::read_to_string(&report_path).unwrap();
    assert!(content.contains("# KNO Operator Ledger Report"));
    assert!(content.contains("Summary Statistics"));

    cleanup_test_dir(&test_dir);
}

#[test]
fn test_ledger_summary_statistics() {
    let mut ledger = OperatorLedger::new();

    // Create diverse set of operators
    for i in 0..10 {
        let mut operator = create_test_operator();
        operator.is_stable = i % 2 == 0;
        operator.is_phase_locked = i % 3 == 0;
        operator.chern_number = Some(0.95 + (i as f64) * 0.01);
        ledger.archive_state(&operator);
    }

    ledger.update_metadata();
    let summary = ledger.get_summary();

    assert_eq!(summary.total_states, 10);
    assert_eq!(summary.stable_operators, 5);
    assert_eq!(summary.phase_locked_operators, 4); // 0, 3, 6, 9
    assert!(summary.average_chern_number.is_some());
}

#[test]
fn test_average_chern_number_computation() {
    let mut ledger = OperatorLedger::new();

    let mut op1 = create_test_operator();
    op1.chern_number = Some(0.9);
    ledger.archive_state(&op1);

    let mut op2 = create_test_operator();
    op2.chern_number = Some(1.1);
    ledger.archive_state(&op2);

    let summary = ledger.get_summary();

    assert!(summary.average_chern_number.is_some());
    let avg = summary.average_chern_number.unwrap();
    assert!((avg - 1.0).abs() < 0.1);
}

#[test]
fn test_archived_state_properties() {
    let mut ledger = OperatorLedger::new();
    let mut operator = create_test_operator();
    operator.phase_field.time = 1.234;
    operator.phase_field.omega = 15.678;
    operator.is_phase_locked = true;
    operator.chern_number = Some(0.987);

    ledger.archive_state(&operator);

    let state = &ledger.states[0];
    assert_eq!(state.time, 1.234);
    assert_eq!(state.omega, 15.678);
    assert!(state.is_phase_locked);
    assert_eq!(state.chern_number, Some(0.987));
}

#[test]
fn test_berry_connection_archival() {
    let mut ledger = OperatorLedger::new();
    let mut operator = create_test_operator();
    operator.berry_connection.components = vec![0.1, 0.2, 0.3];

    ledger.archive_state(&operator);

    let state = &ledger.states[0];
    assert_eq!(state.berry_connection_components, vec![0.1, 0.2, 0.3]);
}

#[test]
fn test_multiple_operator_archival() {
    let test_dir = get_test_dir();
    let mut system = KNOArchivalSystem::new(&test_dir).unwrap();

    let riemann_zeros = vec![14.134725, 21.022040];

    // Archive many operators
    for _ in 0..20 {
        let operator = create_test_operator();
        system.archive_operator(&operator, &riemann_zeros);
    }

    assert_eq!(system.ledger.states.len(), 20);
    assert_eq!(system.ledger.stability_logs.len(), 20);

    cleanup_test_dir(&test_dir);
}

#[test]
fn test_ledger_persistence_integrity() {
    let test_dir = get_test_dir();
    let file_path = test_dir.join("integrity_test.json");

    // Create complex ledger
    let mut ledger = OperatorLedger::new();

    for i in 0..5 {
        let mut operator = create_test_operator();
        operator.is_stable = true;
        operator.is_phase_locked = i % 2 == 0;
        ledger.archive_state(&operator);
        ledger.record_eigenmode(operator.id, i, 1.0, 0.5, 0.1);
    }

    ledger.update_metadata();

    // Save
    ledger.save_to_file(&file_path).unwrap();

    // Load and verify
    let loaded = OperatorLedger::load_from_file(&file_path).unwrap();

    assert_eq!(loaded.states.len(), ledger.states.len());
    assert_eq!(loaded.eigenmodes.len(), ledger.eigenmodes.len());
    assert_eq!(loaded.metadata.total_states, ledger.metadata.total_states);

    cleanup_test_dir(&test_dir);
}

#[test]
fn test_archival_system_metadata_updates() {
    let test_dir = get_test_dir();
    let mut system = KNOArchivalSystem::new(&test_dir).unwrap();

    let initial_timestamp = system.ledger.metadata.last_updated.clone();

    // Wait a tiny bit to ensure timestamp changes
    std::thread::sleep(std::time::Duration::from_millis(10));

    let operator = create_test_operator();
    system.archive_operator(&operator, &vec![14.134725]);

    let updated_timestamp = system.ledger.metadata.last_updated.clone();

    assert_ne!(initial_timestamp, updated_timestamp);

    cleanup_test_dir(&test_dir);
}

#[test]
fn test_empty_ledger_summary() {
    let ledger = OperatorLedger::new();
    let summary = ledger.get_summary();

    assert_eq!(summary.total_operators, 0);
    assert_eq!(summary.total_states, 0);
    assert_eq!(summary.total_eigenmodes, 0);
    assert_eq!(summary.total_phase_locks, 0);
    assert!(summary.average_chern_number.is_none());
}

#[test]
fn test_stability_log_v_pp_recording() {
    let mut ledger = OperatorLedger::new();
    let operator = create_test_operator();

    ledger.log_stability(&operator, "Test log".to_string());

    let log = &ledger.stability_logs[0];
    assert!(log.v_second_derivative.is_finite());
}

#[test]
fn test_phase_lock_event_omega_dot() {
    let mut ledger = OperatorLedger::new();
    let mut operator = create_test_operator();
    operator.phase_field.omega = 14.5;
    operator.is_phase_locked = true;

    ledger.record_phase_lock(&operator, &vec![14.134725]);

    let event = &ledger.phase_lock_events[0];
    assert_eq!(event.omega_at_lock, 14.5);
    assert!(event.omega_dot_at_lock.is_finite());
}

#[test]
fn test_concurrent_archival_safety() {
    let test_dir = get_test_dir();
    let mut system = KNOArchivalSystem::new(&test_dir).unwrap();

    // Archive multiple operators rapidly
    for _ in 0..50 {
        let operator = create_test_operator();
        system.archive_operator(&operator, &vec![14.134725]);
    }

    assert_eq!(system.ledger.states.len(), 50);

    // All states should be unique
    let mut ids: Vec<_> = system.ledger.states.iter().map(|s| s.operator_id).collect();
    ids.sort();
    ids.dedup();
    assert_eq!(ids.len(), 50); // All unique

    cleanup_test_dir(&test_dir);
}

#[test]
fn test_archival_throughput() {
    let test_dir = get_test_dir();
    let mut system = KNOArchivalSystem::new(&test_dir).unwrap();

    let start = std::time::Instant::now();

    for _ in 0..1000 {
        let operator = create_test_operator();
        system.archive_operator(&operator, &vec![14.134725]);
    }

    let elapsed = start.elapsed();
    let throughput = 1000.0 / elapsed.as_secs_f64();

    println!("Archival throughput: {:.2} ops/sec", throughput);

    // Should be able to archive at least 500 operators per second
    assert!(throughput >= 500.0);

    cleanup_test_dir(&test_dir);
}
