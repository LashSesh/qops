//! Comprehensive tests for KNO Core module
//!
//! Tests cover:
//! - Operator creation and properties
//! - Mining core functionality
//! - Hermiticity validation
//! - Spectral analysis
//! - Energy neutrality
//! - Archival integration

use genesis_engine::kno_core::{KNOMiningCore, MiningConfig};
use genesis_engine::kno_framework::{KNOOperator, PolynomialPotential, Complex};

const HERMITIAN_EPSILON: f64 = 1e-8;
const SPECTRAL_TOLERANCE: f64 = 1e-6;

#[test]
fn test_kno_operator_creation() {
    let zeros = vec![14.134725, 21.022040, 25.010858];
    let operator = KNOOperator::new(zeros.clone(), 1.0);

    assert_eq!(operator.alpha, 1.0);
    assert_eq!(operator.beta, 0.9);
    assert!((operator.delta_phi - 0.1).abs() < 1e-10);
    assert!(!operator.spectrum.is_empty());
    assert_eq!(operator.potential.riemann_zeros, zeros);
}

#[test]
fn test_kno_operator_from_parameters() {
    let alpha = 1.2;
    let beta = 0.8;
    let zeros = vec![14.134725, 21.022040];

    let operator = KNOOperator::from_parameters(alpha, beta, zeros.clone());

    assert_eq!(operator.alpha, alpha);
    assert_eq!(operator.beta, beta);
    assert!((operator.delta_phi - (alpha - beta)).abs() < 1e-10);
}

#[test]
fn test_operator_hermiticity() {
    // Create operator with very small delta_phi
    let operator = KNOOperator::from_parameters(1.0, 1.0 - 1e-10, vec![14.134725]);

    assert!(operator.is_hermitian());
    assert!(operator.delta_phi.abs() < HERMITIAN_EPSILON);
}

#[test]
fn test_operator_non_hermitian() {
    let operator = KNOOperator::from_parameters(1.0, 0.5, vec![14.134725]);

    assert!(!operator.is_hermitian());
    assert!(operator.delta_phi.abs() > HERMITIAN_EPSILON);
}

#[test]
fn test_operator_eigenvalues() {
    let operator = KNOOperator::new(vec![14.134725], 1.0);
    let eigenvalues = operator.eigenvalues();

    assert!(!eigenvalues.is_empty());

    // All eigenvalues should have magnitude 1 (since |e^{i n Δφ}| = 1)
    for &lambda in eigenvalues {
        assert!((lambda.abs() - 1.0).abs() < SPECTRAL_TOLERANCE);
    }
}

#[test]
fn test_operator_collapse_to_nullpoint() {
    let mut operator = KNOOperator::from_parameters(1.5, 0.5, vec![14.134725]);

    assert!(!operator.is_phase_locked);
    assert!(operator.delta_phi.abs() > 0.0);

    operator.collapse_to_nullpoint();

    assert_eq!(operator.delta_phi, 0.0);
    assert_eq!(operator.alpha, operator.beta);
    assert!(operator.is_phase_locked);
}

#[test]
fn test_operator_evolution() {
    let mut operator = KNOOperator::new(vec![14.134725, 21.022040], 1.0);
    let primes = vec![2, 3, 5, 7, 11, 13];

    let initial_time = operator.phase_field.time;

    operator.evolve(0.1, &primes);

    assert!(operator.phase_field.time > initial_time);
    assert_ne!(operator.phase_field.psi.re, 1.0); // Should have evolved
}

#[test]
fn test_operator_energy_computation() {
    let mut operator = KNOOperator::new(vec![14.134725], 1.0);
    let primes = vec![2, 3, 5, 7];

    operator.evolve(0.1, &primes);

    // Energy should be finite
    assert!(operator.energy.is_finite());
    assert!(operator.energy.abs() < 1e6);
}

#[test]
fn test_operator_energy_neutrality() {
    let mut operator = KNOOperator::new(vec![14.134725], 1.0);
    let primes = vec![2, 3, 5, 7, 11];

    operator.evolve(0.01, &primes);
    let initial_energy = operator.energy;

    // Evolve multiple steps
    for _ in 0..10 {
        operator.evolve(0.01, &primes);
    }

    // Energy should remain approximately constant (neutral)
    let energy_drift = (operator.energy - initial_energy).abs();
    println!("Energy drift: {:.2e}", energy_drift);

    // Allow some numerical drift, but should be small
    assert!(energy_drift < 1.0); // Reasonable bound for numerical integration
}

#[test]
fn test_mining_core_creation() {
    let config = MiningConfig::default();
    let core = KNOMiningCore::new(config);

    assert_eq!(core.operators.len(), 0);
    assert_eq!(core.current_iteration, 0);
    assert_eq!(core.statistics.total_generated, 0);
}

#[test]
fn test_mining_core_with_defaults() {
    let core = KNOMiningCore::with_defaults();

    assert_eq!(core.operators.len(), 0);
    assert_eq!(core.config.iterations, 1000);
}

#[test]
fn test_operator_mining_small_grid() {
    let mut config = MiningConfig::default();
    config.iterations = 9;
    config.alpha_samples = 3;
    config.beta_samples = 3;

    let mut core = KNOMiningCore::new(config);
    let operators = core.mine().unwrap();

    assert_eq!(operators.len(), 9);
    assert_eq!(core.statistics.total_generated, 9);
    assert!(core.statistics.hermitian_operators <= 9);
}

#[test]
fn test_operator_mining_generates_valid_operators() {
    let mut config = MiningConfig::default();
    config.iterations = 20;
    config.alpha_samples = 4;
    config.beta_samples = 5;

    let mut core = KNOMiningCore::new(config);
    let operators = core.mine().unwrap();

    assert_eq!(operators.len(), 20);

    // All operators should have valid properties
    for op in operators {
        assert!(op.alpha >= core.config.alpha_range.0);
        assert!(op.alpha <= core.config.alpha_range.1);
        assert!(op.beta >= core.config.beta_range.0);
        assert!(op.beta <= core.config.beta_range.1);
        assert!(!op.spectrum.is_empty());
    }
}

#[test]
fn test_mining_evaluation() {
    let mut config = MiningConfig::default();
    config.iterations = 10;
    config.alpha_samples = 2;
    config.beta_samples = 5;

    let mut core = KNOMiningCore::new(config);
    core.mine().unwrap();

    let reports = core.evaluate().unwrap();

    assert_eq!(reports.len(), core.operators.len());

    for report in reports {
        assert!(report.spectral_balance >= 0.0);
        assert!(report.energy.is_finite());
    }
}

#[test]
fn test_evaluation_report_validity() {
    let mut config = MiningConfig::default();
    config.iterations = 15;
    config.alpha_samples = 3;
    config.beta_samples = 5;

    let mut core = KNOMiningCore::new(config);
    core.mine().unwrap();

    let reports = core.evaluate().unwrap();

    let valid_count = reports.iter().filter(|r| r.is_valid()).count();
    println!("Valid operators: {}/{}", valid_count, reports.len());

    // At least some operators should be valid
    assert!(reports.len() > 0);
}

#[test]
fn test_operator_stabilization() {
    let mut config = MiningConfig::default();
    config.iterations = 20;
    config.alpha_samples = 4;
    config.beta_samples = 5;
    config.spectral_threshold = 0.01; // Relatively high threshold for testing

    let mut core = KNOMiningCore::new(config);
    core.mine().unwrap();

    // Manually set some operators near equilibrium
    let num_to_stabilize = core.operators.len() / 3;
    for i in 0..num_to_stabilize {
        core.operators[i].delta_phi = 1e-8; // Near zero
    }

    let stabilized = core.stabilize().unwrap();

    assert!(stabilized >= num_to_stabilize);
    assert_eq!(core.statistics.phase_locked_operators, stabilized);
}

#[test]
fn test_hermitian_filtering() {
    let mut config = MiningConfig::default();
    config.iterations = 25;
    config.alpha_samples = 5;
    config.beta_samples = 5;

    let mut core = KNOMiningCore::new(config);
    core.mine().unwrap();

    let hermitian = core.filter_hermitian();

    // All filtered operators should be Hermitian
    for op in hermitian {
        assert!(op.is_hermitian());
        assert!(op.delta_phi.abs() < HERMITIAN_EPSILON);
    }
}

#[test]
fn test_stable_filtering() {
    let mut config = MiningConfig::default();
    config.iterations = 20;
    config.alpha_samples = 4;
    config.beta_samples = 5;

    let mut core = KNOMiningCore::new(config);
    core.mine().unwrap();

    let stable = core.filter_stable();

    // All filtered operators should be stable
    for op in stable {
        assert!(op.is_stable);
    }
}

#[test]
fn test_spectral_threshold_filtering() {
    let mut config = MiningConfig::default();
    config.iterations = 30;
    config.alpha_samples = 5;
    config.beta_samples = 6;
    config.spectral_threshold = 0.01;

    let mut core = KNOMiningCore::new(config);
    core.mine().unwrap();

    let filtered = core.filter_by_spectral_threshold();

    println!("Filtered: {}/{} operators", filtered.len(), core.operators.len());

    // Filtered operators should meet threshold
    for op in &filtered {
        let balance = core.compute_spectral_balance(op);
        assert!(balance < core.config.spectral_threshold);
    }
}

#[test]
fn test_mining_statistics_accuracy() {
    let mut config = MiningConfig::default();
    config.iterations = 16;
    config.alpha_samples = 4;
    config.beta_samples = 4;

    let mut core = KNOMiningCore::new(config);
    core.mine().unwrap();

    let stats = core.get_statistics();

    assert_eq!(stats.total_generated, 16);
    assert!(stats.hermitian_operators <= stats.total_generated);
    assert!(stats.stable_operators <= stats.total_generated);
    assert!(stats.convergence_rate >= 0.0 && stats.convergence_rate <= 1.0);
}

#[test]
fn test_mining_reset() {
    let mut config = MiningConfig::default();
    config.iterations = 10;
    config.alpha_samples = 2;
    config.beta_samples = 5;

    let mut core = KNOMiningCore::new(config);
    core.mine().unwrap();

    assert!(!core.operators.is_empty());
    assert!(core.current_iteration > 0);

    core.reset();

    assert!(core.operators.is_empty());
    assert_eq!(core.current_iteration, 0);
    assert_eq!(core.statistics.total_generated, 0);
}

#[test]
fn test_spectrum_symmetry() {
    let operator = KNOOperator::new(vec![14.134725, 21.022040], 1.0);

    // Spectrum should be symmetric: λ_n and λ_{-n} have same magnitude
    let eigenvalues = operator.eigenvalues();

    for &lambda in eigenvalues {
        assert!((lambda.abs() - 1.0).abs() < SPECTRAL_TOLERANCE);
    }
}

#[test]
fn test_phase_field_evolution() {
    let mut operator = KNOOperator::new(vec![14.134725], 1.0);
    let primes = vec![2, 3, 5, 7, 11, 13];

    let initial_phi = operator.phase_field.phi;

    operator.evolve(0.1, &primes);

    // Phase should change
    assert_ne!(operator.phase_field.phi, initial_phi);
}

#[test]
fn test_polynomial_potential_evaluation() {
    let zeros = vec![14.134725, 21.022040];
    let potential = PolynomialPotential::from_riemann_zeros(zeros.clone(), 1.0);

    // Evaluate at different points
    let v0 = potential.evaluate(0.0);
    let v1 = potential.evaluate(14.134725);
    let v2 = potential.evaluate(21.022040);

    assert!(v0.is_finite());
    assert!(v1.is_finite());
    assert!(v2.is_finite());
}

#[test]
fn test_potential_gradient() {
    let zeros = vec![15.0];
    let potential = PolynomialPotential::from_riemann_zeros(zeros, 1.0);

    let grad_at_15 = potential.gradient(15.0);

    // Should be near zero at the critical point (mean of zeros)
    println!("Gradient at 15.0: {:.2e}", grad_at_15);
    assert!(grad_at_15.abs() < 0.5); // Allow some tolerance
}

#[test]
fn test_potential_second_derivative() {
    let zeros = vec![10.0, 20.0];
    let potential = PolynomialPotential::from_riemann_zeros(zeros, 1.0);

    let v_pp = potential.second_derivative(15.0);

    // Should be positive (stable minimum)
    assert!(v_pp > 0.0);
}

#[test]
fn test_complex_arithmetic() {
    let a = Complex::new(1.0, 2.0);
    let b = Complex::new(3.0, 4.0);

    let sum = a.add(&b);
    assert_eq!(sum.re, 4.0);
    assert_eq!(sum.im, 6.0);

    let product = a.mul(&b);
    assert!((product.re - (-5.0)).abs() < 1e-10);
    assert!((product.im - 10.0).abs() < 1e-10);
}

#[test]
fn test_complex_magnitude() {
    let c = Complex::new(3.0, 4.0);
    let mag = c.magnitude();

    assert!((mag - 5.0).abs() < 1e-10);
}

#[test]
fn test_complex_phase() {
    let c = Complex::new(1.0, 1.0);
    let phase = c.phase();

    assert!((phase - std::f64::consts::PI / 4.0).abs() < 1e-10);
}

#[test]
fn test_operator_apply() {
    let operator = KNOOperator::new(vec![14.134725], 1.0);
    let psi = Complex::new(1.0, 0.0);
    let dpsi_dt = Complex::new(0.0, 0.1);

    let result = operator.apply(&psi, &dpsi_dt, 0.5);

    assert!(result.magnitude() > 0.0);
    assert!(result.magnitude().is_finite());
}

#[test]
fn test_mining_with_custom_riemann_zeros() {
    let custom_zeros = vec![14.134725, 21.022040, 25.010858, 30.424876];
    let mut config = MiningConfig::default();
    config.iterations = 12;
    config.alpha_samples = 3;
    config.beta_samples = 4;
    config.riemann_zeros = custom_zeros.clone();

    let mut core = KNOMiningCore::new(config);
    let operators = core.mine().unwrap();

    assert_eq!(operators.len(), 12);

    // All operators should use the custom zeros
    for op in operators {
        assert_eq!(op.potential.riemann_zeros, custom_zeros);
    }
}

#[test]
fn test_energy_drift_bound() {
    let mut operator = KNOOperator::new(vec![14.134725, 21.022040], 1.0);
    let primes = vec![2, 3, 5, 7, 11, 13, 17, 19];

    operator.evolve(0.01, &primes);
    let initial_energy = operator.energy;

    // Evolve for many steps
    for _ in 0..100 {
        operator.evolve(0.001, &primes); // Smaller timestep
    }

    let energy_drift = (operator.energy - initial_energy).abs();

    println!("Energy drift after 100 steps: {:.2e}", energy_drift);

    // Energy drift should be bounded (numerical integration error)
    assert!(energy_drift < 10.0); // Reasonable bound
}

#[test]
fn test_hermiticity_violation_detection() {
    let hermitian_op = KNOOperator::from_parameters(1.0, 1.0, vec![14.134725]);
    let non_hermitian_op = KNOOperator::from_parameters(1.0, 0.5, vec![14.134725]);

    assert_eq!(hermitian_op.delta_phi, 0.0);
    assert!(hermitian_op.is_hermitian());

    assert_ne!(non_hermitian_op.delta_phi, 0.0);
    assert!(!non_hermitian_op.is_hermitian());
}

#[test]
fn test_operator_throughput() {
    let mut config = MiningConfig::default();
    config.iterations = 1000;
    config.alpha_samples = 10;
    config.beta_samples = 10;

    let start = std::time::Instant::now();
    let mut core = KNOMiningCore::new(config);
    core.mine().unwrap();
    let elapsed = start.elapsed();

    let throughput = 1000.0 / elapsed.as_secs_f64();

    println!("Operator mining throughput: {:.2} ops/sec", throughput);

    // Should achieve at least 100 operators per second (very conservative)
    assert!(throughput >= 100.0);
}
