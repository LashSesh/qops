//! Pipeline processing modes for the unified system

pub mod sequential;

pub use sequential::SequentialPipeline;
