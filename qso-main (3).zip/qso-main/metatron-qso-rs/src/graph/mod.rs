//! Graph representations related to the Metatron Cube.

pub mod metatron;
