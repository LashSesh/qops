"""Allow scs to be run as a module: python -m scs"""

from .cli import main

if __name__ == "__main__":
    main()
